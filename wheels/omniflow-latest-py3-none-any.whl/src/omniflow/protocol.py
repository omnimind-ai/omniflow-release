"""
OmniFlow 协议定义

三层分离:
- Host: 设备层 (observe/act)
- OmniFlow: 缓存层 (plan/step/run)
- Agent: 决策层 (plan fallback)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Protocol, runtime_checkable

if TYPE_CHECKING:
    from src.utg.assets.embedding.vector_set import PageVectorSet

# =============================================================================
# 数据结构
# =============================================================================


@dataclass
class Observation:
    """设备观测结果。

    `xml` 保留为旧调用链直接传原始 UI 树时的兼容字段；
    `vector_set` 是当前编译/匹配主链优先使用的结构化表示。
    """

    xml: Optional[str] = None
    vector_set: Optional["PageVectorSet"] = None
    package_name: Optional[str] = None
    activity_name: Optional[str] = None
    image_base64: Optional[str] = None  # Renamed from screenshot_base64 for consistency
    ui_elements: Optional[List[Any]] = None
    raw_state: Any = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def screenshot_base64(self) -> Optional[str]:
        """Deprecated alias for image_base64"""
        return self.image_base64


@dataclass
class Action:
    """执行动作"""

    type: str
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"type": self.type, "params": self.params}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Action":
        return cls(
            type=data.get("type", "unknown"),
            params=data.get("params", {}),
        )


@dataclass
class ActionResult:
    """动作执行结果"""

    success: bool
    error: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PlanResult:
    """plan() 返回结果"""

    hit: bool = False
    actions: List[Action] = field(default_factory=list)
    function_id: Optional[str] = None
    decision: str = "miss"  # compile decision string, default miss
    source: str = "cache"  # cache | agent | fallback
    arguments: Dict[str, str] = field(default_factory=dict)
    fallback: bool = False
    reason: Optional[str] = None


@dataclass
class StepResult:
    """step() 返回结果"""

    done: bool = False
    fallback: bool = False
    actions_executed: int = 0
    source: str = "cache"
    error: Optional[str] = None
    observation: Optional[Observation] = None


@dataclass
class RunResult:
    """run() 返回结果"""

    success: bool = False
    fallback: bool = False
    steps_executed: int = 0
    actions_executed: int = 0
    source: str = "cache"
    error_code: Optional[str] = None
    final_observation: Optional[Observation] = None


# =============================================================================
# Host 协议 (设备层)
# =============================================================================


@runtime_checkable
class Host(Protocol):
    """
    Host 协议 - 设备层接口

    由 AndroidWorld env / OOB bridge / ADB 等实现
    """

    def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """获取设备当前状态"""
        ...

    def act(self, action: Action | Dict[str, Any]) -> ActionResult:
        """执行动作到设备"""
        ...


# =============================================================================
# Agent 协议 (决策层, 可选)
# =============================================================================


@runtime_checkable
class Planner(Protocol):
    """
    Planner 协议 - 决策层接口 (可选, 用于 fallback)

    由 VLM/LLM Agent 实现
    """

    def plan(self, goal: str, observation: Observation) -> Action | List[Action]:
        """根据 goal 和 observation 决策下一步动作"""
        ...
