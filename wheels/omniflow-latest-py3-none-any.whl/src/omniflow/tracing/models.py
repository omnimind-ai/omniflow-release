"""
最简 Trace 数据模型

核心：goal + steps[]，每个 step = observation + action
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class TraceStep:
    """一个执行步骤 = observation (执行前) + action (要执行的)"""

    observation: Dict[str, Any] = field(default_factory=dict)  # xml, package_name
    action: Dict[str, Any] = field(default_factory=dict)  # type, params

    def to_dict(self) -> Dict[str, Any]:
        return {
            "observation": self.observation,
            "action": self.action,
        }


@dataclass
class Trace:
    """最简 Trace = goal + steps[]"""

    goal: str
    steps: List[TraceStep] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
        }

    def to_run_log(self) -> Dict[str, Any]:
        """转换为 canonical run log 格式（供 import 使用）"""
        canonical_steps = []
        for i, step in enumerate(self.steps):
            canonical_steps.append(
                {
                    "step_index": i,
                    "observation_before_act": {
                        "xml": step.observation.get("xml"),
                        "package_name": step.observation.get("package_name"),
                    },
                    "executed_actions": [step.action] if step.action else [],
                    "act_result": {"success": True},
                }
            )

        return {
            "goal": self.goal,
            "success": True,
            "steps": canonical_steps,
            "step_count": len(canonical_steps),
        }
