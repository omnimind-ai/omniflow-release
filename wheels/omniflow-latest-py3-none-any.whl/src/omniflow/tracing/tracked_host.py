"""
TrackedHost - Host I/O 层采集

包装任意 Host，自动记录 observe/act。
对上层 Agent 完全透明。
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from src.omniflow.protocol import Action, ActionResult, Host, Observation
from src.omniflow.tracing.models import Trace, TraceStep


class TrackedHost:
    """
    包装任意 Host，自动采集 observe() + act()

    用法:
        with TrackedHost(host, goal="打开设置") as tracked:
            obs = tracked.observe()  # 自动记录
            tracked.act(action)      # 自动记录
        # 退出时 tracked.trace 包含所有 steps
    """

    def __init__(self, host: Host, *, goal: str):
        self._host = host
        self._goal = goal
        self._current_obs: Optional[Dict[str, Any]] = None
        self._steps: list[TraceStep] = []

    @property
    def trace(self) -> Trace:
        """获取采集的 trace"""
        return Trace(goal=self._goal, steps=self._steps)

    def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """observe 并记录"""
        obs = self._host.observe(xml=xml, screenshot=screenshot, app_info=app_info)

        # 记录 observation（只保留核心字段）
        self._current_obs = {
            "xml": obs.xml,
            "package_name": obs.package_name,
        }

        return obs

    def act(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """act 并记录"""
        result = self._host.act(action)

        # 构建 action dict
        if isinstance(action, Action):
            action_dict = action.to_dict()
        elif isinstance(action, dict):
            action_dict = dict(action)
        else:
            action_dict = {}

        # 创建 step = observation + action
        step = TraceStep(
            observation=self._current_obs or {},
            action=action_dict,
        )
        self._steps.append(step)

        # 重置
        self._current_obs = None

        return result

    def __enter__(self) -> "TrackedHost":
        return self

    def __exit__(self, *args) -> None:
        pass
