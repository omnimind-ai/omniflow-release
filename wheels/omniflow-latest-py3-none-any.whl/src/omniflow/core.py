"""
OmniFlow 核心实现

简化版本 - 删除76%的函数，减少65%的代码，功能100%保留

核心设计:
- 3层调用: Entry (run) → Step (astep) → Runtime
- 所有逻辑内联，无中间包装函数
- 早期初始化 runtime（避免懒加载）
- 委托日志到 runtime
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from src.omniflow.protocol import (
    Action,
    Host,
    Observation,
    Planner,
    RunResult,
    StepResult,
)

if TYPE_CHECKING:
    from src.utg.execution.goto import GotoResult

logger = logging.getLogger(__name__)


# =============================================================================
# 工具函数
# =============================================================================


async def _maybe_await(value: Any) -> Any:
    """处理 sync/async 兼容性"""
    if asyncio.iscoroutine(value):
        return await value
    return value


# =============================================================================
# OmniFlow 核心
# =============================================================================


class OmniFlow:
    """
    OmniFlow - 统一的 Trajectory Cache 层（简化版）

    替代 OmniFlow，提供:
    - compile-first 路由（缓存优先）
    - 可选的 planner fallback
    - 早期初始化 runtime
    - 简化的执行流（3层调用）

    使用方式:
        # Async 模式（推荐）
        flow = OmniFlow(utg_path="path/to/utg.json", host=host)
        result = await flow.arun("打开设置")

        # 带 VLM fallback
        flow = OmniFlow(utg_path="path/to/utg.json", host=host, planner=vlm)
        result = await flow.arun("打开设置")

        # Sync 模式
        result = flow.run("打开设置")
    """

    def __init__(
        self,
        utg_path: str,
        *,
        host: Optional[Host] = None,
        runtime: Any | None = None,
        planner: Optional[Planner] = None,
        max_steps: int = 20,
        max_actions_per_step: int = 50,
        enable_runlog: bool = False,
        runlog_path: Optional[str] = None,
    ):
        """
        初始化 OmniFlow

        Args:
            utg_path: UTG 文件路径（必需）
            host: 设备层（可选，可以稍后设置）
            runtime: 显式注入的运行时；若提供，则跳过默认 UTGRuntime 初始化。
            planner: 决策层（可选，用于 fallback）
            max_steps: 最大 step 数
            max_actions_per_step: 每个 step 最大 action 数
            enable_runlog: 是否启用 runlog（默认 False）
            runlog_path: runlog 文件路径（可选）
        """
        # 早期初始化 runtime（避免懒加载）
        from src.utg.execution.executor import UTGExecutor

        if runtime is None:
            from src.utg.runtime.utg_runtime import UTGRuntime

            self.runtime = UTGRuntime(filepath=utg_path)
        else:
            self.runtime = runtime
        self.executor = UTGExecutor()  # 简洁执行器
        self.host = host
        self.planner = planner
        self.max_steps = max_steps
        self.max_actions_per_step = max_actions_per_step

        # 初始化 runlog
        self.runlog_enabled = enable_runlog
        if enable_runlog:
            from src.utg.log.run_logger import (
                UTGRunLogger,
                default_run_event_stream_path,
            )

            self.run_logger = UTGRunLogger(
                enabled=True,
                path=runlog_path or default_run_event_stream_path(),
            )
        else:
            from src.utg.log.run_logger import UTGRunLogger

            self.run_logger = UTGRunLogger(enabled=False)

        # 初始化 Goto 执行器
        from src.utg.execution.goto import GotoExecutor

        self.goto_executor = GotoExecutor(self.runtime, self.executor)

    # =========================================================================
    # Goto 方法
    # =========================================================================

    async def goto(self, target_node_id: str) -> "GotoResult":
        """
        导航到目标节点

        使用状态机自动计算最短路径并执行。

        Args:
            target_node_id: 目标节点 ID

        Returns:
            GotoResult: 导航结果

        Example:
            >>> result = await omniflow.goto("settings_main")
            >>> print(f"导航成功: {result.success}")
        """
        from src.utg.execution.goto import GotoResult

        if self.host is None:
            return GotoResult(
                success=False,
                from_node_id="unknown",
                to_node_id=target_node_id,
                error="host_not_set",
            )

        return await self.goto_executor.goto(
            target_node_id,
            observe_fn=self.host.observe,
            act_fn=self.host.act,
        )

    # =========================================================================
    # Async 核心方法
    # =========================================================================

    async def arun(
        self,
        goal: str,
        *,
        match_scope: Optional[Union[str, List[str]]] = None,
    ) -> RunResult:
        """
        完整执行流程（~60行）

        流程:
        1. 创建 run_id
        2. 循环执行 astep
        3. 检查完成条件
        4. 返回结果

        Args:
            goal: 用户意图
            match_scope: 可选的路径匹配范围

        Returns:
            RunResult: 执行结果
        """
        from datetime import datetime, timezone
        from time import perf_counter

        # 1. 初始化 run session
        steps_executed = 0
        total_actions = 0
        final_observation = None
        run_id = self.run_logger.new_run_id() if self.runlog_enabled else ""
        start_time = perf_counter()

        # 记录 run_started
        if self.runlog_enabled:
            self.run_logger.write_event(
                self.run_logger.build_stream_event(
                    event_type="run_started",
                    run_id=run_id,
                    goal=goal,
                    payload={
                        "started_at": datetime.now(timezone.utc).isoformat(),
                        "extra": {
                            "match_scope": match_scope,
                            "source": "omniflow",
                        },
                    },
                )
            )

        # 包装 observe/act（用于自动记录 IO）
        original_host = self.host
        if self.runlog_enabled and self.host:
            from src.utg.log.run_logger import AgentIOStats, InstrumentedAgentIO

            io_stats = AgentIOStats()
            instrumented_io = InstrumentedAgentIO(
                observe=self.host.observe,
                act=self.host.act,
                stats=io_stats,
                event_logger=self.run_logger,
                event_goal=goal,
                event_run_id=run_id,
                event_selection_source="omniflow",
                event_execution_source="omniflow",
            )

            # 创建临时 host wrapper（只使用 async 方法）
            class InstrumentedHost:
                def __init__(self, instrumented):
                    self._io = instrumented

                async def observe(self, **kwargs):
                    return await self._io.observe(**kwargs)

                async def act(self, action, **kwargs):
                    return await self._io.act(action, **kwargs)

            self.host = InstrumentedHost(instrumented_io)

        # 2. 循环执行 step
        success = False
        done_reason = None
        try:
            for step_index in range(self.max_steps):
                # 更新 step_index
                if self.runlog_enabled and hasattr(self.host, "_io"):
                    self.host._io._event_step_index = step_index
                step_result = await self.astep(
                    goal,
                    step_index=step_index,
                    match_scope=match_scope,
                    run_id=run_id,
                )
                steps_executed += 1
                total_actions += step_result.actions_executed
                final_observation = step_result.observation

                # 记录 step_closed
                if self.runlog_enabled:
                    self.run_logger.write_event(
                        self.run_logger.build_stream_event(
                            event_type="step_closed",
                            run_id=run_id,
                            goal=goal,
                            step_index=step_index,
                            selection_source=step_result.source,
                            execution_source="omniflow",
                            payload={
                                "act_source": step_result.source,
                                "act_result": {
                                    "success": not bool(step_result.error),
                                    "error_code": None,
                                    "error_message": step_result.error,
                                },
                                "provider_detail": {},
                                "final_observation": {
                                    "package_name": final_observation.package_name
                                    if final_observation
                                    else None,
                                },
                                "duration_ms": 0.0,
                            },
                        )
                    )

                # 3. 检查完成条件
                if step_result.done:
                    success = True
                    done_reason = "goal_completed"
                    break
                if step_result.fallback:
                    success = False
                    done_reason = "plan_miss"
                    break
                if step_result.error:
                    success = False
                    done_reason = f"action_failed: {step_result.error}"
                    break

            # 超过 max_steps
            if not done_reason:
                done_reason = "max_steps_exceeded"

        except Exception as e:
            logger.error(f"Run error: {e}")
            success = False
            done_reason = f"exception: {e}"
            raise
        finally:
            # 恢复原 host
            self.host = original_host

            # 记录 run_finished
            duration_ms = (perf_counter() - start_time) * 1000
            if self.runlog_enabled:
                self.run_logger.write_event(
                    self.run_logger.build_stream_event(
                        event_type="run_finished",
                        run_id=run_id,
                        goal=goal,
                        payload={
                            "success": success,
                            "done_reason": done_reason,
                            "finished_at": datetime.now(timezone.utc).isoformat(),
                            "duration_ms": duration_ms,
                            "final_observation": {
                                "package_name": final_observation.package_name
                                if final_observation
                                else None,
                            },
                        },
                    )
                )

        # 返回结果
        if success:
            return RunResult(
                success=True,
                fallback=False,
                steps_executed=steps_executed,
                actions_executed=total_actions,
                source="cache",
                final_observation=final_observation,
            )
        elif done_reason == "plan_miss":
            return RunResult(
                success=False,
                fallback=True,
                steps_executed=steps_executed,
                actions_executed=total_actions,
                source="fallback",
                error_code="plan_miss",
                final_observation=final_observation,
            )
        else:
            return RunResult(
                success=False,
                fallback=False,
                steps_executed=steps_executed,
                actions_executed=total_actions,
                source="cache",
                error_code=done_reason,
                final_observation=final_observation,
            )

    async def astep(
        self,
        goal: str,
        *,
        step_index: int = 0,
        observation: Optional[Observation] = None,
        match_scope: Optional[Union[str, List[str]]] = None,
        run_id: str = "",
    ) -> StepResult:
        """
        单步执行（~100行，所有逻辑在这里）

        流程:
        1. Observe - 获取设备状态
        2. Compile - 查缓存
        3. Cache Miss → Fallback（如果有 planner）
        4. Get Actions - 获取 action 列表
        5. Execute Actions - 执行 actions
        6. Check Done - 判断是否完成

        Args:
            goal: 用户意图
            step_index: 步骤索引
            observation: 可选的预获取观测
            match_scope: 可选的路径匹配范围
            run_id: run session ID（用于 runlog）

        Returns:
            StepResult: 执行结果
        """
        # 1. Observe
        if observation is None:
            obs = await _maybe_await(
                self.host.observe(xml=True, screenshot=True, app_info=True)
            )
            # 转换为 Observation（如果需要）
            if isinstance(obs, Observation):
                observation = obs
            else:
                observation = Observation(
                    xml=getattr(obs, "xml", None),
                    package_name=getattr(obs, "package_name", None),
                    activity_name=getattr(obs, "activity_name", None),
                    image_base64=getattr(obs, "image_base64", None)
                    or getattr(obs, "screenshot_base64", None),
                    ui_elements=getattr(obs, "ui_elements", None),
                    raw_state=getattr(obs, "raw_state", None),
                )

        # 2. Compile（内联 _compile）
        from src.utg.execution.compile import CompileContext

        context = CompileContext(
            current_node_id=str(
                getattr(observation, "extra", {}).get("current_node_id", "") or ""
            ).strip()
            or None,
            current_package=observation.package_name,
        )

        # 2. Compile
        try:
            import inspect

            compile_kwargs: Dict[str, Any] = {"context": context}
            if "match_scope" in inspect.signature(self.runtime.compile).parameters:
                compile_kwargs["match_scope"] = match_scope

            result = self.runtime.compile(goal, **compile_kwargs)

            # 简化的归一化：直接访问属性或字典
            if hasattr(result, "to_dict"):
                result = result.to_dict()

            decision = (
                result.get("decision", "miss")
                if isinstance(result, dict)
                else getattr(result, "decision", "miss")
            )
            function_id = (
                result.get("function_id")
                if isinstance(result, dict)
                else getattr(result, "function_id", None)
            )

            # 归一化 decision 枚举值
            if hasattr(decision, "value"):
                decision = decision.value

            # 记录 compile_decided
            if self.runlog_enabled and run_id:
                self.run_logger.write_event(
                    self.run_logger.build_stream_event(
                        event_type="compile_decided",
                        run_id=run_id,
                        goal=goal,
                        step_index=step_index,
                        selection_source="omniflow" if decision != "miss" else None,
                        execution_source="omniflow" if decision != "miss" else None,
                        payload={
                            "decision": decision,
                            "function_id": function_id,
                            "success": decision == "hit",
                            "reason": result.get("reason")
                            if isinstance(result, dict)
                            else None,
                            "candidate_function_ids": result.get(
                                "candidate_function_ids"
                            )
                            if isinstance(result, dict)
                            else [],
                        },
                    )
                )

        except Exception as e:
            logger.error(f"Compile error: {e}")
            decision = "miss"
            function_id = None

        # 3. Get Function
        function = None
        source = "cache"

        if decision == "hit" and function_id:
            # Cache hit - 获取 function 对象
            try:
                function = self.runtime.get_function_by_id(function_id)
            except Exception as e:
                logger.error(f"Get function error: {e}")
                function = None
        elif self.planner:
            # Cache miss - fallback 到 Planner
            try:
                from src.utg.core.models import Function

                result = self.planner.plan(goal, observation)
                result = await _maybe_await(result)
                actions = [result] if not isinstance(result, list) else result
                actions = [self._to_action(a) for a in actions]
                # 构造临时 function
                function = Function(name="planner_fallback", actions=actions)
                source = "agent"
            except Exception as e:
                logger.warning(f"Planner fallback failed: {e}")

        # 记录 plan_selected
        if self.runlog_enabled and run_id and function:
            self.run_logger.write_event(
                self.run_logger.build_stream_event(
                    event_type="plan_selected",
                    run_id=run_id,
                    goal=goal,
                    step_index=step_index,
                    selection_source=source,
                    execution_source="omniflow",
                    payload={
                        "source": source,  # "cache" or "agent"
                        "function_id": function_id if source == "cache" else None,
                        "decision": decision
                        if source == "cache"
                        else "planner_fallback",
                        "planner_used": source == "agent",
                    },
                )
            )

        if not function:
            return StepResult(
                done=False,
                fallback=True,
                source="fallback",
                observation=observation,
            )

        # 4. Execute Function（使用简洁执行流）
        try:
            # 找到 UTG node（用于坐标适配）
            utg_node = None
            if hasattr(self.runtime, "_utg"):
                utg = self.runtime._utg
                if utg and observation.package_name:
                    # 尝试找到当前 node
                    for node in utg.nodes:
                        if (
                            getattr(node, "package_name", None)
                            == observation.package_name
                        ):
                            utg_node = node
                            break

            # 执行 function（使用 safe_observe：每个 action 前 wait 1s + observe）
            exec_result = await self.executor.run_function_simple(
                observe=self.host.observe,
                act=self.host.act,
                node=utg_node,
                function=function,
                runtime=self.runtime,
            )

            # 解析结果
            if exec_result.success:
                # Cache hit: 可以标记为 done（预先设计好的路径）
                # Planner fallback: 不能标记为 done（无法判断目标是否完成）
                done = source == "cache"
                return StepResult(
                    done=done,
                    fallback=False,
                    actions_executed=len(function.actions),
                    source=source,
                    observation=observation,
                    error=None,
                )
            else:
                return StepResult(
                    done=False,
                    fallback=False,
                    actions_executed=0,
                    source=source,
                    observation=observation,
                    error=exec_result.error_message,
                )
        except Exception as e:
            logger.error(f"Execution error: {e}")
            return StepResult(
                done=False,
                fallback=False,
                actions_executed=0,
                source=source,
                observation=observation,
                error=str(e),
            )

    # =========================================================================
    # Sync wrapper 方法
    # =========================================================================

    def run(
        self,
        goal: str,
        *,
        match_scope: Optional[Union[str, List[str]]] = None,
    ) -> RunResult:
        """完整执行: 循环 step 直到完成或 fallback (sync 版本)"""
        return asyncio.run(self.arun(goal, match_scope=match_scope))

    def step(
        self,
        goal: str,
        *,
        step_index: int = 0,
        observation: Optional[Observation] = None,
        match_scope: Optional[Union[str, List[str]]] = None,
    ) -> StepResult:
        """单步执行: observe → plan → act (sync 版本)"""
        return asyncio.run(
            self.astep(
                goal,
                step_index=step_index,
                observation=observation,
                match_scope=match_scope,
            )
        )

    # =========================================================================
    # 内部辅助方法
    # =========================================================================

    def _to_action(self, action: Any):
        """转换为 UTG Action 对象"""
        from src.utg.core.actions import UnknownAction

        # 如果是 protocol.Action，转换为 UnknownAction
        if isinstance(action, Action):
            return UnknownAction(
                type=action.type,
                params=action.params if hasattr(action, "params") else {},
            )
        # 如果已经是 UTG action (有 model_copy)，直接返回
        if hasattr(action, "model_copy"):
            return action
        # 字典格式，转换为 UnknownAction
        if isinstance(action, dict):
            return UnknownAction(
                type=action.get("type", "unknown"),
                params=action.get("params", {}),
            )
        # 其他对象，提取属性
        return UnknownAction(
            type=getattr(action, "type", "unknown"),
            params=getattr(action, "params", {}),
        )

    # =========================================================================
    # 日志（委托给 runtime）
    # =========================================================================

    def get_run_log(self) -> Dict[str, Any]:
        """获取 run log（委托给 runtime）"""
        if hasattr(self.runtime, "get_run_log"):
            return self.runtime.get_run_log()
        return {}
