"""
OmniFlow Unified Configuration Management

Provides centralized configuration with:
- Pydantic validation
- Environment variable overrides (OMNIFLOW_ prefix)
- Sensible defaults
- Type safety

Usage:
    from src.omniflow.config import omniflow_config

    # Access config values
    timeout = omniflow_config.execution.post_action_wait_seconds
    similarity = omniflow_config.matching.similarity_threshold
"""

from __future__ import annotations

from functools import lru_cache
import os
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

# =============================================================================
# Execution Configuration
# =============================================================================


class ExecutionConfig(BaseModel):
    """Execution layer configuration."""

    # Timing
    post_action_wait_seconds: float = Field(
        default=1.0,
        ge=0.0,
        description="Wait time after each action execution",
    )
    open_app_foreground_timeout_s: float = Field(
        default=2.5,
        ge=0.0,
        description="Timeout for waiting app to come to foreground",
    )
    open_app_foreground_poll_interval_s: float = Field(
        default=0.0,
        ge=0.0,
        description="Poll interval when waiting for app foreground",
    )
    local_stable_poll_interval_s: float = Field(
        default=0.10,
        ge=0.0,
        description="Poll interval for local stabilization checks",
    )
    unified_poll_timeout_s: float = Field(
        default=0.6,
        ge=0.0,
        description="Unified poll timeout for state changes",
    )

    # Limits
    max_steps: int = Field(
        default=20,
        ge=1,
        description="Maximum execution steps per run",
    )
    max_actions_per_step: int = Field(
        default=50,
        ge=1,
        description="Maximum actions per execution step",
    )
    max_retry_count: int = Field(
        default=3,
        ge=0,
        description="Maximum retry attempts for failed actions",
    )

    # Cache TTLs
    observe_cache_ttl_s: float = Field(
        default=2.0,
        ge=0.0,
        description="TTL for observation cache entries",
    )
    compile_cache_ttl_s: float = Field(
        default=300.0,
        ge=0.0,
        description="TTL for compile result cache entries",
    )
    action_cache_ttl_s: float = Field(
        default=30.0,
        ge=0.0,
        description="TTL for action result cache entries",
    )


# =============================================================================
# Matching Configuration
# =============================================================================


class MatchingConfig(BaseModel):
    """Node and page matching configuration."""

    # Similarity thresholds
    similarity_threshold: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Minimum similarity score for node matching",
    )
    exact_match_threshold: float = Field(
        default=0.99,
        ge=0.0,
        le=1.0,
        description="Threshold for exact text matching",
    )

    # Scoring weights
    text_weight: float = Field(default=0.42, ge=0.0, le=1.0)
    geometry_weight: float = Field(default=0.16, ge=0.0, le=1.0)
    state_weight: float = Field(default=0.24, ge=0.0, le=1.0)
    structure_weight: float = Field(default=0.18, ge=0.0, le=1.0)

    # Bonus factors
    verb_match_bonus: float = Field(
        default=0.15,
        ge=0.0,
        description="Bonus for matching action verbs",
    )
    locality_match_bonus: float = Field(
        default=0.10,
        ge=0.0,
        description="Bonus for matching start node locality",
    )
    locality_mismatch_penalty: float = Field(
        default=0.02,
        ge=0.0,
        description="Penalty for mismatched start node",
    )
    recent_path_bonus: float = Field(
        default=0.05,
        ge=0.0,
        description="Bonus for recently used paths",
    )

    # Geometry bins
    geometry_area_bins: List[float] = Field(
        default_factory=lambda: [0.01, 0.05, 0.18],
        description="Area thresholds for geometry binning",
    )
    geometry_aspect_cap: float = Field(
        default=6.0,
        ge=1.0,
        description="Maximum aspect ratio for geometry",
    )

    @field_validator("geometry_area_bins")
    @classmethod
    def validate_bins_sorted(cls, v: List[float]) -> List[float]:
        if v != sorted(v):
            raise ValueError("geometry_area_bins must be sorted ascending")
        return v


# =============================================================================
# Compile Configuration
# =============================================================================


class CompileConfig(BaseModel):
    """Compile gate configuration."""

    top_k_candidates: int = Field(
        default=10,
        ge=1,
        description="Maximum candidates returned by compile recall",
    )
    hint_top_k: int = Field(
        default=5,
        ge=1,
        description="Maximum hints returned by compile",
    )


# =============================================================================
# Control Plane Configuration
# =============================================================================


class ControlPlaneConfig(BaseModel):
    """Control plane and trigger configuration."""

    # Scroll detection
    scroll_viewport_margin_ratio: float = Field(
        default=0.12,
        ge=0.0,
        le=0.5,
        description="Margin ratio for scroll viewport detection",
    )
    scroll_outer_margin_factor: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Outer margin factor for scroll detection",
    )
    scroll_minimum_margin_px: float = Field(
        default=48.0,
        ge=0.0,
        description="Minimum margin in pixels for scroll",
    )
    scroll_max_distance_px: float = Field(
        default=120.0,
        ge=0.0,
        description="Maximum scroll distance in pixels",
    )
    scroll_viewport_ratio: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Viewport ratio for scroll calculations",
    )

    # Trigger thresholds
    trigger_activation_threshold: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum score for trigger activation",
    )


# =============================================================================
# Logging Configuration
# =============================================================================


class LoggingConfig(BaseModel):
    """Logging and telemetry configuration."""

    level: str = Field(
        default="INFO",
        description="Log level (DEBUG, INFO, WARNING, ERROR)",
    )
    enable_telemetry: bool = Field(
        default=False,
        description="Enable telemetry collection",
    )
    log_actions: bool = Field(
        default=True,
        description="Log individual action executions",
    )
    log_observations: bool = Field(
        default=False,
        description="Log observation details (verbose)",
    )

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        v_upper = v.upper()
        if v_upper not in valid_levels:
            raise ValueError(f"level must be one of {valid_levels}")
        return v_upper


# =============================================================================
# Root Configuration
# =============================================================================


class OmniFlowConfig(BaseModel):
    """Root configuration container for OmniFlow."""

    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    matching: MatchingConfig = Field(default_factory=MatchingConfig)
    compile: CompileConfig = Field(default_factory=CompileConfig)
    control_plane: ControlPlaneConfig = Field(default_factory=ControlPlaneConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    model_config = {"extra": "ignore"}


# =============================================================================
# Configuration Loading
# =============================================================================


def _get_env_value(key: str) -> Optional[str]:
    """Get environment variable with OMNIFLOW_ prefix."""
    prefixed_key = f"OMNIFLOW_{key.upper()}"
    value = os.getenv(prefixed_key)
    if value is not None and value.strip():
        return value.strip()
    return None


def _parse_env_overrides() -> Dict[str, Any]:
    """Parse environment variable overrides for config."""
    overrides: Dict[str, Any] = {}

    # Execution overrides
    if v := _get_env_value("POST_ACTION_WAIT_SECONDS"):
        overrides.setdefault("execution", {})["post_action_wait_seconds"] = float(v)
    if v := _get_env_value("MAX_STEPS"):
        overrides.setdefault("execution", {})["max_steps"] = int(v)
    if v := _get_env_value("MAX_ACTIONS_PER_STEP"):
        overrides.setdefault("execution", {})["max_actions_per_step"] = int(v)

    # Matching overrides
    if v := _get_env_value("SIMILARITY_THRESHOLD"):
        overrides.setdefault("matching", {})["similarity_threshold"] = float(v)

    # Logging overrides
    if v := _get_env_value("LOG_LEVEL"):
        overrides.setdefault("logging", {})["level"] = v
    if v := _get_env_value("ENABLE_TELEMETRY"):
        overrides.setdefault("logging", {})["enable_telemetry"] = v.lower() in (
            "true",
            "1",
            "yes",
        )

    return overrides


@lru_cache(maxsize=1)
def load_config() -> OmniFlowConfig:
    """
    Load OmniFlow configuration with environment overrides.

    Priority (highest to lowest):
    1. Environment variables (OMNIFLOW_* prefix)
    2. Default values

    Returns:
        OmniFlowConfig instance
    """
    env_overrides = _parse_env_overrides()

    # Build nested config with overrides
    config_data: Dict[str, Any] = {}

    for section in ["execution", "matching", "compile", "control_plane", "logging"]:
        if section in env_overrides:
            config_data[section] = env_overrides[section]

    return OmniFlowConfig(**config_data)


def reload_config() -> OmniFlowConfig:
    """Force reload configuration (clears cache)."""
    load_config.cache_clear()
    return load_config()


# =============================================================================
# Module-level singleton
# =============================================================================


omniflow_config = load_config()


__all__ = [
    "OmniFlowConfig",
    "ExecutionConfig",
    "MatchingConfig",
    "CompileConfig",
    "ControlPlaneConfig",
    "LoggingConfig",
    "omniflow_config",
    "load_config",
    "reload_config",
]
