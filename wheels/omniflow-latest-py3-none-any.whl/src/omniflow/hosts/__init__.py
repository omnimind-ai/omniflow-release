"""
OmniFlow Host 适配器

支持:
- AndroidWorld: AndroidWorldHost
- OOB HTTP Bridge: HTTPBridgeHost (同步) / AsyncHTTPBridgeHost (异步)
- Web (Playwright): AsyncWebHost (异步)
"""

from src.omniflow.hosts.android_world import AndroidWorldHost
from src.omniflow.hosts.http_bridge import AsyncHTTPBridgeHost, HTTPBridgeHost
from src.omniflow.hosts.web_host import AsyncWebHost

__all__ = [
    "AndroidWorldHost",
    "HTTPBridgeHost",
    "AsyncHTTPBridgeHost",
    "AsyncWebHost",
]
