"""
AndroidWorld Host 适配器

将 AndroidWorld env 适配为 OmniFlow Host 协议
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Union

from src.omniflow.protocol import Action, ActionResult, Host, Observation

logger = logging.getLogger(__name__)


class AndroidWorldHost(Host):
    """
    AndroidWorld Host 适配器

    将 AndroidWorld env 的接口适配为 OmniFlow Host 协议:
    - observe() ← env.get_state() + XML 转换
    - act() → env.execute_action()

    使用方式:
        from android_world.env import AndroidWorldEnv
        env = AndroidWorldEnv(...)
        host = AndroidWorldHost(env)
        omniflow = OmniFlow(host)
    """

    def __init__(
        self,
        env: Any,
        *,
        adb_serial: str = "",
    ):
        """
        初始化 AndroidWorld Host

        Args:
            env: AndroidWorld 环境实例
            adb_serial: ADB 设备序列号 (可选)
        """
        self.env = env
        self.adb_serial = adb_serial

    def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """
        获取 AndroidWorld 当前页面状态

        Args:
            xml: 是否获取 XML
            screenshot: 是否获取截图
            app_info: 是否获取 app 信息

        Returns:
            Observation: 统一的观测结果
        """
        from src.integrations.android_world.host import (
            capture_current_page,
            capture_xml,
            page_pixels_to_image_data_url,
        )

        # 获取页面快照
        page = capture_current_page(
            env=self.env,
            adb_serial=self.adb_serial,
        )

        # 提取 XML
        xml_text = None
        if xml:
            xml_text = capture_xml(env=self.env, page=page)

        # 提取截图
        image_base64 = None
        if screenshot:
            image_base64 = page_pixels_to_image_data_url(page)

        # 提取 app 信息
        package_name = None
        activity_name = None
        if app_info:
            package_name = str(getattr(page, "package_name", "") or "").strip() or None
            activity_name = (
                str(getattr(page, "activity_name", "") or "").strip() or None
            )

        return Observation(
            xml=xml_text,
            package_name=package_name,
            activity_name=activity_name,
            image_base64=image_base64,
            ui_elements=list(getattr(page, "ui_elements", []) or []),
            raw_state=page,
        )

    def act(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """
        执行动作到 AndroidWorld 设备

        Args:
            action: OmniFlow Action 或字典格式

        Returns:
            ActionResult: 执行结果
        """
        from src.integrations.android_world.host import (
            coerce_android_world_action_for_execution,
            import_json_action_module,
            utg_action_to_android_world_action,
        )

        # 转换为字典格式
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)

        try:
            # 转换为 AndroidWorld 格式
            json_action_module = import_json_action_module()
            aw_action = utg_action_to_android_world_action(
                action_dict,
                json_action_module=json_action_module,
            )
            aw_action = coerce_android_world_action_for_execution(
                aw_action,
                json_action_module=json_action_module,
            )

            # 执行
            if aw_action is not None:
                self.env.execute_action(aw_action)

            return ActionResult(success=True)

        except Exception as e:
            logger.error(f"AndroidWorld action execution failed: {e}")
            return ActionResult(success=False, error=str(e))
