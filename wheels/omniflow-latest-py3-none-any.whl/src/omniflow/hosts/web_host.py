"""
Web Host 适配器

将 Playwright browser 适配为 OmniFlow Host 协议，实现跨平台泛化
"""

from __future__ import annotations

import base64
import logging
from typing import Any, Dict, Union

from src.omniflow.protocol import Action, ActionResult, Host, Observation

logger = logging.getLogger(__name__)


class WebHost(Host):
    """
    Web Host 适配器

    将 Playwright Page 接口适配为 OmniFlow Host 协议:
    - observe() ← page.content() + DOM 转换为 XML
    - act() → page.click() / page.fill() / page.mouse.wheel()

    使用方式:
        from playwright.async_api import async_playwright

        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.goto("https://example.com")

            host = WebHost(page)
            omniflow = OmniFlow(host)
            result = await omniflow.arun("Click login button")
    """

    def __init__(
        self,
        page: Any,
        *,
        viewport_width: int = 1920,
        viewport_height: int = 1080,
        wait_after_action: int = 500,  # ms
    ):
        """
        初始化 Web Host

        Args:
            page: Playwright Page 实例
            viewport_width: 浏览器视口宽度（论文需要固定）
            viewport_height: 浏览器视口高度
            wait_after_action: 动作执行后等待时间（ms）
        """
        self.page = page
        self.viewport_width = viewport_width
        self.viewport_height = viewport_height
        self.wait_after_action = wait_after_action

        # 确保视口大小一致（论文实验需要）
        self._ensure_viewport()

    def _ensure_viewport(self):
        """确保视口大小一致"""
        try:
            # 同步设置视口（Playwright 自动处理 async）
            # 注意：这里假设 page 是 async，实际使用时需要 await
            pass  # 实际实现在 async 版本
        except Exception as e:
            logger.warning(f"Failed to set viewport: {e}")

    def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """
        获取 Web 页面当前状态

        Args:
            xml: 是否获取 DOM XML（转换为 Android 格式）
            screenshot: 是否获取截图
            app_info: 是否获取页面信息（URL, title）

        Returns:
            Observation: 统一的观测结果
        """
        # 导入 DOM parser（稍后实现）
        from src.utg.assets.embedding.dom_parser import dom_to_xml

        # 获取 DOM XML
        xml_text = None
        if xml:
            try:
                # 获取 DOM 内容（这里需要同步包装）
                # 实际使用时需要 async 版本
                html = self._get_page_content()
                xml_text = dom_to_xml(
                    html=html,
                    page=self.page,
                    viewport_width=self.viewport_width,
                    viewport_height=self.viewport_height,
                )
            except Exception as e:
                logger.error(f"Failed to extract DOM XML: {e}")
                xml_text = None

        # 获取截图
        image_base64 = None
        if screenshot:
            try:
                screenshot_bytes = self._take_screenshot()
                image_base64 = f"data:image/png;base64,{base64.b64encode(screenshot_bytes).decode()}"
            except Exception as e:
                logger.error(f"Failed to capture screenshot: {e}")

        # 获取页面信息
        package_name = None  # Web 上用 domain
        activity_name = None  # Web 上用 URL path
        if app_info:
            try:
                url = self._get_url()
                from urllib.parse import urlparse

                parsed = urlparse(url)
                package_name = parsed.netloc  # e.g., "amazon.com"
                activity_name = parsed.path or "/"  # e.g., "/products/123"
            except Exception as e:
                logger.error(f"Failed to extract app info: {e}")

        return Observation(
            xml=xml_text,
            package_name=package_name,
            activity_name=activity_name,
            image_base64=image_base64,
            ui_elements=None,  # 暂时不提取（可选）
            raw_state=None,
            extra={
                "url": self._get_url(),
                "title": self._get_title(),
            },
        )

    def act(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """
        执行动作到 Web 浏览器

        Args:
            action: OmniFlow Action 或字典格式

        Returns:
            ActionResult: 执行结果
        """
        # 转换为字典格式
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)

        action_type = action_dict.get("type", "")
        params = action_dict.get("params", {})

        try:
            # 根据动作类型分发
            if action_type == "click":
                self._execute_click(params)
            elif action_type == "input_text":
                self._execute_input(params)
            elif action_type == "scroll":
                self._execute_scroll(params)
            elif action_type == "navigate":
                self._execute_navigate(params)
            elif action_type == "press_key":
                self._execute_key(params)
            elif action_type == "wait":
                self._execute_wait(params)
            else:
                logger.warning(f"Unknown action type: {action_type}")
                return ActionResult(
                    success=False, error=f"Unknown action: {action_type}"
                )

            # 等待页面稳定
            if self.wait_after_action > 0:
                self._wait(self.wait_after_action)

            return ActionResult(success=True)

        except Exception as e:
            logger.error(f"Web action execution failed: {e}")
            return ActionResult(success=False, error=str(e))

    # =========================================================================
    # 内部辅助方法（同步包装，实际使用时需要 async 版本）
    # =========================================================================

    def _get_page_content(self) -> str:
        """获取页面 HTML 内容（需要 async 包装）"""
        # 这里是同步占位，实际需要：await self.page.content()
        raise NotImplementedError("Use async version: await page.content()")

    def _take_screenshot(self) -> bytes:
        """截图（需要 async 包装）"""
        # 实际需要：await self.page.screenshot()
        raise NotImplementedError("Use async version: await page.screenshot()")

    def _get_url(self) -> str:
        """获取当前 URL"""
        try:
            return self.page.url
        except AttributeError:
            return ""

    def _get_title(self) -> str:
        """获取页面标题（需要 async 包装）"""
        # 实际需要：await self.page.title()
        try:
            return ""  # 占位
        except AttributeError:
            return ""

    def _execute_click(self, params: Dict[str, Any]):
        """执行点击"""
        x = params.get("x")
        y = params.get("y")

        if x is None or y is None:
            raise ValueError("Click action requires x and y coordinates")

        # 实际需要：await self.page.mouse.click(x, y)
        raise NotImplementedError("Use async version")

    def _execute_input(self, params: Dict[str, Any]):
        """执行输入"""
        params.get("text", "")

        # 方案1：输入到当前焦点元素
        # 实际需要：await self.page.keyboard.type(text)

        # 方案2：如果有 selector，输入到指定元素
        # selector = params.get("selector")
        # await self.page.fill(selector, text)

        raise NotImplementedError("Use async version")

    def _execute_scroll(self, params: Dict[str, Any]):
        """执行滚动"""
        direction = params.get("direction", "down")
        params.get("delta", 500)  # 滚动距离

        if direction == "up":
            pass
        elif direction == "down":
            pass
        elif direction == "left":
            pass
        elif direction == "right":
            pass

        # 实际需要：await self.page.mouse.wheel(delta_x, delta_y)
        raise NotImplementedError("Use async version")

    def _execute_navigate(self, params: Dict[str, Any]):
        """执行导航"""
        url = params.get("url")

        if not url:
            raise ValueError("Navigate action requires url")

        # 实际需要：await self.page.goto(url)
        raise NotImplementedError("Use async version")

    def _execute_key(self, params: Dict[str, Any]):
        """执行按键"""
        key = params.get("key", "")

        # 映射到 Playwright 按键名
        key_map = {
            "enter": "Enter",
            "back": "Escape",  # Web 上用 Escape 代替
            "home": "Home",
        }

        key_map.get(key.lower(), key)

        # 实际需要：await self.page.keyboard.press(playwright_key)
        raise NotImplementedError("Use async version")

    def _execute_wait(self, params: Dict[str, Any]):
        """执行等待"""
        params.get("seconds", 1.0)

        # 实际需要：await self.page.wait_for_timeout(seconds * 1000)
        raise NotImplementedError("Use async version")

    def _wait(self, milliseconds: int):
        """内部等待"""
        # 实际需要：await self.page.wait_for_timeout(milliseconds)
        raise NotImplementedError("Use async version")


# =============================================================================
# Async 版本（推荐使用）
# =============================================================================


class AsyncWebHost(Host):
    """
    Async Web Host 适配器（推荐）

    使用方式:
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            host = AsyncWebHost(page)

            # 使用 async 方法
            obs = await host.aobserve()
            result = await host.aact(Action(type="click", params={"x": 100, "y": 200}))
    """

    def __init__(
        self,
        page: Any,
        *,
        viewport_width: int = 1920,
        viewport_height: int = 1080,
        wait_after_action: int = 500,
    ):
        self.page = page
        self.viewport_width = viewport_width
        self.viewport_height = viewport_height
        self.wait_after_action = wait_after_action

    async def aobserve(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """异步获取页面状态"""
        from src.utg.assets.embedding.dom_parser import dom_to_xml

        # 获取 DOM XML
        xml_text = None
        if xml:
            try:
                html = await self.page.content()
                xml_text = await dom_to_xml(
                    html=html,
                    page=self.page,
                    viewport_width=self.viewport_width,
                    viewport_height=self.viewport_height,
                )
            except Exception as e:
                logger.error(f"Failed to extract DOM XML: {e}")

        # 获取截图
        image_base64 = None
        if screenshot:
            try:
                screenshot_bytes = await self.page.screenshot()
                image_base64 = f"data:image/png;base64,{base64.b64encode(screenshot_bytes).decode()}"
            except Exception as e:
                logger.error(f"Failed to capture screenshot: {e}")

        # 获取页面信息
        package_name = None
        activity_name = None
        if app_info:
            try:
                url = self.page.url
                from urllib.parse import urlparse

                parsed = urlparse(url)
                package_name = parsed.netloc
                activity_name = parsed.path or "/"
            except Exception as e:
                logger.error(f"Failed to extract app info: {e}")

        return Observation(
            xml=xml_text,
            package_name=package_name,
            activity_name=activity_name,
            image_base64=image_base64,
            extra={
                "url": self.page.url,
                "title": await self.page.title(),
            },
        )

    async def aact(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """异步执行动作"""
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)

        action_type = action_dict.get("type", "")
        params = action_dict.get("params", {})

        try:
            if action_type == "click":
                x, y = params["x"], params["y"]
                await self.page.mouse.click(x, y)

            elif action_type == "input_text":
                text = params.get("text", "")
                await self.page.keyboard.type(text)

            elif action_type == "scroll":
                direction = params.get("direction", "down")
                delta = params.get("delta", 500)

                delta_x = 0
                delta_y = (
                    delta if direction == "down" else -delta if direction == "up" else 0
                )
                await self.page.mouse.wheel(delta_x, delta_y)

            elif action_type == "navigate":
                url = params["url"]
                await self.page.goto(url)

            elif action_type == "press_key":
                key = params.get("key", "")
                key_map = {"enter": "Enter", "back": "Escape", "home": "Home"}
                await self.page.keyboard.press(key_map.get(key.lower(), key))

            elif action_type == "wait":
                seconds = params.get("seconds", 1.0)
                await self.page.wait_for_timeout(int(seconds * 1000))

            else:
                return ActionResult(
                    success=False, error=f"Unknown action: {action_type}"
                )

            # 等待稳定
            if self.wait_after_action > 0:
                await self.page.wait_for_timeout(self.wait_after_action)

            return ActionResult(success=True)

        except Exception as e:
            logger.error(f"Web action failed: {e}")
            return ActionResult(success=False, error=str(e))

    # 同步接口（为了兼容 Host Protocol）
    def observe(self, **kwargs) -> Observation:
        """同步版本占位（不推荐使用）"""
        raise NotImplementedError("Use async version: await host.aobserve()")

    def act(self, action) -> ActionResult:
        """同步版本占位（不推荐使用）"""
        raise NotImplementedError("Use async version: await host.aact()")
