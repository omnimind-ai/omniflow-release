"""
HTTP Bridge Host 适配器

将 OOB 等 HTTP bridge 适配为 OmniFlow Host 协议

支持两种模式:
1. 同步模式 (HTTPBridgeHost) - 用于简单场景
2. 异步模式 (AsyncHTTPBridgeHost) - 用于 utg_api.py 集成
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Union

import aiohttp
import requests

from src.omniflow.protocol import Action, ActionResult, Host, Observation

logger = logging.getLogger(__name__)


class HTTPBridgeHost(Host):
    """
    HTTP Bridge Host 适配器

    将 HTTP bridge (如 OOB) 的接口适配为 OmniFlow Host 协议:
    - observe() → POST /utg/observe
    - act() → POST /utg/act

    使用方式:
        host = HTTPBridgeHost(
            base_url="http://127.0.0.1:8899/utg",
            token="bearer-token"
        )
        omniflow = OmniFlow(host)
    """

    def __init__(
        self,
        base_url: str,
        *,
        token: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        初始化 HTTP Bridge Host

        Args:
            base_url: Bridge 基础 URL (如 http://127.0.0.1:8899/utg)
            token: Bearer token (可选)
            timeout: 请求超时时间
        """
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _headers(self) -> Dict[str, str]:
        """构建请求头"""
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """
        通过 HTTP bridge 获取设备状态

        Args:
            xml: 是否获取 XML
            screenshot: 是否获取截图
            app_info: 是否获取 app 信息

        Returns:
            Observation: 统一的观测结果
        """
        try:
            response = requests.post(
                f"{self.base_url}/observe",
                headers=self._headers(),
                json={
                    "xml": xml,
                    "screenshot": screenshot,
                    "app_info": app_info,
                },
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()

            return Observation(
                xml=data.get("xml"),
                package_name=data.get("package_name"),
                activity_name=data.get("activity_name"),
                image_base64=data.get("image_base64"),
            )

        except requests.RequestException as e:
            logger.error(f"HTTP observe failed: {e}")
            return Observation()

    def act(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """
        通过 HTTP bridge 执行动作

        Args:
            action: OmniFlow Action 或字典格式

        Returns:
            ActionResult: 执行结果
        """
        # 转换为字典格式
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)

        try:
            response = requests.post(
                f"{self.base_url}/act",
                headers=self._headers(),
                json={"action": action_dict},
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()

            return ActionResult(
                success=data.get("success", True),
                error=data.get("message") if not data.get("success") else None,
                extra=data.get("data") or {},
            )

        except requests.RequestException as e:
            logger.error(f"HTTP act failed: {e}")
            return ActionResult(success=False, error=str(e))

    def confirm(self, prompt: str) -> bool:
        """
        通过 HTTP bridge 请求用户确认

        Args:
            prompt: 确认提示

        Returns:
            bool: 用户是否确认
        """
        try:
            response = requests.post(
                f"{self.base_url}/confirm",
                headers=self._headers(),
                json={"prompt": prompt},
                timeout=self.timeout * 2,  # 确认可能需要更长时间
            )
            response.raise_for_status()
            data = response.json()
            return data.get("confirmed", False)

        except requests.RequestException as e:
            logger.error(f"HTTP confirm failed: {e}")
            return False


class AsyncHTTPBridgeHost:
    """
    异步 HTTP Bridge Host 适配器

    将 HTTP bridge (如 OOB) 的接口适配为异步版本:
    - observe() → POST /utg/observe (async)
    - act() → POST /utg/act (async)

    用于 utg_api.py 等异步场景集成。

    使用方式:
        host = AsyncHTTPBridgeHost(
            base_url="http://127.0.0.1:8899/utg",
            token="bearer-token"
        )
        obs = await host.observe()
        result = await host.act(action)
    """

    def __init__(
        self,
        base_url: str,
        *,
        token: Optional[str] = None,
        timeout: float = 120.0,
    ):
        """
        初始化异步 HTTP Bridge Host

        Args:
            base_url: Bridge 基础 URL (如 http://127.0.0.1:8899/utg)
            token: Bearer token (可选)
            timeout: 请求超时时间
        """
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None

    def _headers(self) -> Dict[str, str]:
        """构建请求头"""
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 aiohttp session"""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def _post_json(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """发送 POST 请求并返回 JSON 响应"""
        session = await self._get_session()
        url = f"{self.base_url}{path}"
        async with session.post(url, headers=self._headers(), json=payload) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
    ) -> Observation:
        """
        通过 HTTP bridge 异步获取设备状态

        Args:
            xml: 是否获取 XML
            screenshot: 是否获取截图
            app_info: 是否获取 app 信息

        Returns:
            Observation: 统一的观测结果
        """
        try:
            data = await self._post_json(
                "/observe",
                {
                    "xml": xml,
                    "screenshot": screenshot,
                    "app_info": app_info,
                },
            )
            return Observation(
                xml=data.get("xml"),
                package_name=data.get("package_name"),
                activity_name=data.get("activity_name"),
                image_base64=data.get("image_base64"),
            )
        except aiohttp.ClientError as e:
            logger.error(f"Async HTTP observe failed: {e}")
            return Observation()

    async def act(self, action: Union[Action, Dict[str, Any]]) -> ActionResult:
        """
        通过 HTTP bridge 异步执行动作

        Args:
            action: OmniFlow Action 或字典格式

        Returns:
            ActionResult: 执行结果
        """
        # 转换为字典格式
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)

        try:
            data = await self._post_json("/act", {"action": action_dict})
            return ActionResult(
                success=data.get("success", True),
                error=data.get("message") if not data.get("success") else None,
                extra=data.get("data") or {},
            )
        except aiohttp.ClientError as e:
            logger.error(f"Async HTTP act failed: {e}")
            return ActionResult(success=False, error=str(e))

    async def confirm(self, prompt: str) -> bool:
        """
        通过 HTTP bridge 异步请求用户确认

        Args:
            prompt: 确认提示

        Returns:
            bool: 用户是否确认
        """
        try:
            data = await self._post_json("/confirm", {"prompt": prompt})
            return data.get("confirmed", False)
        except aiohttp.ClientError as e:
            logger.error(f"Async HTTP confirm failed: {e}")
            return False

    async def close(self):
        """关闭 HTTP session"""
        if self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
