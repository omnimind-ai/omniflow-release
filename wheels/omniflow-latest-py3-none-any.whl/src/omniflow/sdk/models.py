"""
OmniFlow SDK Models

直接从 contracts.py 导入，保持单一数据源。
"""

# Re-export from contracts (单一数据源)
from src.integrations.api.contracts import (
    CompileContextPayload as CompileContext,
)
from src.integrations.api.contracts import (
    CompileResult,
    ExecuteResult,
    IngestResult,
)

__all__ = [
    "CompileContext",
    "CompileResult",
    "ExecuteResult",
    "IngestResult",
]
