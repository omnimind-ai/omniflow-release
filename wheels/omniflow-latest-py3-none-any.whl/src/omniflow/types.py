"""
OmniFlow 类型定义

提供执行时需要的数据结构
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from src.omniflow.protocol import ActionResult, Observation


@dataclass
class ExecutionContext:
    """执行上下文

    替代之前的 runtime_context 字典，提供类型安全的执行上下文。

    Attributes:
        step_index: 当前步骤索引
        params: 参数绑定值，用于 ${param} 替换
        observation: 当前设备观测
        last_action_result: 上一个 action 的执行结果（可选）
    """

    step_index: int
    params: Dict[str, Any] = field(default_factory=dict)
    observation: Optional[Observation] = None
    last_action_result: Optional[ActionResult] = None
