"""
OmniFlow - Trajectory Cache for GUI Agents

架构:
    Host (设备层)    →  OmniFlow (缓存层)  →  Planner (决策层)
    observe/act         plan/step/run         plan fallback

使用方式:

    # 最简示例
    from src.omniflow import OmniFlow

    flow = OmniFlow("utg.json", host=device_host)
    result = flow.run("打开设置")

    # 带 VLM fallback
    flow = OmniFlow("utg.json", host=device_host, planner=vlm_planner)
    result = flow.run("打开设置")

    # Async 模式
    result = await flow.arun("打开设置")

外部集成 SDK:

    from src.omniflow.sdk import OmniFlowClient

    client = OmniFlowClient("http://localhost:19070")
    result = client.compile("打开设置")
    if result.matched:
        client.execute(result.function_id, bridge_url, token)
"""

from src.omniflow.config import (
    CompileConfig,
    ControlPlaneConfig,
    ExecutionConfig,
    LoggingConfig,
    MatchingConfig,
    OmniFlowConfig,
    omniflow_config,
)
from src.omniflow.core import OmniFlow
from src.omniflow.protocol import (
    Action,
    ActionResult,
    Host,
    Observation,
    Planner,
    PlanResult,
    RunResult,
    StepResult,
)

# SDK for external integration
from src.omniflow.sdk import (
    AsyncOmniFlowClient,
    CompileContext,
    CompileResult,
    ExecuteResult,
    IngestResult,
    OmniFlowClient,
)
from src.omniflow.tracing import (
    Trace,
    TraceStep,
    TrackedHost,
)

__all__ = [
    # 核心
    "OmniFlow",
    # 配置
    "omniflow_config",
    "OmniFlowConfig",
    "ExecutionConfig",
    "MatchingConfig",
    "CompileConfig",
    "ControlPlaneConfig",
    "LoggingConfig",
    # 协议
    "Host",
    "Planner",
    # 数据结构
    "Action",
    "ActionResult",
    "Observation",
    "PlanResult",
    "StepResult",
    "RunResult",
    # Tracing
    "TrackedHost",
    "Trace",
    "TraceStep",
    # SDK
    "OmniFlowClient",
    "AsyncOmniFlowClient",
    "CompileContext",
    "CompileResult",
    "ExecuteResult",
    "IngestResult",
]
