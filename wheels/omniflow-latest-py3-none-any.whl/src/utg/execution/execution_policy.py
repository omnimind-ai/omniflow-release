from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
from typing import Any, Dict, Optional, Protocol

from src.foundation.config import config as runtime_config
from src.foundation.paths import get_utg_bundle_file
from src.foundation.source_tools import (
    read_env_bool,
    read_env_text,
)


@dataclass(frozen=True)
class CompileConfig:
    candidate_limit: int = 5


# === 执行模式常量 ===
class ExecutionMode:
    """执行模式常量，避免魔法字符串。"""

    DEFAULT = "default"
    BASELINE_SLEEP_ONLY = "baseline_sleep_only"  # 跳过控制总线，仅保留 sleep


def is_baseline_mode(mode: str | None) -> bool:
    """检查是否为 baseline 模式。"""
    return str(mode or "").strip() == ExecutionMode.BASELINE_SLEEP_ONLY


_UNIFIED_VERIFIED_ACTION_TYPES: tuple[str, ...] = (
    "click",
    "click_node",
    "long_press",
    "open_app",
)
_UNIFIED_POLL_TIMEOUT_S: float = 0.6
_UNIFIED_MAX_POLLS: int = 12
_UNIFIED_POLL_YIELD_S: float = 0.0
_UNIFIED_RETRY_ATTEMPTS: int = 5
_UNIFIED_RETRY_JITTER_PX: int = 0
_UNIFIED_HARD_FAIL_ON_NO_EFFECT: bool = False
_UNIFIED_SETTLE_CONSECUTIVE_OBSERVATIONS: int = 2


def get_runtime_utg_store_path() -> Optional[str]:
    value = getattr(runtime_config, "OMNIFLOW_UTG_STORE_PATH", None)
    return str(value) if value is not None and str(value).strip() else None


def get_runtime_trigger_pool_file() -> Optional[str]:
    return read_env_text("UTG_TRIGGER_POOL_FILE")


def get_runtime_trigger_pool_enabled(default: bool = True) -> bool:
    return read_env_bool("UTG_TRIGGER_POOL_ENABLED", default)


def get_utg_bundle_file_for_execution(filename: str, utg_path: Optional[str]) -> Path:
    return Path(get_utg_bundle_file(filename, utg_path))


def get_runtime_policy_file(utg_path: Optional[str] = None) -> str:
    explicit = read_env_text("UTG_RUNTIME_POLICY_FILE")
    if explicit:
        return str(Path(explicit).expanduser())
    return str(get_utg_bundle_file_for_execution("runtime_policy.json", utg_path))


def _normalize_action_type(raw: Any) -> str:
    if raw in (None, ""):
        return ""
    if hasattr(raw, "name"):
        name = str(getattr(raw, "name", "") or "").strip().lower()
        if name:
            return name
    text = str(raw).strip().lower()
    if "." in text:
        text = text.split(".")[-1]
    return text


def _env_verified_action_types(name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = read_env_text(name)
    if not raw:
        return tuple(default)
    items = [_normalize_action_type(part) for part in raw.split(",")]
    filtered = tuple(item for item in items if item)
    return filtered or tuple(default)


@dataclass(frozen=True)
class ActionControlConfig:
    enabled: bool = True
    verified_action_types: tuple[str, ...] = _UNIFIED_VERIFIED_ACTION_TYPES
    poll_timeout_s: float = _UNIFIED_POLL_TIMEOUT_S
    max_polls: int = _UNIFIED_MAX_POLLS
    poll_yield_s: float = _UNIFIED_POLL_YIELD_S
    retry_attempts: int = _UNIFIED_RETRY_ATTEMPTS
    retry_jitter_px: int = _UNIFIED_RETRY_JITTER_PX
    hard_fail_on_no_effect: bool = _UNIFIED_HARD_FAIL_ON_NO_EFFECT
    settle_consecutive_observations: int = _UNIFIED_SETTLE_CONSECUTIVE_OBSERVATIONS


def build_action_control_config(
    *,
    hard_fail_on_no_effect: Optional[bool] = None,
) -> ActionControlConfig:
    """Build ActionControlConfig from unified settings."""
    from src.foundation.settings import settings

    s = settings.execution
    return ActionControlConfig(
        enabled=s.action_effect_enabled,
        verified_action_types=s.action_effect_types,
        poll_timeout_s=s.poll_timeout_s,
        max_polls=s.max_polls,
        poll_yield_s=s.poll_yield_s,
        retry_attempts=s.retry_attempts,
        retry_jitter_px=s.retry_jitter_px,
        hard_fail_on_no_effect=(
            hard_fail_on_no_effect
            if hard_fail_on_no_effect is not None
            else s.hard_fail_on_no_effect
        ),
        settle_consecutive_observations=s.settle_consecutive_observations,
    )


@dataclass(frozen=True)
class PathControlConfig:
    enable_click_prompt: bool = True
    enable_coordinate_adaptation: bool = True
    enable_keyboard_dismiss_re_adapt: bool = True
    enable_scroll_retry_re_adapt: bool = True
    enable_auto_press_back_after_type: bool = True
    post_action_wait_seconds: float = 1.0
    open_app_foreground_timeout_s: float = 2.5
    open_app_foreground_poll_interval_s: float = 0.0
    open_app_foreground_required_hits: int = 2


@dataclass(frozen=True)
class ExecutionConfig:
    """General execution configuration."""

    max_call_depth: int = 10


def build_path_control_config() -> PathControlConfig:
    """Build PathControlConfig from unified settings."""
    from src.foundation.settings import settings

    s = settings.execution
    return PathControlConfig(
        enable_click_prompt=s.enable_click_prompt,
        enable_coordinate_adaptation=s.enable_coordinate_adaptation,
        enable_keyboard_dismiss_re_adapt=s.enable_keyboard_dismiss_re_adapt,
        enable_scroll_retry_re_adapt=s.enable_scroll_retry_re_adapt,
        enable_auto_press_back_after_type=s.enable_auto_press_back_after_type,
        post_action_wait_seconds=s.post_action_wait_seconds,
        open_app_foreground_timeout_s=s.open_app_foreground_timeout_s,
        open_app_foreground_poll_interval_s=s.open_app_foreground_poll_interval_s,
        open_app_foreground_required_hits=s.open_app_foreground_required_hits,
    )


class ExecutionPolicyProvider(Protocol):
    def action_config(self) -> ActionControlConfig: ...

    def path_config(self) -> PathControlConfig: ...

    def compile_config(self) -> CompileConfig: ...

    def execution_config(self) -> ExecutionConfig: ...

    def source_path(self) -> str: ...

    def trigger_pool_enabled(self) -> bool:
        return False

    def trigger_pool_payload(self) -> Optional[Dict[str, Any]]:
        return None

    def trigger_pool_source_path(self) -> Optional[str]:
        return None

    def node_triggers_enabled(self) -> bool:
        return True


@dataclass(frozen=True)
class ExecutionPolicyBundle(ExecutionPolicyProvider):
    compile: CompileConfig = field(default_factory=CompileConfig)
    action_control: ActionControlConfig = field(
        default_factory=build_action_control_config
    )
    path_control: PathControlConfig = field(default_factory=build_path_control_config)
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    trigger_pool_enabled_flag: bool = False
    trigger_pool: Optional[Dict[str, Any]] = None
    trigger_pool_source: str = ""
    node_triggers: bool = True
    path: str = ""

    def action_config(self) -> ActionControlConfig:
        return self.action_control

    def path_config(self) -> PathControlConfig:
        return self.path_control

    def compile_config(self) -> CompileConfig:
        return self.compile

    def execution_config(self) -> ExecutionConfig:
        return self.execution

    def source_path(self) -> str:
        return self.path

    def trigger_pool_enabled(self) -> bool:
        return bool(self.trigger_pool_enabled_flag)

    def trigger_pool_payload(self) -> Optional[Dict[str, Any]]:
        return dict(self.trigger_pool) if isinstance(self.trigger_pool, dict) else None

    def trigger_pool_source_path(self) -> Optional[str]:
        source = str(self.trigger_pool_source or "").strip()
        return source or None

    def node_triggers_enabled(self) -> bool:
        return bool(self.node_triggers)

    def to_dict(self) -> Dict[str, Any]:
        action_control_payload = {
            **asdict(self.action_control),
            "verified_action_types": list(self.action_control.verified_action_types),
            "node_triggers_enabled": bool(self.node_triggers),
        }
        if self.trigger_pool_enabled():
            action_control_payload["trigger_pool"] = dict(self.trigger_pool or {})
            if self.trigger_pool_source_path():
                action_control_payload["trigger_pool_source_path"] = (
                    self.trigger_pool_source_path()
                )
        path_control_payload = asdict(self.path_control)
        return {
            "compile": asdict(self.compile),
            "action_control": action_control_payload,
            "path_control": path_control_payload,
        }

    @classmethod
    def from_file(
        cls,
        *,
        path: Optional[str] = None,
        utg_path: Optional[str] = None,
        default_candidate_limit: int = 5,
        trigger_pool_config_path: Optional[str] = None,
        trigger_pool_enabled: bool = True,
    ) -> "ExecutionPolicyBundle":
        resolved = (
            path
            or read_env_text("UTG_RUNTIME_POLICY_FILE")
            or get_runtime_policy_file(utg_path)
        )
        defaults = cls(
            compile=CompileConfig(
                candidate_limit=max(1, int(default_candidate_limit)),
            ),
            path_control=PathControlConfig(),
            path=str(resolved or ""),
        )
        payload, file_path = _load_json_payload(resolved)
        payload = payload if isinstance(payload, dict) else {}

        compile_raw = (
            payload.get("compile") if isinstance(payload.get("compile"), dict) else {}
        )
        action_control_raw = (
            payload.get("action_control")
            if isinstance(payload.get("action_control"), dict)
            else {}
        )
        path_control_raw = (
            payload.get("path_control")
            if isinstance(payload.get("path_control"), dict)
            else {}
        )

        compile_cfg = CompileConfig(
            candidate_limit=max(
                1,
                int(
                    compile_raw.get("candidate_limit", defaults.compile.candidate_limit)
                ),
            ),
        )
        action_control_cfg = ActionControlConfig(
            enabled=bool(
                action_control_raw.get("enabled", defaults.action_control.enabled)
            ),
            verified_action_types=tuple(
                str(item).strip().lower()
                for item in list(
                    action_control_raw.get(
                        "verified_action_types",
                        defaults.action_control.verified_action_types,
                    )
                    or []
                )
                if str(item).strip()
            )
            or tuple(defaults.action_control.verified_action_types),
            poll_timeout_s=float(
                action_control_raw.get(
                    "poll_timeout_s", defaults.action_control.poll_timeout_s
                )
            ),
            max_polls=max(
                1,
                int(
                    action_control_raw.get(
                        "max_polls", defaults.action_control.max_polls
                    )
                ),
            ),
            poll_yield_s=max(
                0.0,
                float(
                    action_control_raw.get(
                        "poll_yield_s", defaults.action_control.poll_yield_s
                    )
                ),
            ),
            retry_attempts=max(
                0,
                int(
                    action_control_raw.get(
                        "retry_attempts", defaults.action_control.retry_attempts
                    )
                ),
            ),
            retry_jitter_px=max(
                0,
                int(
                    action_control_raw.get(
                        "retry_jitter_px", defaults.action_control.retry_jitter_px
                    )
                ),
            ),
            hard_fail_on_no_effect=bool(
                action_control_raw.get(
                    "hard_fail_on_no_effect",
                    defaults.action_control.hard_fail_on_no_effect,
                )
            ),
            settle_consecutive_observations=max(
                1,
                int(
                    action_control_raw.get(
                        "settle_consecutive_observations",
                        defaults.action_control.settle_consecutive_observations,
                    )
                ),
            ),
        )
        path_control_cfg = PathControlConfig(
            enable_click_prompt=bool(
                path_control_raw.get(
                    "enable_click_prompt", defaults.path_control.enable_click_prompt
                )
            ),
            enable_coordinate_adaptation=bool(
                path_control_raw.get(
                    "enable_coordinate_adaptation",
                    defaults.path_control.enable_coordinate_adaptation,
                )
            ),
            enable_keyboard_dismiss_re_adapt=bool(
                path_control_raw.get(
                    "enable_keyboard_dismiss_re_adapt",
                    defaults.path_control.enable_keyboard_dismiss_re_adapt,
                )
            ),
            enable_scroll_retry_re_adapt=bool(
                path_control_raw.get(
                    "enable_scroll_retry_re_adapt",
                    defaults.path_control.enable_scroll_retry_re_adapt,
                )
            ),
            enable_auto_press_back_after_type=bool(
                path_control_raw.get(
                    "enable_auto_press_back_after_type",
                    defaults.path_control.enable_auto_press_back_after_type,
                )
            ),
            post_action_wait_seconds=max(
                0.0,
                float(
                    path_control_raw.get(
                        "post_action_wait_seconds",
                        defaults.path_control.post_action_wait_seconds,
                    )
                ),
            ),
            open_app_foreground_timeout_s=max(
                0.0,
                float(
                    path_control_raw.get(
                        "open_app_foreground_timeout_s",
                        defaults.path_control.open_app_foreground_timeout_s,
                    )
                ),
            ),
            open_app_foreground_poll_interval_s=max(
                0.0,
                float(
                    path_control_raw.get(
                        "open_app_foreground_poll_interval_s",
                        defaults.path_control.open_app_foreground_poll_interval_s,
                    )
                ),
            ),
            open_app_foreground_required_hits=max(
                1,
                int(
                    path_control_raw.get(
                        "open_app_foreground_required_hits",
                        defaults.path_control.open_app_foreground_required_hits,
                    )
                ),
            ),
        )

        inline_trigger_cfg = (
            action_control_raw.get("trigger_pool")
            if isinstance(action_control_raw.get("trigger_pool"), dict)
            else None
        )
        trigger_payload, trigger_source = _load_action_trigger_payload(
            inline_payload=inline_trigger_cfg,
            explicit_path=trigger_pool_config_path,
            utg_path=utg_path,
            enabled=trigger_pool_enabled,
        )

        return cls(
            compile=compile_cfg,
            action_control=action_control_cfg,
            path_control=path_control_cfg,
            trigger_pool_enabled_flag=bool(trigger_pool_enabled and trigger_payload),
            trigger_pool=trigger_payload,
            trigger_pool_source=str(trigger_source or ""),
            node_triggers=bool(action_control_raw.get("node_triggers_enabled", True)),
            path=str(file_path or resolved or ""),
        )


def _load_json_payload(path: Optional[str]) -> tuple[Dict[str, Any], Optional[Path]]:
    if not path:
        return {}, None
    file_path = Path(str(path)).expanduser()
    if not file_path.exists():
        return {}, file_path
    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except Exception:
        return {}, file_path
    if not isinstance(payload, dict):
        return {}, file_path
    return payload, file_path


def _load_action_trigger_payload(
    *,
    inline_payload: Optional[Dict[str, Any]],
    explicit_path: Optional[str],
    utg_path: Optional[str],
    enabled: bool,
) -> tuple[Optional[Dict[str, Any]], Optional[str]]:
    if not enabled:
        return None, explicit_path
    if isinstance(inline_payload, dict):
        return dict(inline_payload), str(explicit_path or "") or None
    path = _resolve_action_trigger_path(explicit_path=explicit_path, utg_path=utg_path)
    if path is None:
        return None, None
    payload, file_path = _load_json_payload(str(path))
    if not payload:
        return None, str(file_path or path)
    return payload, str(file_path or path)


def _resolve_action_trigger_path(
    *, explicit_path: Optional[str], utg_path: Optional[str]
) -> Optional[Path]:
    if explicit_path:
        candidate = Path(explicit_path).expanduser()
        return candidate if candidate.exists() else None
    candidate = get_utg_bundle_file_for_execution("trigger_pool.json", utg_path)
    return candidate if candidate.exists() else None


__all__ = [
    "CompileConfig",
    "ExecutionConfig",
    "ExecutionPolicyBundle",
    "ExecutionPolicyProvider",
    "PathControlConfig",
]
