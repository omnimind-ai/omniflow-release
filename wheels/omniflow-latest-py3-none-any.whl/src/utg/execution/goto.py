"""
Goto State Machine Executor - 状态机路由执行器

核心思想：
- goto(target_node) 作为一等公民原语
- 自动计算最短路径并逐边执行
- 每条边对应一个 Function，展开为原子动作执行

Example:
    >>> executor = GotoExecutor(runtime, utg_executor)
    >>> result = await executor.goto(
    ...     "settings_main",
    ...     observe_fn=host.observe,
    ...     act_fn=host.act,
    ... )
    >>> print(f"到达: {result.success}, 执行了 {result.actions_executed} 个动作")
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
from typing import TYPE_CHECKING, Any, Callable, List, Optional, Set

from src.utg.core.actions import AnyAction
from src.utg.core.graph_runtime import FunctionEdge, PathResult, UTGGraphRuntime
from src.utg.core.models import Function, UTGNode
from src.utg.execution.protocol import Observation

if TYPE_CHECKING:
    from src.utg.execution.executor import UTGExecutor
    from src.utg.runtime.utg_runtime import UTGRuntime

logger = logging.getLogger(__name__)


async def _maybe_await(value: Any) -> Any:
    """Handle sync/async compatibility."""
    if asyncio.iscoroutine(value):
        return await value
    return value


@dataclass
class GotoResult:
    """goto 执行结果"""

    success: bool
    from_node_id: str
    to_node_id: str
    path: Optional[PathResult] = None
    actions_executed: int = 0
    error: Optional[str] = None
    # 详细信息
    edges_executed: int = 0
    final_node_id: Optional[str] = None

    def __repr__(self) -> str:
        status = "OK" if self.success else f"FAIL({self.error})"
        return (
            f"GotoResult({self.from_node_id} -> {self.to_node_id}: "
            f"{status}, actions={self.actions_executed})"
        )


class GotoExecutor:
    """状态机路由执行器

    职责：
    1. 识别当前节点
    2. 计算到目标节点的最短路径
    3. 逐边执行（每条边对应一个 Function）
    4. 验证到达目标

    Example:
        >>> goto = GotoExecutor(runtime, executor)
        >>> result = await goto.goto("settings_main", observe_fn=obs, act_fn=act)
    """

    def __init__(
        self,
        runtime: "UTGRuntime",
        executor: "UTGExecutor",
        *,
        max_hops: int = 5,
        max_actions: int = 20,
        post_edge_wait_seconds: float = 1.0,
    ):
        """
        初始化 GotoExecutor

        Args:
            runtime: UTG 运行时（提供节点匹配和图结构）
            executor: UTG 执行器（执行 Function）
            max_hops: 最大跳数限制
            max_actions: 最大动作数限制
            post_edge_wait_seconds: 每条边执行后的等待时间
        """
        self.runtime = runtime
        self.executor = executor
        self.max_hops = max_hops
        self.max_actions = max_actions
        self.post_edge_wait_seconds = post_edge_wait_seconds

        # 构建图运行时
        self._graph_runtime: Optional[UTGGraphRuntime] = None

    @property
    def graph_runtime(self) -> UTGGraphRuntime:
        """延迟初始化图运行时"""
        if self._graph_runtime is None:
            self._graph_runtime = UTGGraphRuntime(self.runtime._utg)
        return self._graph_runtime

    def rebuild_graph_runtime(self) -> None:
        """重建图运行时（当 UTG 发生变化时调用）"""
        self._graph_runtime = UTGGraphRuntime(self.runtime._utg)

    async def goto(
        self,
        target_node_id: str,
        *,
        observe_fn: Callable,
        act_fn: Callable,
        current_observation: Optional[Observation] = None,
    ) -> GotoResult:
        """
        导航到目标节点

        流程:
        1. 识别当前节点
        2. 如果已在目标节点，直接返回成功
        3. 计算最短路径
        4. 检查路径动作总量
        5. 逐边执行
        6. 验证到达

        Args:
            target_node_id: 目标节点 ID
            observe_fn: 观测函数
            act_fn: 执行函数
            current_observation: 可选的当前观测（避免重复观测）

        Returns:
            GotoResult: 执行结果
        """
        logger.info("[goto] target=%s", target_node_id)

        # 1. 获取当前观测
        if current_observation is None:
            current_observation = await _maybe_await(observe_fn())

        # 2. 识别当前节点
        current_node = self._match_current_node(current_observation)
        if not current_node:
            logger.warning("[goto] cannot identify current node")
            return GotoResult(
                success=False,
                from_node_id="unknown",
                to_node_id=target_node_id,
                error="cannot_identify_current_node",
            )

        logger.info("[goto] current_node=%s", current_node.id)

        # 3. 已经在目标节点
        if current_node.id == target_node_id:
            logger.info("[goto] already at target node")
            return GotoResult(
                success=True,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                actions_executed=0,
                final_node_id=current_node.id,
            )

        # 4. 检查目标节点是否存在
        target_node = self.runtime.get_node_by_id(target_node_id)
        if target_node is None:
            logger.warning("[goto] target node not found: %s", target_node_id)
            return GotoResult(
                success=False,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                error="target_node_not_found",
            )

        # 5. 计算最短路径
        path = self.graph_runtime.shortest_path(
            current_node.id,
            target_node_id,
            max_depth=self.max_hops,
        )
        if not path:
            logger.warning(
                "[goto] no path found: %s -> %s", current_node.id, target_node_id
            )
            return GotoResult(
                success=False,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                error="no_path_found",
            )

        logger.info(
            "[goto] path found: %s (cost=%.1f, edges=%d)",
            path.function_sequence,
            path.total_cost,
            len(path.edges),
        )

        # 6. 检查动作总量
        total_actions = self._count_path_actions(path)
        if total_actions > self.max_actions:
            logger.warning(
                "[goto] path too long: %d actions > max %d",
                total_actions,
                self.max_actions,
            )
            return GotoResult(
                success=False,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                path=path,
                error="path_too_long",
            )

        # 7. 逐边执行
        actions_executed = 0
        edges_executed = 0
        obs = current_observation

        for edge in path.edges:
            logger.info(
                "[goto] executing edge: %s -> %s via %s",
                edge.from_node_id,
                edge.to_node_id,
                edge.function_name,
            )

            # 展开边的 function 为原子动作
            edge_actions = self._expand_edge_function(edge)

            # 执行每个动作
            for action in edge_actions:
                try:
                    response = await _maybe_await(act_fn(action))
                    actions_executed += 1

                    # 检查执行结果
                    if isinstance(response, dict) and not response.get("success", True):
                        error_msg = response.get("error_message", "action_failed")
                        logger.error("[goto] action failed: %s", error_msg)
                        return GotoResult(
                            success=False,
                            from_node_id=current_node.id,
                            to_node_id=target_node_id,
                            path=path,
                            actions_executed=actions_executed,
                            edges_executed=edges_executed,
                            error=f"action_failed: {error_msg}",
                        )
                except Exception as exc:
                    logger.error("[goto] action exception: %s", exc)
                    return GotoResult(
                        success=False,
                        from_node_id=current_node.id,
                        to_node_id=target_node_id,
                        path=path,
                        actions_executed=actions_executed,
                        edges_executed=edges_executed,
                        error=f"action_exception: {exc}",
                    )

            edges_executed += 1

            # 边执行完毕，等待 UI 稳定
            await asyncio.sleep(self.post_edge_wait_seconds)

            # 获取新观测
            obs = await _maybe_await(observe_fn())

        # 8. 最终验证
        final_node = self._match_current_node(obs)
        final_node_id = final_node.id if final_node else None

        if final_node and final_node.id == target_node_id:
            logger.info("[goto] arrived at target: %s", target_node_id)
            return GotoResult(
                success=True,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                path=path,
                actions_executed=actions_executed,
                edges_executed=edges_executed,
                final_node_id=final_node_id,
            )
        else:
            logger.warning(
                "[goto] verification failed: expected %s, got %s",
                target_node_id,
                final_node_id,
            )
            return GotoResult(
                success=False,
                from_node_id=current_node.id,
                to_node_id=target_node_id,
                path=path,
                actions_executed=actions_executed,
                edges_executed=edges_executed,
                final_node_id=final_node_id,
                error="verification_failed",
            )

    def _match_current_node(self, observation: Observation) -> Optional[UTGNode]:
        """匹配当前观测到已知节点

        优先使用 vector_set 匹配，fallback 到 XML 匹配。

        Args:
            observation: 当前观测

        Returns:
            匹配到的 UTGNode，或 None
        """
        # 优先使用 vector_set
        vector_set = getattr(observation, "vector_set", None)
        if vector_set is not None:
            try:
                return self.runtime._matcher.match_node_from_vector_set(
                    vector_set=vector_set,
                    package_name=str(getattr(observation, "package_name", "") or ""),
                )
            except (AttributeError, Exception):
                pass

        # Fallback 到 XML 匹配
        xml = str(getattr(observation, "xml", "") or "").strip()
        package_name = str(getattr(observation, "package_name", "") or "").strip()
        if xml:
            return self.runtime.match_node(xml, package_name)

        return None

    def _expand_edge_function(self, edge: FunctionEdge) -> List[AnyAction]:
        """展开边的 function 为原始动作

        处理 call_function 嵌套调用。

        Args:
            edge: 图的边（包含 Function）

        Returns:
            展开后的动作列表
        """
        return self._expand_function(edge.function, set())

    def _expand_function(self, func: Function, seen: Set[str]) -> List[AnyAction]:
        """递归展开 function，处理 call_function

        Args:
            func: 要展开的 Function
            seen: 已访问的 function ID（防止循环）

        Returns:
            展开后的动作列表
        """
        func_id = func.name
        if func_id in seen:
            logger.warning("[goto] circular call_function detected: %s", func_id)
            return []
        seen.add(func_id)

        actions: List[AnyAction] = []
        for action in func.actions or []:
            action_type = str(getattr(action, "type", "") or "").strip()

            if action_type == "call_function":
                # 解析 call_function 参数
                params = getattr(action, "params", None)
                if params is None:
                    continue

                node_id = str(getattr(params, "node_id", "") or "").strip()
                function_name = str(getattr(params, "function_name", "") or "").strip()

                if not node_id or not function_name:
                    continue

                # 查找嵌套 function
                nested_node = self.runtime.get_node_by_id(node_id)
                if nested_node is None:
                    continue

                nested_func = nested_node.functions.get(function_name)
                if nested_func is None:
                    continue

                # 递归展开
                nested_actions = self._expand_function(nested_func, seen)
                actions.extend(nested_actions)
            else:
                # 普通动作，直接添加
                actions.append(action)

        return actions

    def _count_path_actions(self, path: PathResult) -> int:
        """计算路径总动作数

        Args:
            path: 路径结果

        Returns:
            总动作数
        """
        total = 0
        for edge in path.edges:
            edge_actions = self._expand_edge_function(edge)
            total += len(edge_actions)
        return total


__all__ = [
    "GotoExecutor",
    "GotoResult",
]
