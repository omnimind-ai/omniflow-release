from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import logging
import re
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Literal

from src.utg.core.actions import AnyAction

if TYPE_CHECKING:
    from src.utg.assets.embedding.vector_set import PageVectorSet

logger = logging.getLogger(__name__)

ObserveFn = Callable[..., Awaitable[Any]]
ActFn = Callable[..., Awaitable[Any]]

_LOCAL_STABLE_REQUIRED_MATCHES = 2
_LOCAL_STABLE_MAX_POLLS = 4
_LOCAL_STABLE_POLL_INTERVAL_S = 0.10
_LOCAL_TRANSITION_SHELL_MAX_POLLS = 10
_LOCAL_STABLE_ABSOLUTE_MAX_POLLS = 15  # 硬性上限，防止无限循环


def _should_use_local_stabilization(observe: ObserveFn) -> bool:
    """Return whether one observe callable should use OmniFlow-side stabilization.

    Args:
        observe: Shared observe callable passed into runtime/control execution.

    Returns:
        True only for AndroidWorld live observe wrappers that explicitly opt into
        local fresh-poll stabilization. Offline replay and generic mocks skip
        this extra observe loop and return their direct snapshot immediately.
    """

    if bool(getattr(observe, "_omniflow_local_stabilize", False)):
        return True
    owner = getattr(observe, "__self__", None)
    return bool(getattr(owner, "_omniflow_local_stabilize", False))


@dataclass(frozen=True)
class DeviceObservation:
    """
    Normalized live observation returned by any agent-side observe call.

    Args:
        xml: Current UI XML snapshot when requested.
        image_base64: Optional screenshot payload, usually a data URL.
        package_name: Foreground package name if app identity was requested.
        activity_name: Foreground activity name if app identity was requested.
        ui_elements: Optional host-native UI elements kept for XML fallback reuse.
        raw_state: Host-native page object kept only for host-local reuse.
    """

    xml: str | None = None
    image_base64: str | None = None
    package_name: str | None = None
    activity_name: str | None = None
    ui_elements: Any | None = None
    raw_state: Any | None = None


def _coerce_device_observation(value: Any) -> DeviceObservation:
    """Normalize dict/object observations into the shared `DeviceObservation` shape."""

    if isinstance(value, DeviceObservation):
        return value
    if isinstance(value, dict):
        return DeviceObservation(
            xml=value.get("xml"),
            image_base64=value.get("image_base64"),
            package_name=value.get("package_name"),
            activity_name=value.get("activity_name"),
            ui_elements=value.get("ui_elements"),
            raw_state=value.get("raw_state"),
        )
    return DeviceObservation(
        xml=getattr(value, "xml", None),
        image_base64=getattr(value, "image_base64", None),
        package_name=getattr(value, "package_name", None),
        activity_name=getattr(value, "activity_name", None),
        ui_elements=getattr(value, "ui_elements", None),
        raw_state=getattr(value, "raw_state", None),
    )


def is_response_failed(response_obj: Any) -> bool:
    """Classify whether one live act response should be treated as failed."""

    if response_obj is None:
        return False
    if isinstance(response_obj, dict):
        if "success" in response_obj and not bool(response_obj.get("success")):
            return True
        if "ok" in response_obj and not bool(response_obj.get("ok")):
            return True
        error = response_obj.get("error")
        if isinstance(error, dict) and bool(error):
            return True
        return False
    if hasattr(response_obj, "success"):
        try:
            return not bool(getattr(response_obj, "success", False))
        except Exception:
            return True
    if hasattr(response_obj, "ok"):
        try:
            return not bool(getattr(response_obj, "ok", True))
        except Exception:
            return True
    return False


def _is_transition_shell_observation(
    observation: DeviceObservation,
    *,
    xml: bool,
    app_info: bool,
) -> bool:
    """Detect transient launch/transition frames that should not count as stable.

    Args:
        observation: One normalized live observation sample.
        xml: Whether the current caller requested XML in this sample.
        app_info: Whether the current caller requested package/activity identity.

    Returns:
        True when the observation looks like a temporary shell page: the host
        already reports a foreground app package, but the XML still contains at
        most one node from that package and is dominated by `SystemUI` overlay
        nodes. These frames commonly appear right after page transitions and are
        not safe to reuse as a settled control observation.
    """
    if not (xml and app_info):
        return False
    xml_text = str(observation.xml or "").strip()
    package_name = str(observation.package_name or "").strip()
    if not xml_text or not package_name or package_name == "com.android.systemui":
        return False
    # 使用正则确保精确匹配 package 属性，避免误匹配文本内容
    escaped_pkg = re.escape(package_name)
    current_package_pattern = re.compile(rf'\bpackage="{escaped_pkg}"')
    current_package_node_count = len(current_package_pattern.findall(xml_text))
    systemui_node_count = len(
        re.findall(r'\bpackage="com\.android\.systemui"', xml_text)
    )
    return current_package_node_count <= 1 and systemui_node_count >= 3


async def _collect_observation(
    observe: ObserveFn,
    *,
    xml: bool = False,
    screenshot: bool = False,
    app_info: bool = False,
    **kwargs: Any,
) -> DeviceObservation:
    """Call one observe function and normalize the returned payload.

    Args:
        observe: Live host observation callable implementing the shared
            `observe(...)` protocol.
        xml: Whether the caller needs XML in the returned observation.
        screenshot: Whether the caller needs screenshot content.
        app_info: Whether the caller needs package/activity identity.
        **kwargs: Extra observe kwargs forwarded as-is to the host.

    Returns:
        One normalized `DeviceObservation` snapshot.
    """

    async def _observe_once() -> DeviceObservation:
        observed = await observe(
            xml=xml,
            screenshot=screenshot,
            app_info=app_info,
            **kwargs,
        )
        return _coerce_device_observation(observed)

    if not (xml or app_info) or not _should_use_local_stabilization(observe):
        return await _observe_once()

    def _stable_key(observation: DeviceObservation) -> tuple[str, str, str]:
        xml_key = str(observation.xml or "").strip() if xml else ""
        package_key = str(observation.package_name or "").strip() if app_info else ""
        activity_key = str(observation.activity_name or "").strip() if app_info else ""
        return xml_key, package_key, activity_key

    last_observation = await _observe_once()
    last_key = _stable_key(last_observation)
    stable_hits = (
        0
        if _is_transition_shell_observation(
            last_observation,
            xml=xml,
            app_info=app_info,
        )
        else 1
    )
    if stable_hits >= _LOCAL_STABLE_REQUIRED_MATCHES:
        return last_observation
    max_polls = _LOCAL_STABLE_MAX_POLLS
    if stable_hits == 0:
        max_polls = max(max_polls, _LOCAL_TRANSITION_SHELL_MAX_POLLS)
    attempt_index = 0
    # 添加绝对上限保护，防止无限循环
    while (
        attempt_index < max_polls and attempt_index < _LOCAL_STABLE_ABSOLUTE_MAX_POLLS
    ):
        if attempt_index >= 0 and _LOCAL_STABLE_POLL_INTERVAL_S > 0:
            await asyncio.sleep(_LOCAL_STABLE_POLL_INTERVAL_S)
        current_observation = await _observe_once()
        current_key = _stable_key(current_observation)
        if _is_transition_shell_observation(
            current_observation,
            xml=xml,
            app_info=app_info,
        ):
            max_polls = min(
                max(max_polls, _LOCAL_TRANSITION_SHELL_MAX_POLLS),
                _LOCAL_STABLE_ABSOLUTE_MAX_POLLS,
            )
            last_observation = current_observation
            last_key = current_key
            stable_hits = 0
            attempt_index += 1
            continue
        if current_key == last_key:
            stable_hits += 1
            last_observation = current_observation
            if stable_hits >= _LOCAL_STABLE_REQUIRED_MATCHES:
                return current_observation
            attempt_index += 1
            continue
        last_observation = current_observation
        last_key = current_key
        stable_hits = 1
        attempt_index += 1
    return last_observation


async def observe_xml(observe: ObserveFn, **kwargs: Any) -> str:
    """Collect only XML from one live observation snapshot.

    Args:
        observe: Shared live observe callable.
        **kwargs: Extra observe kwargs forwarded to the host.

    Returns:
        The observed XML text, or `""` when host returned no XML payload.
    """

    observation = await _collect_observation(
        observe,
        xml=True,
        **kwargs,
    )
    xml_text = str(observation.xml or "")
    if not xml_text.strip():
        logger.warning(
            "observe_xml returned empty XML - control decisions may be incorrect"
        )
    return xml_text


async def observe_app_info(
    observe: ObserveFn,
    **kwargs: Any,
) -> tuple[str | None, str | None]:
    """Collect only app identity from the current live agent observation."""

    observation = await _collect_observation(
        observe,
        app_info=True,
        **kwargs,
    )
    return observation.package_name, observation.activity_name


async def act_on_device(
    act: ActFn,
    action: AnyAction,
    *,
    observation: DeviceObservation | None = None,
    **kwargs: Any,
) -> Any:
    """Call the live action function with a normalized optional observation."""

    return await act(
        action,
        observation=_coerce_device_observation(observation)
        if observation is not None
        else None,
        **kwargs,
    )


@dataclass
class Observation:
    """
    One observed runtime page snapshot consumed by the control bus.

    Args:
        xml: Raw XML snapshot kept for compatibility with existing control logic.
        vector_set: PageVectorSet representation of the UI (replaces XML).
        package_name: Foreground package name.
        activity_name: Foreground activity name.
    """

    xml: str | None = None
    vector_set: "PageVectorSet | None" = None
    package_name: str = ""
    activity_name: str = ""


@dataclass
class ObservationCache:
    """
    统一的 Observation 缓存管理器，替代散落的 context key。

    用法：
        cache = ObservationCache()
        cache.store(observation, phase="before_action")
        if not cache.is_stale():
            return cache.observation
    """

    observation: Observation | None = None
    phase: str = ""
    _captured_at: float = 0.0
    _fingerprint: str = ""

    def store(self, obs: Observation, phase: str = "") -> None:
        """存储新的观测。"""
        from time import perf_counter

        self.observation = obs
        self.phase = phase
        self._captured_at = perf_counter()

        # Use vector_set fingerprint for change detection
        if obs and obs.vector_set:
            self._fingerprint = obs.vector_set.fingerprint
        else:
            self._fingerprint = ""

    def is_stale(self, max_age_s: float = 2.0) -> bool:
        """检查缓存是否过期。"""
        from time import perf_counter

        if self.observation is None:
            return True
        return perf_counter() - self._captured_at > max_age_s

    def is_changed(self, new_observation: Observation) -> bool:
        """检查观测是否变化。"""
        if new_observation and new_observation.vector_set:
            return new_observation.vector_set.fingerprint != self._fingerprint
        return True

    def to_dict(self) -> dict[str, str] | None:
        """转换为标准字典格式。"""
        if self.observation is None:
            return None
        return {
            "package_name": self.observation.package_name or "",
            "activity_name": self.observation.activity_name or "",
            "fingerprint": self._fingerprint,
        }

    def clear(self) -> None:
        """清除缓存。"""
        self.observation = None
        self.phase = ""
        self._captured_at = 0.0
        self._fingerprint = ""


@dataclass
class RouteContext:
    """
    Mutable execution cursor shared between executor and control bus.

    Args:
        observe: Live observe function used when executor needs a fresh page snapshot.
        act: Live act function used when executor later applies device effects.
        node: Current UTG node bound to the function being executed.
        original_action: Action before parameter rendering / coordinate adaptation.
        action: Current candidate action that controllers may replace.
        effective_action: Last action that was actually executed on device.
        response: Last device response returned by executor.
        runtime_context: Shared execution context dictionary persisted across the run.
        adaptation_debug: Debug payload produced by action adaptation.
        action_effect_debug: Debug payload produced by post-action observation checks.
        effect_result: Optional structured post-action observation result.
    """

    observe: ObserveFn
    act: ActFn
    node: Any = None
    original_action: Any = None
    action: Any = None
    effective_action: Any = None
    response: Any = None
    runtime_context: dict[str, Any] = field(default_factory=dict)
    adaptation_debug: dict[str, Any] = field(default_factory=dict)
    action_effect_debug: dict[str, Any] = field(default_factory=dict)
    effect_result: Any = None
    before_observation: Observation | None = None


@dataclass
class WhenContext:
    """
    Unified context for all controller when functions.

    This provides a standard interface for condition evaluation,
    replacing the varied signatures across different when_* functions.

    Args:
        observation: Current observed page snapshot.
        route: Current execution route cursor.
        phase: Current control phase (before_step, before_action, etc.).
        runtime: Optional runtime facade for UTG lookups.
        policy: Optional execution policy provider.
    """

    observation: Observation
    route: RouteContext
    phase: str = ""
    runtime: Any = None
    policy: Any = None  # ExecutionPolicyProvider


@dataclass
class ControlEffect:
    """
    Minimal control-bus effect emitted by one controller.

    Args:
        kind: Effect type handled by executor or bus.
        controller_id: Stable controller id used for trace/debug.
        reason: Human-readable reason attached to the effect.
        error_code: Stable execution error code for abort effects.
        action: Replacement action for `replace_action`.
        actions: Action list for `run_actions`.
        stable: Whether refresh/run_actions should be followed by stable observation.
        debug: Optional debug payload copied into control trace.
    """

    kind: Literal[
        "abort",
        "replace_action",
        "run_actions",
        "refresh_observation",
        "human_gate",
        "handoff_human",
    ]
    controller_id: str
    reason: str | None = None
    error_code: str | None = None
    action: Any = None
    actions: list[Any] = field(default_factory=list)
    stable: bool = True
    debug: dict[str, Any] = field(default_factory=dict)


@dataclass
class ControllerResult:
    """
    Result produced by one controller evaluation round.

    Args:
        controller_id: Stable controller id.
        matched: Whether the controller `when` condition matched.
        effects: Effects returned by the controller `then` logic.
        debug: Optional debug payload for trace/debugging.
    """

    controller_id: str
    matched: bool = False
    effects: list[ControlEffect] = field(default_factory=list)
    debug: dict[str, Any] = field(default_factory=dict)


def abort_effect(
    controller_id: str,
    *,
    reason: str,
    error_code: str,
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one abort effect for a matched controller."""

    return ControlEffect(
        kind="abort",
        controller_id=str(controller_id or "").strip(),
        reason=str(reason or "").strip(),
        error_code=str(error_code or "").strip(),
        debug=dict(debug or {}),
    )


def replace_action_effect(
    controller_id: str,
    *,
    action: Any,
    reason: str = "",
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one action-replacement effect for a matched controller."""

    return ControlEffect(
        kind="replace_action",
        controller_id=str(controller_id or "").strip(),
        action=action,
        reason=str(reason or "").strip() or None,
        debug=dict(debug or {}),
    )


def run_actions_effect(
    controller_id: str,
    *,
    actions: list[Any],
    stable: bool = True,
    reason: str = "",
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one action-list effect that executor must execute on device."""

    return ControlEffect(
        kind="run_actions",
        controller_id=str(controller_id or "").strip(),
        actions=list(actions or []),
        stable=bool(stable),
        reason=str(reason or "").strip() or None,
        debug=dict(debug or {}),
    )


def refresh_observation_effect(
    controller_id: str,
    *,
    stable: bool = True,
    reason: str = "",
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one pure observation-refresh effect for a matched controller."""

    return ControlEffect(
        kind="refresh_observation",
        controller_id=str(controller_id or "").strip(),
        stable=bool(stable),
        reason=str(reason or "").strip() or None,
        debug=dict(debug or {}),
    )


def human_gate_effect(
    controller_id: str,
    *,
    reason: str = "",
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one human-confirmation barrier effect."""

    return ControlEffect(
        kind="human_gate",
        controller_id=str(controller_id or "").strip(),
        reason=str(reason or "").strip() or None,
        debug=dict(debug or {}),
    )


def handoff_human_effect(
    controller_id: str,
    *,
    reason: str,
    error_code: str,
    debug: dict[str, Any] | None = None,
) -> ControlEffect:
    """Build one explicit human-handoff barrier effect."""

    return ControlEffect(
        kind="handoff_human",
        controller_id=str(controller_id or "").strip(),
        reason=str(reason or "").strip(),
        error_code=str(error_code or "").strip(),
        debug=dict(debug or {}),
    )


def observations_equal(first: Observation | None, second: Observation | None) -> bool:
    """比较两个观测是否相等。

    用于检测动作是否有效果（页面是否变化）。
    只有当两边 package/activity 都非空时才比较，否则视为相等（宽松模式）。

    Args:
        first: 第一个观测。
        second: 第二个观测。

    Returns:
        True 如果两个观测相等。
    """
    if first is None or second is None:
        return False
    first_xml = str(getattr(first, "xml", "") or "").strip()
    second_xml = str(getattr(second, "xml", "") or "").strip()
    if first_xml != second_xml:
        return False
    # Package comparison: only compare if BOTH are non-empty
    first_package = str(getattr(first, "package_name", "") or "").strip()
    second_package = str(getattr(second, "package_name", "") or "").strip()
    if first_package and second_package and first_package != second_package:
        return False
    # Activity comparison: only compare if BOTH are non-empty
    first_activity = str(getattr(first, "activity_name", "") or "").strip()
    second_activity = str(getattr(second, "activity_name", "") or "").strip()
    if first_activity and second_activity and first_activity != second_activity:
        return False
    return True


__all__ = [
    "ActFn",
    "ControlEffect",
    "ControllerResult",
    "DeviceObservation",
    "Observation",
    "ObservationCache",
    "ObserveFn",
    "RouteContext",
    "WhenContext",
    "_coerce_device_observation",
    "act_on_device",
    "abort_effect",
    "handoff_human_effect",
    "human_gate_effect",
    "is_response_failed",
    "observations_equal",
    "observe_app_info",
    "observe_xml",
    "refresh_observation_effect",
    "replace_action_effect",
    "run_actions_effect",
]
