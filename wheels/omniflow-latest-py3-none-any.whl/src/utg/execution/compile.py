"""
Unified Semantic Compile: Goal → Function 编译器。

核心设计：
1. 收集所有候选 Functions (全局 + App + 页面)
2. 统一语义匹配 (sentence-transformers)，降级到轻量级匹配
3. 动词词表软加权（非硬过滤）
4. 编译决策: HIT / AMBIGUOUS / MISS
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import json
import logging
from pathlib import Path
import re
from time import perf_counter
from typing import Dict, List, Optional, Sequence, Set, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# ============================================================================
# 动词词表（跟随 execution 模块一起版本化）
# ============================================================================

_VERB_VOCAB_PATH = Path(__file__).with_name("verb_vocab.json")


def _load_verb_vocab() -> Tuple[Dict[str, Set[str]], Dict[str, str]]:
    """加载动词词表，返回 (synonyms, index)."""
    synonyms: Dict[str, Set[str]] = {}
    index: Dict[str, str] = {}
    try:
        with open(_VERB_VOCAB_PATH, encoding="utf-8") as f:
            data = json.load(f)
        for canonical, words in data.items():
            synonyms[canonical] = set(words)
            for word in words:
                if word not in index:
                    index[word] = canonical
    except Exception as e:
        logger.debug(f"Failed to load verb vocab: {e}, using empty")
    return synonyms, index


VERB_SYNONYMS, VERB_INDEX = _load_verb_vocab()


def extract_verbs(text: str) -> Set[str]:
    """从文本中提取动词 (返回规范化动词集合)."""
    found = set()
    text_lower = text.lower()
    for word, canonical in VERB_INDEX.items():
        if word in text_lower:
            found.add(canonical)
    return found


def get_verb_group(verb: str) -> Set[str]:
    """获取动词的同义词组."""
    canonical = VERB_INDEX.get(verb, verb)
    return VERB_SYNONYMS.get(canonical, {verb})


# ============================================================================
# 数据结构
# ============================================================================


class CompileDecision(Enum):
    """编译决策类型."""

    HIT = "hit"  # 高置信度，直接执行
    AMBIGUOUS = "ambiguous"  # 需要确认或 LLM
    MISS = "miss"  # 无匹配，Fallback LLM


class FunctionScope(Enum):
    """Function 作用域."""

    GLOBAL = "global"  # 全局可执行
    APP = "app"  # App 内可执行
    PAGE = "page"  # 特定页面可执行


@dataclass
class FunctionCandidate:
    """候选 Function."""

    function_id: str
    description: str  # 包含上下文的描述
    scope: FunctionScope
    parameter_names: Tuple[str, ...] = ()
    recall_phrases: Tuple[str, ...] = ()  # 额外召回短语

    # 来源信息
    source_app: Optional[str] = None  # App package name
    source_node_id: Optional[str] = None  # UTG node ID (PAGE scope 用)

    # Graph 结构：Function 是图的边
    from_node_id: Optional[str] = None  # 起始节点（None = 任意节点）
    to_node_id: Optional[str] = None  # 目标节点（执行后到达的页面）

    def get_searchable_text(self) -> str:
        """获取用于语义搜索的文本."""
        texts = [self.description]
        texts.extend(self.recall_phrases)
        return " | ".join(filter(None, texts))


@dataclass
class CompileConfig:
    """编译配置."""

    # 阈值
    hit_threshold: float = 0.95  # HIT 最低分数
    ambiguous_threshold: float = 0.60  # AMBIGUOUS 最低分数
    margin_threshold: float = 0.10  # 第一名与第二名的最小差距

    # 页面匹配阈值
    page_match_threshold: float = 0.80  # 页面匹配分数阈值

    # 语义模型
    model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

    # Bonus
    locality_bonus: float = 0.10
    recency_bonus: float = 0.05

    # FAISS 索引
    faiss_index_enabled: bool = True
    faiss_index_dir: str = "runtime/faiss_index"

    @classmethod
    def from_env(cls) -> "CompileConfig":
        """Create config from unified settings."""
        from src.foundation.settings import settings

        return cls(
            model_name=settings.compile.model_name,
            hit_threshold=settings.compile.hit_threshold,
            ambiguous_threshold=settings.compile.ambiguous_threshold,
            margin_threshold=settings.compile.margin_threshold,
            page_match_threshold=settings.compile.page_match_threshold,
            locality_bonus=settings.compile.locality_bonus,
            recency_bonus=settings.compile.recency_bonus,
            faiss_index_enabled=settings.compile.faiss_index_enabled,
            faiss_index_dir=settings.compile.faiss_index_dir,
        )


@dataclass
class CompileResult:
    """编译结果."""

    decision: CompileDecision
    function_id: str = ""
    score: float = 0.0
    margin: float = 0.0
    arguments: Dict[str, str] = field(default_factory=dict)
    reason: str = ""

    # Debug info
    candidate_scores: List[Tuple[str, float]] = field(default_factory=list)
    latency_ms: float = 0.0

    @property
    def success(self) -> bool:
        return self.decision == CompileDecision.HIT


@dataclass
class CompileContext:
    """编译上下文."""

    current_xml: Optional[str] = None
    current_package: Optional[str] = None
    current_node_id: Optional[str] = None  # 当前页面的 UTG node ID
    page_match_score: float = 0.0  # 页面匹配分数
    recent_function_ids: List[str] = field(default_factory=list)


# ============================================================================
# 轻量级匹配器 (Fallback)
# ============================================================================


class LightweightMatcher:
    """轻量级匹配器: 编辑距离 + N-gram Hash + 动词词表.

    当 sentence-transformers 不可用时的降级方案。
    """

    NGRAM_N = 2

    def _normalize(self, text: str) -> str:
        return text.lower().strip()

    def _extract_ngrams(self, text: str, n: int = 2) -> set:
        text = self._normalize(text)
        if len(text) < n:
            return {text} if text else set()
        return {text[i : i + n] for i in range(len(text) - n + 1)}

    def _ngram_similarity(self, text1: str, text2: str) -> float:
        ngrams1 = self._extract_ngrams(text1, self.NGRAM_N)
        ngrams2 = self._extract_ngrams(text2, self.NGRAM_N)
        if not ngrams1 or not ngrams2:
            return 0.0
        intersection = len(ngrams1 & ngrams2)
        union = len(ngrams1 | ngrams2)
        return intersection / union if union > 0 else 0.0

    def _edit_distance(self, s1: str, s2: str) -> int:
        s1, s2 = self._normalize(s1), self._normalize(s2)
        if len(s1) < len(s2):
            s1, s2 = s2, s1
        if not s2:
            return len(s1)

        prev_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            curr_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = prev_row[j + 1] + 1
                deletions = curr_row[j] + 1
                substitutions = prev_row[j] + (c1 != c2)
                curr_row.append(min(insertions, deletions, substitutions))
            prev_row = curr_row
        return prev_row[-1]

    def _edit_similarity(self, text1: str, text2: str) -> float:
        dist = self._edit_distance(text1, text2)
        max_len = max(len(text1), len(text2))
        if max_len == 0:
            return 1.0
        return 1.0 - (dist / max_len)

    def _verb_match_score(self, query: str, candidate_text: str) -> float:
        query_verbs = extract_verbs(query)
        cand_verbs = extract_verbs(candidate_text)
        if query_verbs and cand_verbs and (query_verbs & cand_verbs):
            return 0.15
        return 0.0

    def score(self, query: str, candidate_text: str) -> float:
        ngram_score = self._ngram_similarity(query, candidate_text)
        edit_score = self._edit_similarity(query, candidate_text)
        verb_bonus = self._verb_match_score(query, candidate_text)
        base_score = 0.5 * ngram_score + 0.5 * edit_score
        return min(1.0, base_score + verb_bonus)

    def rank(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        if not candidates:
            return []

        scored: List[Tuple[FunctionCandidate, float]] = []
        for candidate in candidates:
            best_score = 0.0
            if candidate.description:
                best_score = max(best_score, self.score(query, candidate.description))
            for phrase in candidate.recall_phrases:
                if phrase:
                    best_score = max(best_score, self.score(query, phrase))
            scored.append((candidate, best_score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored


# ============================================================================
# 语义匹配器
# ============================================================================


class SemanticMatcher:
    """语义匹配器: 优先 sentence-transformers，降级到 LightweightMatcher.

    支持 FAISS 索引加速：
    - 预计算所有 function embeddings 并持久化
    - 运行时只需编码 query goal（1 个文本）
    - 使用 FAISS 快速检索 top-k 候选
    """

    def __init__(self, model_name: str, index_dir: Optional[str] = None):
        self.model_name = model_name
        self.index_dir = index_dir
        self._model = None
        self._fallback: Optional[LightweightMatcher] = None
        self._use_fallback = False

        # FAISS 索引相关
        self._faiss_index = None
        self._index_phrases: List[str] = []  # 索引中的短语列表
        self._index_phrase_to_func_id: List[str] = []  # phrase idx → function_id
        self._index_func_id_to_candidate: Dict[
            str, FunctionCandidate
        ] = {}  # function_id → candidate
        self._index_loaded = False

    def _load_model(self):
        if self._model is not None or self._use_fallback:
            return

        try:
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(self.model_name)
            logger.info(f"Loaded semantic model: {self.model_name}")
        except ImportError:
            logger.warning(
                "sentence-transformers not installed, using lightweight fallback"
            )
            self._use_fallback = True
            self._fallback = LightweightMatcher()
        except Exception as e:
            logger.warning(
                f"Failed to load model {self.model_name}: {e}, using fallback"
            )
            self._use_fallback = True
            self._fallback = LightweightMatcher()

    def encode(self, texts: List[str]) -> np.ndarray:
        self._load_model()
        if self._use_fallback:
            raise RuntimeError("Fallback mode, use rank() instead")
        return self._model.encode(texts, normalize_embeddings=True)

    def build_index(self, all_candidates: List[FunctionCandidate]) -> None:
        """预计算所有 function embeddings 并构建 FAISS 索引.

        Args:
            all_candidates: 所有可能的 function 候选（来自整个 UTG）
        """
        self._load_model()

        if self._use_fallback:
            logger.info("Using fallback matcher, skipping FAISS index build")
            return

        try:
            import faiss
        except ImportError:
            logger.warning("faiss-cpu not installed, skipping index build")
            return

        # 收集所有短语
        all_phrases: List[str] = []
        phrase_to_func_id: List[str] = []
        func_id_to_candidate: Dict[str, FunctionCandidate] = {}

        for candidate in all_candidates:
            func_id_to_candidate[candidate.function_id] = candidate

            # 添加 description
            if candidate.description:
                all_phrases.append(candidate.description)
                phrase_to_func_id.append(candidate.function_id)

            # 添加 recall_phrases
            for phrase in candidate.recall_phrases:
                if phrase:
                    all_phrases.append(phrase)
                    phrase_to_func_id.append(candidate.function_id)

        if not all_phrases:
            logger.warning("No phrases to index")
            return

        logger.info(
            f"Building FAISS index for {len(all_phrases)} phrases from {len(all_candidates)} functions"
        )

        # 批量编码所有短语
        embeddings = self._model.encode(
            all_phrases,
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=256,
        )

        # 创建 FAISS 索引（使用 Inner Product，因为向量已归一化）
        embedding_dim = embeddings.shape[1]
        index = faiss.IndexFlatIP(embedding_dim)
        index.add(embeddings.astype("float32"))

        # 保存到内存
        self._faiss_index = index
        self._index_phrases = all_phrases
        self._index_phrase_to_func_id = phrase_to_func_id
        self._index_func_id_to_candidate = func_id_to_candidate
        self._index_loaded = True

        logger.info(f"FAISS index built: {index.ntotal} vectors, dim={embedding_dim}")

        # 持久化到磁盘
        if self.index_dir:
            self._save_index()

    def _save_index(self) -> None:
        """保存 FAISS 索引到磁盘."""
        if not self._faiss_index or not self.index_dir:
            return

        import os
        import pickle

        import faiss

        os.makedirs(self.index_dir, exist_ok=True)

        index_path = os.path.join(self.index_dir, "faiss.index")
        meta_path = os.path.join(self.index_dir, "faiss.meta")

        # 保存 FAISS 索引
        faiss.write_index(self._faiss_index, index_path)

        # 保存元数据
        metadata = {
            "phrases": self._index_phrases,
            "phrase_to_func_id": self._index_phrase_to_func_id,
            "func_id_to_candidate": self._index_func_id_to_candidate,
            "model_name": self.model_name,
        }

        with open(meta_path, "wb") as f:
            pickle.dump(metadata, f)

        logger.info(f"FAISS index saved to {self.index_dir}")

    def _load_index(self) -> bool:
        """从磁盘加载 FAISS 索引.

        Returns:
            是否成功加载
        """
        if not self.index_dir:
            return False

        import os
        import pickle

        try:
            import faiss
        except ImportError:
            return False

        index_path = os.path.join(self.index_dir, "faiss.index")
        meta_path = os.path.join(self.index_dir, "faiss.meta")

        if not os.path.exists(index_path) or not os.path.exists(meta_path):
            return False

        try:
            # 加载 FAISS 索引
            self._faiss_index = faiss.read_index(index_path)

            # 加载元数据
            with open(meta_path, "rb") as f:
                metadata = pickle.load(f)

            # 验证模型名称
            if metadata.get("model_name") != self.model_name:
                logger.warning(
                    f"Index model mismatch: {metadata.get('model_name')} != {self.model_name}, "
                    "will rebuild index"
                )
                return False

            self._index_phrases = metadata["phrases"]
            self._index_phrase_to_func_id = metadata["phrase_to_func_id"]
            self._index_func_id_to_candidate = metadata["func_id_to_candidate"]
            self._index_loaded = True

            logger.info(
                f"FAISS index loaded from {self.index_dir}: {self._faiss_index.ntotal} vectors"
            )
            return True

        except Exception as e:
            logger.warning(f"Failed to load FAISS index: {e}")
            return False

    def rank(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        self._load_model()

        if self._use_fallback:
            return self._fallback.rank(query, candidates)

        if not candidates:
            return []

        # 尝试使用 FAISS 加速（如果索引可用）
        if self._index_loaded and self._faiss_index:
            return self._rank_with_faiss(query, candidates)

        # 降级到原始实现（每次重新编码）
        return self._rank_original(query, candidates)

    def _rank_with_faiss(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        """使用 FAISS 索引加速的排序.

        只需编码 query（1 个文本），然后检索预计算的候选。
        """
        # 1. 编码 query（只需编码 1 个文本！）
        query_emb = self._model.encode(
            [query], normalize_embeddings=True, show_progress_bar=False
        )

        # 2. 构建候选 function_id 集合
        candidate_func_ids = {c.function_id for c in candidates}

        # 3. FAISS 检索 top-k（多检索一些，因为需要过滤）
        k = min(len(self._index_phrases), len(candidate_func_ids) * 10)
        scores, indices = self._faiss_index.search(query_emb.astype("float32"), k)

        # 4. 映射到候选 functions 并去重
        candidate_scores: Dict[str, float] = {}

        for score, idx in zip(scores[0], indices[0]):
            phrase_func_id = self._index_phrase_to_func_id[idx]

            # 只保留在候选集合中的 function
            if phrase_func_id not in candidate_func_ids:
                continue

            # 取最高分
            if phrase_func_id not in candidate_scores:
                candidate_scores[phrase_func_id] = float(score)
            else:
                candidate_scores[phrase_func_id] = max(
                    candidate_scores[phrase_func_id], float(score)
                )

        # 5. 构建结果（保留原始候选顺序，补充未检索到的为 0 分）
        ranked = []
        for candidate in candidates:
            score = candidate_scores.get(candidate.function_id, 0.0)
            ranked.append((candidate, score))

        # 6. 按分数排序
        ranked.sort(key=lambda x: x[1], reverse=True)

        return ranked

    def _rank_original(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        """原始实现：每次重新编码所有候选（降级方案）."""
        all_phrases: List[str] = []
        phrase_to_candidate: List[int] = []

        for i, c in enumerate(candidates):
            if c.description:
                all_phrases.append(c.description)
                phrase_to_candidate.append(i)
            for phrase in c.recall_phrases:
                if phrase:
                    all_phrases.append(phrase)
                    phrase_to_candidate.append(i)

        if not all_phrases:
            return []

        all_texts = [query] + all_phrases
        embeddings = self._model.encode(all_texts, normalize_embeddings=True)

        query_emb = embeddings[0]
        phrase_embs = embeddings[1:]

        phrase_scores = np.dot(phrase_embs, query_emb)

        candidate_scores = [0.0] * len(candidates)
        for phrase_idx, cand_idx in enumerate(phrase_to_candidate):
            score = float(phrase_scores[phrase_idx])
            if score > candidate_scores[cand_idx]:
                candidate_scores[cand_idx] = score

        ranked = [(candidates[i], candidate_scores[i]) for i in range(len(candidates))]
        ranked.sort(key=lambda x: x[1], reverse=True)

        return ranked


# ============================================================================
# Goal 归一化
# ============================================================================


class GoalNormalizer:
    """Goal 归一化器（用于缓存）."""

    PATTERNS = [
        (r"给[\u4e00-\u9fa5]{2,4}", "给{}"),
        (r"\d+", "{}"),
        (r"@\w+", "@{}"),
        (r"[「」『』" "''\"'].*?[「」『』" "''\"']", "{}"),
    ]

    @classmethod
    def normalize(cls, goal: str) -> str:
        result = goal
        for pattern, replacement in cls.PATTERNS:
            result = re.sub(pattern, replacement, result)
        return result

    @classmethod
    def extract_params(cls, goal: str, template: str) -> Dict[str, str]:
        pattern = re.escape(template)
        param_names = re.findall(r"\{(\w+)\}", template)

        if not param_names:
            return {}

        for i, name in enumerate(param_names):
            escaped_placeholder = re.escape(f"{{{name}}}")
            if i == len(param_names) - 1:
                pattern = pattern.replace(escaped_placeholder, f"(?P<{name}>.+)")
            else:
                pattern = pattern.replace(escaped_placeholder, f"(?P<{name}>.+?)")

        pattern = pattern + "$"
        match = re.match(pattern, goal)
        if match:
            return match.groupdict()
        return {}


# ============================================================================
# 统一编译器
# ============================================================================


class Compiler:
    """统一语义匹配编译器."""

    def __init__(
        self, config: Optional[CompileConfig] = None, index_dir: Optional[str] = None
    ):
        self.config = config or CompileConfig()

        # FAISS 索引目录（优先使用传入参数，否则使用配置）
        if index_dir is None and self.config.faiss_index_enabled:
            index_dir = self.config.faiss_index_dir

        self.index_dir = index_dir
        self._matcher = SemanticMatcher(self.config.model_name, index_dir=index_dir)

        # Function 注册表
        self._global_functions: List[FunctionCandidate] = []
        self._app_functions: Dict[str, List[FunctionCandidate]] = {}
        self._page_functions: Dict[str, List[FunctionCandidate]] = {}

        # 向量索引（旧版，保留用于兼容）
        self._vectors: Optional[np.ndarray] = None
        self._function_ids: List[str] = []

    def register_function(self, candidate: FunctionCandidate) -> None:
        """注册 Function."""
        if candidate.scope == FunctionScope.GLOBAL:
            self._global_functions.append(candidate)
        elif candidate.scope == FunctionScope.APP:
            if candidate.source_app:
                self._app_functions.setdefault(candidate.source_app, []).append(
                    candidate
                )
        elif candidate.scope == FunctionScope.PAGE:
            if candidate.source_node_id:
                self._page_functions.setdefault(candidate.source_node_id, []).append(
                    candidate
                )

    def register_functions(self, candidates: Sequence[FunctionCandidate]) -> None:
        """批量注册 Functions."""
        for candidate in candidates:
            self.register_function(candidate)

    def build_index(self) -> None:
        """构建向量索引（使用 FAISS 加速）."""
        all_funcs = list(self._global_functions)
        for funcs in self._app_functions.values():
            all_funcs.extend(funcs)
        for funcs in self._page_functions.values():
            all_funcs.extend(funcs)

        if not all_funcs:
            return

        # 如果启用了 FAISS，尝试加载或构建索引
        if self.index_dir:
            # 尝试从磁盘加载 FAISS 索引
            if self._matcher._load_index():
                logger.info("FAISS index loaded from disk, skipping rebuild")
                return

            # 使用新的 FAISS 索引构建
            self._matcher.build_index(all_funcs)

        # 旧版索引（保留用于向后兼容）
        texts = [f.get_searchable_text() for f in all_funcs]
        self._function_ids = [f.function_id for f in all_funcs]

        try:
            self._vectors = self._matcher.encode(texts)
            logger.info(f"Built compile index with {len(self._function_ids)} functions")
        except RuntimeError:
            # Fallback mode
            self._vectors = None

    def compile(
        self, goal: str, context: Optional[CompileContext] = None
    ) -> CompileResult:
        """编译 goal 到 function（内联版本 ~100 行）"""
        started_at = perf_counter()
        context = context or CompileContext()

        # 1. 验证输入
        if not goal or not goal.strip():
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="empty_goal",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        # 2. 收集候选（内联 collect_candidates）
        all_funcs = list(self._global_functions)

        if context.current_package:
            all_funcs.extend(self._app_functions.get(context.current_package, []))

        if (
            context.current_node_id
            and context.page_match_score >= self.config.page_match_threshold
        ):
            all_funcs.extend(self._page_functions.get(context.current_node_id, []))

        # Graph 约束过滤
        if context.current_node_id:
            candidates = [
                f
                for f in all_funcs
                if f.from_node_id is None or f.from_node_id == context.current_node_id
            ]
        else:
            candidates = [f for f in all_funcs if f.from_node_id is None]

        if not candidates:
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="no_candidates",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        # 3. 语义匹配 + 应用 bonuses（内联 _apply_bonuses）
        ranked = self._matcher.rank(goal, candidates)
        recent_ids = set(context.recent_function_ids or [])

        adjusted = []
        for candidate, score in ranked:
            bonus = 0.0

            # Locality bonus
            if context.current_node_id:
                if candidate.from_node_id == context.current_node_id:
                    bonus += self.config.locality_bonus
                elif candidate.from_node_id is not None:
                    bonus -= 0.02

            # Recency bonus
            if candidate.function_id in recent_ids:
                bonus += self.config.recency_bonus

            adjusted.append((candidate, score + bonus))

        adjusted.sort(key=lambda x: x[1], reverse=True)

        # 4. 做出决策（内联 _make_decision）
        if not adjusted:
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="no_match",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        top_candidate, top_score = adjusted[0]
        margin = top_score - adjusted[1][1] if len(adjusted) > 1 else 1.0
        candidate_scores = [(c.function_id, s) for c, s in adjusted[:5]]

        # 5. 返回结果
        latency_ms = (perf_counter() - started_at) * 1000

        if top_score < self.config.ambiguous_threshold:
            return CompileResult(
                decision=CompileDecision.MISS,
                score=top_score,
                margin=margin,
                reason=f"below_threshold_{top_score:.2f}",
                candidate_scores=candidate_scores,
                latency_ms=latency_ms,
            )

        if (
            top_score >= self.config.hit_threshold
            and margin >= self.config.margin_threshold
        ):
            return CompileResult(
                decision=CompileDecision.HIT,
                function_id=top_candidate.function_id,
                score=top_score,
                margin=margin,
                arguments={},
                reason="hit",
                candidate_scores=candidate_scores,
                latency_ms=latency_ms,
            )

        return CompileResult(
            decision=CompileDecision.AMBIGUOUS,
            function_id=top_candidate.function_id,
            score=top_score,
            margin=margin,
            reason=f"ambiguous_margin_{margin:.2f}"
            if margin < self.config.margin_threshold
            else f"below_hit_{top_score:.2f}",
            candidate_scores=candidate_scores,
            latency_ms=latency_ms,
        )


__all__ = [
    # Core
    "Compiler",
    "CompileConfig",
    "CompileResult",
    "CompileContext",
    "CompileDecision",
    "FunctionCandidate",
    "FunctionScope",
    # Utilities
    "GoalNormalizer",
    "SemanticMatcher",
    "LightweightMatcher",
    # Verb vocab
    "extract_verbs",
    "get_verb_group",
    "VERB_SYNONYMS",
    "VERB_INDEX",
]
