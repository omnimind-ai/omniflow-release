"""Shared utility functions for the UTG execution module."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from src.utg.execution.protocol import Observation

__all__ = [
    "safe_str",
    "safe_dict",
    "safe_list",
    "safe_float",
    "observation_to_dict",
    "parse_bounds",
    "bounds_center",
    "bounds_area",
    "point_in_bounds",
    "normalize_set_from_list",
    "slice_length",
    "extract_string_list",
    "extract_int_list",
    "format_score",
]


def safe_str(obj: Any, attr: str, default: str = "") -> str:
    """Safely extract a string attribute from an object.

    Args:
        obj: Source object to extract from.
        attr: Attribute name to extract.
        default: Default value if attribute is missing or None.

    Returns:
        Stripped string value or default.
    """
    return str(getattr(obj, attr, default) or default).strip()


def safe_dict(value: Any) -> Dict[str, Any]:
    """Safely convert a value to a dictionary.

    Args:
        value: Value to convert (dict, None, or other).

    Returns:
        The value as a dict, or empty dict if not a dict.
    """
    return dict(value) if isinstance(value, dict) else {}


def safe_list(value: Any) -> list:
    """Safely convert a value to a list.

    Args:
        value: Value to convert (list, None, or other).

    Returns:
        The value as a list, or empty list if not a list.
    """
    return list(value) if isinstance(value, (list, tuple)) else []


def observation_to_dict(obs: Optional[Observation]) -> Optional[Dict[str, Any]]:
    """Convert an Observation to a standard dictionary format.

    Args:
        obs: Observation object or None.

    Returns:
        Dictionary with vector_set, package_name, activity_name keys, or None.
    """
    if obs is None:
        return None
    return {
        "vector_set": getattr(obs, "vector_set", None),
        "package_name": safe_str(obs, "package_name"),
        "activity_name": safe_str(obs, "activity_name"),
    }


# === Geometry Utilities ===

_BOUNDS_PATTERN = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")


def parse_bounds(bounds_str: str) -> Optional[tuple[int, int, int, int]]:
    """Parse Android bounds string to (x1, y1, x2, y2) tuple.

    Args:
        bounds_str: Bounds string like "[0,0][1080,1920]".

    Returns:
        Tuple of (x1, y1, x2, y2) or None if parsing fails.
    """
    match = _BOUNDS_PATTERN.search(str(bounds_str or ""))
    if not match:
        return None
    return tuple(int(v) for v in match.groups())  # type: ignore


def bounds_center(bounds: tuple[int, int, int, int]) -> tuple[int, int]:
    """Calculate center point of bounds.

    Args:
        bounds: Tuple of (x1, y1, x2, y2).

    Returns:
        Tuple of (center_x, center_y).
    """
    x1, y1, x2, y2 = bounds
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def bounds_area(bounds: tuple[int, int, int, int]) -> int:
    """Calculate area of bounds.

    Args:
        bounds: Tuple of (x1, y1, x2, y2).

    Returns:
        Area in pixels.
    """
    x1, y1, x2, y2 = bounds
    return max(0, x2 - x1) * max(0, y2 - y1)


def point_in_bounds(x: int, y: int, bounds: tuple[int, int, int, int]) -> bool:
    """Check if a point is within bounds.

    Args:
        x: X coordinate.
        y: Y coordinate.
        bounds: Tuple of (x1, y1, x2, y2).

    Returns:
        True if point is inside bounds.
    """
    x1, y1, x2, y2 = bounds
    return x1 <= x <= x2 and y1 <= y <= y2


# === Collection Utilities ===


def normalize_set_from_list(
    items: Any,
    *,
    key: Optional[str] = None,
) -> set[str]:
    """Convert a list of items to a normalized set of strings.

    Args:
        items: List of items (strings or dicts).
        key: If items are dicts, extract this key.

    Returns:
        Set of non-empty stripped strings.
    """
    if not items:
        return set()
    result: set[str] = set()
    for item in list(items):
        if key and isinstance(item, dict):
            value = str(item.get(key) or "").strip()
        else:
            value = str(item or "").strip()
        if value:
            result.add(value)
    return result


def slice_length(value: Any) -> int:
    """Get length of a value if it's a list, otherwise 0."""
    return len(value) if isinstance(value, list) else 0


def safe_float(value: Any) -> Optional[float]:
    """安全转换为 float，失败返回 None。"""
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


def format_score(value: Any, decimals: int = 3) -> str:
    """格式化分数为固定小数位字符串。"""
    if isinstance(value, (int, float)):
        return f"{float(value):.{decimals}f}"
    return "-"


def extract_string_list(raw: Any, key: str) -> list[str]:
    """从字典中提取并规范化字符串列表。

    常用于解析配置文件中的字符串列表字段。

    Args:
        raw: 源字典或任意对象。
        key: 要提取的键名。

    Returns:
        去空格后的非空字符串列表。
    """
    if not isinstance(raw, dict):
        return []
    return [str(v) for v in list(raw.get(key) or []) if str(v).strip()]


def extract_int_list(raw: Any, key: str) -> list[int]:
    """从字典中提取并规范化整数列表。

    Args:
        raw: 源字典或任意对象。
        key: 要提取的键名。

    Returns:
        有效整数列表。
    """
    if not isinstance(raw, dict):
        return []
    result = []
    for v in list(raw.get(key) or []):
        try:
            result.append(int(v))
        except (ValueError, TypeError):
            pass
    return result
