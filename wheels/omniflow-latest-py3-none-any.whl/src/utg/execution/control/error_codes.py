EXEC_NODE_MATCH_FAIL = "EXEC_NODE_MATCH_FAIL"
EXEC_NODE_NOT_FOUND = "EXEC_NODE_NOT_FOUND"
EXEC_FUNCTION_NOT_FOUND = "EXEC_FUNCTION_NOT_FOUND"
EXEC_FUNCTION_FAIL = "EXEC_FUNCTION_FAIL"
EXEC_ACTION_FAIL = "EXEC_ACTION_FAIL"
EXEC_ACTION_NO_EFFECT = "EXEC_ACTION_NO_EFFECT"
EXEC_STATE_STALL = "EXEC_STATE_STALL"
EXEC_HUMAN_HANDOFF = "EXEC_HUMAN_HANDOFF"

# Error code descriptions for API documentation
ERROR_CODE_DESCRIPTIONS: dict[str, str] = {
    EXEC_NODE_MATCH_FAIL: "Page structure matching failed - current page doesn't match expected node",
    EXEC_NODE_NOT_FOUND: "Expected node not found in UTG graph",
    EXEC_FUNCTION_NOT_FOUND: "Function lookup failed - function_id not in store",
    EXEC_FUNCTION_FAIL: "Function execution failed with unrecoverable error",
    EXEC_ACTION_FAIL: "Device action execution failed",
    EXEC_ACTION_NO_EFFECT: "Action executed but no state change detected",
    EXEC_STATE_STALL: "Control loop stalled - max recovery rounds exceeded",
    EXEC_HUMAN_HANDOFF: "Execution escalated to human intervention",
}


def list_error_codes() -> list[dict[str, str]]:
    """Return all error codes with descriptions."""
    return [
        {"code": code, "description": desc}
        for code, desc in ERROR_CODE_DESCRIPTIONS.items()
    ]
