from __future__ import annotations

from dataclasses import dataclass
import inspect
import json
import logging
import os
import re
import sys
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.utg.core.actions import (
    OpenAppAction,
    SwipeAction,
    SwipeActionParams,
    canonical_action_type,
    make_press_back_action,
)
from src.utg.core.models import Function
from src.utg.execution.control.error_codes import (
    EXEC_ACTION_NO_EFFECT,
    EXEC_HUMAN_HANDOFF,
    EXEC_STATE_STALL,
)
from src.utg.execution.control.trigger_runtime import (
    TriggerRuntime,
    resolve_trigger_then,
    when_auto_back_after_type,
    when_handoff_human,
    when_human_gate,
    when_keyboard_dismiss,
    when_no_effect_guard,
    when_observation_trigger,
    when_open_app_verify,
    when_package_mismatch_open_app,
    when_page_mismatch_press_back,
    when_scroll_retry,
)
from src.utg.execution.execution_policy import (
    ExecutionPolicyBundle,
    ExecutionPolicyProvider,
)
from src.utg.execution.protocol import (
    ControllerResult,
    Observation,
    ObserveFn,
    RouteContext,
    WhenContext,
    _collect_observation,
    abort_effect,
    handoff_human_effect,
    human_gate_effect,
    observe_app_info,
    observe_xml,
    run_actions_effect,
)

# =============================================================================
# 效果构建器 - 简化 then 逻辑为纯函数
# =============================================================================


def _then_run_actions_with_back(
    controller_id: str,
    match: Any,
    *,
    description: str,
) -> List[Any]:
    """构建 press_back 动作效果。"""
    return [
        run_actions_effect(
            controller_id,
            actions=[make_press_back_action(description=description)],
            stable=True,
            reason=str((match or {}).get("reason") or controller_id),
            debug=dict(match or {}),
        )
    ]


def _then_open_app(controller_id: str, match: Any) -> List[Any]:
    """构建 open_app 动作效果。"""
    expected_package = str((match or {}).get("expected_package") or "").strip()
    if not expected_package:
        return []
    return [
        run_actions_effect(
            controller_id,
            actions=[
                OpenAppAction(
                    type="open_app",
                    params={"package_name": expected_package},
                    description="control_before_step_open_app",
                )
            ],
            stable=True,
            reason=str((match or {}).get("reason") or controller_id),
            debug=dict(match or {}),
        )
    ]


def _then_trigger_actions(
    controller_id: str,
    match: Any,
    observation: Observation,
) -> List[Any]:
    """构建触发器动作效果。"""
    resolved = resolve_trigger_then(match.effect, current_xml=observation.xml)
    if resolved is None or not list(resolved.actions or []):
        return []
    return [
        run_actions_effect(
            controller_id,
            actions=list(resolved.actions or []),
            stable=True,
            reason=str(getattr(match, "id", "") or controller_id),
            debug={
                "trigger_id": str(getattr(match, "id", "") or ""),
                "source": str(getattr(match, "source", "") or ""),
            },
        )
    ]


def _then_scroll_retry(match: Any) -> List[Any]:
    """构建滚动重试动作效果。"""
    direction = str((match or {}).get("direction") or "down")
    action = SwipeAction(
        type="swipe",
        params=SwipeActionParams(
            x=int(round(float((match or {}).get("selected_center_x") or 0.0))),
            y=int(
                round(
                    (
                        float((match or {}).get("viewport_top") or 0.0)
                        + float((match or {}).get("viewport_bottom") or 0.0)
                    )
                    / 2.0
                )
            ),
            direction=direction,
            distance=max(1, int((match or {}).get("distance") or 1)),
        ),
        description="control_scroll_retry",
    )
    return [
        run_actions_effect(
            SCROLL_RETRY,
            actions=[action],
            stable=True,
            reason=str(
                (match or {}).get("reason")
                or (match or {}).get("decision")
                or SCROLL_RETRY
            ),
            debug=dict(match or {}),
        )
    ]


# =============================================================================
# 控制器规格定义
# =============================================================================


@dataclass
class ControllerSpec:
    """声明式控制器规格。"""

    controller_id: str
    when_key: str  # 用于查找 when 函数
    then_key: str  # 用于查找 then 函数
    requires_utg_path_scope: bool = False
    policy_gate: str | None = None  # 策略门控字段名


logger = logging.getLogger(__name__)

OBSERVATION_TRIGGER = "observation_trigger"
HUMAN_GATE = "human_gate"
HANDOFF_HUMAN = "handoff_human"
BEFORE_ACTION_TRIGGER = "before_action_trigger"
KEYBOARD_DISMISS = "keyboard_dismiss"
SCROLL_RETRY = "scroll_retry"
MAIN_ACTION = "main_action"
AFTER_ACTION_TRIGGER = "after_action_trigger"
OPEN_APP_VERIFY = "open_app_verify"
PACKAGE_MISMATCH_OPEN_APP = "package_mismatch_open_app"
PAGE_MISMATCH_BACK_STALLED = "page_mismatch_back_stalled"
PAGE_MISMATCH_PRESS_BACK = "page_mismatch_press_back"
NO_EFFECT_GUARD = "no_effect_guard"
AUTO_BACK_AFTER_TYPE = "auto_back_after_type"

# Controller descriptions for API documentation
_CONTROLLER_DESCRIPTIONS: Dict[str, str] = {
    OBSERVATION_TRIGGER: "Match trigger pool rules against current observation",
    HUMAN_GATE: "Block execution until human confirms (env: UTG_HUMAN_GATE_*)",
    HANDOFF_HUMAN: "Escalate to human when unrecoverable (env: UTG_HANDOFF_HUMAN_*)",
    BEFORE_ACTION_TRIGGER: "Match trigger pool rules before action execution",
    KEYBOARD_DISMISS: "Dismiss keyboard when editable target mismatches",
    SCROLL_RETRY: "Scroll viewport when target is outside visible area",
    MAIN_ACTION: "Execute the primary device action",
    AFTER_ACTION_TRIGGER: "Match trigger pool rules after action execution",
    OPEN_APP_VERIFY: "Verify foreground app after open_app action",
    PACKAGE_MISMATCH_OPEN_APP: "Reopen app when foreground package differs from expected",
    PAGE_MISMATCH_BACK_STALLED: "Abort when page mismatch back recovery stalls",
    PAGE_MISMATCH_PRESS_BACK: "Press back when same-package page mismatches",
    NO_EFFECT_GUARD: "Abort when click/tap action has no state change effect",
    AUTO_BACK_AFTER_TYPE: "Auto press back after input_text if keyboard visible",
}

__all__ = [
    "AUTO_BACK_AFTER_TYPE",
    "AFTER_ACTION_TRIGGER",
    "BEFORE_ACTION_TRIGGER",
    "ControlEngine",
    "HANDOFF_HUMAN",
    "HUMAN_GATE",
    "KEYBOARD_DISMISS",
    "MAIN_ACTION",
    "NO_EFFECT_GUARD",
    "OBSERVATION_TRIGGER",
    "OPEN_APP_VERIFY",
    "PAGE_MISMATCH_BACK_STALLED",
    "PAGE_MISMATCH_PRESS_BACK",
    "PACKAGE_MISMATCH_OPEN_APP",
    "Observation",
    "SCROLL_RETRY",
    "WhenContext",
    "verify_terminal_state",
]


def _should_capture_cases() -> bool:
    """Check if test case capture is enabled (requires test environment)."""
    return (
        os.environ.get("CAPTURE_CONTROL_CASES") == "1"
        and os.environ.get("UTG_ENV") == "test"
    )


def _should_capture_hit_miss() -> bool:
    """Check if hit-miss capture is enabled (requires test environment)."""
    return (
        os.environ.get("CAPTURE_HIT_MISS") == "1"
        and os.environ.get("UTG_ENV") == "test"
    )


@dataclass(frozen=True)
class _Controller:
    controller_id: str
    when: Callable[..., Any]
    then: Callable[..., Any]


# =============================================================================
# Phase 控制器注册表 - 数据驱动的声明式配置
# =============================================================================

# 格式: (controller_id, requires_utg_path_scope, policy_gate)
# when/then 函数由 ControlEngine 根据 controller_id 动态查找

_BEFORE_STEP_CONTROLLERS: Tuple[Tuple[str, bool, str | None], ...] = (
    (HANDOFF_HUMAN, False, None),
    (HUMAN_GATE, False, None),
    (PACKAGE_MISMATCH_OPEN_APP, False, None),
    (PAGE_MISMATCH_BACK_STALLED, False, None),
    (PAGE_MISMATCH_PRESS_BACK, False, None),
    (OBSERVATION_TRIGGER, False, None),
)

_BEFORE_ACTION_CONTROLLERS: Tuple[Tuple[str, bool, str | None], ...] = (
    (HANDOFF_HUMAN, False, None),
    (HUMAN_GATE, False, None),
    (BEFORE_ACTION_TRIGGER, True, None),
    (KEYBOARD_DISMISS, True, "enable_keyboard_dismiss_re_adapt"),
    (SCROLL_RETRY, True, "enable_scroll_retry_re_adapt"),
)

_EXECUTE_ACTION_CONTROLLERS: Tuple[Tuple[str, bool, str | None], ...] = (
    (MAIN_ACTION, False, None),
)

_AFTER_ACTION_CONTROLLERS: Tuple[Tuple[str, bool, str | None], ...] = (
    (HANDOFF_HUMAN, False, None),
    (HUMAN_GATE, False, None),
    (AFTER_ACTION_TRIGGER, True, None),  # 仅 utg_path scope 时启用
    (OPEN_APP_VERIFY, False, None),
    (NO_EFFECT_GUARD, False, None),
    (AUTO_BACK_AFTER_TYPE, False, "enable_auto_press_back_after_type"),
)

_PHASE_REGISTRY: Dict[str, Tuple[Tuple[str, bool, str | None], ...]] = {
    "before_step": _BEFORE_STEP_CONTROLLERS,
    "before_action": _BEFORE_ACTION_CONTROLLERS,
    "execute_action": _EXECUTE_ACTION_CONTROLLERS,
    "after_action": _AFTER_ACTION_CONTROLLERS,
}


class ControlEngine:
    """Minimal control bus: `when` lives in trigger_runtime, `then` lives here."""

    def __init__(
        self,
        policy_provider: Optional[ExecutionPolicyProvider] = None,
    ) -> None:
        self.policy_provider = policy_provider or ExecutionPolicyBundle()
        self.trigger_runtime = TriggerRuntime(self.policy_provider)
        self._init_controller_funcs()

    def max_rounds_per_phase(self, phase: str) -> int:
        """Return executor rerun budget for one phase after `run_actions`."""

        return self.trigger_runtime.max_rounds_per_phase(phase)

    def list_controllers(self) -> list[dict[str, Any]]:
        """Return all registered controllers with their phase and config."""
        result: list[dict[str, Any]] = []
        for phase, controllers in _PHASE_REGISTRY.items():
            for controller_id, requires_scope, policy_gate in controllers:
                result.append(
                    {
                        "controller_id": controller_id,
                        "phase": phase,
                        "requires_utg_path_scope": requires_scope,
                        "policy_gate": policy_gate,
                        "description": _CONTROLLER_DESCRIPTIONS.get(controller_id, ""),
                    }
                )
        return result

    def list_trigger_pool_rules(self) -> list[dict[str, Any]]:
        """Return trigger pool rules from configuration."""
        return [
            {
                "id": spec.id,
                "phase": spec.phase,
                "enabled": spec.enabled,
                "priority": spec.priority,
                "description": spec.description,
                "source": spec.source,
            }
            for spec in self.trigger_runtime.pool.rules
        ]

    def get_trigger_pool_status(self) -> dict[str, Any]:
        """Return trigger pool status and config."""
        pool = self.trigger_runtime.pool
        return {
            "enabled": pool.enabled,
            "rule_count": len(pool.rules),
            "max_rounds_per_phase": pool.max_rounds_per_phase,
            "source_path": pool.source_path,
            "reason": pool.reason,
        }

    async def collect_effects(
        self,
        phase: str,
        observation: Observation,
        route: RouteContext,
        *,
        runtime: Any = None,
    ) -> list[ControllerResult]:
        """
        Evaluate one phase and return matched controller results up to the first barrier.

        The bus only assembles controller outputs. Device actions are executed later by
        executor when it sees `run_actions` effects.
        """

        results: list[ControllerResult] = []
        for controller in self._assemble_controllers(phase, route=route):
            match = await self._run_when(
                controller.when,
                observation=observation,
                route=route,
                runtime=runtime,
            )
            if match in (None, False):
                continue
            effects = await self._run_then(
                controller.then,
                observation=observation,
                route=route,
                runtime=runtime,
                match=match,
            )
            result = ControllerResult(
                controller_id=controller.controller_id,
                matched=True,
                effects=list(effects or []),
                debug=self._debug_from_effects(list(effects or [])),
            )
            self._apply_inline_route_mutations(route, result.effects)
            self._record_result(phase, route, result)
            results.append(result)
            if self._has_barrier_effect(result.effects):
                break
        return results

    async def observe(
        self,
        observe: ObserveFn,
        *,
        stable: bool,
        include_xml: bool = True,
        include_app_info: bool = True,
    ) -> Observation:
        """Capture one normalized observation for the control bus.

        Args:
            observe: Live observe function used to observe the device state.
            stable: Whether XML capture should wait for a stable page snapshot.
            include_xml: Whether this observation needs XML content.
            include_app_info: Whether this observation needs package/activity info.

        Returns:
            One normalized control-bus observation with PageVectorSet.
        """
        from src.utg.assets.embedding.vector_set import xml_to_vector_set

        vector_set = None
        xml_text = ""
        package_name = ""
        activity_name = ""

        if include_xml or include_app_info:
            try:
                observed = await _collect_observation(
                    observe,
                    xml=include_xml,
                    screenshot=False,
                    app_info=include_app_info,
                )
                xml_text = str(getattr(observed, "xml", "") or "")
                package_name = str(getattr(observed, "package_name", "") or "")
                activity_name = str(getattr(observed, "activity_name", "") or "")

                # Convert XML to PageVectorSet immediately
                if include_xml and xml_text:
                    try:
                        vector_set = xml_to_vector_set(
                            xml_content=xml_text,
                            page_id=f"{package_name}_{activity_name}",
                            package_name=package_name,
                        )
                    except Exception as e:
                        logger.warning(f"Failed to convert XML to PageVectorSet: {e}")
                        vector_set = None

            except Exception as e:
                logger.warning(f"Failed to collect observation: {e}")
                vector_set = None
                package_name = ""
                activity_name = ""

        return Observation(
            xml=str(xml_text or "").strip() if include_xml else None,
            vector_set=vector_set,
            package_name=str(package_name or "").strip(),
            activity_name=str(activity_name or "").strip(),
        )

    async def verify_terminal_state(
        self,
        runtime: Any,
        observe: ObserveFn,
        *,
        function_id: Optional[str] = None,
        function: Optional[Function] = None,
        arguments: Optional[Dict[str, Any]] = None,
        execution_result: Any = None,
        action_type: Optional[str] = None,
        respect_env: bool = True,
        include_app_identity: bool = True,
    ) -> Dict[str, Any]:
        """Verify whether the current page has reached the terminal node for a function."""

        return await verify_terminal_state(
            runtime,
            observe,
            function_id=function_id,
            function=function,
            arguments=arguments,
            execution_result=execution_result,
            action_type=action_type,
            respect_env=respect_env,
            include_app_identity=include_app_identity,
        )

    def _assemble_controllers(
        self, phase: str, *, route: Optional[RouteContext] = None
    ) -> tuple[_Controller, ...]:
        """根据注册表组装当前 phase 的控制器列表。"""
        registry = _PHASE_REGISTRY.get(phase)
        if not registry:
            return ()

        runtime_context = (
            getattr(route, "runtime_context", {})
            if route is not None
            and isinstance(getattr(route, "runtime_context", {}), dict)
            else {}
        )
        control_scope = str(
            runtime_context.get("__utg_control_scope__", "utg_path") or "utg_path"
        ).strip()
        is_utg_path_scope = control_scope == "utg_path"
        path_config = self.policy_provider.path_config()
        disabled_controllers = {
            str(item or "").strip()
            for item in list(runtime_context.get("__utg_disabled_controllers__") or [])
            if str(item or "").strip()
        }

        controllers: list[_Controller] = []
        for controller_id, requires_utg_path, policy_gate in registry:
            if controller_id in disabled_controllers:
                continue
            # 检查 scope 条件
            if requires_utg_path and not is_utg_path_scope:
                continue
            # 检查策略门控
            if policy_gate and not getattr(path_config, policy_gate, False):
                continue
            # 查找 when/then 函数
            when_fn, then_fn = self._get_controller_funcs(controller_id)
            if when_fn and then_fn:
                controllers.append(_Controller(controller_id, when_fn, then_fn))

        return tuple(controllers)

    def _init_controller_funcs(self) -> None:
        """初始化控制器函数映射表。"""
        self._controller_funcs: Dict[
            str, Tuple[Callable[..., Any], Callable[..., Any]]
        ] = {
            HANDOFF_HUMAN: (self._when_handoff_human, self._then_handoff_human),
            HUMAN_GATE: (self._when_human_gate, self._then_human_gate),
            PACKAGE_MISMATCH_OPEN_APP: (
                self._when_package_mismatch_open_app,
                self._then_package_mismatch_open_app,
            ),
            PAGE_MISMATCH_BACK_STALLED: (
                self._when_page_mismatch_back_stalled,
                self._then_page_mismatch_back_stalled,
            ),
            PAGE_MISMATCH_PRESS_BACK: (
                self._when_page_mismatch_press_back,
                self._then_page_mismatch_press_back,
            ),
            OBSERVATION_TRIGGER: (
                self._when_observation_trigger,
                self._then_observation_trigger,
            ),
            BEFORE_ACTION_TRIGGER: (
                self._when_before_action_trigger,
                self._then_before_action_trigger,
            ),
            KEYBOARD_DISMISS: (
                self._when_keyboard_dismiss,
                self._then_keyboard_dismiss,
            ),
            SCROLL_RETRY: (self._when_scroll_retry, self._then_scroll_retry),
            MAIN_ACTION: (self._when_main_action, self._then_main_action),
            OPEN_APP_VERIFY: (self._when_open_app_verify, self._then_open_app_verify),
            AFTER_ACTION_TRIGGER: (
                self._when_after_action_trigger,
                self._then_after_action_trigger,
            ),
            NO_EFFECT_GUARD: (self._when_no_effect_guard, self._then_no_effect_guard),
            AUTO_BACK_AFTER_TYPE: (
                self._when_auto_back_after_type,
                self._then_auto_back_after_type,
            ),
        }

    def _get_controller_funcs(
        self, controller_id: str
    ) -> tuple[Callable[..., Any] | None, Callable[..., Any] | None]:
        """根据 controller_id 返回 (when_fn, then_fn) 元组。"""
        return self._controller_funcs.get(controller_id, (None, None))

    async def _run_when(self, fn: Callable[..., Any], **kwargs: Any) -> Any:
        result = fn(**kwargs)
        if inspect.isawaitable(result):
            return await result
        return result

    async def _run_then(self, fn: Callable[..., Any], **kwargs: Any) -> list[Any]:
        result = fn(**kwargs)
        if inspect.isawaitable(result):
            result = await result
        return list(result or [])

    def _make_when_context(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> WhenContext:
        """Create unified WhenContext for when_* functions."""
        phase = str(route.runtime_context.get("__utg_current_phase__", "") or "")
        return WhenContext(
            observation=observation,
            route=route,
            phase=phase,
            runtime=runtime,
            policy=self.policy_provider,
        )

    def _apply_inline_route_mutations(
        self,
        route: RouteContext,
        effects: list[Any],
    ) -> None:
        runtime_context = (
            route.runtime_context if isinstance(route.runtime_context, dict) else {}
        )
        for effect in list(effects or []):
            effect_kind = getattr(effect, "kind", "")
            if effect_kind == "replace_action":
                route.action = getattr(effect, "action", None)
                continue
            if effect_kind == "human_gate":
                seen = runtime_context.setdefault("__utg_human_gate_seen__", set())
                if not isinstance(seen, set):
                    seen = {str(item) for item in list(seen or []) if str(item).strip()}
                    runtime_context["__utg_human_gate_seen__"] = seen
                seen.add(str(getattr(effect, "debug", {}).get("gate_key", "") or ""))
                continue
            if effect_kind == "handoff_human":
                seen = runtime_context.setdefault("__utg_handoff_human_seen__", set())
                if not isinstance(seen, set):
                    seen = {str(item) for item in list(seen or []) if str(item).strip()}
                    runtime_context["__utg_handoff_human_seen__"] = seen
                seen.add(str(getattr(effect, "debug", {}).get("gate_key", "") or ""))

    @staticmethod
    def _has_barrier_effect(effects: list[Any]) -> bool:
        return any(
            getattr(effect, "kind", "")
            in {
                "abort",
                "run_actions",
                "refresh_observation",
                "human_gate",
                "handoff_human",
            }
            for effect in list(effects or [])
        )

    @staticmethod
    def _debug_from_effects(effects: list[Any]) -> dict[str, Any]:
        if not effects:
            return {}
        first = effects[0]
        return dict(getattr(first, "debug", {}) or {})

    def _record_result(
        self,
        phase: str,
        route: RouteContext,
        result: ControllerResult,
    ) -> None:
        runtime_context = (
            route.runtime_context if isinstance(route.runtime_context, dict) else {}
        )
        step_index = runtime_context.get("__utg_current_step_index__")
        try:
            step_index = int(step_index)
        except Exception:
            step_index = getattr(getattr(route, "step", None), "index", None)
        if step_index is None:
            return
        controls = runtime_context.setdefault("__utg_control_trace__", {})
        if not isinstance(controls, dict):
            return
        bucket = controls.setdefault(int(step_index), [])
        if not isinstance(bucket, list):
            return
        effect = result.effects[0] if result.effects else None
        status = "matched"
        reason = ""
        error_code = None
        if effect is not None:
            status = {
                "abort": "blocked",
                "run_actions": "triggered",
                "replace_action": "triggered",
                "refresh_observation": "triggered",
                "human_gate": "triggered",
                "handoff_human": "blocked",
            }.get(getattr(effect, "kind", ""), "matched")
            reason = str(getattr(effect, "reason", "") or "")
            error_code = getattr(effect, "error_code", None)
        bucket.append(
            {
                "plane_id": result.controller_id,
                "phase": str(phase or ""),
                "status": status,
                "reason": reason or None,
                "error_code": error_code,
                "extra": dict(result.debug or {}) or None,
            }
        )
        trace_logger = runtime_context.get("__utg_execution_trace_logger__")
        if getattr(trace_logger, "enabled", False):
            control_event = trace_logger.build_trace_event(
                event_type="control",
                run_id=str(
                    runtime_context.get("__utg_execution_trace_run_id__", "") or ""
                ),
                function_id=str(
                    runtime_context.get("__utg_execution_trace_function_id__", "")
                    or getattr(getattr(route, "path", None), "id", "")
                    or ""
                ),
                payload={
                    "step_index": int(step_index),
                    "plane_id": result.controller_id,
                    "phase": str(phase or ""),
                    "status": status,
                    "reason": reason or None,
                    "error_code": error_code,
                    "extra": dict(result.debug or {}) or None,
                },
            )
            trace_logger.write_event(control_event)
            if bool(runtime_context.get("__utg_execution_trace_echo__")):
                print(
                    json.dumps(control_event, ensure_ascii=False),
                    file=sys.stderr,
                    flush=True,
                )

        # 捕获测试用例 (CAPTURE_CONTROL_CASES=1 and UTG_ENV=test)
        if _should_capture_cases() and status == "triggered":
            self._save_captured_case(phase, route, result, runtime_context)

        # 捕获 Hit-Miss 事件 (CAPTURE_HIT_MISS=1 and UTG_ENV=test)
        if _should_capture_hit_miss():
            self._capture_hit_miss_event(phase, route, result, runtime_context, status)

    def _capture_hit_miss_event(
        self,
        phase: str,
        route: RouteContext,
        result: ControllerResult,
        runtime_context: dict,
        status: str,
    ) -> None:
        """捕获 Hit-Miss 事件用于论文分析"""
        from datetime import datetime
        from pathlib import Path

        capture_dir = (
            Path(__file__).parent.parent.parent.parent.parent
            / "tests"
            / "control_plane_benchmark"
            / "captured_hit_miss"
        )
        capture_dir.mkdir(parents=True, exist_ok=True)

        run_id = str(runtime_context.get("__utg_execution_trace_run_id__", "unknown"))
        step_index = runtime_context.get("__utg_current_step_index__", 0)
        obs = runtime_context.get("__utg_current_observation__")

        # 判断 Hit/Miss
        event_type = "miss" if status == "triggered" else "hit"

        event = {
            "timestamp": datetime.now().isoformat(),
            "run_id": run_id,
            "step_index": step_index,
            "phase": phase,
            "event_type": event_type,
            "controller_id": result.controller_id if status == "triggered" else None,
            "package_name": getattr(obs, "package_name", "") if obs else "",
            "expected_package": getattr(
                getattr(route, "step", None), "expected_package", None
            ),
            "recovery_action": (
                getattr(result.effects[0], "kind", "")
                if result.effects and status == "triggered"
                else None
            ),
            "observation_xml_preview": (
                (getattr(obs, "xml", "") or "")[:500] if obs else None
            ),
        }

        filepath = capture_dir / f"{run_id}.jsonl"
        with filepath.open("a") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

    def _save_captured_case(
        self,
        phase: str,
        route: RouteContext,
        result: ControllerResult,
        runtime_context: dict,
    ) -> None:
        """保存触发的 controller 作为测试用例（含完整 XML）"""
        from datetime import datetime
        from pathlib import Path

        capture_dir = (
            Path(__file__).parent.parent.parent.parent.parent
            / "tests"
            / "control_plane_benchmark"
            / "cases"
            / "captured"
        )
        capture_dir.mkdir(parents=True, exist_ok=True)

        controller_id = result.controller_id or "unknown"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

        obs = runtime_context.get("__utg_current_observation__")
        case = {
            "case_id": f"{controller_id}_{timestamp}",
            "captured_at": datetime.now().isoformat(),
            "phase": str(phase),
            "controller": controller_id,
            "observation": {
                "xml": getattr(obs, "xml", "") if obs else "",
                "package_name": getattr(obs, "package_name", "") if obs else "",
                "activity_name": getattr(obs, "activity_name", "") if obs else "",
            },
            "action": {
                "type": getattr(route.action, "type", "") if route.action else "",
                "params": dict(getattr(route.action, "params", {}) or {})
                if route.action
                else {},
            },
            "step": {
                "index": getattr(getattr(route, "step", None), "index", None),
                "expected_package": getattr(
                    getattr(route, "step", None), "expected_package", None
                ),
            },
            "result": {
                "matched": result.matched,
                "effect_kind": getattr(result.effects[0], "kind", "")
                if result.effects
                else "",
                "debug": dict(result.debug or {}),
            },
        }

        filepath = capture_dir / f"{controller_id}_{timestamp}.json"
        filepath.write_text(json.dumps(case, indent=2, ensure_ascii=False))

    def _when_observation_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        return when_observation_trigger(
            self.trigger_runtime,
            runtime=runtime,
            observation=observation,
            route=route,
        )

    def _when_package_mismatch_open_app(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_package_mismatch_open_app(ctx)

    def _then_package_mismatch_open_app(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        expected_package = str((match or {}).get("expected_package") or "").strip()
        if not expected_package:
            return []
        return [
            run_actions_effect(
                PACKAGE_MISMATCH_OPEN_APP,
                actions=[
                    OpenAppAction(
                        type="open_app",
                        params={"package_name": expected_package},
                        description="control_before_step_open_app",
                    )
                ],
                stable=True,
                reason=str((match or {}).get("reason") or PACKAGE_MISMATCH_OPEN_APP),
                debug=dict(match or {}),
            )
        ]

    def _when_page_mismatch_back_stalled(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        match = when_page_mismatch_press_back(ctx)
        if match is None:
            return None
        runtime_context = (
            route.runtime_context if isinstance(route.runtime_context, dict) else {}
        )
        no_change_count = int(
            runtime_context.get("__utg_page_mismatch_back_no_change_count__", 0) or 0
        )
        if no_change_count < 2:
            return None
        return {
            **dict(match or {}),
            "reason": "page_mismatch_back_stalled",
            "no_change_back_count": no_change_count,
        }

    def _then_page_mismatch_back_stalled(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        return [
            abort_effect(
                PAGE_MISMATCH_BACK_STALLED,
                reason=str((match or {}).get("reason") or PAGE_MISMATCH_BACK_STALLED),
                error_code=EXEC_STATE_STALL,
                debug=dict(match or {}),
            )
        ]

    def _when_page_mismatch_press_back(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_page_mismatch_press_back(ctx)

    def _then_page_mismatch_press_back(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        return [
            run_actions_effect(
                PAGE_MISMATCH_PRESS_BACK,
                actions=[
                    make_press_back_action(
                        description="control_before_step_page_mismatch_back"
                    )
                ],
                stable=True,
                reason=str((match or {}).get("reason") or PAGE_MISMATCH_PRESS_BACK),
                debug=dict(match or {}),
            )
        ]

    def _when_human_gate(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_human_gate(ctx)

    def _then_human_gate(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, runtime
        phase = str(
            (match or {}).get("phase")
            or route.runtime_context.get("__utg_current_phase__", "")
            or ""
        )
        return [
            human_gate_effect(
                HUMAN_GATE,
                reason=f"human gate before {phase or 'phase'}",
                debug=self._build_human_debug_payload(
                    route=route, phase=phase, match=match
                ),
            )
        ]

    def _when_handoff_human(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_handoff_human(ctx)

    def _then_handoff_human(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, runtime
        phase = str(
            (match or {}).get("phase")
            or route.runtime_context.get("__utg_current_phase__", "")
            or ""
        )
        return [
            handoff_human_effect(
                HANDOFF_HUMAN,
                reason=f"handoff to human before {phase or 'phase'}",
                error_code=EXEC_HUMAN_HANDOFF,
                debug=self._build_human_debug_payload(
                    route=route, phase=phase, match=match
                ),
            )
        ]

    def _then_observation_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del route, runtime
        resolved = resolve_trigger_then(match.effect, current_xml=observation.xml)
        if resolved is None or not list(resolved.actions or []):
            return []
        return [
            run_actions_effect(
                OBSERVATION_TRIGGER,
                actions=list(resolved.actions or []),
                stable=True,
                reason=str(getattr(match, "id", "") or OBSERVATION_TRIGGER),
                debug={
                    "trigger_id": str(getattr(match, "id", "") or ""),
                    "source": str(getattr(match, "source", "") or ""),
                },
            )
        ]

    def _when_keyboard_dismiss(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_keyboard_dismiss(ctx)

    def _then_keyboard_dismiss(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        return [
            run_actions_effect(
                KEYBOARD_DISMISS,
                actions=[
                    make_press_back_action(description="control_keyboard_dismiss")
                ],
                stable=True,
                reason=str((match or {}).get("reason") or KEYBOARD_DISMISS),
                debug=dict(match or {}),
            )
        ]

    def _when_before_action_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        return self.trigger_runtime.match_trigger(
            runtime=runtime,
            phase="before_action",
            observation=observation,
            route=route,
        )

    def _then_before_action_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del route, runtime
        resolved = resolve_trigger_then(match.effect, current_xml=observation.xml)
        if resolved is None or not list(resolved.actions or []):
            return []
        return [
            run_actions_effect(
                BEFORE_ACTION_TRIGGER,
                actions=list(resolved.actions or []),
                stable=True,
                reason=str(getattr(match, "id", "") or BEFORE_ACTION_TRIGGER),
                debug={
                    "trigger_id": str(getattr(match, "id", "") or ""),
                    "source": str(getattr(match, "source", "") or ""),
                },
            )
        ]

    def _when_scroll_retry(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_scroll_retry(ctx)

    def _then_scroll_retry(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        direction = str((match or {}).get("direction") or "down")
        action = SwipeAction(
            type="swipe",
            params=SwipeActionParams(
                x=int(round(float((match or {}).get("selected_center_x") or 0.0))),
                y=int(
                    round(
                        (
                            float((match or {}).get("viewport_top") or 0.0)
                            + float((match or {}).get("viewport_bottom") or 0.0)
                        )
                        / 2.0
                    )
                ),
                direction=direction,
                distance=max(1, int((match or {}).get("distance") or 1)),
            ),
            description="control_scroll_retry",
        )
        return [
            run_actions_effect(
                SCROLL_RETRY,
                actions=[action],
                stable=True,
                reason=str(
                    (match or {}).get("reason")
                    or (match or {}).get("decision")
                    or SCROLL_RETRY
                ),
                debug=dict(match or {}),
            )
        ]

    def _when_main_action(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        del observation, runtime
        return route.action is not None

    def _then_main_action(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, runtime, match
        if route.action is None:
            return []
        return [
            run_actions_effect(
                MAIN_ACTION,
                actions=[route.action],
                stable=True,
                reason=MAIN_ACTION,
            )
        ]

    def _when_open_app_verify(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_open_app_verify(ctx)

    def _then_open_app_verify(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del route, runtime
        expected_package = str((match or {}).get("expected_package") or "").strip()
        if expected_package and (
            observation.package_name == expected_package
            or _xml_mentions_package(observation.xml, expected_package)
        ):
            return []
        reason = "open_app foreground verification failed"
        if expected_package:
            reason = (
                f"open_app foreground verification failed: expected_package={expected_package}, "
                f"observed_package={observation.package_name or '-'}"
            )
        return [
            abort_effect(
                OPEN_APP_VERIFY,
                reason=reason,
                error_code="EXEC_OPEN_APP_FOREGROUND_MISMATCH",
                debug=dict(match or {}),
            )
        ]

    def _when_after_action_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        return self.trigger_runtime.match_trigger(
            runtime=runtime,
            phase="after_action",
            observation=observation,
            route=route,
        )

    def _then_after_action_trigger(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del route, runtime
        resolved = resolve_trigger_then(match.effect, current_xml=observation.xml)
        if resolved is None or not list(resolved.actions or []):
            return []
        return [
            run_actions_effect(
                AFTER_ACTION_TRIGGER,
                actions=list(resolved.actions or []),
                stable=True,
                reason=str(getattr(match, "id", "") or AFTER_ACTION_TRIGGER),
                debug={
                    "trigger_id": str(getattr(match, "id", "") or ""),
                    "source": str(getattr(match, "source", "") or ""),
                },
            )
        ]

    def _when_no_effect_guard(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_no_effect_guard(ctx)

    def _then_no_effect_guard(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, runtime, match
        action = route.effective_action or route.action
        reason = _build_action_no_effect_message(action)
        return [
            abort_effect(
                NO_EFFECT_GUARD,
                reason=reason,
                error_code=EXEC_ACTION_NO_EFFECT,
            )
        ]

    def _when_auto_back_after_type(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
    ) -> Any:
        ctx = self._make_when_context(
            observation=observation, route=route, runtime=runtime
        )
        return when_auto_back_after_type(ctx)

    def _then_auto_back_after_type(
        self,
        *,
        observation: Observation,
        route: RouteContext,
        runtime: Any = None,
        match: Any = None,
    ) -> list[Any]:
        del observation, route, runtime
        return [
            run_actions_effect(
                AUTO_BACK_AFTER_TYPE,
                actions=[
                    make_press_back_action(description="control_auto_back_after_type")
                ],
                stable=True,
                reason=str((match or {}).get("reason") or AUTO_BACK_AFTER_TYPE),
                debug=dict(match or {}),
            )
        ]

    @staticmethod
    def _build_human_debug_payload(
        *,
        route: RouteContext,
        phase: str,
        match: Any = None,
    ) -> dict[str, Any]:
        action = getattr(route, "action", None)
        original_action = getattr(route, "original_action", None)
        return {
            "phase": str(phase or ""),
            "function_id": str(getattr(getattr(route, "path", None), "id", "") or ""),
            "node_id": str(getattr(getattr(route, "node", None), "id", "") or ""),
            "step_index": getattr(getattr(route, "step", None), "index", None),
            "action_type": str(getattr(action, "type", "") or ""),
            "original_action_type": str(getattr(original_action, "type", "") or ""),
            "action": _action_debug_payload(action),
            "original_action": _action_debug_payload(original_action),
            "match": dict(match or {}),
        }


def _make_terminal_state_unverified(reason: str) -> dict[str, Any]:
    return {
        "verifiable": False,
        "terminal_page_reached": None,
        "reason": str(reason or ""),
    }


def _action_debug_payload(action: Any) -> dict[str, Any] | None:
    if action is None:
        return None
    params = getattr(action, "params", None)
    if hasattr(params, "model_dump"):
        try:
            params = params.model_dump()
        except Exception:
            params = repr(params)
    return {
        "type": str(getattr(action, "type", "") or ""),
        "description": getattr(action, "description", None),
        "params": params
        if isinstance(params, (dict, list, str, int, float, bool, type(None)))
        else repr(params),
    }


async def verify_terminal_state(
    runtime: Any,
    observe: ObserveFn,
    *,
    function_id: Optional[str] = None,
    function: Any = None,
    arguments: Optional[Dict[str, Any]] = None,
    execution_result: Any = None,
    action_type: Optional[str] = None,
    respect_env: bool = True,
    include_app_identity: bool = True,
) -> Dict[str, Any]:
    """Verify whether the current page has reached the terminal node for one function."""

    if respect_env:
        from src.foundation.settings import settings

        if not settings.execution.terminal_node_verify:
            return _make_terminal_state_unverified("terminal_disabled")
    if _is_system_level_terminal_bypass_action(
        execution_result=execution_result,
        action_type=action_type,
    ):
        return _make_terminal_state_unverified("system_level_action")

    resolved_func = function
    if resolved_func is None:
        func_id_text = str(function_id or "").strip()
        if not func_id_text:
            return _make_terminal_state_unverified("no_compiled_function")
        get_function_by_id = getattr(runtime, "get_function_by_id", None)
        if not callable(get_function_by_id):
            return _make_terminal_state_unverified("runtime_missing_function_lookup")
        resolved_func = get_function_by_id(func_id_text)
        if resolved_func is None:
            return _make_terminal_state_unverified("function_not_found")

    end_node_id = str(getattr(resolved_func, "end_node_id", "") or "").strip()
    if not end_node_id:
        return _make_terminal_state_unverified("function_has_no_terminal_node")

    get_node_by_id = getattr(runtime, "get_node_by_id", None)
    if not callable(get_node_by_id):
        return _make_terminal_state_unverified("runtime_missing_node_lookup")
    expected_node = get_node_by_id(end_node_id)
    if expected_node is None:
        return _make_terminal_state_unverified("terminal_node_not_found")

    # 优先使用 VectorSet 版本，fallback 到 XML 版本
    is_page_match_node = getattr(
        runtime, "_is_current_page_match_node_from_vector_set", None
    )
    if not callable(is_page_match_node):
        # Fallback to XML version for backward compatibility
        is_page_match_node = getattr(runtime, "_is_current_page_match_node", None)
    if not callable(is_page_match_node):
        return _make_terminal_state_unverified("runtime_missing_terminal_matcher")

    cached_final_state = None
    run_log = getattr(execution_result, "run_log", None)
    if run_log is None and isinstance(execution_result, dict):
        run_log = execution_result.get("run_log")
    if isinstance(run_log, dict):
        maybe_final_state = run_log.get("final_state")
        if isinstance(maybe_final_state, dict):
            cached_final_state = maybe_final_state
    if cached_final_state is None:
        maybe_final_state = getattr(execution_result, "final_observation", None)
        if maybe_final_state is None and isinstance(execution_result, dict):
            maybe_final_state = execution_result.get("final_observation")
        if isinstance(maybe_final_state, dict):
            cached_final_state = maybe_final_state

    # Get current vector_set (优先使用 cached，否则 observe)
    current_vector_set = (cached_final_state or {}).get("vector_set")
    if current_vector_set is None:
        # Fallback: observe to get vector_set
        try:
            from src.utg.execution.control.engine import ControlEngine

            # 如果 runtime 有 control_engine，使用它的 observe
            control_engine = getattr(runtime, "_control_engine", None)
            if control_engine and isinstance(control_engine, ControlEngine):
                obs = await control_engine.observe(
                    observe, stable=True, include_xml=True, include_app_info=True
                )
                current_vector_set = obs.vector_set
            else:
                # Fallback to XML-based approach (backward compatibility)
                current_xml = await observe_xml(observe)
                from src.utg.assets.embedding.vector_set import xml_to_vector_set

                (
                    current_package_name_temp,
                    current_activity_name_temp,
                ) = await observe_app_info(observe)
                current_vector_set = xml_to_vector_set(
                    xml_content=current_xml,
                    page_id=f"{current_package_name_temp}_{current_activity_name_temp}",
                    package_name=current_package_name_temp or "",
                )
        except Exception as exc:
            return _make_terminal_state_unverified(f"observe_failed:{exc}")

    current_package_name: str | None = (
        str((cached_final_state or {}).get("package_name") or "").strip() or None
    )
    current_activity_name: str | None = (
        str((cached_final_state or {}).get("activity_name") or "").strip() or None
    )

    # 如果 package/activity 信息不在 cache，从 vector_set 获取
    if current_vector_set and not current_package_name:
        current_package_name = getattr(current_vector_set, "package_name", None)

    if include_app_identity and not current_package_name and not current_activity_name:
        try:
            current_package_name, current_activity_name = await observe_app_info(
                observe
            )
        except Exception as exc:
            return _make_terminal_state_unverified(f"observe_failed:{exc}")

    expected_package_name = str(
        getattr(getattr(expected_node, "repr", None), "packageName", "") or ""
    ).strip()
    package_matched = None
    if include_app_identity and expected_package_name:
        package_matched = (
            str(current_package_name or "").strip() == expected_package_name
        )

    # 使用 VectorSet 进行结构匹配（优先）
    structure_matched = False
    if current_vector_set:
        structure_matched = bool(is_page_match_node(current_vector_set, expected_node))
    else:
        structure_matched = False

    widget_tokens = _collect_terminal_widget_tokens(expected_node)
    missing_widgets = [
        token
        for token in widget_tokens
        if not _vector_set_contains_terminal_token(current_vector_set, token)
    ]
    field_tokens = _collect_terminal_field_tokens(dict(arguments or {}))
    missing_fields = [
        token
        for token in field_tokens
        if not _vector_set_contains_terminal_token(current_vector_set, token)
    ]
    terminal_page_reached = bool(
        (package_matched is not False)
        and structure_matched
        and not missing_widgets
        and not missing_fields
    )
    return {
        "verifiable": True,
        "terminal_page_reached": terminal_page_reached,
        "reason": "verified" if terminal_page_reached else "terminal_page_not_reached",
        "page_identity": {
            "expected_package_name": expected_package_name or None,
            "observed_package_name": str(current_package_name or "").strip() or None,
            "observed_activity_name": str(current_activity_name or "").strip() or None,
            "package_matched": package_matched,
            "structure_matched": structure_matched,
            "terminal_node_id": end_node_id,
        },
        "key_widgets": {
            "required": widget_tokens,
            "missing": missing_widgets,
            "matched": not missing_widgets,
        },
        "key_fields": {
            "required": field_tokens,
            "missing": missing_fields,
            "matched": not missing_fields,
        },
    }


def _build_action_no_effect_message(action: Any) -> str:
    action_type = canonical_action_type(getattr(action, "type", None))
    return f"[run_function] Action had no effect: {action_type or 'unknown'}"


def _xml_mentions_package(xml: str, package_name: str) -> bool:
    if not xml or not package_name:
        return False
    escaped = re.escape(package_name)
    return any(
        re.search(pattern, xml)
        for pattern in (
            rf'package\s*=\s*"{escaped}"',
            rf"package\s*=\s*'{escaped}'",
        )
    )


def _normalize_terminal_text(value: Any) -> str:
    return " ".join(str(value or "").strip().split())


def _collect_terminal_widget_tokens(expected_node: Any) -> list[str]:
    tokens: list[str] = []
    repr_obj = getattr(expected_node, "repr", None)
    if repr_obj is None:
        return tokens

    # Use new match_rules if available
    match_rules = getattr(repr_obj, "match_rules", None)
    if match_rules:
        for req in getattr(match_rules, "required", []) or []:
            token = _normalize_terminal_text(req)
            if token:
                tokens.append(token)
        return list(dict.fromkeys(tokens))

    # Fallback to legacy nodeFilter
    node_filter = list(getattr(repr_obj, "nodeFilter", []) or [])
    for item in node_filter:
        if not isinstance(item, dict):
            continue
        for key in (
            "text",
            "content-desc",
            "content_description",
            "hint-text",
            "hint_text",
            "resource-id",
            "resource_id",
            "resource-name",
            "resource_name",
        ):
            token = _normalize_terminal_text(item.get(key))
            if token:
                tokens.append(token)
    return list(dict.fromkeys(tokens))


def _collect_terminal_field_tokens(arguments: Dict[str, Any]) -> list[str]:
    tokens: list[str] = []
    ignored_parameter_names = ("package", "activity", "app", "path", "node", "function")
    for key, value in dict(arguments or {}).items():
        key_text = str(key or "").strip().lower()
        if any(part in key_text for part in ignored_parameter_names):
            continue
        token = _normalize_terminal_text(value)
        if not token:
            continue
        if "." in token and " " not in token and "/" not in token:
            continue
        tokens.append(token)
    return list(dict.fromkeys(tokens))


def _xml_contains_terminal_token(xml_text: str, token: str) -> bool:
    """已废弃，使用 _vector_set_contains_terminal_token() 代替."""
    xml_norm = _normalize_terminal_text(xml_text).lower()
    token_norm = _normalize_terminal_text(token).lower()
    return bool(token_norm) and token_norm in xml_norm


def _vector_set_contains_terminal_token(vector_set, token: str) -> bool:
    """Check if vector_set contains the terminal token in any node text.

    Args:
        vector_set: PageVectorSet to search
        token: Token to find

    Returns:
        True if token found in any node's text, content_desc, or resource_id
    """
    from src.utg.assets.embedding.vector_set import PageVectorSet

    if vector_set is None or not isinstance(vector_set, PageVectorSet):
        return False

    token_norm = _normalize_terminal_text(token).lower()
    if not token_norm:
        return False

    # Search in all nodes
    for node in vector_set.nodes:
        # Check text
        if node.text:
            text_norm = _normalize_terminal_text(node.text).lower()
            if token_norm in text_norm:
                return True
        # Check content_desc
        if node.content_desc:
            desc_norm = _normalize_terminal_text(node.content_desc).lower()
            if token_norm in desc_norm:
                return True
        # Check resource_id
        if node.resource_id:
            rid_norm = _normalize_terminal_text(node.resource_id).lower()
            if token_norm in rid_norm:
                return True

    return False


def _is_system_level_terminal_bypass_action(
    *,
    execution_result: Any = None,
    action_type: Optional[str] = None,
) -> bool:
    if action_type not in (None, ""):
        action_type_name = canonical_action_type(action_type)
        if action_type_name == "press_key":
            return True
        if action_type_name == "open_app":
            return not _execution_result_has_cached_final_state(execution_result)
        return False
    if execution_result is None:
        return False
    run_log = getattr(execution_result, "run_log", None)
    if run_log is None and isinstance(execution_result, dict):
        run_log = execution_result.get("run_log")
    if isinstance(run_log, dict):
        action_effect = run_log.get("action_effect")
        if isinstance(action_effect, dict):
            action_type_name = canonical_action_type(action_effect.get("action_type"))
            if action_type_name == "press_key":
                return True
            if action_type_name == "open_app":
                return not _execution_result_has_cached_final_state(execution_result)
    return False


def _execution_result_has_cached_final_state(execution_result: Any) -> bool:
    run_log = getattr(execution_result, "run_log", None)
    if run_log is None and isinstance(execution_result, dict):
        run_log = execution_result.get("run_log")
    if isinstance(run_log, dict) and isinstance(run_log.get("final_state"), dict):
        return True
    final_observation = getattr(execution_result, "final_observation", None)
    if final_observation is None and isinstance(execution_result, dict):
        final_observation = execution_result.get("final_observation")
    return isinstance(final_observation, dict) and bool(final_observation)
