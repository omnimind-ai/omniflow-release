"""
Execution Tracer

Extracts execution tracing logic from Executor.
Handles action trace logging and effect debugging.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any, Optional

from src.utg.core.models import Function
from src.utg.execution.protocol import RouteContext

logger = logging.getLogger(__name__)


class ExecutionTracer:
    """Execution tracing utility.

    Provides action trace logging and effect debugging capabilities.
    """

    def __init__(self, last_action_effect_debug: Optional[dict] = None):
        """Initialize the tracer.

        Args:
            last_action_effect_debug: Shared dict for last action effect debug info
        """
        self.last_action_effect_debug = last_action_effect_debug or {}

    def write_action_trace(
        self,
        trace_logger: Any,
        *,
        route: RouteContext,
        function: Function,
        action_index: int,
    ) -> None:
        """Write the action trace event after the action has been adapted.

        Args:
            trace_logger: The trace logger instance
            route: Current route context
            function: The function being executed
            action_index: Index of the action in the function
        """
        if not getattr(trace_logger, "enabled", False):
            return

        action_params = getattr(route.action, "params", None)
        if hasattr(action_params, "model_dump"):
            try:
                action_params = action_params.model_dump()
            except Exception as exc:
                logger.debug("Action params model_dump failed: %s", exc)

        action_event = trace_logger.build_trace_event(
            event_type="action",
            run_id=str(
                route.runtime_context.get("__utg_execution_trace_run_id__", "") or ""
            ),
            function_id=str(
                route.runtime_context.get("__utg_execution_trace_function_id__", "")
                or getattr(getattr(route, "path", None), "id", "")
                or ""
            ),
            payload={
                "step_index": int(
                    route.runtime_context.get("__utg_current_step_index__", 0) or 0
                ),
                "node_id": str(getattr(route.node, "id", "") or ""),
                "function_name": str(getattr(function, "name", "") or ""),
                "action_index": int(action_index),
                "action_type": str(getattr(route.action, "type", "") or ""),
                "action_params": action_params,
            },
        )
        trace_logger.write_event(action_event)

        if bool(route.runtime_context.get("__utg_execution_trace_echo__")):
            print(
                json.dumps(action_event, ensure_ascii=False),
                file=sys.stderr,
                flush=True,
            )

    def log_action_effect_debug(self, action: Any) -> None:
        """Emit the compact action-effect summary used by run logging and debugging.

        Args:
            action: The action that was executed
        """
        if not self.last_action_effect_debug:
            return

        logger.info(
            "[action_effect] action=%s reason=%s xml_changed=%s",
            getattr(action, "type", "unknown"),
            self.last_action_effect_debug.get("reason"),
            self.last_action_effect_debug.get("xml_changed"),
        )


__all__ = ["ExecutionTracer"]
