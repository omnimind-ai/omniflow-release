"""
Action Parameter Renderer

Extracts parameter rendering logic from Executor.
Handles ${param} expression rendering in action parameters.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from src.utg.core.models import AnyAction
from src.utg.core.params import ParamRenderer

logger = logging.getLogger(__name__)


class ActionParamRenderer:
    """Action parameter rendering utility.

    Renders ${param} expressions in action parameters using runtime context.
    """

    @staticmethod
    def render(action: AnyAction, context: dict) -> AnyAction:
        """Render parameter expressions inside one action using the runtime context.

        Args:
            action: The action to render parameters for
            context: Runtime context containing parameter values

        Returns:
            A deep copy of the action with rendered parameters
        """
        if not context or not hasattr(action, "params"):
            return action

        rendered = action.model_copy(deep=True)
        params = getattr(rendered, "params", None)
        if params is None:
            return rendered

        if isinstance(params, BaseModel):
            data = params.model_dump()
            data = ActionParamRenderer._render_value(data, context)
            try:
                rendered.params = params.__class__(**data)
            except Exception as exc:
                logger.debug(
                    "Parameter rendering failed for %s: %s",
                    params.__class__.__name__,
                    exc,
                )
                return rendered
            return rendered

        if isinstance(params, dict):
            rendered.params = ActionParamRenderer._render_value(params, context)

        return rendered

    @staticmethod
    def _render_value(value: Any, context: dict) -> Any:
        """Render one nested parameterized value tree with the runtime context.

        Args:
            value: The value to render (can be string, list, dict, or other)
            context: Runtime context containing parameter values

        Returns:
            The rendered value
        """
        if isinstance(value, str) and "${" in value:
            return ParamRenderer.render(value, context, strict=False)
        if isinstance(value, list):
            return [ActionParamRenderer._render_value(v, context) for v in value]
        if isinstance(value, dict):
            return {
                k: ActionParamRenderer._render_value(v, context)
                for k, v in value.items()
            }
        return value


__all__ = ["ActionParamRenderer"]
