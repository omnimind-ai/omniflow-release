"""Execution control layer public surface.

Compile architecture:
- Unified semantic matching with lightweight fallback
- Verb vocabulary: src/utg/execution/verb_vocab.json
"""

from src.utg.execution.compile import (
    VERB_INDEX,
    VERB_SYNONYMS,
    CompileConfig,
    CompileContext,
    CompileDecision,
    Compiler,
    CompileResult,
    FunctionCandidate,
    FunctionScope,
    GoalNormalizer,
    LightweightMatcher,
    SemanticMatcher,
    extract_verbs,
    get_verb_group,
)

__all__ = [
    # Compile
    "Compiler",
    "CompileConfig",
    "CompileContext",
    "CompileDecision",
    "CompileResult",
    "FunctionCandidate",
    "FunctionScope",
    "GoalNormalizer",
    "SemanticMatcher",
    "LightweightMatcher",
    # Verb vocab
    "extract_verbs",
    "get_verb_group",
    "VERB_SYNONYMS",
    "VERB_INDEX",
]
