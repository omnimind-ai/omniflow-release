"""UTG Memory Export - 将 UTG 导出为 RAG Memory 格式。

核心功能：
1. 导出 Node 描述 - 页面状态信息，供模型理解当前位置
2. 导出 Function - 可调用能力，供模型决策
3. 构建关系图 - 节点间转移关系

输出格式兼容：
- OpenAI Function Calling
- Anthropic Tool Use
- MCP Tool
"""

from __future__ import annotations

from dataclasses import dataclass, field
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pydantic import BaseModel, Field

from src.utg.core.models import Function, UTGGraph, UTGNode

logger = logging.getLogger(__name__)


# =============================================================================
# 输出数据结构
# =============================================================================


class NodeMemory(BaseModel):
    """Node 的 RAG Memory 表示。"""

    id: str = Field(..., description="节点唯一标识")
    package: str = Field(default="", description="应用包名")
    activity: str = Field(default="", description="Activity 名称")

    # 语义描述（可由 VLM/LLM 增强）
    description: str = Field(default="", description="页面描述")
    visual_summary: str = Field(default="", description="视觉摘要（VLM 生成）")
    visual_elements: List[str] = Field(default_factory=list, description="页面关键元素")

    # 能力与关系
    available_functions: List[str] = Field(
        default_factory=list, description="当前页面可用的 function"
    )
    can_reach: List[str] = Field(
        default_factory=list, description="从当前页面可到达的节点"
    )
    reachable_from: List[str] = Field(
        default_factory=list, description="可到达当前页面的节点"
    )

    # 匹配特征
    signatures: List[str] = Field(default_factory=list, description="页面签名关键词")
    xml_sample: str = Field(default="", description="XML 样本（用于 VLM 分析）")

    # 元数据
    metadata: Dict[str, Any] = Field(default_factory=dict)


class FunctionMemory(BaseModel):
    """Function 的标准格式（兼容 OpenAI/Anthropic/MCP）。"""

    id: str = Field(..., description="Function 唯一标识")
    name: str = Field(..., description="Function 名称")
    description: str = Field(default="", description="Function 描述（支持参数模板）")

    # OpenAI Function Calling 兼容
    parameters: Dict[str, Any] = Field(
        default_factory=lambda: {
            "type": "object",
            "properties": {},
            "required": [],
        },
        description="JSON Schema 参数定义",
    )

    # 前后置条件
    precondition: Dict[str, Any] = Field(
        default_factory=dict,
        description="前置条件（需要在哪个 Node）",
    )
    postcondition: Dict[str, Any] = Field(
        default_factory=dict,
        description="后置条件（执行后到哪个 Node）",
    )

    # 执行信息
    actions_count: int = Field(default=0, description="动作数量")
    is_composite: bool = Field(default=False, description="是否为复合函数")
    source_node_id: Optional[str] = Field(default=None, description="来源节点 ID")

    # 元数据
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AppMemory(BaseModel):
    """App 级别的 RAG Memory 表示。"""

    package: str = Field(..., description="应用包名")
    name: str = Field(default="", description="应用名称")

    # 语义描述（可由 LLM 增强）
    description: str = Field(default="", description="应用整体描述")
    capabilities: List[str] = Field(
        default_factory=list, description="应用核心能力列表"
    )

    # 结构信息
    nodes: List[str] = Field(default_factory=list, description="该应用的所有节点 ID")
    functions: List[str] = Field(
        default_factory=list, description="该应用的所有 function ID"
    )
    entry_nodes: List[str] = Field(default_factory=list, description="应用入口节点")

    # 跨应用关系
    can_navigate_to: List[str] = Field(
        default_factory=list, description="可跳转到的其他应用包名"
    )
    navigable_from: List[str] = Field(
        default_factory=list, description="可从哪些应用跳转过来"
    )

    # 元数据
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GraphMemory(BaseModel):
    """UTG 图的关系表示。"""

    nodes: List[str] = Field(default_factory=list, description="所有节点 ID")
    edges: List[Dict[str, str]] = Field(
        default_factory=list,
        description="边列表 [{from, to, function}]",
    )
    entry_nodes: List[str] = Field(default_factory=list, description="入口节点")
    apps: List[Dict[str, str]] = Field(default_factory=list, description="应用信息")


class UTGMemoryBundle(BaseModel):
    """完整的 UTG Memory 导出包。"""

    version: str = Field(default="1.0.0")
    apps: List[AppMemory] = Field(default_factory=list)
    nodes: List[NodeMemory] = Field(default_factory=list)
    functions: List[FunctionMemory] = Field(default_factory=list)
    graph: GraphMemory = Field(default_factory=GraphMemory)
    metadata: Dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# 导出器
# =============================================================================


@dataclass
class UTGMemoryExporter:
    """UTG Memory 导出器。"""

    utg: UTGGraph
    include_xml_sample: bool = True
    max_xml_length: int = 5000  # XML 样本最大长度

    # 内部状态
    _node_functions: Dict[str, List[str]] = field(default_factory=dict)
    _function_sources: Dict[str, str] = field(default_factory=dict)
    _edges: List[Dict[str, str]] = field(default_factory=list)
    _reachable_from: Dict[str, Set[str]] = field(default_factory=dict)
    _package_nodes: Dict[str, List[str]] = field(default_factory=dict)
    _package_functions: Dict[str, List[str]] = field(default_factory=dict)
    _cross_app_edges: Dict[str, Set[str]] = field(default_factory=dict)

    def export(self) -> UTGMemoryBundle:
        """导出完整的 Memory Bundle。"""
        self._build_indices()

        apps = self._export_all_apps()
        nodes = [self._export_node(node) for node in self.utg.nodes]
        functions = self._export_all_functions()
        graph = self._export_graph()

        return UTGMemoryBundle(
            version="1.0.0",
            apps=apps,
            nodes=nodes,
            functions=functions,
            graph=graph,
            metadata={
                "utg_version": self.utg.version,
                "app_count": len(apps),
                "node_count": len(nodes),
                "function_count": len(functions),
            },
        )

    def _build_indices(self) -> None:
        """构建内部索引。"""
        self._node_functions = {}
        self._function_sources = {}
        self._edges = []
        self._reachable_from = {node.id: set() for node in self.utg.nodes}
        self._package_nodes = {}
        self._package_functions = {}
        self._cross_app_edges = {}  # package -> set of reachable packages

        # 构建 node -> package 映射
        node_package_map: Dict[str, str] = {}
        for node in self.utg.nodes:
            pkg = node.repr.packageName or ""
            node_package_map[node.id] = pkg
            if pkg not in self._package_nodes:
                self._package_nodes[pkg] = []
                self._package_functions[pkg] = []
                self._cross_app_edges[pkg] = set()
            self._package_nodes[pkg].append(node.id)

        # 索引节点级 functions
        for node in self.utg.nodes:
            self._node_functions[node.id] = list(node.functions.keys())
            pkg = node.repr.packageName or ""
            for func_name in node.functions:
                func_id = f"{node.id}:{func_name}"
                self._function_sources[func_id] = node.id
                if pkg:
                    self._package_functions[pkg].append(func_id)

        # 索引全局 functions 并提取边
        for func_name, func in self.utg.functions.items():
            self._function_sources[func_name] = func.start_node_id or ""

            # 从 actions 中提取 call_function 构建边
            current_node = func.start_node_id
            for action in func.actions:
                action_type = getattr(action, "type", "")
                if action_type == "call_function":
                    params = getattr(action, "params", None)
                    if params:
                        next_node = getattr(params, "node_id", None)
                        if current_node and next_node and current_node != next_node:
                            self._edges.append(
                                {
                                    "from": current_node,
                                    "to": next_node,
                                    "function": func_name,
                                }
                            )
                            self._reachable_from[next_node].add(current_node)
                            # 检测跨应用边
                            from_pkg = node_package_map.get(current_node, "")
                            to_pkg = node_package_map.get(next_node, "")
                            if from_pkg and to_pkg and from_pkg != to_pkg:
                                self._cross_app_edges[from_pkg].add(to_pkg)
                        current_node = next_node

            # end_node_id 作为终点
            if func.end_node_id and current_node and current_node != func.end_node_id:
                self._reachable_from[func.end_node_id].add(current_node)

            # 将全局 function 关联到起始 package
            if func.start_node_id:
                start_pkg = node_package_map.get(func.start_node_id, "")
                if start_pkg:
                    self._package_functions[start_pkg].append(func_name)

    def _export_node(self, node: UTGNode) -> NodeMemory:
        """导出单个 Node。"""
        # 提取可到达的节点
        can_reach = set()
        for edge in self._edges:
            if edge["from"] == node.id:
                can_reach.add(edge["to"])

        # 提取 XML 样本
        xml_sample = ""
        if self.include_xml_sample and node.repr.xmls:
            xml_sample = node.repr.xmls[0]
            if len(xml_sample) > self.max_xml_length:
                xml_sample = xml_sample[: self.max_xml_length] + "..."

        # 提取签名关键词
        signatures = self._extract_signatures(node)

        return NodeMemory(
            id=node.id,
            package=node.repr.packageName or "",
            activity="",  # NodeRepr 不包含 activityName
            description=node.repr.description or "",
            visual_summary="",  # 待 VLM 增强
            visual_elements=[],  # 待 VLM 增强
            available_functions=list(node.functions.keys()),
            can_reach=list(can_reach),
            reachable_from=list(self._reachable_from.get(node.id, set())),
            signatures=signatures,
            xml_sample=xml_sample,
            metadata=dict(node.metadata or {}),
        )

    def _extract_signatures(self, node: UTGNode) -> List[str]:
        """从 Node 提取签名关键词。"""
        signatures = []

        # 从 description 提取
        if node.repr.description:
            signatures.append(node.repr.description)

        # 从 match_rules 提取（新格式）
        if node.repr.match_rules:
            for req in node.repr.match_rules.required or []:
                if req.strip():
                    signatures.append(req)
        else:
            # Fallback: 从 nodeFilter 提取（旧格式）
            for filter_item in node.repr.nodeFilter or []:
                if isinstance(filter_item, dict):
                    for key in ["text", "content-desc", "resource-id"]:
                        if key in filter_item:
                            signatures.append(str(filter_item[key]))

        return list(set(s for s in signatures if s.strip()))

    def _export_all_apps(self) -> List[AppMemory]:
        """导出所有 App 级别的 Memory。"""
        apps = []

        for app_info in self.utg.appInfo:
            pkg = app_info.packageName
            app = self._export_app(pkg, app_info.appName)
            apps.append(app)

        # 处理没有在 appInfo 中但有节点的 package
        known_packages = {app.packageName for app in self.utg.appInfo}
        for pkg in self._package_nodes:
            if pkg and pkg not in known_packages:
                app = self._export_app(pkg, "")
                apps.append(app)

        return apps

    def _export_app(self, package: str, name: str) -> AppMemory:
        """导出单个 App。"""
        nodes = self._package_nodes.get(package, [])
        functions = self._package_functions.get(package, [])

        # 找入口节点（该应用中没有 reachable_from 的节点，或 reachable_from 来自其他应用）
        entry_nodes = []
        for node_id in nodes:
            reachable_from = self._reachable_from.get(node_id, set())
            # 如果没有来源，或所有来源都来自其他应用
            same_app_sources = [
                src for src in reachable_from if self._get_node_package(src) == package
            ]
            if not same_app_sources:
                entry_nodes.append(node_id)

        # 跨应用关系
        can_navigate_to = list(self._cross_app_edges.get(package, set()))
        navigable_from = [
            pkg for pkg, targets in self._cross_app_edges.items() if package in targets
        ]

        # 生成能力列表（从 function 名称提取）
        capabilities = self._extract_app_capabilities(package)

        return AppMemory(
            package=package,
            name=name,
            description="",  # 待 LLM 增强
            capabilities=capabilities,
            nodes=nodes,
            functions=functions,
            entry_nodes=entry_nodes,
            can_navigate_to=can_navigate_to,
            navigable_from=navigable_from,
        )

    def _get_node_package(self, node_id: str) -> str:
        """获取节点所属的 package。"""
        for node in self.utg.nodes:
            if node.id == node_id:
                return node.repr.packageName or ""
        return ""

    def _extract_app_capabilities(self, package: str) -> List[str]:
        """从应用的 functions 中提取能力列表。"""
        capabilities = set()
        functions = self._package_functions.get(package, [])

        for func_id in functions:
            # 从 function 名称提取动词短语
            if ":" in func_id:
                name = func_id.split(":")[-1]
            else:
                name = func_id
            # 简单处理：用下划线分割，取前两个词
            parts = name.replace("_", " ").split()
            if parts:
                capabilities.add(" ".join(parts[:2]))

        return list(capabilities)[:10]  # 限制数量

    def _export_all_functions(self) -> List[FunctionMemory]:
        """导出所有 Functions。"""
        functions = []

        # 导出节点级 functions
        for node in self.utg.nodes:
            for func_name, func in node.functions.items():
                func_memory = self._export_function(
                    func,
                    func_id=f"{node.id}:{func_name}",
                    source_node_id=node.id,
                    is_composite=False,
                )
                functions.append(func_memory)

        # 导出全局 functions
        for func_name, func in self.utg.functions.items():
            func_memory = self._export_function(
                func,
                func_id=func_name,
                source_node_id=func.start_node_id,
                is_composite=True,
            )
            functions.append(func_memory)

        return functions

    def _export_function(
        self,
        func: Function,
        func_id: str,
        source_node_id: Optional[str],
        is_composite: bool,
    ) -> FunctionMemory:
        """导出单个 Function。"""
        return FunctionMemory(
            id=func_id,
            name=func.name,
            description=func.description or "",
            parameters=dict(func.parameters),
            precondition=(
                {"node_id": func.start_node_id}
                if func.start_node_id
                else {"node_id": source_node_id}
                if source_node_id
                else {}
            ),
            postcondition=({"node_id": func.end_node_id} if func.end_node_id else {}),
            actions_count=len(func.actions),
            is_composite=is_composite,
            source_node_id=source_node_id,
            metadata=dict(func.metadata or {}),
        )

    def _export_graph(self) -> GraphMemory:
        """导出图结构。"""
        # 找入口节点（没有 reachable_from 的节点）
        entry_nodes = [
            node.id for node in self.utg.nodes if not self._reachable_from.get(node.id)
        ]

        return GraphMemory(
            nodes=[node.id for node in self.utg.nodes],
            edges=self._edges,
            entry_nodes=entry_nodes,
            apps=[
                {"name": app.appName, "package": app.packageName}
                for app in self.utg.appInfo
            ],
        )


# =============================================================================
# 便捷函数
# =============================================================================


def export_utg_memory(
    utg: UTGGraph,
    *,
    include_xml: bool = True,
) -> UTGMemoryBundle:
    """导出 UTG 为 Memory Bundle。"""
    exporter = UTGMemoryExporter(utg=utg, include_xml_sample=include_xml)
    return exporter.export()


def export_utg_memory_to_dir(
    utg: UTGGraph,
    output_dir: str | Path,
    *,
    include_xml: bool = True,
) -> Path:
    """导出 UTG Memory 到目录。"""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    bundle = export_utg_memory(utg, include_xml=include_xml)

    # 写入主文件
    (output_path / "memory.json").write_text(
        bundle.model_dump_json(indent=2), encoding="utf-8"
    )

    # 写入 apps
    apps_dir = output_path / "apps"
    apps_dir.mkdir(exist_ok=True)
    for app in bundle.apps:
        safe_pkg = app.package.replace(".", "_")
        (apps_dir / f"{safe_pkg}.json").write_text(
            app.model_dump_json(indent=2), encoding="utf-8"
        )

    # 写入 nodes
    nodes_dir = output_path / "nodes"
    nodes_dir.mkdir(exist_ok=True)
    for node in bundle.nodes:
        (nodes_dir / f"{node.id}.json").write_text(
            node.model_dump_json(indent=2), encoding="utf-8"
        )

    # 写入 functions
    functions_dir = output_path / "functions"
    functions_dir.mkdir(exist_ok=True)
    for func in bundle.functions:
        safe_id = func.id.replace(":", "_")
        (functions_dir / f"{safe_id}.json").write_text(
            func.model_dump_json(indent=2), encoding="utf-8"
        )

    # 写入图结构
    (output_path / "graph.json").write_text(
        bundle.graph.model_dump_json(indent=2), encoding="utf-8"
    )

    logger.info(
        "Exported UTG memory: %d apps, %d nodes, %d functions -> %s",
        len(bundle.apps),
        len(bundle.nodes),
        len(bundle.functions),
        output_path,
    )
    return output_path


def export_functions_for_llm(utg: UTGGraph) -> List[Dict[str, Any]]:
    """导出 Functions 为 LLM Tool 格式（OpenAI/Anthropic 兼容）。"""
    bundle = export_utg_memory(utg, include_xml=False)
    return [
        {
            "name": func.name,
            "description": func.description,
            "parameters": func.parameters,
        }
        for func in bundle.functions
    ]


# 向后兼容别名
def export_node_context(
    utg: UTGGraph,
    node_id: str,
) -> Optional[Dict[str, Any]]:
    """导出单个 Node 的上下文（用于 RAG 查询）。"""
    bundle = export_utg_memory(utg, include_xml=True)

    for node in bundle.nodes:
        if node.id == node_id:
            # 找到关联的 functions
            related_functions = [
                f
                for f in bundle.functions
                if f.source_node_id == node_id
                or (f.precondition and f.precondition.get("node_id") == node_id)
            ]
            return {
                "node": node.model_dump(),
                "available_functions": [f.model_dump() for f in related_functions],
                "graph_position": {
                    "can_reach": node.can_reach,
                    "reachable_from": node.reachable_from,
                },
            }
    return None


def export_app_context(
    utg: UTGGraph,
    package: str,
) -> Optional[Dict[str, Any]]:
    """导出单个 App 的上下文（用于 RAG 查询）。"""
    bundle = export_utg_memory(utg, include_xml=False)

    for app in bundle.apps:
        if app.package == package:
            # 找到关联的 nodes 和 functions
            related_nodes = [n for n in bundle.nodes if n.package == package]
            related_functions = [f for f in bundle.functions if f.id in app.functions]
            return {
                "app": app.model_dump(),
                "nodes": [n.model_dump() for n in related_nodes],
                "functions": [f.model_dump() for f in related_functions],
            }
    return None


# =============================================================================
# 自然语言转换（用于 RAG 存储）
# =============================================================================


def function_to_natural_language(func: FunctionMemory, app_name: str = "") -> str:
    """将 Function 转换为自然语言描述（用于 RAG）。"""
    lines = []

    # 标题
    lines.append(f"## 功能：{func.name}")
    lines.append("")

    # 所属应用
    if app_name:
        lines.append(f"**所属应用**: {app_name}")
        lines.append("")

    # 功能描述
    lines.append("**功能描述**:")
    if func.description:
        lines.append(func.description)
    else:
        lines.append(f"执行 {func.name} 操作。")
    lines.append("")

    # 参数
    props = func.parameters.get("properties", {})
    required = func.parameters.get("required", [])
    if props:
        lines.append("**参数**:")
        for param_name, param_info in props.items():
            param_desc = param_info.get("description", "")
            param_type = param_info.get("type", "string")
            is_required = "必填" if param_name in required else "可选"
            lines.append(f"- {param_name} ({param_type}, {is_required}): {param_desc}")
        lines.append("")
    else:
        lines.append("**参数**: 无")
        lines.append("")

    # 前置条件
    if func.precondition:
        node_id = func.precondition.get("node_id", "")
        if node_id:
            lines.append(f"**前置条件**: 需要在页面 {node_id}")
            lines.append("")

    # 执行结果
    if func.postcondition:
        node_id = func.postcondition.get("node_id", "")
        if node_id:
            lines.append(f"**执行结果**: 跳转到页面 {node_id}")
            lines.append("")

    return "\n".join(lines)


# 向后兼容别名
def node_to_natural_language(node: NodeMemory) -> str:
    """将 Node 转换为自然语言描述（用于 RAG）。"""
    lines = []

    # 标题
    lines.append(f"## 页面：{node.id}")
    lines.append("")

    # 所属应用
    if node.package:
        lines.append(f"**所属应用**: {node.package}")
        lines.append("")

    # 页面描述
    lines.append("**页面描述**:")
    if node.description:
        lines.append(node.description)
    elif node.signatures:
        lines.append(f"包含 {', '.join(node.signatures[:5])} 等元素的页面。")
    else:
        lines.append("未知页面。")
    lines.append("")

    # 视觉元素
    if node.visual_elements:
        lines.append("**页面元素**:")
        for elem in node.visual_elements[:10]:
            lines.append(f"- {elem}")
        lines.append("")

    # 可用函数
    if node.available_functions:
        lines.append("**可执行的操作**:")
        for func in node.available_functions:
            lines.append(f"- {func}")
        lines.append("")

    # 可到达的页面
    if node.can_reach:
        lines.append("**可跳转到**:")
        for target in node.can_reach:
            lines.append(f"- {target}")
        lines.append("")

    # 页面签名
    if node.signatures:
        lines.append(f"**关键词**: {', '.join(node.signatures)}")
        lines.append("")

    return "\n".join(lines)


def app_to_natural_language(app: AppMemory) -> str:
    """将 App 转换为自然语言描述（用于 RAG）。"""
    lines = []

    # 标题
    display_name = app.name or app.package.split(".")[-1]
    lines.append(f"## 应用：{display_name}")
    lines.append("")

    # 包名
    lines.append(f"**包名**: {app.package}")
    lines.append("")

    # 应用描述
    if app.description:
        lines.append("**应用描述**:")
        lines.append(app.description)
        lines.append("")

    # 核心能力
    if app.capabilities:
        lines.append("**核心能力**:")
        for cap in app.capabilities:
            lines.append(f"- {cap}")
        lines.append("")

    # 包含的页面
    if app.nodes:
        lines.append(f"**包含页面**: {len(app.nodes)} 个")
        for node_id in app.nodes[:10]:
            lines.append(f"- {node_id}")
        if len(app.nodes) > 10:
            lines.append(f"- ... 等共 {len(app.nodes)} 个页面")
        lines.append("")

    # 入口页面
    if app.entry_nodes:
        lines.append("**入口页面**:")
        for node_id in app.entry_nodes:
            lines.append(f"- {node_id}")
        lines.append("")

    # 可用功能
    if app.functions:
        lines.append(f"**可用功能**: {len(app.functions)} 个")
        for func_id in app.functions[:10]:
            lines.append(f"- {func_id}")
        if len(app.functions) > 10:
            lines.append(f"- ... 等共 {len(app.functions)} 个功能")
        lines.append("")

    # 跨应用导航
    if app.can_navigate_to:
        lines.append("**可跳转到的应用**:")
        for pkg in app.can_navigate_to:
            lines.append(f"- {pkg}")
        lines.append("")

    return "\n".join(lines)


def export_memory_as_documents(
    utg: UTGGraph,
) -> List[Dict[str, Any]]:
    """导出 Memory 为文档列表（用于 RAG 向量化）。

    返回格式:
    [
        {
            "id": "app:com.android.settings",
            "type": "app",
            "content": "## 应用：设置\\n...",
            "metadata": {"package": "com.android.settings", ...}
        },
        ...
    ]
    """
    bundle = export_utg_memory(utg, include_xml=False)
    documents = []

    # 导出 Apps
    for app in bundle.apps:
        documents.append(
            {
                "id": f"app:{app.package}",
                "type": "app",
                "content": app_to_natural_language(app),
                "metadata": {
                    "package": app.package,
                    "name": app.name,
                    "node_count": len(app.nodes),
                    "function_count": len(app.functions),
                },
            }
        )

    # 导出 Nodes
    for node in bundle.nodes:
        documents.append(
            {
                "id": f"node:{node.id}",
                "type": "node",
                "content": node_to_natural_language(node),
                "metadata": {
                    "node_id": node.id,
                    "package": node.package,
                    "function_count": len(node.available_functions),
                },
            }
        )

    # 导出 Functions
    # 先构建 package -> app_name 映射
    pkg_to_name = {app.package: app.name for app in bundle.apps}

    for func in bundle.functions:
        # 获取 function 所属的 app name
        source_node = next(
            (n for n in bundle.nodes if n.id == func.source_node_id), None
        )
        app_name = ""
        if source_node:
            app_name = pkg_to_name.get(source_node.package, "")

        documents.append(
            {
                "id": f"function:{func.id}",
                "type": "function",
                "content": function_to_natural_language(func, app_name),
                "metadata": {
                    "function_id": func.id,
                    "name": func.name,
                    "source_node": func.source_node_id,
                    "has_params": bool(func.parameters.get("properties")),
                },
            }
        )

    return documents


def export_memory_to_markdown_dir(
    utg: UTGGraph,
    output_dir: str | Path,
) -> Path:
    """导出 Memory 为 Markdown 文件（用于 RAG）。"""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    documents = export_memory_as_documents(utg)

    # 按类型分目录
    for doc in documents:
        doc_type = doc["type"]
        doc_id = doc["id"].replace(":", "/").replace(".", "_")
        type_dir = output_path / doc_type
        type_dir.mkdir(exist_ok=True)

        # 写入 markdown
        filename = doc_id.split("/")[-1] + ".md"
        (type_dir / filename).write_text(doc["content"], encoding="utf-8")

    logger.info(
        "Exported %d documents to %s",
        len(documents),
        output_path,
    )
    return output_path


__all__ = [
    "AppMemory",
    "NodeMemory",
    "FunctionMemory",
    "GraphMemory",
    "UTGMemoryBundle",
    "UTGMemoryExporter",
    "export_utg_memory",
    "export_utg_memory_to_dir",
    "export_functions_for_llm",
    "export_node_context",
    "export_app_context",
    # 自然语言导出
    "function_to_natural_language",
    "node_to_natural_language",
    "app_to_natural_language",
    "export_memory_as_documents",
    "export_memory_to_markdown_dir",
]
