"""UTG Memory Enricher - 使用 VLM/LLM 增强 Node 描述。

功能：
1. VLM 分析 XML/截图，生成视觉摘要
2. LLM 生成 Node 用途描述
3. 自动提取页面关键元素
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Protocol

from src.utg.assets.memory_export import (
    FunctionMemory,
    NodeMemory,
    UTGMemoryBundle,
)

logger = logging.getLogger(__name__)


# =============================================================================
# LLM/VLM 接口协议
# =============================================================================


class LLMClient(Protocol):
    """LLM 客户端协议。"""

    def complete(self, prompt: str) -> str:
        """生成文本补全。"""
        ...


class VLMClient(Protocol):
    """VLM 客户端协议（支持图像输入）。"""

    def analyze_image(self, image_base64: str, prompt: str) -> str:
        """分析图像并返回描述。"""
        ...

    def analyze_xml(self, xml: str, prompt: str) -> str:
        """分析 XML UI 结构并返回描述。"""
        ...


# =============================================================================
# 基于 foundation/ai 的 LLM 客户端适配器
# =============================================================================


class FoundationLLMClient:
    """使用 foundation/ai 的 LLM 客户端。"""

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4o",
    ):
        self.provider = provider
        self.model = model

    def complete(self, prompt: str) -> str:
        """同步文本补全。"""
        from src.foundation.ai import complete

        return complete(prompt, provider=self.provider, model=self.model)

    async def acomplete(self, prompt: str) -> str:
        """异步文本补全。"""
        from src.foundation.ai import acomplete

        return await acomplete(prompt, provider=self.provider, model=self.model)

    async def acomplete_json(self, prompt: str) -> Dict[str, Any]:
        """异步 JSON 补全。"""
        from src.foundation.ai import acomplete_json

        return await acomplete_json(prompt, provider=self.provider, model=self.model)


# =============================================================================
# Prompt 模板
# =============================================================================

NODE_DESCRIPTION_PROMPT = """分析以下 Android 页面信息，生成简洁的页面描述。

包名: {package}
Activity: {activity}
页面签名: {signatures}
可用功能: {functions}

XML 结构:
{xml_sample}

请用一句话描述这个页面的用途和主要功能。只返回描述文本，不要其他内容。
"""

VISUAL_ELEMENTS_PROMPT = """分析以下 Android 页面的 XML 结构，提取页面的关键视觉元素。

XML:
{xml_sample}

请列出页面上最重要的 5-10 个可交互元素（按钮、输入框、开关等），每行一个。
格式: 元素类型: 元素文本/描述
只返回列表，不要其他内容。
"""

FUNCTION_DESCRIPTION_PROMPT = """根据以下信息，为这个自动化功能生成简洁的描述。

功能名称: {name}
参数: {parameters}
前置条件: {precondition}
后置条件: {postcondition}
动作数量: {actions_count}

请用一句话描述这个功能的作用。如果有参数，说明参数的用途。只返回描述文本。
"""

NODE_ID_GENERATION_PROMPT = """为这个 Android 应用页面生成一个语义化的 ID 标识符。

应用包名: {package}
Activity: {activity}
页面描述: {description}
页面签名关键词: {signatures}
主要功能: {functions}

XML 结构示例:
{xml_sample}

命名规则:
1. 格式: {{app}}_{{页面用途}}_{{可选细节}}
2. 使用小写字母和下划线
3. app 部分用包名最后一段的简写（如 com.taobao.taobao → taobao）
4. 页面用途用简短英文描述（如 home, login, settings, product_detail, cart, search_result）
5. 长度控制在 30 个字符以内

示例:
- taobao_home (淘宝首页)
- taobao_product_detail (商品详情页)
- taobao_cart (购物车页)
- wechat_chat_list (微信聊天列表)
- wechat_moments (微信朋友圈)
- alipay_transfer (支付宝转账页)

只返回生成的 ID，不要其他内容。
"""


# =============================================================================
# 增强器
# =============================================================================


class MemoryEnricher:
    """Memory 增强器 - 使用 LLM/VLM 增强描述。"""

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        vlm_client: Optional[VLMClient] = None,
    ):
        self.llm = llm_client
        self.vlm = vlm_client

    def enrich_bundle(
        self,
        bundle: UTGMemoryBundle,
        *,
        enrich_nodes: bool = True,
        enrich_functions: bool = True,
    ) -> UTGMemoryBundle:
        """增强整个 Memory Bundle。"""
        enriched_nodes = (
            [self.enrich_node(node) for node in bundle.nodes]
            if enrich_nodes
            else bundle.nodes
        )
        enriched_functions = (
            [self.enrich_function(func) for func in bundle.functions]
            if enrich_functions
            else bundle.functions
        )

        return UTGMemoryBundle(
            version=bundle.version,
            nodes=enriched_nodes,
            functions=enriched_functions,
            graph=bundle.graph,
            metadata={
                **bundle.metadata,
                "enriched": True,
                "enricher": "llm" if self.llm else "none",
            },
        )

    def enrich_node(self, node: NodeMemory) -> NodeMemory:
        """增强单个 Node 描述。"""
        if not self.llm and not self.vlm:
            return node

        enriched_data = node.model_dump()

        # 生成页面描述
        if not node.description and (self.llm or self.vlm):
            description = self._generate_node_description(node)
            if description:
                enriched_data["description"] = description

        # 生成视觉摘要
        if not node.visual_summary and self.vlm and node.xml_sample:
            visual_summary = self._generate_visual_summary(node)
            if visual_summary:
                enriched_data["visual_summary"] = visual_summary

        # 提取视觉元素
        if not node.visual_elements and (self.llm or self.vlm) and node.xml_sample:
            elements = self._extract_visual_elements(node)
            if elements:
                enriched_data["visual_elements"] = elements

        return NodeMemory(**enriched_data)

    def enrich_function(self, func: FunctionMemory) -> FunctionMemory:
        """增强单个 Function 描述。"""
        if not self.llm or func.description:
            return func

        description = self._generate_function_description(func)
        if not description:
            return func

        enriched_data = func.model_dump()
        enriched_data["description"] = description
        return FunctionMemory(**enriched_data)

    def _generate_node_description(self, node: NodeMemory) -> Optional[str]:
        """生成 Node 描述。"""
        prompt = NODE_DESCRIPTION_PROMPT.format(
            package=node.package,
            activity=node.activity,
            signatures=", ".join(node.signatures[:5]),
            functions=", ".join(node.available_functions[:5]),
            xml_sample=node.xml_sample[:3000] if node.xml_sample else "(无)",
        )

        try:
            if self.vlm and node.xml_sample:
                return self.vlm.analyze_xml(node.xml_sample, prompt)
            elif self.llm:
                return self.llm.complete(prompt)
        except Exception as e:
            logger.warning("Failed to generate node description: %s", e)
        return None

    def _generate_visual_summary(self, node: NodeMemory) -> Optional[str]:
        """生成视觉摘要。"""
        if not self.vlm or not node.xml_sample:
            return None

        prompt = "用一句话描述这个 Android 页面的视觉布局和主要内容。"
        try:
            return self.vlm.analyze_xml(node.xml_sample, prompt)
        except Exception as e:
            logger.warning("Failed to generate visual summary: %s", e)
        return None

    def _extract_visual_elements(self, node: NodeMemory) -> List[str]:
        """提取视觉元素。"""
        prompt = VISUAL_ELEMENTS_PROMPT.format(
            xml_sample=node.xml_sample[:3000] if node.xml_sample else ""
        )

        try:
            if self.vlm:
                result = self.vlm.analyze_xml(node.xml_sample, prompt)
            elif self.llm:
                result = self.llm.complete(prompt)
            else:
                return []

            # 解析结果
            elements = [
                line.strip()
                for line in result.split("\n")
                if line.strip() and not line.startswith("#")
            ]
            return elements[:10]
        except Exception as e:
            logger.warning("Failed to extract visual elements: %s", e)
        return []

    def _generate_function_description(self, func: FunctionMemory) -> Optional[str]:
        """生成 Function 描述。"""
        if not self.llm:
            return None

        prompt = FUNCTION_DESCRIPTION_PROMPT.format(
            name=func.name,
            parameters=str(func.parameters.get("properties", {})),
            precondition=str(func.precondition),
            postcondition=str(func.postcondition),
            actions_count=func.actions_count,
        )

        try:
            return self.llm.complete(prompt)
        except Exception as e:
            logger.warning("Failed to generate function description: %s", e)
        return None


# =============================================================================
# 基于规则的轻量级增强（无需 LLM）
# =============================================================================


def enrich_node_from_xml(node: NodeMemory) -> NodeMemory:
    """从 XML 提取信息增强 Node（无需 LLM）。"""
    if not node.xml_sample:
        return node

    enriched_data = node.model_dump()

    # 从 XML 提取可点击元素
    if not node.visual_elements:
        elements = _extract_clickable_elements(node.xml_sample)
        if elements:
            enriched_data["visual_elements"] = elements

    # 从 XML 生成基础描述
    if not node.description:
        description = _generate_basic_description(node)
        if description:
            enriched_data["description"] = description

    return NodeMemory(**enriched_data)


def _extract_clickable_elements(xml: str) -> List[str]:
    """从 XML 提取可点击元素。"""
    import re

    elements = []

    # 匹配有 text 属性的可点击节点
    pattern = r'<node[^>]*clickable="true"[^>]*text="([^"]+)"[^>]*/>'
    for match in re.finditer(pattern, xml):
        text = match.group(1).strip()
        if text and text not in elements:
            elements.append(f"按钮: {text}")

    # 匹配输入框
    pattern = r'<node[^>]*class="[^"]*EditText[^"]*"[^>]*(?:hint="([^"]*)")?[^>]*/>'
    for match in re.finditer(pattern, xml):
        hint = match.group(1) or "输入框"
        elements.append(f"输入: {hint.strip()}")

    return elements[:10]


def _generate_basic_description(node: NodeMemory) -> str:
    """生成基础描述。"""
    parts = []

    if node.package:
        app_name = node.package.split(".")[-1]
        parts.append(f"{app_name} 应用")

    if node.signatures:
        parts.append(f"包含 {', '.join(node.signatures[:3])}")

    if node.available_functions:
        parts.append(f"可执行 {len(node.available_functions)} 个操作")

    return "，".join(parts) if parts else ""


def enrich_bundle_without_llm(bundle: UTGMemoryBundle) -> UTGMemoryBundle:
    """无需 LLM 的轻量级增强。"""
    enriched_nodes = [enrich_node_from_xml(node) for node in bundle.nodes]

    return UTGMemoryBundle(
        version=bundle.version,
        nodes=enriched_nodes,
        functions=bundle.functions,
        graph=bundle.graph,
        metadata={
            **bundle.metadata,
            "enriched": True,
            "enricher": "rule-based",
        },
    )


# =============================================================================
# Node ID 生成（语义化命名）
# =============================================================================


class NodeIDGenerator:
    """Node ID 生成器 - 生成语义化的唯一 ID。

    命名格式: {app}_{页面用途}_{可选后缀}
    示例: taobao_home, taobao_product_detail, wechat_chat_list
    """

    def __init__(self):
        self._used_ids: set = set()
        self._id_counter: Dict[str, int] = {}

    def reset(self):
        """重置已用 ID 记录。"""
        self._used_ids.clear()
        self._id_counter.clear()

    def register_existing_id(self, node_id: str):
        """注册已存在的 ID（避免冲突）。"""
        self._used_ids.add(node_id.lower())

    def generate_unique_id(self, base_id: str) -> str:
        """确保 ID 唯一，必要时添加数字后缀。

        Args:
            base_id: 基础 ID（由 LLM 生成或规则生成）

        Returns:
            唯一的 ID
        """
        # 标准化: 小写，替换非法字符
        normalized = self._normalize_id(base_id)

        if not normalized:
            normalized = "unknown_page"

        # 检查是否唯一
        if normalized.lower() not in self._used_ids:
            self._used_ids.add(normalized.lower())
            return normalized

        # 添加数字后缀
        base_lower = normalized.lower()
        if base_lower not in self._id_counter:
            self._id_counter[base_lower] = 1

        while True:
            self._id_counter[base_lower] += 1
            candidate = f"{normalized}_{self._id_counter[base_lower]}"
            if candidate.lower() not in self._used_ids:
                self._used_ids.add(candidate.lower())
                return candidate

    def _normalize_id(self, raw_id: str) -> str:
        """标准化 ID。"""
        import re

        # 转小写
        result = raw_id.lower().strip()

        # 移除非法字符，只保留字母、数字、下划线
        result = re.sub(r"[^a-z0-9_]", "_", result)

        # 合并连续下划线
        result = re.sub(r"_+", "_", result)

        # 移除首尾下划线
        result = result.strip("_")

        # 限制长度
        if len(result) > 50:
            result = result[:50].rstrip("_")

        return result

    def generate_id_from_context(
        self,
        package: str,
        activity: str = "",
        description: str = "",
        signatures: List[str] = None,
    ) -> str:
        """基于上下文生成 ID（无需 LLM）。

        Args:
            package: 应用包名
            activity: Activity 名称
            description: 页面描述
            signatures: 页面签名

        Returns:
            生成的 ID
        """
        # 提取 app 简称
        app_short = self._extract_app_short(package)

        # 尝试从 Activity 提取页面类型
        page_type = self._extract_page_type_from_activity(activity)

        # 尝试从 description 提取页面类型
        if not page_type and description:
            page_type = self._extract_page_type_from_description(description)

        # 尝试从 signatures 提取页面类型
        if not page_type and signatures:
            page_type = self._extract_page_type_from_signatures(signatures)

        # 组合 ID
        if page_type:
            base_id = f"{app_short}_{page_type}"
        else:
            base_id = f"{app_short}_page"

        return self.generate_unique_id(base_id)

    def _extract_app_short(self, package: str) -> str:
        """从包名提取应用简称。"""
        if not package:
            return "app"

        # com.taobao.taobao -> taobao
        # com.tencent.mm -> mm (微信)
        # com.eg.android.AlipayGphone -> alipay
        parts = package.lower().split(".")

        # 常见 App 映射
        app_mapping = {
            "taobao": "taobao",
            "tmall": "tmall",
            "mm": "wechat",
            "tencent": "tencent",
            "alipay": "alipay",
            "alipaygphone": "alipay",
            "jd": "jd",
            "meituan": "meituan",
            "dianping": "dianping",
            "douyin": "douyin",
            "kuaishou": "kuaishou",
            "bilibili": "bilibili",
            "weibo": "weibo",
            "zhihu": "zhihu",
            "baidu": "baidu",
            "netease": "netease",
            "xiaomi": "xiaomi",
            "huawei": "huawei",
            "oppo": "oppo",
            "vivo": "vivo",
        }

        for part in reversed(parts):
            if part in app_mapping:
                return app_mapping[part]
            # 移除常见前缀后缀
            cleaned = (
                part.replace("android", "").replace("client", "").replace("mobile", "")
            )
            if cleaned and len(cleaned) >= 2:
                return cleaned[:15]

        return parts[-1][:15] if parts else "app"

    def _extract_page_type_from_activity(self, activity: str) -> str:
        """从 Activity 名称提取页面类型。"""
        if not activity:
            return ""

        # HomeActivity -> home
        # LoginActivity -> login
        # ProductDetailActivity -> product_detail
        # LauncherUI -> launcher
        import re

        # 提取类名
        class_name = activity.split(".")[-1]

        # 移除常见后缀
        for suffix in ["Activity", "Fragment", "Page", "View", "Screen", "UI"]:
            if class_name.endswith(suffix):
                class_name = class_name[: -len(suffix)]

        # 驼峰转下划线（处理连续大写如 UI, ID）
        # 先处理连续大写: ABCDef -> Abc_Def
        result = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", class_name)
        # 再处理普通驼峰: abcDef -> abc_Def
        result = re.sub(r"([a-z])([A-Z])", r"\1_\2", result)
        result = result.lower().strip("_")

        # 合并连续下划线
        result = re.sub(r"_+", "_", result)

        return result[:30] if result else ""

    def _extract_page_type_from_description(self, description: str) -> str:
        """从描述提取页面类型。"""
        if not description:
            return ""

        # 关键词映射
        keywords = {
            "首页": "home",
            "主页": "home",
            "home": "home",
            "登录": "login",
            "登陆": "login",
            "login": "login",
            "注册": "register",
            "register": "register",
            "设置": "settings",
            "settings": "settings",
            "个人": "profile",
            "我的": "profile",
            "profile": "profile",
            "搜索": "search",
            "search": "search",
            "详情": "detail",
            "detail": "detail",
            "商品": "product",
            "product": "product",
            "购物车": "cart",
            "cart": "cart",
            "订单": "order",
            "order": "order",
            "支付": "payment",
            "pay": "payment",
            "聊天": "chat",
            "chat": "chat",
            "消息": "message",
            "message": "message",
            "列表": "list",
            "list": "list",
            "发现": "discover",
            "discover": "discover",
            "视频": "video",
            "video": "video",
            "图片": "image",
            "image": "image",
            "相册": "album",
            "album": "album",
        }

        desc_lower = description.lower()
        for keyword, page_type in keywords.items():
            if keyword in desc_lower:
                return page_type

        return ""

    def _extract_page_type_from_signatures(self, signatures: List[str]) -> str:
        """从签名提取页面类型。"""
        if not signatures:
            return ""

        # 合并签名文本
        combined = " ".join(signatures).lower()
        return self._extract_page_type_from_description(combined)


# 全局 ID 生成器实例
_node_id_generator = NodeIDGenerator()


def generate_node_id(
    package: str,
    activity: str = "",
    description: str = "",
    signatures: List[str] = None,
) -> str:
    """生成语义化的 Node ID（便捷函数）。

    Args:
        package: 应用包名
        activity: Activity 名称
        description: 页面描述
        signatures: 页面签名

    Returns:
        唯一的语义化 ID
    """
    return _node_id_generator.generate_id_from_context(
        package, activity, description, signatures
    )


def reset_node_id_generator():
    """重置 Node ID 生成器（新 UTG 时调用）。"""
    _node_id_generator.reset()


def register_existing_node_id(node_id: str):
    """注册已存在的 Node ID（加载 UTG 时调用）。"""
    _node_id_generator.register_existing_id(node_id)


# =============================================================================
# 异步 API（供 utg_api 使用）
# =============================================================================


VISION_DESCRIPTION_PROMPT = """分析这个 Android 应用页面截图，生成简洁的页面描述。

包名: {package}
Activity: {activity}

请用 1-2 句话描述：
1. 这是什么页面（功能/用途）
2. 页面的主要内容和布局

只返回描述文本，不要其他内容。
"""

VISION_ELEMENTS_PROMPT = """分析这个 Android 应用页面截图，提取页面的关键可交互元素。

请列出页面上最重要的 5-10 个可交互元素（按钮、输入框、开关、列表项等），每行一个。
格式: 元素类型: 元素文本/描述
只返回列表，不要其他内容。
"""


VISION_NODE_ID_PROMPT = """分析这个 Android 应用页面截图，为该页面生成一个语义化的 ID 标识符。

应用包名: {package}
Activity: {activity}

命名规则:
1. 格式: {{app}}_{{页面用途}}_{{可选细节}}
2. 使用小写字母和下划线
3. app 部分用包名最后一段的简写（如 com.taobao.taobao → taobao）
4. 页面用途用简短英文描述（如 home, login, settings, product_detail, cart, search_result）
5. 长度控制在 30 个字符以内

示例:
- taobao_home (淘宝首页)
- taobao_product_detail (商品详情页)
- taobao_cart (购物车页)
- wechat_chat_list (微信聊天列表)
- wechat_moments (微信朋友圈)
- alipay_transfer (支付宝转账页)

只返回生成的 ID，不要其他内容。
"""


async def generate_node_id_async(
    node: NodeMemory,
    *,
    screenshot_base64: Optional[str] = None,
    llm_provider: str = "openai",
    llm_model: str = "gpt-4o",
) -> str:
    """使用 VLM/LLM 异步生成语义化 Node ID。

    优先使用 VLM 分析截图（如果提供），否则使用 LLM 分析 XML。

    Args:
        node: NodeMemory 对象
        screenshot_base64: 可选的页面截图（base64 编码）
        llm_provider: LLM/VLM 提供商
        llm_model: LLM/VLM 模型

    Returns:
        生成的 Node ID
    """
    from src.foundation.ai import acomplete, acomplete_vision

    try:
        if screenshot_base64:
            # 使用 VLM 分析截图
            prompt = VISION_NODE_ID_PROMPT.format(
                package=node.package or "",
                activity=node.activity or "",
            )
            raw_id = await acomplete_vision(
                prompt,
                image_base64=screenshot_base64,
                provider=llm_provider,
                model=llm_model,
            )
        else:
            # Fallback: 使用 LLM 分析 XML
            prompt = NODE_ID_GENERATION_PROMPT.format(
                package=node.package or "",
                activity=node.activity or "",
                description=node.description or "",
                signatures=", ".join(node.signatures[:5]) if node.signatures else "",
                functions=", ".join(node.available_functions[:5])
                if node.available_functions
                else "",
                xml_sample=(node.xml_sample[:2000] if node.xml_sample else "(无)"),
            )
            raw_id = await acomplete(prompt, provider=llm_provider, model=llm_model)

        raw_id = raw_id.strip().strip('"').strip("'")

        # 使用 NodeIDGenerator 确保唯一性
        return _node_id_generator.generate_unique_id(raw_id)
    except Exception as e:
        logger.warning("Failed to generate node ID with VLM/LLM: %s", e)
        # Fallback: 使用规则生成
        return _node_id_generator.generate_id_from_context(
            node.package or "",
            node.activity or "",
            node.description or "",
            node.signatures,
        )


async def enrich_node_async(
    node: NodeMemory,
    *,
    screenshot_base64: Optional[str] = None,
    llm_provider: str = "openai",
    llm_model: str = "gpt-4o",
    generate_semantic_id: bool = False,
) -> NodeMemory:
    """异步增强单个 Node。

    Args:
        node: 待增强的 NodeMemory
        screenshot_base64: 可选的页面截图（base64 编码）
        llm_provider: LLM 提供商
        llm_model: LLM 模型
        generate_semantic_id: 是否生成语义化 ID

    Returns:
        增强后的 NodeMemory
    """
    from src.foundation.ai import acomplete, acomplete_vision

    enriched_data = node.model_dump()
    use_vision = bool(screenshot_base64)

    # 生成语义化 ID（优先使用 VLM）
    if generate_semantic_id:
        semantic_id = await generate_node_id_async(
            node,
            screenshot_base64=screenshot_base64,
            llm_provider=llm_provider,
            llm_model=llm_model,
        )
        enriched_data["semantic_id"] = semantic_id

    # 生成页面描述
    if not node.description:
        if use_vision:
            # 使用 VLM 分析截图
            prompt = VISION_DESCRIPTION_PROMPT.format(
                package=node.package,
                activity=node.activity,
            )
            try:
                description = await acomplete_vision(
                    prompt,
                    image_base64=screenshot_base64,
                    provider=llm_provider,
                    model=llm_model,
                )
                if description:
                    enriched_data["description"] = description.strip()
            except Exception as e:
                logger.warning("Failed to generate node description with vision: %s", e)
        elif node.xml_sample:
            # Fallback: 使用 LLM 分析 XML
            prompt = NODE_DESCRIPTION_PROMPT.format(
                package=node.package,
                activity=node.activity,
                signatures=", ".join(node.signatures[:5]),
                functions=", ".join(node.available_functions[:5]),
                xml_sample=node.xml_sample[:3000] if node.xml_sample else "(无)",
            )
            try:
                description = await acomplete(
                    prompt, provider=llm_provider, model=llm_model
                )
                if description:
                    enriched_data["description"] = description.strip()
            except Exception as e:
                logger.warning("Failed to generate node description: %s", e)

    # 提取视觉元素
    if not node.visual_elements:
        if use_vision:
            # 使用 VLM 分析截图
            try:
                result = await acomplete_vision(
                    VISION_ELEMENTS_PROMPT,
                    image_base64=screenshot_base64,
                    provider=llm_provider,
                    model=llm_model,
                )
                if result:
                    elements = [
                        line.strip()
                        for line in result.split("\n")
                        if line.strip() and not line.startswith("#")
                    ]
                    enriched_data["visual_elements"] = elements[:10]
            except Exception as e:
                logger.warning("Failed to extract visual elements with vision: %s", e)
        elif node.xml_sample:
            # Fallback: 使用 LLM 分析 XML
            prompt = VISUAL_ELEMENTS_PROMPT.format(
                xml_sample=node.xml_sample[:3000] if node.xml_sample else ""
            )
            try:
                result = await acomplete(prompt, provider=llm_provider, model=llm_model)
                if result:
                    elements = [
                        line.strip()
                        for line in result.split("\n")
                        if line.strip() and not line.startswith("#")
                    ]
                    enriched_data["visual_elements"] = elements[:10]
            except Exception as e:
                logger.warning("Failed to extract visual elements: %s", e)

    return NodeMemory(**enriched_data)


async def enrich_bundle_async(
    bundle: UTGMemoryBundle,
    *,
    llm_provider: str = "openai",
    llm_model: str = "gpt-4o",
    enrich_nodes: bool = True,
    enrich_functions: bool = True,
    max_concurrent: int = 5,
) -> UTGMemoryBundle:
    """异步增强整个 Memory Bundle。

    Args:
        bundle: 待增强的 UTGMemoryBundle
        llm_provider: LLM 提供商
        llm_model: LLM 模型
        enrich_nodes: 是否增强 nodes
        enrich_functions: 是否增强 functions
        max_concurrent: 最大并发数

    Returns:
        增强后的 UTGMemoryBundle
    """
    import asyncio

    enriched_nodes = bundle.nodes
    enriched_functions = bundle.functions

    if enrich_nodes:
        # 并发增强 nodes
        semaphore = asyncio.Semaphore(max_concurrent)

        async def enrich_with_limit(node: NodeMemory) -> NodeMemory:
            async with semaphore:
                return await enrich_node_async(
                    node,
                    llm_provider=llm_provider,
                    llm_model=llm_model,
                )

        enriched_nodes = await asyncio.gather(
            *[enrich_with_limit(node) for node in bundle.nodes]
        )

    if enrich_functions:
        # 增强 functions（简单版，只生成描述）
        from src.foundation.ai import acomplete

        async def enrich_function(func: FunctionMemory) -> FunctionMemory:
            if func.description:
                return func

            prompt = FUNCTION_DESCRIPTION_PROMPT.format(
                name=func.name,
                parameters=str(func.parameters.get("properties", {})),
                precondition=str(func.precondition),
                postcondition=str(func.postcondition),
                actions_count=func.actions_count,
            )
            try:
                description = await acomplete(
                    prompt, provider=llm_provider, model=llm_model
                )
                if description:
                    data = func.model_dump()
                    data["description"] = description.strip()
                    return FunctionMemory(**data)
            except Exception as e:
                logger.warning("Failed to generate function description: %s", e)
            return func

        semaphore = asyncio.Semaphore(max_concurrent)

        async def enrich_function_with_limit(func: FunctionMemory) -> FunctionMemory:
            async with semaphore:
                return await enrich_function(func)

        enriched_functions = await asyncio.gather(
            *[enrich_function_with_limit(func) for func in bundle.functions]
        )

    return UTGMemoryBundle(
        version=bundle.version,
        nodes=list(enriched_nodes),
        functions=list(enriched_functions),
        graph=bundle.graph,
        metadata={
            **bundle.metadata,
            "enriched": True,
            "enricher": f"{llm_provider}/{llm_model}",
        },
    )


__all__ = [
    "LLMClient",
    "VLMClient",
    "MemoryEnricher",
    "FoundationLLMClient",
    "enrich_node_from_xml",
    "enrich_bundle_without_llm",
    "enrich_node_async",
    "enrich_bundle_async",
    # Node ID 生成
    "NodeIDGenerator",
    "generate_node_id",
    "generate_node_id_async",
    "reset_node_id_generator",
    "register_existing_node_id",
]
