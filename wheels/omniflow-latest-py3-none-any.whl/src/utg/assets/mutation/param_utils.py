"""
Parameter utilities for UTG mutation operations.

Provides parameter extraction, normalization, and binding utilities.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

# =============================================================================
# Parameter type configuration
# =============================================================================

# Parameter types with explicit descriptions
PARAMETER_TYPE_DESC: Dict[str, str] = {
    "query": "search query keyword",
    "app": "app name or package",
    "phone": "phone number",
    "contact": "contact name",
    "url": "website url",
    "address": "physical address or location",
    "email": "email address",
    "date": "date or time",
    "number": "numeric value",
    "price": "price or amount",
    "text": "generic text input",
    "password": "password or credential",
    "username": "username or login",
    "note": "note or message content",
    "title": "title or subject",
    "whitelist_item": "whitelist item entry",
    "target": "dynamic UI target element",
}

# Aliases mapping to canonical parameter types
PARAMETER_TYPE_ALIAS: Dict[str, str] = {
    "search": "query",
    "keyword": "query",
    "q": "query",
    "application": "app",
    "package": "app",
    "pkg": "app",
    "tel": "phone",
    "telephone": "phone",
    "mobile": "phone",
    "phonenumber": "phone",
    "name": "contact",
    "person": "contact",
    "link": "url",
    "website": "url",
    "web": "url",
    "http": "url",
    "location": "address",
    "place": "address",
    "mail": "email",
    "e-mail": "email",
    "time": "date",
    "datetime": "date",
    "num": "number",
    "int": "number",
    "float": "number",
    "amount": "price",
    "cost": "price",
    "money": "price",
    "pass": "password",
    "pwd": "password",
    "secret": "password",
    "user": "username",
    "login": "username",
    "account": "username",
    "message": "note",
    "content": "note",
    "body": "note",
    "subject": "title",
    "header": "title",
    "whitelist": "whitelist_item",
}

# Generic tokens that should not be treated as explicit parameter types
GENERIC_PARAMETER_TYPE_TOKENS = frozenset(
    {"text", "string", "input", "value", "parameter"}
)

# Parameter type inference keywords
PARAMETER_TYPE_KEYWORDS: Dict[str, List[str]] = {
    "query": ["query", "search", "keyword"],
    "phone": ["phone", "tel", "mobile", "call"],
    "contact": ["contact", "name", "person"],
    "email": ["email", "mail"],
    "url": ["url", "link", "http", "website"],
    "address": ["address", "location", "place"],
    "date": ["date", "time", "datetime"],
    "password": ["password", "pass", "pwd", "secret"],
    "username": ["user", "login", "account"],
}

# Path description prefix hints for parameter type inference
FUNCTION_DESC_PREFIX_HINTS: List[Tuple[List[str], str]] = [
    (["search", "find", "query", "搜索", "查找", "查询"], "query"),
    (["call", "dial", "phone", "拨打", "呼叫"], "phone"),
    (["open", "launch", "打开", "启动"], "app"),
    (["browse", "visit", "go to", "浏览", "访问"], "url"),
]


# =============================================================================
# Parameter extraction utilities
# =============================================================================


def extract_parameter_names_from_template(template: str) -> List[str]:
    """Extract parameter names from a template string with `${parameter}` placeholders."""
    if not template:
        return []
    names = re.findall(r"\$\{(\w+)\}", template)
    out: List[str] = []
    seen: set[str] = set()
    for name in names:
        key = str(name).strip()
        if key and key not in seen:
            out.append(key)
            seen.add(key)
    return out


def strip_parameter_placeholders(text: str) -> str:
    """Remove all `${parameter}` placeholders from text."""
    stripped = re.sub(r"\$\{\w+\}", "", str(text or ""))
    stripped = re.sub(r"\s+", " ", stripped).strip()
    return stripped


def collect_parameter_bindings(
    parameter_name: str,
    actions: List[Any],
    param_string_iter: Any = None,
) -> List[str]:
    """Collect action types that bind to a parameter placeholder.

    Args:
        parameter_name: Name of the parameter to search for.
        actions: List of action dicts or objects.
        param_string_iter: Optional function to iterate param strings.

    Returns:
        List of action types that contain the parameter placeholder.
    """
    placeholder = f"${{{parameter_name}}}"
    out: List[str] = []
    seen: set[str] = set()
    for action in actions:
        action_type = str(
            action.get("type", "")
            if isinstance(action, dict)
            else getattr(action, "type", "")
        ).strip()
        params: Any
        if isinstance(action, dict):
            params = action.get("params")
        else:
            params = getattr(action, "params", None)
        if not isinstance(params, dict):
            continue

        # Get text values from params
        if param_string_iter:
            text_values = param_string_iter(params)
        else:
            text_values = _default_param_strings(params)

        if any(placeholder in value for value in text_values):
            key = action_type or "unknown"
            if key not in seen:
                out.append(key)
                seen.add(key)
    return out


def _default_param_strings(params: Dict[str, Any]) -> List[str]:
    """Extract string values from params dict."""
    values = []
    for key in ("text", "clickPrompt", "click_prompt"):
        val = params.get(key)
        if isinstance(val, str):
            values.append(val)
    return values


def iter_param_strings(value: Any) -> List[str]:
    """Recursively extract all string values from a nested structure.

    Args:
        value: A value that may be a string, dict, list, or nested combination.

    Returns:
        List of all string values found.
    """
    out: List[str] = []
    if isinstance(value, str):
        out.append(value)
        return out
    if isinstance(value, dict):
        for v in value.values():
            out.extend(iter_param_strings(v))
        return out
    if isinstance(value, list):
        for v in value:
            out.extend(iter_param_strings(v))
        return out
    return out


# =============================================================================
# Parameter type normalization
# =============================================================================


def sanitize_parameter_type_token(raw_value: Any) -> str:
    """Sanitize a raw parameter type value to a normalized token."""
    key = str(raw_value or "").strip().lower()
    if not key:
        return ""
    key = key.split(";", 1)[0].strip()
    if key.startswith("type="):
        key = key.split("=", 1)[1].strip()
    key = key.split(":", 1)[0].strip()
    return key


def resolve_parameter_type_token(
    raw_value: Any,
    *,
    parameter_type_desc: Optional[Dict[str, str]] = None,
    parameter_type_alias: Optional[Dict[str, str]] = None,
) -> Optional[str]:
    """Resolve a raw value to a canonical parameter type.

    Args:
        raw_value: Raw parameter type value to resolve.
        parameter_type_desc: Optional custom parameter type descriptions.
        parameter_type_alias: Optional custom parameter type aliases.

    Returns:
        Canonical parameter type or None if not resolvable.
    """
    desc = (
        parameter_type_desc if parameter_type_desc is not None else PARAMETER_TYPE_DESC
    )
    alias = (
        parameter_type_alias
        if parameter_type_alias is not None
        else PARAMETER_TYPE_ALIAS
    )

    key = sanitize_parameter_type_token(raw_value)
    if not key or key in GENERIC_PARAMETER_TYPE_TOKENS:
        return None
    if key in desc:
        return key
    return alias.get(key)


def infer_parameter_type_from_name(
    parameter_name: str,
    *,
    keywords: Optional[Dict[str, List[str]]] = None,
) -> Optional[str]:
    """Infer parameter type from the parameter name using keyword matching.

    Args:
        parameter_name: Name of the parameter.
        keywords: Optional custom keyword mapping.

    Returns:
        Inferred parameter type or None.
    """
    kw = keywords if keywords is not None else PARAMETER_TYPE_KEYWORDS
    lower_name = str(parameter_name or "").lower()
    if not lower_name:
        return None
    for parameter_type, parameter_keywords in kw.items():
        if any(keyword in lower_name for keyword in parameter_keywords):
            return parameter_type
    return None


def infer_parameter_type_from_function(
    function_description: str,
    *,
    prefix_hints: Optional[List[Tuple[List[str], str]]] = None,
) -> Optional[str]:
    """Infer parameter type from function description using prefix matching.

    Args:
        function_description: Function description text.
        prefix_hints: Optional custom prefix hints.

    Returns:
        Inferred parameter type or None.
    """
    hints = prefix_hints if prefix_hints is not None else FUNCTION_DESC_PREFIX_HINTS
    desc = str(function_description or "").strip().lower()
    if not desc:
        return None
    for prefixes, parameter_type in hints:
        if any(desc.startswith(prefix) for prefix in prefixes):
            return parameter_type
    return None


def normalize_parameter_type(
    parameter_name: str,
    declared: str,
    function_description: str,
    *,
    parameter_type_desc: Optional[Dict[str, str]] = None,
    parameter_type_alias: Optional[Dict[str, str]] = None,
    parameter_type_keywords: Optional[Dict[str, List[str]]] = None,
    function_prefix_hints: Optional[List[Tuple[List[str], str]]] = None,
) -> str:
    """Normalize a parameter type using declared value, name inference, and path inference.

    Args:
        parameter_name: Name of the parameter.
        declared: Declared parameter type value.
        function_description: Function description for context.
        parameter_type_desc: Optional custom parameter type descriptions.
        parameter_type_alias: Optional custom parameter type aliases.
        parameter_type_keywords: Optional custom keyword mapping.
        function_prefix_hints: Optional custom prefix hints.

    Returns:
        Normalized parameter type, defaults to "text".
    """
    # Try declared value first
    for value in (declared, parameter_name):
        resolved = resolve_parameter_type_token(
            value,
            parameter_type_desc=parameter_type_desc,
            parameter_type_alias=parameter_type_alias,
        )
        if resolved:
            return resolved

    # Try name inference
    inferred_from_name = infer_parameter_type_from_name(
        parameter_name, keywords=parameter_type_keywords
    )
    if inferred_from_name:
        return inferred_from_name

    # Try function inference
    inferred_from_function = infer_parameter_type_from_function(
        function_description, prefix_hints=function_prefix_hints
    )
    if inferred_from_function:
        return inferred_from_function

    return "text"


# =============================================================================
# Parameter value extraction
# =============================================================================


def is_precise_param_value(value: str, sentence: str) -> bool:
    """Check if a parameter value precisely matches content in the sentence."""
    parameter_value = str(value or "").strip()
    raw_sentence = str(sentence or "").strip()
    if not parameter_value or not raw_sentence:
        return False

    sentence_norm = re.sub(r"\s+", "", raw_sentence).lower()
    value_norm = re.sub(r"\s+", "", parameter_value).lower()
    if not value_norm:
        return False
    if value_norm in sentence_norm:
        return True
    if len(value_norm) < 2:
        return False
    return _is_subsequence(value_norm, sentence_norm)


def _is_subsequence(needle: str, haystack: str) -> bool:
    """Check if needle is a subsequence of haystack."""
    if not needle:
        return True
    idx = 0
    for ch in haystack:
        if ch == needle[idx]:
            idx += 1
            if idx == len(needle):
                return True
    return False


def extract_arguments_from_template(template: str, text: str) -> Dict[str, str]:
    """Extract parameter values by matching text against a template pattern.

    Args:
        template: Template string with `${parameter}` placeholders.
        text: Text to extract values from.

    Returns:
        Dict mapping parameter names to extracted values.
    """
    template_str = str(template or "")
    text_str = str(text or "").strip()
    if not template_str or not text_str:
        return {}

    matches = list(re.finditer(r"\$\{(\w+)\}", template_str))
    if not matches:
        return {}

    pattern_parts: List[str] = []
    capture_map: List[Tuple[str, str]] = []
    cursor = 0
    for index, match in enumerate(matches):
        pattern_parts.append(re.escape(template_str[cursor : match.start()]))
        group_name = f"parameter_{index}"
        pattern_parts.append(f"(?P<{group_name}>.+?)")
        capture_map.append((group_name, str(match.group(1) or "").strip()))
        cursor = match.end()
    pattern_parts.append(re.escape(template_str[cursor:]))
    pattern = "".join(pattern_parts)
    matched = re.fullmatch(pattern, text_str)
    if not matched:
        return {}

    extracted: Dict[str, str] = {}
    for group_name, parameter_name in capture_map:
        if not parameter_name:
            continue
        value = str(matched.group(group_name) or "").strip()
        if not value:
            continue
        existing = extracted.get(parameter_name)
        if existing and existing != value:
            return {}
        extracted[parameter_name] = value
    return extracted


def build_parameter_descriptions(
    function_parameters: Dict[str, str],
    actions: List[Any],
    parameter_type_desc: Optional[Dict[str, str]] = None,
    param_string_iter: Any = None,
) -> Dict[str, str]:
    """Build parameter descriptions including type, description, and binding info.

    Args:
        function_parameters: Dict mapping parameter names to parameter types.
        actions: List of actions for binding analysis.
        parameter_type_desc: Optional custom parameter type descriptions.
        param_string_iter: Optional function to iterate param strings.

    Returns:
        Dict mapping parameter names to description strings.
    """
    desc_map = (
        parameter_type_desc if parameter_type_desc is not None else PARAMETER_TYPE_DESC
    )
    out: Dict[str, str] = {}
    for parameter_name, parameter_type in function_parameters.items():
        parameter_name = str(parameter_name or "").strip()
        parameter_type = str(parameter_type or "").strip() or "text"
        if not parameter_name:
            continue
        desc = desc_map.get(parameter_type, "text input")
        bindings = collect_parameter_bindings(
            parameter_name, actions, param_string_iter=param_string_iter
        )
        binding_text = ",".join(bindings) if bindings else "none"
        out[parameter_name] = f"type={parameter_type};desc={desc};bound={binding_text}"
    return out


def actions_bind_parameters(actions: List[Any], parameter_names: List[str]) -> bool:
    """Check if any action binds to the given parameter names.

    Args:
        actions: List of actions to check.
        parameter_names: List of parameter names to look for.

    Returns:
        True if at least one action binds to a parameter.
    """
    placeholders = [f"${{{name}}}" for name in parameter_names]
    for action in actions:
        params: Any = None
        if isinstance(action, dict):
            params = action.get("params")
        else:
            params = getattr(action, "params", None)

        if isinstance(params, dict):
            for value in _default_param_strings(params):
                if any(ph in value for ph in placeholders):
                    return True
    return False


__all__ = [
    # Configuration
    "PARAMETER_TYPE_DESC",
    "PARAMETER_TYPE_ALIAS",
    "GENERIC_PARAMETER_TYPE_TOKENS",
    "PARAMETER_TYPE_KEYWORDS",
    "FUNCTION_DESC_PREFIX_HINTS",
    # Extraction
    "extract_parameter_names_from_template",
    "strip_parameter_placeholders",
    "collect_parameter_bindings",
    # Normalization
    "sanitize_parameter_type_token",
    "resolve_parameter_type_token",
    "infer_parameter_type_from_name",
    "infer_parameter_type_from_function",
    "normalize_parameter_type",
    # Value extraction
    "is_precise_param_value",
    "extract_arguments_from_template",
    "build_parameter_descriptions",
    "actions_bind_parameters",
    "iter_param_strings",
]
