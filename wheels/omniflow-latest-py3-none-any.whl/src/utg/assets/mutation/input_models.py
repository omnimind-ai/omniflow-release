"""
Pydantic input models for run log validation.

These models replace ~400 lines of defensive parsing code with declarative validation.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
import uuid

from pydantic import BaseModel, Field, field_validator, model_validator


class ObservationInput(BaseModel):
    """Validated observation from device."""

    xml: str = ""
    package_name: str = ""
    activity_name: str = ""

    @field_validator("xml", "package_name", "activity_name", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return str(v or "").strip()


class ActResultInput(BaseModel):
    """Validated action result."""

    success: bool = False
    error_code: Optional[str] = None
    message: Optional[str] = None

    @field_validator("success", mode="before")
    @classmethod
    def coerce_bool(cls, v: Any) -> bool:
        return bool(v)

    @field_validator("error_code", "message", mode="before")
    @classmethod
    def coerce_optional_str(cls, v: Any) -> Optional[str]:
        s = str(v or "").strip()
        return s or None


class PlanInput(BaseModel):
    """Validated plan from agent."""

    description: str = ""
    tool_name: str = ""
    tool_args: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("description", "tool_name", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return str(v or "").strip()

    @field_validator("tool_args", mode="before")
    @classmethod
    def coerce_dict(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @property
    def is_run_action(self) -> bool:
        """Check if this plan is a run_action plan."""
        return self.tool_name == "run_action"

    @property
    def action(self) -> Any:
        """Get action from tool_args if this is a run_action plan."""
        if self.is_run_action:
            return self.tool_args.get("action")
        return None


class ProviderDetailInput(BaseModel):
    """Validated provider detail."""

    final_observation: Optional[ObservationInput] = None
    function_id: str = ""

    @field_validator("function_id", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return str(v or "").strip()

    @field_validator("final_observation", mode="before")
    @classmethod
    def coerce_observation(cls, v: Any) -> Optional[Dict[str, Any]]:
        return dict(v) if isinstance(v, dict) else None


class TargetElementInput(BaseModel):
    """目标 UI 元素"""

    resource_id: Optional[str] = None
    text: Optional[str] = None
    content_desc: Optional[str] = None
    class_name: Optional[str] = None
    bounds: Optional[List[int]] = None
    match_method: Optional[str] = None

    @field_validator("resource_id", "text", "content_desc", "class_name", mode="before")
    @classmethod
    def coerce_optional_str(cls, v: Any) -> Optional[str]:
        s = str(v or "").strip()
        return s or None

    @field_validator("bounds", mode="before")
    @classmethod
    def coerce_bounds(cls, v: Any) -> Optional[List[int]]:
        if v is None:
            return None
        if isinstance(v, (list, tuple)) and len(v) == 4:
            try:
                return [int(x) for x in v]
            except (TypeError, ValueError):
                return None
        return None


class StepInput(BaseModel):
    """Validated step from canonical run log."""

    observation_before_act: ObservationInput = Field(default_factory=ObservationInput)
    act_result: ActResultInput = Field(default_factory=ActResultInput)
    executed_actions: List[Any] = Field(default_factory=list)
    plan: PlanInput = Field(default_factory=PlanInput)
    provider_detail: ProviderDetailInput = Field(default_factory=ProviderDetailInput)
    terminal_state: Dict[str, Any] = Field(default_factory=dict)
    operation_description: str = ""

    # 新增字段：来源标识
    source: str = ""
    target_element: Optional[TargetElementInput] = None
    intent: Optional[str] = None
    selection_source: Optional[str] = None
    execution_source: Optional[str] = None

    @field_validator("observation_before_act", mode="before")
    @classmethod
    def coerce_observation(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("act_result", mode="before")
    @classmethod
    def coerce_act_result(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("executed_actions", mode="before")
    @classmethod
    def coerce_list(cls, v: Any) -> List[Any]:
        return list(v) if isinstance(v, list) else []

    @field_validator("plan", mode="before")
    @classmethod
    def coerce_plan(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("provider_detail", mode="before")
    @classmethod
    def coerce_provider_detail(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("terminal_state", mode="before")
    @classmethod
    def coerce_terminal_state(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("operation_description", "source", mode="before")
    @classmethod
    def coerce_str_field(cls, v: Any) -> str:
        return str(v or "").strip()

    @field_validator("target_element", mode="before")
    @classmethod
    def coerce_target_element(cls, v: Any) -> Optional[Dict[str, Any]]:
        return dict(v) if isinstance(v, dict) else None

    @field_validator("intent", "selection_source", "execution_source", mode="before")
    @classmethod
    def coerce_optional_str_field(cls, v: Any) -> Optional[str]:
        s = str(v or "").strip()
        return s or None

    @model_validator(mode="after")
    def infer_source(self) -> "StepInput":
        """从 execution_source 推断 source"""
        if not self.source:
            if self.execution_source in ("human_step", "human"):
                self.source = "human"
            else:
                self.source = "agent"
        return self

    @property
    def xml_before(self) -> str:
        return self.observation_before_act.xml

    @property
    def package_name(self) -> str:
        return self.observation_before_act.package_name

    @property
    def activity_name(self) -> str:
        return self.observation_before_act.activity_name

    @property
    def success(self) -> bool:
        return self.act_result.success

    @property
    def error_code(self) -> Optional[str]:
        return self.act_result.error_code

    def get_description(self) -> str:
        """Get operation description from step or plan."""
        if self.operation_description:
            return self.operation_description
        return self.plan.description


class RunLogInput(BaseModel):
    """Validated canonical run log input.

    Replaces ~400 lines of _coerce_run_log and _canonical_* methods.
    """

    run_id: str = ""
    trace_id: str = ""
    source: str = ""
    goal: str = ""
    success: bool = False
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    done_reason: str = ""
    started_at: str = ""
    finished_at: str = ""
    final_observation: ObservationInput = Field(default_factory=ObservationInput)
    steps: List[StepInput] = Field(default_factory=list)
    extra: Dict[str, Any] = Field(default_factory=dict)

    @field_validator(
        "run_id",
        "trace_id",
        "source",
        "goal",
        "done_reason",
        "started_at",
        "finished_at",
        mode="before",
    )
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return str(v or "").strip()

    @field_validator("success", mode="before")
    @classmethod
    def coerce_bool(cls, v: Any) -> bool:
        return bool(v)

    @field_validator("error_code", "error_message", mode="before")
    @classmethod
    def coerce_optional_str(cls, v: Any) -> Optional[str]:
        s = str(v or "").strip()
        return s or None

    @field_validator("final_observation", mode="before")
    @classmethod
    def coerce_final_observation(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @field_validator("steps", mode="before")
    @classmethod
    def coerce_steps(cls, v: Any) -> List[Dict[str, Any]]:
        if not isinstance(v, list):
            return []
        return [dict(s) if isinstance(s, dict) else {} for s in v]

    @field_validator("extra", mode="before")
    @classmethod
    def coerce_extra(cls, v: Any) -> Dict[str, Any]:
        return dict(v) if isinstance(v, dict) else {}

    @model_validator(mode="after")
    def ensure_trace_id(self) -> "RunLogInput":
        """Ensure trace_id is always set."""
        if not self.trace_id:
            self.trace_id = self.run_id or f"coerced_{uuid.uuid4().hex[:8]}"
        return self

    @property
    def effective_source(self) -> str:
        """Get source with fallback detection from steps."""
        if self.source:
            return self.source
        for step in reversed(self.steps):
            if step.provider_detail.function_id:
                return "utg"
        return "unknown"

    @property
    def first_observation(self) -> ObservationInput:
        """Get first step's observation."""
        if self.steps:
            return self.steps[0].observation_before_act
        return ObservationInput()

    @property
    def effective_final_observation(self) -> ObservationInput:
        """Get final observation with fallback from steps."""
        if self.final_observation.xml:
            return self.final_observation
        for step in reversed(self.steps):
            obs = step.provider_detail.final_observation
            if obs and obs.xml:
                return obs
        return ObservationInput()

    @property
    def effective_error_code(self) -> Optional[str]:
        """Get error code with fallback from steps."""
        if self.error_code:
            return self.error_code
        for step in reversed(self.steps):
            if step.error_code:
                return step.error_code
        return None

    @property
    def effective_error_message(self) -> Optional[str]:
        """Get error message with fallback from steps."""
        if self.error_message:
            return self.error_message
        for step in reversed(self.steps):
            if step.act_result.message:
                return step.act_result.message
        return None

    @property
    def effective_function_id(self) -> Optional[str]:
        """Get function id from steps."""
        for step in reversed(self.steps):
            function_id = step.plan.tool_args.get("function_id")
            if function_id:
                return str(function_id).strip()
            if step.provider_detail.function_id:
                return step.provider_detail.function_id
        return None

    @property
    def terminal_state(self) -> Dict[str, Any]:
        """Get terminal state from steps."""
        for step in reversed(self.steps):
            if step.terminal_state:
                return step.terminal_state
        return {}

    def get_xml_after(self, step_index: int) -> str:
        """Get xml_after for a step with proper fallback."""
        if step_index < len(self.steps):
            step = self.steps[step_index]
            # Try provider_detail first
            if step.provider_detail.final_observation:
                xml = step.provider_detail.final_observation.xml
                if xml:
                    return xml
            # Try next step's observation
            if step_index + 1 < len(self.steps):
                xml = self.steps[step_index + 1].xml_before
                if xml:
                    return xml
        # Fall back to final observation
        return self.effective_final_observation.xml


def parse_run_log(raw: Any) -> RunLogInput:
    """Parse raw run log dict into validated model.

    Args:
        raw: Raw run log dictionary or existing RunLogInput

    Returns:
        Validated RunLogInput instance
    """
    if isinstance(raw, RunLogInput):
        return raw
    if not isinstance(raw, dict):
        return RunLogInput()
    return RunLogInput.model_validate(raw)


__all__ = [
    "ObservationInput",
    "ActResultInput",
    "PlanInput",
    "ProviderDetailInput",
    "TargetElementInput",
    "StepInput",
    "RunLogInput",
    "parse_run_log",
]
