"""
UTG Mutation Module

简化版：
- 1 run_log → 1 function
- 语义操作（enrich, split）用 LLM
"""

from src.utg.assets.function_store import (
    Action,
    Function,
    FunctionStore,
    Observation,
    Slot,
    Step,
    enrich_function,
    extract_step_action,
    # Run log import helpers
    extract_step_function_id,
    import_function,
    split_function,
    update_function_source_run_ids,
)

# 保留 input_models 用于验证（可选）
from src.utg.assets.mutation.input_models import (
    ObservationInput,
    RunLogInput,
    StepInput,
    parse_run_log,
)

__all__ = [
    # 新数据模型
    "Observation",
    "Action",
    "Step",
    "Slot",
    "Function",
    "FunctionStore",
    # API 函数
    "import_function",
    "enrich_function",
    "split_function",
    # Run log import helpers
    "extract_step_function_id",
    "extract_step_action",
    "update_function_source_run_ids",
    # 输入验证（可选）
    "RunLogInput",
    "StepInput",
    "ObservationInput",
    "parse_run_log",
]
