"""UTG graph merge helpers."""

from __future__ import annotations

import copy
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from src.utg.assets.embedding import xml_similarity
from src.utg.core.actions import UTG_ACTION_SCHEMA_VERSION
from src.utg.core.models import DEFAULT_UTG_VERSION

logger = logging.getLogger(__name__)

_XML_MERGE_SIMILARITY_THRESHOLD = 0.9


def _is_same_page_xml(base_xml: str, incoming_xml: str) -> bool:
    a = (base_xml or "").strip()
    b = (incoming_xml or "").strip()
    if not a or not b:
        return False
    if a == b:
        return True
    return xml_similarity(a, b) >= _XML_MERGE_SIMILARITY_THRESHOLD


def merge_utg(base_utg: Dict[str, Any], incoming_utg: Dict[str, Any]) -> Dict[str, Any]:
    """Merge two UTG payload dicts and return a new dict."""
    base_nodes = base_utg.get("nodes", [])
    base_functions = base_utg.get("functions", {})
    incoming_nodes = incoming_utg.get("nodes", [])
    incoming_functions = incoming_utg.get("functions", {})

    merged_nodes, node_id_remap = _merge_nodes_with_remap(base_nodes, incoming_nodes)
    merged_functions = merge_functions(
        base_functions, incoming_functions, node_id_remap=node_id_remap
    )
    merged_app_info = _merge_app_info(
        base_utg.get("appInfo", []), incoming_utg.get("appInfo", [])
    )
    merged_triggers = _merge_triggers(
        list(base_utg.get("triggers", []) or []),
        list(incoming_utg.get("triggers", []) or []),
    )

    return {
        "version": DEFAULT_UTG_VERSION,
        "actionSchemaVersion": (
            base_utg.get("actionSchemaVersion")
            or incoming_utg.get("actionSchemaVersion")
            or UTG_ACTION_SCHEMA_VERSION
        ),
        "appInfo": merged_app_info,
        "nodes": merged_nodes,
        "functions": merged_functions,
        "triggers": merged_triggers,
    }


def _merge_nodes_with_remap(
    base_nodes: List[Dict], incoming_nodes: List[Dict]
) -> Tuple[List[Dict], Dict[str, str]]:
    node_dict: Dict[str, Dict[str, Any]] = {}
    base_node_ids: set[str] = set()
    for base_node in base_nodes:
        node_id = str(base_node.get("id", "") or "").strip()
        if not node_id:
            continue
        node_dict[node_id] = copy.deepcopy(base_node)
        base_node_ids.add(node_id)

    node_id_remap: Dict[str, str] = {}
    new_nodes_count = 0
    merged_same_id_count = 0
    merged_same_page_count = 0
    renamed_count = 0

    for index, incoming_raw in enumerate(incoming_nodes):
        incoming_node = copy.deepcopy(incoming_raw)
        raw_node_id = str(incoming_node.get("id", "") or "").strip()
        node_id = raw_node_id or f"auto_node_{index}"
        incoming_node["id"] = node_id

        if node_id in node_dict:
            merged_node, resolved_id = _merge_same_id_nodes(
                node_dict[node_id],
                incoming_node,
                existing_ids=set(node_dict.keys()),
            )
            node_dict[resolved_id] = merged_node
            if resolved_id != node_id:
                renamed_count += 1
            else:
                merged_same_id_count += 1
            node_id_remap[node_id] = resolved_id
            continue

        matched_base_node_id = _find_same_page_node_id(
            node_dict,
            incoming_node,
            candidate_node_ids=base_node_ids,
        )
        if matched_base_node_id:
            node_dict[matched_base_node_id] = _merge_node_payload(
                node_dict[matched_base_node_id],
                incoming_node,
            )
            merged_same_page_count += 1
            node_id_remap[node_id] = matched_base_node_id
            continue

        resolved_id = _next_available_id(node_id, set(node_dict.keys()))
        if resolved_id != node_id:
            incoming_node["id"] = resolved_id
            renamed_count += 1
        node_dict[resolved_id] = incoming_node
        node_id_remap[node_id] = resolved_id
        new_nodes_count += 1

    logger.info(
        "节点合并统计: 新增=%s, 合并相同ID=%s, 合并同一页面=%s, 重命名=%s",
        new_nodes_count,
        merged_same_id_count,
        merged_same_page_count,
        renamed_count,
    )
    return list(node_dict.values()), node_id_remap


def _find_same_page_node_id(
    node_dict: Dict[str, Dict[str, Any]],
    incoming_node: Dict[str, Any],
    *,
    candidate_node_ids: Optional[set[str]] = None,
) -> Optional[str]:
    incoming_xmls = list((incoming_node.get("repr") or {}).get("xmls") or [])
    if not incoming_xmls:
        return None
    incoming_package = _node_package(incoming_node)
    if candidate_node_ids is None:
        candidates = node_dict.items()
    else:
        candidates = (
            (node_id, node_dict[node_id])
            for node_id in candidate_node_ids
            if node_id in node_dict
        )
    for base_node_id, base_node in candidates:
        if _node_package(base_node) != incoming_package:
            continue
        base_xmls = list((base_node.get("repr") or {}).get("xmls") or [])
        if _has_same_page_xml(base_xmls, incoming_xmls):
            return base_node_id
    return None


def _has_same_page_xml(base_xmls: List[str], incoming_xmls: List[str]) -> bool:
    for incoming_xml in incoming_xmls:
        for base_xml in base_xmls:
            try:
                if _is_same_page_xml(base_xml, incoming_xml):
                    return True
            except Exception:
                continue
    return False


def _next_available_id(preferred_id: str, existing_ids: set[str]) -> str:
    candidate = str(preferred_id or "").strip() or "auto_id"
    if candidate not in existing_ids:
        return candidate
    index = 1
    while f"{candidate}_{index}" in existing_ids:
        index += 1
    return f"{candidate}_{index}"


def _node_package(node: Dict[str, Any]) -> str:
    return str((node.get("repr") or {}).get("packageName", "") or "").strip()


def _merge_same_id_nodes(
    base_node: Dict[str, Any],
    incoming_node: Dict[str, Any],
    *,
    existing_ids: set[str],
) -> Tuple[Dict[str, Any], str]:
    base_package = _node_package(base_node)
    incoming_package = _node_package(incoming_node)

    if base_package != incoming_package:
        resolved_id = _next_available_id(
            str(incoming_node.get("id") or ""), existing_ids
        )
        out = copy.deepcopy(incoming_node)
        out["id"] = resolved_id
        logger.info(
            "  节点 '%s': package 不匹配，重命名为 '%s'",
            incoming_node.get("id"),
            resolved_id,
        )
        return out, resolved_id

    merged = _merge_node_payload(base_node, incoming_node)
    resolved_id = str(base_node.get("id") or incoming_node.get("id") or "").strip()
    merged["id"] = resolved_id
    return merged, resolved_id


def _merge_node_payload(
    base_node: Dict[str, Any], incoming_node: Dict[str, Any]
) -> Dict[str, Any]:
    merged_node = copy.deepcopy(base_node)
    for key, value in incoming_node.items():
        if key not in merged_node:
            merged_node[key] = copy.deepcopy(value)

    base_repr = copy.deepcopy(base_node.get("repr", {}))
    incoming_repr = copy.deepcopy(incoming_node.get("repr", {}))
    merged_xmls = _merge_xmls(
        list(base_repr.get("xmls", []) or []),
        list(incoming_repr.get("xmls", []) or []),
    )
    merged_repr = {**incoming_repr, **base_repr}
    merged_repr["xmls"] = merged_xmls
    merged_repr["packageName"] = _node_package(base_node)

    merged_node["repr"] = merged_repr
    merged_node["functions"] = _merge_functions(
        base_node.get("functions", {}), incoming_node.get("functions", {})
    )
    merged_node["triggers"] = _merge_triggers(
        list(base_node.get("triggers", []) or []),
        list(incoming_node.get("triggers", []) or []),
    )
    return merged_node


def _merge_xmls(base_xmls: List[str], incoming_xmls: List[str]) -> List[str]:
    merged_xmls = list(base_xmls)
    for incoming_xml in incoming_xmls:
        if not any(
            _is_same_page_xml(base_xml, incoming_xml) for base_xml in merged_xmls
        ):
            merged_xmls.append(incoming_xml)
    return merged_xmls


def _merge_functions(base_functions: Dict, incoming_functions: Dict) -> Dict:
    merged = copy.deepcopy(base_functions)
    for key, value in incoming_functions.items():
        if key not in merged:
            merged[key] = copy.deepcopy(value)
    return merged


def _merge_triggers(base_triggers: List, incoming_triggers: List) -> List:
    return _merge_object_list_dedup(base_triggers, incoming_triggers)


def merge_functions(
    base_functions: Dict[str, Dict[str, Any]],
    incoming_functions: Dict[str, Dict[str, Any]],
    *,
    node_id_remap: Optional[Dict[str, str]] = None,
) -> Dict[str, Dict[str, Any]]:
    function_dict: Dict[str, Dict[str, Any]] = {}
    for function_id, func in dict(base_functions or {}).items():
        normalized_id = str(function_id or "").strip()
        if not normalized_id:
            continue
        function_dict[normalized_id] = copy.deepcopy(func)

    added_functions = 0
    merged_same_id_functions = 0
    skipped_equivalent_functions = 0
    renamed_functions = 0

    for incoming_key, incoming_raw in dict(incoming_functions or {}).items():
        function_id = str(incoming_key or "").strip()
        if not function_id:
            continue
        incoming_func = _remap_function_node_ids(
            function_id,
            copy.deepcopy(incoming_raw),
            node_id_remap or {},
        )

        if function_id in function_dict:
            function_dict[function_id] = _merge_same_id_functions(
                function_dict[function_id], incoming_func
            )
            merged_same_id_functions += 1
            continue

        duplicate = next(
            (
                existing_id
                for existing_id, existing_func in function_dict.items()
                if _functions_have_same_actions(existing_func, incoming_func)
            ),
            None,
        )
        if duplicate:
            logger.info(
                "  Function '%s' 与已有 function '%s' 动作等价，跳过新增",
                function_id,
                duplicate,
            )
            skipped_equivalent_functions += 1
            continue

        resolved_id = _next_available_id(function_id, set(function_dict.keys()))
        if resolved_id != function_id:
            if str(incoming_func.get("name", "") or "").strip() == function_id:
                incoming_func["name"] = resolved_id
            renamed_functions += 1
        function_dict[resolved_id] = incoming_func
        added_functions += 1

    logger.info(
        "函数合并统计: 新增=%s, 合并相同ID=%s, 跳过等价=%s, 重命名=%s",
        added_functions,
        merged_same_id_functions,
        skipped_equivalent_functions,
        renamed_functions,
    )
    return function_dict


def _remap_function_node_ids(
    function_id: str,
    func: Dict[str, Any],
    node_id_remap: Dict[str, str],
) -> Dict[str, Any]:
    if not node_id_remap:
        if not str(func.get("name", "") or "").strip():
            func["name"] = function_id
        return func
    for key in ("startNodeId", "endNodeId", "start_node_id", "end_node_id"):
        value = func.get(key)
        if value in node_id_remap:
            func[key] = node_id_remap[value]
    for action in list(func.get("actions") or []):
        if not isinstance(action, dict):
            continue
        if str(action.get("type") or "").strip() != "call_function":
            continue
        params = action.get("params")
        if not isinstance(params, dict):
            continue
        node_id = params.get("node_id")
        if node_id in node_id_remap:
            params["node_id"] = node_id_remap[node_id]
    if not str(func.get("name", "") or "").strip():
        func["name"] = function_id
    return func


def _merge_same_id_functions(
    base_func: Dict[str, Any], incoming_func: Dict[str, Any]
) -> Dict[str, Any]:
    merged = copy.deepcopy(base_func)
    for key, value in incoming_func.items():
        if key not in merged:
            merged[key] = copy.deepcopy(value)
    merged["actions"] = copy.deepcopy(
        base_func.get("actions") or incoming_func.get("actions") or []
    )
    merged["description"] = base_func.get("description") or incoming_func.get(
        "description"
    )
    merged["parameters"] = copy.deepcopy(
        base_func.get("parameters") or incoming_func.get("parameters") or {}
    )
    merged["metadata"] = copy.deepcopy(
        {
            **dict(incoming_func.get("metadata") or {}),
            **dict(base_func.get("metadata") or {}),
        }
    )
    merged["triggers"] = _merge_triggers(
        list(base_func.get("triggers", []) or []),
        list(incoming_func.get("triggers", []) or []),
    )
    for key in ("startNodeId", "endNodeId", "start_node_id", "end_node_id"):
        merged[key] = base_func.get(key) or incoming_func.get(key)
    return merged


def _functions_have_same_actions(func1: Dict, func2: Dict) -> bool:
    def function_signature(func: Dict) -> Dict[str, Any]:
        return {
            "actions": copy.deepcopy(list(func.get("actions") or [])),
            "start_node_id": func.get("start_node_id") or func.get("startNodeId"),
            "end_node_id": func.get("end_node_id") or func.get("endNodeId"),
        }

    return _canonical_obj_key(function_signature(func1)) == _canonical_obj_key(
        function_signature(func2)
    )


def _merge_app_info(
    base_app_info: List[Any], incoming_app_info: List[Any]
) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for item in list(base_app_info) + list(incoming_app_info):
        if not isinstance(item, dict):
            try:
                item = json.loads(
                    json.dumps(
                        item,
                        ensure_ascii=False,
                        default=lambda value: getattr(value, "__dict__", str(value)),
                    )
                )
            except Exception:
                continue
        package_name = str(item.get("packageName", "") or "").strip()
        if not package_name:
            continue
        if package_name not in merged:
            merged[package_name] = copy.deepcopy(item)
    return list(merged.values())


def _merge_object_list_dedup(
    base_items: List[Any], incoming_items: List[Any]
) -> List[Any]:
    merged: List[Any] = []
    seen: set[str] = set()
    for item in list(base_items) + list(incoming_items):
        key = _canonical_obj_key(item)
        if key in seen:
            continue
        seen.add(key)
        merged.append(copy.deepcopy(item))
    return merged


def _canonical_obj_key(item: Any) -> str:
    try:
        return json.dumps(item, ensure_ascii=False, sort_keys=True)
    except Exception:
        return repr(item)
