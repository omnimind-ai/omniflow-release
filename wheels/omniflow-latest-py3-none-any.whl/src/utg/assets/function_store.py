"""
Function Store - 简单的 function 存储

设计原则:
1. 收集时简单存，1 run_log → 1 function
2. 聚合时再处理
3. 拆分用 LLM（可选）
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
import uuid

logger = logging.getLogger(__name__)


# =============================================================================
# 数据模型
# =============================================================================


@dataclass
class Observation:
    """观测数据"""

    xml: Optional[str] = None
    image_base64: Optional[str] = None
    package_name: Optional[str] = None
    activity_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "xml": self.xml,
            "image_base64": self.image_base64,
            "package_name": self.package_name,
            "activity_name": self.activity_name,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Observation":
        return cls(
            xml=data.get("xml"),
            image_base64=data.get("image_base64"),
            package_name=data.get("package_name"),
            activity_name=data.get("activity_name"),
        )


@dataclass
class Action:
    """动作"""

    type: str
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"type": self.type, "params": self.params}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Action":
        return cls(
            type=data.get("type", ""),
            params=data.get("params") or {},
        )


@dataclass
class Step:
    """执行步骤"""

    observation: Observation
    actions: List[Action]
    success: bool = True
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "observation": self.observation.to_dict(),
            "actions": [a.to_dict() for a in self.actions],
            "success": self.success,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Step":
        obs_data = data.get("observation") or data.get("observation_before_act") or {}

        # 支持多种 action 格式
        actions_data = data.get("actions") or data.get("executed_actions") or []
        if not actions_data:
            # 从 tool_call 提取 action（materialized run_log 格式）
            tool_call = data.get("tool_call") or {}
            if isinstance(tool_call, dict) and tool_call.get("name"):
                actions_data = [
                    {
                        "type": tool_call.get("name"),
                        "params": tool_call.get("params") or {},
                    }
                ]

        act_result = data.get("act_result") or {}

        return cls(
            observation=Observation.from_dict(obs_data),
            actions=[Action.from_dict(a) for a in actions_data],
            success=act_result.get("success", True)
            if act_result
            else data.get("success", True),
            error=act_result.get("error_message") if act_result else data.get("error"),
        )


@dataclass
class Slot:
    """可参数化的变量"""

    name: str
    description: str = ""
    type: str = "string"
    default: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "default": self.default,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Slot":
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            type=data.get("type", "string"),
            default=data.get("default"),
        )


@dataclass
class Function:
    """
    Function - 一次任务执行的完整记录

    设计:
    - 1 run_log → 1 function（原始设计）
    - 多个相同 goal 的 run_log → 1 function（语义去重后）
    - 语义信息（description, slots）通过 enrich 补充
    - 拆分通过 split 完成
    """

    id: str
    goal: str
    success: bool
    steps: List[Step]

    # 语义信息（enrich 后填充）
    description: Optional[str] = None
    slots: List[Slot] = field(default_factory=list)
    preconditions: List[str] = field(default_factory=list)
    postconditions: List[str] = field(default_factory=list)

    # 原始数据追溯（用于语义去重）
    source_run_ids: List[str] = field(default_factory=list)  # 关联的 run_log IDs
    enriched_goal: Optional[str] = None  # LLM 规范化后的 goal

    # 元数据
    source: str = "unknown"  # agent, human, utg, vlm
    created_at: Optional[str] = None
    split_from: Optional[str] = None  # 如果是从其他 function 拆分出来的
    aggregated_from: List[str] = field(default_factory=list)  # 如果是聚合产生的

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "goal": self.goal,
            "success": self.success,
            "steps": [s.to_dict() for s in self.steps],
            "description": self.description,
            "slots": [s.to_dict() for s in self.slots],
            "preconditions": self.preconditions,
            "postconditions": self.postconditions,
            "source_run_ids": self.source_run_ids,
            "enriched_goal": self.enriched_goal,
            "source": self.source,
            "created_at": self.created_at,
            "split_from": self.split_from,
            "aggregated_from": self.aggregated_from,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Function":
        steps_data = data.get("steps") or []
        slots_data = data.get("slots") or []

        return cls(
            id=data.get("id", ""),
            goal=data.get("goal", ""),
            success=data.get("success", False),
            steps=[Step.from_dict(s) for s in steps_data],
            description=data.get("description"),
            slots=[Slot.from_dict(s) for s in slots_data],
            preconditions=data.get("preconditions") or [],
            postconditions=data.get("postconditions") or [],
            source_run_ids=data.get("source_run_ids") or [],
            enriched_goal=data.get("enriched_goal"),
            source=data.get("source", "unknown"),
            created_at=data.get("created_at"),
            split_from=data.get("split_from"),
            aggregated_from=data.get("aggregated_from") or [],
        )

    @classmethod
    def from_run_log(cls, run_log: Dict[str, Any]) -> "Function":
        """从 run_log 创建 function（1:1 映射，不拆分）"""
        run_id = run_log.get("run_id") or str(uuid.uuid4())[:8]
        steps_data = run_log.get("steps") or []

        return cls(
            id=f"func_{run_id}",
            goal=run_log.get("goal", ""),
            success=run_log.get("success", False),
            steps=[Step.from_dict(s) for s in steps_data],
            source=run_log.get("source", "agent"),
            created_at=run_log.get("created_at")
            or datetime.now(timezone.utc).isoformat(),
        )


# =============================================================================
# Function Store
# =============================================================================


class FunctionStore:
    """
    Function 存储

    每个 function 一个目录，包含：
    - function.json: 主 JSON 文件（不含大型数据）
    - step_N_xml.xml: 每个 step 的 XML
    - step_N_screenshot.png: 每个 step 的截图
    """

    def __init__(self, store_path: str | Path):
        self.store_path = Path(store_path)
        self.store_path.mkdir(parents=True, exist_ok=True)
        self._cache: Dict[str, Function] = {}

    def _function_dir(self, func_id: str) -> Path:
        return self.store_path / func_id

    def _function_path(self, func_id: str) -> Path:
        return self._function_dir(func_id) / "function.json"

    def save(self, func: Function) -> str:
        """保存 function，XML 和 screenshot 单独存文件"""
        import base64

        func_dir = self._function_dir(func.id)
        func_dir.mkdir(parents=True, exist_ok=True)

        # 准备 JSON 数据，提取大型数据到文件
        func_dict = func.to_dict()
        steps = func_dict.get("steps") or []

        for i, step in enumerate(steps):
            obs = step.get("observation") or {}

            # 保存 XML 到文件
            xml_content = obs.get("xml") or ""
            if xml_content:
                xml_path = func_dir / f"step_{i}_xml.xml"
                with open(xml_path, "w", encoding="utf-8") as f:
                    f.write(xml_content)
                obs["xml"] = f"@file:step_{i}_xml.xml"

            # 保存 screenshot 到文件
            image_base64 = obs.get("image_base64") or ""
            if image_base64:
                try:
                    image_data = base64.b64decode(image_base64)
                    img_path = func_dir / f"step_{i}_screenshot.png"
                    with open(img_path, "wb") as f:
                        f.write(image_data)
                    obs["image_base64"] = f"@file:step_{i}_screenshot.png"
                except Exception as e:
                    logger.warning(f"Failed to save screenshot for step {i}: {e}")

        # 保存 JSON
        json_path = self._function_path(func.id)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(func_dict, f, ensure_ascii=False, indent=2)

        self._cache[func.id] = func
        logger.info(f"Saved function: {func.id} with {len(steps)} steps")
        return func.id

    def load(self, func_id: str) -> Optional[Function]:
        """加载 function，自动解析文件引用"""
        import base64

        if func_id in self._cache:
            return self._cache[func_id]

        json_path = self._function_path(func_id)
        if not json_path.exists():
            return None

        func_dir = self._function_dir(func_id)

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 解析文件引用
        steps = data.get("steps") or []
        for step in steps:
            obs = step.get("observation") or {}

            # 加载 XML
            xml_ref = obs.get("xml") or ""
            if xml_ref.startswith("@file:"):
                xml_file = func_dir / xml_ref[6:]
                if xml_file.exists():
                    with open(xml_file, "r", encoding="utf-8") as f:
                        obs["xml"] = f.read()

            # 加载 screenshot
            img_ref = obs.get("image_base64") or ""
            if img_ref.startswith("@file:"):
                img_file = func_dir / img_ref[6:]
                if img_file.exists():
                    with open(img_file, "rb") as f:
                        obs["image_base64"] = base64.b64encode(f.read()).decode()

        func = Function.from_dict(data)
        self._cache[func_id] = func
        return func

    def delete(self, func_id: str) -> bool:
        """删除 function 及其目录"""
        import shutil

        func_dir = self._function_dir(func_id)
        if func_dir.exists() and func_dir.is_dir():
            shutil.rmtree(func_dir)
            self._cache.pop(func_id, None)
            logger.info(f"Deleted function directory: {func_id}")
            return True

        return False

    def list_all(self) -> List[str]:
        """列出所有 function ID"""
        func_ids: set[str] = set()

        for func_dir in self.store_path.iterdir():
            if func_dir.is_dir() and (func_dir / "function.json").exists():
                func_ids.add(func_dir.name)

        return sorted(func_ids)

    def search_by_goal(self, goal: str) -> List[Function]:
        """按 goal 搜索（简单包含匹配）"""
        results = []
        for func_id in self.list_all():
            func = self.load(func_id)
            if func and goal.lower() in func.goal.lower():
                results.append(func)
        return results


# =============================================================================
# API 函数
# =============================================================================


def import_function(run_log: Dict[str, Any], store: FunctionStore) -> Function:
    """
    导入 run_log 为 function

    1 run_log → 1 function，不拆分
    """
    func = Function.from_run_log(run_log)
    store.save(func)
    return func


async def enrich_function(
    func_id: str,
    store: FunctionStore,
    *,
    llm_provider: str = "openai",
    llm_model: str = "gpt-4o",
) -> Function:
    """
    LLM 补齐语义信息

    补齐:
    - description: 任务描述
    - slots: 可参数化的变量
    - preconditions: 前置条件
    - postconditions: 后置条件
    """
    func = store.load(func_id)
    if func is None:
        raise ValueError(f"Function not found: {func_id}")

    # 构建 prompt
    steps_summary = []
    for i, step in enumerate(func.steps):
        actions_str = ", ".join(f"{a.type}({a.params})" for a in step.actions)
        steps_summary.append(f"Step {i}: {actions_str}")

    prompt = f"""分析以下任务执行记录，提取语义信息。

任务目标: {func.goal}
执行步骤:
{chr(10).join(steps_summary)}

请返回 JSON:
{{
    "description": "任务的详细描述",
    "slots": [
        {{"name": "变量名", "description": "描述", "type": "string"}}
    ],
    "preconditions": ["前置条件1", "前置条件2"],
    "postconditions": ["后置条件1", "后置条件2"]
}}
"""

    # 调用 LLM
    try:
        from src.foundation.llm_client import acomplete_json

        result = await acomplete_json(prompt, provider=llm_provider, model=llm_model)

        func.description = result.get("description", func.goal)
        func.slots = [Slot.from_dict(s) for s in result.get("slots", [])]
        func.preconditions = result.get("preconditions", [])
        func.postconditions = result.get("postconditions", [])

        store.save(func)
        logger.info(f"Enriched function: {func_id}")
    except Exception as e:
        logger.warning(f"Failed to enrich function {func_id}: {e}")

    return func


async def split_function(
    func_id: str,
    store: FunctionStore,
    *,
    hint: Optional[str] = None,
    llm_provider: str = "openai",
    llm_model: str = "gpt-4o",
) -> List[Function]:
    """
    LLM 语义切分

    输入: 一个长 function
    输出: 多个短 function（语义独立单元）
    """
    func = store.load(func_id)
    if func is None:
        raise ValueError(f"Function not found: {func_id}")

    # 构建 prompt
    steps_summary = []
    for i, step in enumerate(func.steps):
        actions_str = ", ".join(f"{a.type}({a.params})" for a in step.actions)
        pkg = step.observation.package_name or "unknown"
        steps_summary.append(f"Step {i} [{pkg}]: {actions_str}")

    hint_text = f"\n提示: {hint}" if hint else ""

    prompt = f"""分析以下任务执行记录，将其拆分成语义独立的子任务。

任务目标: {func.goal}
执行步骤:
{chr(10).join(steps_summary)}
{hint_text}

请返回 JSON:
{{
    "splits": [
        {{
            "goal": "子任务目标",
            "step_indices": [0, 1, 2]  // 包含的步骤索引
        }}
    ]
}}

拆分原则:
1. 每个子任务应该是语义完整的独立单元
2. 不要过度拆分，只在明显的语义边界处切断
3. 如果任务本身很简单，可以不拆分（返回空 splits）
"""

    # 调用 LLM
    try:
        from src.foundation.llm_client import acomplete_json

        result = await acomplete_json(prompt, provider=llm_provider, model=llm_model)

        splits = result.get("splits", [])
        if not splits:
            logger.info(f"No split needed for function: {func_id}")
            return [func]

        new_functions = []
        for i, split in enumerate(splits):
            step_indices = split.get("step_indices", [])
            if not step_indices:
                continue

            new_func = Function(
                id=f"{func.id}_part{i}",
                goal=split.get("goal", f"{func.goal} (part {i})"),
                success=func.success,
                steps=[
                    func.steps[idx] for idx in step_indices if idx < len(func.steps)
                ],
                source=func.source,
                created_at=datetime.now(timezone.utc).isoformat(),
                split_from=func.id,
            )
            store.save(new_func)
            new_functions.append(new_func)

        logger.info(f"Split function {func_id} into {len(new_functions)} parts")
        return new_functions

    except Exception as e:
        logger.warning(f"Failed to split function {func_id}: {e}")
        return [func]


# =============================================================================
# Run Log Import Helpers
# =============================================================================


def extract_step_function_id(
    step: Dict[str, Any],
    get_function_by_id: Any,  # callable: (str) -> Function | None
) -> Optional[str]:
    """从 step 中提取 compile hit 的 function_id。

    检查 step 是否是 compile hit（执行已有 function），如果是则返回 function_id。

    Args:
        step: run_log 的单个 step
        get_function_by_id: 用于验证 function 是否存在的回调函数

    Returns:
        function_id 如果是 compile hit，否则 None
    """
    if not isinstance(step, dict):
        return None

    # 1. 检查 compile_result.function_id
    compile_result = step.get("compile_result")
    if isinstance(compile_result, dict):
        func_id = str(compile_result.get("function_id") or "").strip()
        if func_id and get_function_by_id(func_id) is not None:
            return func_id

    # 2. 检查 step.tool_call 是否引用已有 function
    tool_call = step.get("tool_call")
    if not isinstance(tool_call, dict):
        return None

    tool_name = str(tool_call.get("name") or "").strip()
    if not tool_name:
        return None

    tool_params = (
        dict(tool_call.get("params") or {})
        if isinstance(tool_call.get("params"), dict)
        else {}
    )

    # 检查 run_function/execute_function/call_function 工具
    if tool_name in {"run_function", "execute_function", "call_function"}:
        func_id = str(
            tool_call.get("function_id")
            or tool_params.get("function_id")
            or tool_params.get("function_name")
            or ""
        ).strip()
        if func_id and get_function_by_id(func_id) is not None:
            return func_id

    # 检查 tool_name 本身是否是已有 function
    if get_function_by_id(tool_name) is not None:
        return tool_name

    return None


def extract_step_action(step: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """从 step 中提取原子 action。

    检查 step 是否包含可执行的原子动作（click, swipe 等）。

    Args:
        step: run_log 的单个 step

    Returns:
        规范化的 action dict 如果是原子动作，否则 None
    """
    if not isinstance(step, dict):
        return None

    tool_call = step.get("tool_call")
    if not isinstance(tool_call, dict):
        return None

    tool_name = str(tool_call.get("name") or "").strip()
    if not tool_name:
        return None

    tool_params = (
        dict(tool_call.get("params") or {})
        if isinstance(tool_call.get("params"), dict)
        else {}
    )

    # 规范化 tool_name
    canonical_name = _canonical_tool_call_name(tool_name)

    # 支持的动作类型（包括 call_function）
    supported_actions = {
        "click",
        "go_to_node",
        "long_press",
        "input_text",
        "swipe",
        "open_app",
        "press_key",
        "wait",
        "finished",
        "call_function",  # 保留 call_function 作为 step
    }

    if canonical_name not in supported_actions:
        return None

    # 提取 observation_before_act.xml 用于锚点坐标适配
    obs_before = step.get("observation_before_act")
    if isinstance(obs_before, dict):
        source_xml = str(obs_before.get("xml") or "").strip()
        if source_xml:
            tool_params["source_xml"] = source_xml

    # 处理 call_function 类型
    if canonical_name == "call_function":
        # 提取 function_id
        function_id = str(
            tool_call.get("function_id")
            or tool_params.get("function_id")
            or tool_params.get("function_name")
            or ""
        ).strip()
        if function_id:
            tool_params["function_id"] = function_id

        normalized: Dict[str, Any] = {
            "type": "call_function",
            "params": tool_params,
        }
    else:
        normalized = {
            "type": "click_node" if canonical_name == "go_to_node" else canonical_name,
            "params": tool_params,
        }

    reason = str(tool_call.get("reason") or "").strip()
    if reason:
        normalized["description"] = reason

    return normalized


def _canonical_tool_call_name(name: str) -> str:
    """规范化 tool_call name。

    将各种变体名称映射到标准名称。
    """
    name_lower = name.lower().strip()
    # 常见变体映射
    mappings = {
        "tap": "click",
        "click_element": "click",
        "click_at": "click",
        "clickelement": "click",
        "type": "input_text",
        "type_text": "input_text",
        "setText": "input_text",
        "set_text": "input_text",
        "inputtext": "input_text",
        "scroll": "swipe",
        "scroll_down": "swipe",
        "scroll_up": "swipe",
        "longpress": "long_press",
        "long_click": "long_press",
        "presskey": "press_key",
        "key_event": "press_key",
        "keyevent": "press_key",
        "openapp": "open_app",
        "launch_app": "open_app",
        "launchapp": "open_app",
        "navigate_to_node": "go_to_node",
        "gotonode": "go_to_node",
        "goto_node": "go_to_node",
        "finish": "finished",
        "done": "finished",
        "complete": "finished",
        # call_function 变体
        "run_function": "call_function",
        "execute_function": "call_function",
        "callfunction": "call_function",
        "runfunction": "call_function",
        "executefunction": "call_function",
    }
    return mappings.get(name_lower, name_lower)


def update_function_source_run_ids(
    func: "Function",
    run_id: str,
) -> bool:
    """更新 function 的 source_run_ids。

    Args:
        func: 要更新的 Function 实例
        run_id: 要添加的 run_id

    Returns:
        是否更新成功（True 如果添加了新的 run_id）
    """
    if run_id not in func.source_run_ids:
        func.source_run_ids.append(run_id)
        return True
    return False


# =============================================================================
# 导出
# =============================================================================

__all__ = [
    "Observation",
    "Action",
    "Step",
    "Slot",
    "Function",
    "FunctionStore",
    "import_function",
    "enrich_function",
    "split_function",
    # Run log import helpers
    "extract_step_function_id",
    "extract_step_action",
    "update_function_source_run_ids",
]
