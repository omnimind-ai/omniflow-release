"""UTG asset package root."""
