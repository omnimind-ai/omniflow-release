"""
DOM to XML Converter

将 Web DOM 转换为 Android XML hierarchy 格式，实现跨平台 UTG 抽象

核心映射规则:
- DOM element → XML element
- getBoundingClientRect() → bounds="[x1,y1][x2,y2]"
- id/data-testid → resource-id
- aria-label/innerText → text/content-desc
- domain → package
- interactive elements → clickable="true"
"""

from __future__ import annotations

from html.parser import HTMLParser
import logging
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET

logger = logging.getLogger(__name__)


# =============================================================================
# DOM 元素特征提取
# =============================================================================


class DOMElement:
    """DOM 元素的 UTG 表示"""

    def __init__(
        self,
        tag: str,
        attrs: Dict[str, str],
        text: str = "",
        bounds: Optional[Tuple[int, int, int, int]] = None,
        clickable: bool = False,
        xpath: str = "",
        index: int = 0,
    ):
        self.tag = tag
        self.attrs = attrs
        self.text = text
        self.bounds = bounds  # (x1, y1, x2, y2)
        self.clickable = clickable
        self.xpath = xpath
        self.index = index


def is_interactive_element(tag: str, attrs: Dict[str, str]) -> bool:
    """
    判断元素是否可交互

    Args:
        tag: HTML 标签名
        attrs: 元素属性

    Returns:
        bool: 是否可交互
    """
    # 原生交互元素
    interactive_tags = {
        "a",
        "button",
        "input",
        "select",
        "textarea",
        "label",
        "option",
        "details",
        "summary",
    }

    if tag.lower() in interactive_tags:
        return True

    # 有 onclick 或其他事件监听
    event_attrs = {
        "onclick",
        "onchange",
        "onsubmit",
        "onkeydown",
        "onmousedown",
        "onmouseup",
        "ontouchstart",
    }

    if any(attr in attrs for attr in event_attrs):
        return True

    # 有 role 属性
    role = attrs.get("role", "").lower()
    interactive_roles = {
        "button",
        "link",
        "tab",
        "menuitem",
        "option",
        "checkbox",
        "radio",
        "textbox",
        "searchbox",
    }

    if role in interactive_roles:
        return True

    # 有 tabindex（可聚焦）
    if "tabindex" in attrs:
        return True

    return False


def extract_resource_id(attrs: Dict[str, str]) -> Optional[str]:
    """
    提取元素的稳定 ID

    优先级:
    1. id 属性
    2. data-testid 属性
    3. name 属性（表单元素）
    4. aria-labelledby

    Args:
        attrs: 元素属性

    Returns:
        str | None: 资源 ID
    """
    # 优先 id
    if "id" in attrs and attrs["id"].strip():
        return attrs["id"].strip()

    # data-testid（测试 ID）
    if "data-testid" in attrs:
        return attrs["data-testid"].strip()

    # name（表单元素）
    if "name" in attrs:
        return attrs["name"].strip()

    # aria-labelledby
    if "aria-labelledby" in attrs:
        return attrs["aria-labelledby"].strip()

    return None


def extract_text_content(attrs: Dict[str, str], inner_text: str) -> str:
    """
    提取元素的文本内容

    优先级:
    1. aria-label（屏幕阅读器标签）
    2. alt（图片替代文本）
    3. title
    4. placeholder（输入框提示）
    5. innerText

    Args:
        attrs: 元素属性
        inner_text: DOM innerText

    Returns:
        str: 文本内容
    """
    # aria-label
    if "aria-label" in attrs and attrs["aria-label"].strip():
        return attrs["aria-label"].strip()

    # alt (图片)
    if "alt" in attrs and attrs["alt"].strip():
        return attrs["alt"].strip()

    # title
    if "title" in attrs and attrs["title"].strip():
        return attrs["title"].strip()

    # placeholder (输入框)
    if "placeholder" in attrs and attrs["placeholder"].strip():
        return attrs["placeholder"].strip()

    # innerText
    return inner_text.strip()


def extract_css_classes(attrs: Dict[str, str]) -> str:
    """
    提取 CSS 类名（拼接为字符串）

    Args:
        attrs: 元素属性

    Returns:
        str: 类名，用点分隔（如 "button.primary.large"）
    """
    class_attr = attrs.get("class", "")
    classes = class_attr.strip().split()

    if not classes:
        return ""

    # 转换为点分隔
    return "." + ".".join(classes)


# =============================================================================
# DOM → XML 转换
# =============================================================================


async def dom_to_xml(
    html: str,
    page: Any,
    *,
    viewport_width: int = 1920,
    viewport_height: int = 1080,
) -> str:
    """
    将 HTML DOM 转换为 Android XML hierarchy 格式

    Args:
        html: HTML 内容
        page: Playwright Page 实例（用于获取 bounding box）
        viewport_width: 视口宽度
        viewport_height: 视口高度

    Returns:
        str: Android XML 格式的 hierarchy
    """
    try:
        # 获取所有元素的 bounding boxes
        bounds_map = await _extract_bounding_boxes(page)

        # 解析 HTML
        dom_elements = _parse_html_to_dom_elements(html, bounds_map)

        # 构建 XML 树
        root = _build_xml_hierarchy(
            dom_elements,
            package_name=_extract_domain(page.url),
        )

        # 序列化为字符串
        xml_str = ET.tostring(root, encoding="unicode", method="xml")

        return xml_str

    except Exception as e:
        logger.error(f"Failed to convert DOM to XML: {e}")
        raise


async def _extract_bounding_boxes(page: Any) -> Dict[str, Tuple[int, int, int, int]]:
    """
    使用 Playwright 提取所有元素的 bounding box

    Args:
        page: Playwright Page

    Returns:
        Dict: xpath → (x1, y1, x2, y2)
    """
    # 执行 JavaScript 获取所有元素的位置
    script = """
    () => {
        const result = {};
        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_ELEMENT,
            null
        );

        let index = 0;
        let node;
        while (node = walker.nextNode()) {
            const rect = node.getBoundingClientRect();
            const xpath = getXPath(node);

            result[xpath] = {
                x: Math.round(rect.left),
                y: Math.round(rect.top),
                width: Math.round(rect.width),
                height: Math.round(rect.height),
            };

            index++;
        }

        // Helper: 生成 XPath
        function getXPath(element) {
            if (element.id) {
                return `//*[@id="${element.id}"]`;
            }

            const parts = [];
            let current = element;

            while (current && current.nodeType === Node.ELEMENT_NODE) {
                let index = 1;
                let sibling = current.previousSibling;

                while (sibling) {
                    if (sibling.nodeType === Node.ELEMENT_NODE &&
                        sibling.nodeName === current.nodeName) {
                        index++;
                    }
                    sibling = sibling.previousSibling;
                }

                const tagName = current.nodeName.toLowerCase();
                parts.unshift(`${tagName}[${index}]`);

                current = current.parentNode;
            }

            return '/' + parts.join('/');
        }

        return result;
    }
    """

    try:
        bounds_data = await page.evaluate(script)

        # 转换为 (x1, y1, x2, y2) 格式
        bounds_map = {}
        for xpath, rect in bounds_data.items():
            x1 = rect["x"]
            y1 = rect["y"]
            x2 = x1 + rect["width"]
            y2 = y1 + rect["height"]
            bounds_map[xpath] = (x1, y1, x2, y2)

        return bounds_map

    except Exception as e:
        logger.warning(f"Failed to extract bounding boxes: {e}")
        return {}


def _parse_html_to_dom_elements(
    html: str,
    bounds_map: Dict[str, Tuple[int, int, int, int]],
) -> List[DOMElement]:
    """
    解析 HTML 为 DOMElement 列表

    Args:
        html: HTML 内容
        bounds_map: xpath → bounds 映射

    Returns:
        List[DOMElement]: DOM 元素列表
    """

    class DOMHTMLParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self.elements = []
            self.index = 0
            self.xpath_stack = []

        def handle_starttag(self, tag, attrs):
            attrs_dict = dict(attrs)

            # 简化 xpath（不使用真实 xpath，用索引代替）
            xpath = f"//{tag}[{self.index}]"
            self.index += 1

            # 获取 bounds
            bounds = bounds_map.get(xpath)

            # 判断是否可交互
            clickable = is_interactive_element(tag, attrs_dict)

            elem = DOMElement(
                tag=tag,
                attrs=attrs_dict,
                bounds=bounds,
                clickable=clickable,
                xpath=xpath,
                index=self.index,
            )

            self.elements.append(elem)
            self.xpath_stack.append(elem)

        def handle_endtag(self, tag):
            if self.xpath_stack and self.xpath_stack[-1].tag == tag:
                self.xpath_stack.pop()

        def handle_data(self, data):
            if self.xpath_stack and data.strip():
                # 添加文本到最近的父元素
                self.xpath_stack[-1].text += data.strip() + " "

    parser = DOMHTMLParser()
    parser.feed(html)
    parser.close()

    return parser.elements


def _build_xml_hierarchy(
    elements: List[DOMElement],
    package_name: str,
) -> ET.Element:
    """
    构建 Android XML hierarchy

    Args:
        elements: DOM 元素列表
        package_name: 包名（domain）

    Returns:
        ElementTree.Element: XML 根节点
    """
    # 创建根节点（模仿 Android hierarchy）
    root = ET.Element("hierarchy", rotation="0")

    # 遍历元素，构建 XML 节点
    for elem in elements:
        node = ET.SubElement(root, "node")

        # 基础属性
        node.set("index", str(elem.index))
        node.set("class", elem.tag + extract_css_classes(elem.attrs))
        node.set("package", package_name)

        # resource-id
        resource_id = extract_resource_id(elem.attrs)
        if resource_id:
            node.set("resource-id", resource_id)

        # text
        text = extract_text_content(elem.attrs, elem.text)
        if text:
            node.set("text", text[:200])  # 限制长度

        # content-desc (同 text)
        if text:
            node.set("content-desc", text[:200])

        # clickable
        node.set("clickable", "true" if elem.clickable else "false")

        # bounds
        if elem.bounds:
            x1, y1, x2, y2 = elem.bounds
            node.set("bounds", f"[{x1},{y1}][{x2},{y2}]")
        else:
            node.set("bounds", "[0,0][0,0]")

        # xpath (用于调试)
        node.set("xpath", elem.xpath)

    return root


def _extract_domain(url: str) -> str:
    """
    从 URL 提取 domain

    Args:
        url: 完整 URL

    Returns:
        str: domain（如 "amazon.com"）
    """
    from urllib.parse import urlparse

    try:
        parsed = urlparse(url)
        return parsed.netloc or "unknown"
    except ValueError:
        return "unknown"
