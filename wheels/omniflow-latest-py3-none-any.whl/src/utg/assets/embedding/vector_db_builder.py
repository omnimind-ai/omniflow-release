from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Tuple

from src.foundation.paths import get_runtime_file
from src.utg.core.models import UTGGraph, UTGNode

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from src.utg.assets.embedding.page_embedding import LiteVectorDB


def _vector_db_cache_enabled() -> bool:
    from src.foundation.settings import settings

    return settings.storage.vector_db_cache_enabled


def _compute_page_access_weights(utg_graph: UTGGraph) -> Dict[str, float]:
    from math import exp, log, log1p

    try:
        from src.utg.assets.embedding.page_match import UTGMatchConfig

        cfg = UTGMatchConfig()
        max_weight = max(1.0, float(cfg.node_importance_max_weight or 1.0))
        growth_k = max(0.0, float(cfg.node_importance_growth_k or 0.0))
        seq_weight = max(0.0, float(cfg.node_importance_seq_weight or 0.0))
        cluster_weight = max(0.0, float(cfg.node_importance_cluster_weight or 0.0))
    except Exception:
        max_weight = 3.0
        growth_k = 0.6
        seq_weight = 0.7
        cluster_weight = 0.3

    seq_hit_counts: Dict[str, int] = {}
    # Extract node_ids from function call_function actions
    for func_name, func in (utg_graph.functions or {}).items():
        for action in getattr(func, "actions", []) or []:
            action_type = str(getattr(action, "type", "")).strip()
            if action_type == "call_function":
                params = getattr(action, "params", None)
                if params:
                    node_id = str(getattr(params, "node_id", "") or "").strip()
                    if node_id:
                        seq_hit_counts[node_id] = seq_hit_counts.get(node_id, 0) + 1

    weights: Dict[str, float] = {}
    for node in utg_graph.nodes or []:
        node_id = str(node.id)
        seq_hit_count = max(0, int(seq_hit_counts.get(node_id, 0)))
        # Cluster size: count from both vector_sets and legacy xmls
        cluster_size = max(
            1, len(node.repr.vector_sets or []) or len(node.repr.xmls or [])
        )
        score = (seq_weight * log1p(float(seq_hit_count))) + (
            cluster_weight * log(float(cluster_size))
        )
        if growth_k <= 0 or max_weight <= 1.0:
            weight = 1.0
        else:
            growth = 1.0 - exp(-growth_k * max(0.0, score))
            weight = 1.0 + ((max_weight - 1.0) * growth)
        weights[node_id] = float(max(1.0, min(max_weight, weight)))
    return weights


def _utg_fingerprint(utg_graph: UTGGraph) -> str:
    sha = hashlib.sha256()
    sha.update(str(len(utg_graph.nodes)).encode("utf-8"))
    for node in utg_graph.nodes:
        sha.update(str(node.id).encode("utf-8"))
        sha.update(str(node.repr.packageName or "").encode("utf-8"))
        sha.update(str(node.repr.description or "").encode("utf-8"))
        # Include both vector_sets and legacy xmls in fingerprint
        for vs in node.repr.vector_sets or []:
            sha.update(str(vs.get("fingerprint", "")).encode("utf-8"))
        for xml in node.repr.xmls or []:
            sha.update(str(xml).encode("utf-8"))
    return sha.hexdigest()


def _embedding_pipeline_fingerprint() -> str:
    """
    Fingerprint embedding implementation files so cache invalidates when
    vectorization logic changes even if UTG data is unchanged.
    """
    sha = hashlib.sha256()
    try:
        from src.utg.assets.embedding import element_embedding, page_embedding

        for module in (element_embedding, page_embedding):
            module_file = Path(str(getattr(module, "__file__", ""))).resolve()
            if module_file.exists():
                sha.update(module_file.read_bytes())
    except Exception:
        # Fall back to a deterministic marker when source hashing is unavailable.
        sha.update(b"embedding-pipeline-fingerprint-unavailable")
    return sha.hexdigest()


def _meta_path(db_path: str) -> Path:
    return Path(f"{db_path}.meta.json")


def _load_meta(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_meta(path: Path, payload: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception:
        logger.warning("Failed to save vector DB meta file: %s", path)


def build_utg_vector_db(
    utg_graph: UTGGraph,
    db_path: str | None = None,
) -> Tuple["LiteVectorDB", Dict[str, UTGNode]]:
    """
    Build vector DB for UTG nodes (offline or on-demand).
    1) Vectorize all node XMLs into the DB.
    2) Return DB instance and node_id -> node mapping.
    """
    from src.utg.assets.embedding.page_embedding import LiteVectorDB

    logger.info("开始构建向量库，共 %s 个节点...", len(utg_graph.nodes))

    resolved_path = db_path or str(get_runtime_file("cache", "ui_auto_enhanced.db"))
    db = LiteVectorDB(resolved_path)
    node_lookup: Dict[str, UTGNode] = {}
    utg_fingerprint = _utg_fingerprint(utg_graph)
    embedding_fingerprint = _embedding_pipeline_fingerprint()

    for node in utg_graph.nodes:
        node_lookup[node.id] = node

    cache_enabled = _vector_db_cache_enabled()
    meta_file = _meta_path(resolved_path)
    meta = _load_meta(meta_file) if cache_enabled else {}
    db_count = len(db.ids)
    if (
        cache_enabled
        and db_count > 0
        and str(meta.get("utg_fingerprint", "")) == utg_fingerprint
        and str(meta.get("embedding_fingerprint", "")) == embedding_fingerprint
    ):
        logger.info("向量库命中缓存：%s（页面数=%s）", resolved_path, db_count)
        return db, node_lookup

    db.clear()
    count = 0
    page_access_weights = _compute_page_access_weights(utg_graph)
    for node in utg_graph.nodes:
        access_weight = float(page_access_weights.get(str(node.id), 1.0))
        base_meta = {
            "node_id": node.id,
            "package": node.repr.packageName,
            "desc": node.repr.description or "No Description",
            "page_access_weight": access_weight,
        }
        encode_ctx = {
            "page_access_weight": access_weight,
            "package_name": str(node.repr.packageName or ""),
            "package": str(node.repr.packageName or ""),
        }

        # Priority 1: Use vector_sets if available (new asset separation model)
        if node.repr.vector_sets:
            import numpy as np

            for idx, vs_dict in enumerate(node.repr.vector_sets):
                page_id = f"{node.id}#vs_{idx}"
                meta = dict(base_meta)
                meta["source"] = "vector_set"

                # Try to use pre-computed page_vector
                page_vector = vs_dict.get("page_vector")
                if page_vector is not None and hasattr(db, "add_page_with_vector"):
                    vec = np.array(page_vector, dtype=np.float32)
                    db.add_page_with_vector(page_id, vec, meta)
                    count += 1
                else:
                    # Fallback: create minimal representation
                    fingerprint = vs_dict.get("fingerprint", "")
                    pkg = vs_dict.get("package_name", node.repr.packageName)
                    db.add_page(
                        page_id,
                        f"<page package='{pkg}' fingerprint='{fingerprint}'/>",
                        meta,
                        encode_context=encode_ctx,
                    )
                    count += 1
            continue

        # Priority 2: Use legacy xmls (backward compatibility)
        if not node.repr.xmls:
            continue

        for idx, xml_content in enumerate(node.repr.xmls):
            page_id = f"{node.id}#{idx}"
            meta = dict(base_meta)
            meta["source"] = "xml"
            db.add_page(
                page_id,
                xml_content,
                meta,
                encode_context=encode_ctx,
            )
            count += 1

    if cache_enabled:
        db.save()
        _save_meta(
            meta_file,
            {
                "utg_fingerprint": utg_fingerprint,
                "embedding_fingerprint": embedding_fingerprint,
                "page_count": count,
                "node_count": len(utg_graph.nodes),
            },
        )

    logger.info("向量库构建完成。录入 XML 页面数: %s", count)
    return db, node_lookup
