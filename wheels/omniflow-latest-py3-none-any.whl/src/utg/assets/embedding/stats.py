from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, Dict, List, Optional


@dataclass
class MatchStats:
    attempts: int = 0
    hits: int = 0
    last_node_id: Optional[str] = None
    last_score: Optional[float] = None
    last_strategy: Optional[str] = None
    timings_ms: List[float] = field(default_factory=list)

    def record(
        self,
        node_id: Optional[str],
        score: Optional[float],
        strategy: str,
        elapsed_ms: float,
    ) -> None:
        self.attempts += 1
        if node_id is not None:
            self.hits += 1
        self.last_node_id = node_id
        self.last_score = score
        self.last_strategy = strategy
        self.timings_ms.append(elapsed_ms)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attempts": self.attempts,
            "hits": self.hits,
            "hit_rate": self.hits / self.attempts if self.attempts else 0.0,
            "last_node_id": self.last_node_id,
            "last_score": self.last_score,
            "last_strategy": self.last_strategy,
            "timings_ms": self.timings_ms,
        }


@dataclass
class ExecutionStats:
    functions_run: int = 0
    actions_run: int = 0
    function_assets_run: int = 0
    errors: List[str] = field(default_factory=list)
    last_function_id: Optional[str] = None
    timings_ms: List[float] = field(default_factory=list)

    def record_function_asset(self, function_id: str, elapsed_ms: float) -> None:
        self.function_assets_run += 1
        self.last_function_id = function_id
        self.timings_ms.append(elapsed_ms)

    def record_function(self, actions_count: int) -> None:
        self.functions_run += 1
        self.actions_run += actions_count

    def record_error(self, message: str) -> None:
        self.errors.append(message)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "function_assets_run": self.function_assets_run,
            "functions_run": self.functions_run,
            "actions_run": self.actions_run,
            "errors": self.errors,
            "last_function_id": self.last_function_id,
            "timings_ms": self.timings_ms,
        }


class UTGStatsCollector:
    def __init__(self) -> None:
        self.match = MatchStats()
        self.execution = ExecutionStats()

    def timed_match(
        self,
        node_id: Optional[str],
        score: Optional[float],
        strategy: str,
        start_time: float,
    ) -> None:
        elapsed_ms = (perf_counter() - start_time) * 1000
        self.match.record(
            node_id=node_id, score=score, strategy=strategy, elapsed_ms=elapsed_ms
        )

    def timed_function_asset(self, function_id: str, start_time: float) -> None:
        elapsed_ms = (perf_counter() - start_time) * 1000
        self.execution.record_function_asset(
            function_id=function_id,
            elapsed_ms=elapsed_ms,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "match": self.match.to_dict(),
            "execution": self.execution.to_dict(),
        }


__all__ = ["MatchStats", "ExecutionStats", "UTGStatsCollector"]
