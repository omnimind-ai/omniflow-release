import logging
import os
from pathlib import Path
import pickle
import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from src.foundation.paths import get_runtime_file
from src.utg.assets.embedding.config import ElementEmbeddingConfig, PageEncodingConfig
from src.utg.assets.embedding.element_embedding import (
    ElementVectorizer,
    TextHashEncoder,
    UITree,
)

logger = logging.getLogger(__name__)

# ==============================================================================
# 1. 语义清洗器 (Semantic Cleaner)
# ==============================================================================


class SemanticCleaner:
    """
    负责清洗页面文本，去除噪音（时间、电量、纯数字、停用词），
    提取出真正代表页面业务属性的关键词。
    """

    def __init__(self, config: Optional[PageEncodingConfig] = None):
        self.config = config or PageEncodingConfig()
        self.stop_words = set(self.config.stop_words)
        self.re_noise = re.compile(self.config.noise_regex)
        self.re_chinese = re.compile(self.config.chinese_regex)

    def is_valid(self, text: str, element_class: str = "") -> bool:
        if not text:
            return False
        # 忽略输入框的内容（通常是用户填写的，不稳定）
        if "EditText" in element_class:
            return False
        # 忽略纯数字/符号
        if self.re_noise.match(text):
            return False
        # 忽略太短的非中文
        if len(text) < self.config.min_text_len and not self.re_chinese.search(text):
            return False
        # 忽略太长的文本（通常是内容而非标题）
        if len(text) > self.config.max_text_len:
            return False
        # 忽略停用词
        if text in self.stop_words:
            return False
        return True

    def tokenize(self, text: str) -> List[str]:
        """将文本切分为用于 Page Hash 的 Token"""
        text = text.strip().lower()
        # 移除标点
        text = re.sub(r"[^\w\u4e00-\u9fff]", "", text)
        if not text:
            return []

        tokens = []
        # 中文：全词 + 单字
        if self.re_chinese.search(text):
            tokens.append(text)
            if len(text) >= 2:
                tokens.extend([c for c in text if c not in self.stop_words])
        # 英文：空格切分
        else:
            tokens.extend([t for t in text.split() if len(t) > 2])
        # print(tokens)
        return tokens


# ==============================================================================
# 2. 增强型页面编码器 (Enhanced Page Encoder)
# ==============================================================================


class EnhancedPageEncoder:
    """
    V3 架构：
    1. Global/Regional Pooling: weighted-max Global/App Topbar/Footer/Middle
    2. Functional Subspaces: selected_target + body actionable/focus/display
    3. Functional Anchors: 关键功能点探测 (搜索/返回/关闭)
    """

    def __init__(
        self,
        config: Optional[PageEncodingConfig] = None,
        element_config: Optional[ElementEmbeddingConfig] = None,
    ):
        self.config = config or PageEncodingConfig()
        self.element_config = element_config or ElementEmbeddingConfig()
        # 1. 获取节点向量维度
        self.element_vectorizer = ElementVectorizer(self.element_config)
        self.element_dim = self.element_vectorizer.total_dim

        # 3. 定义功能锚点 (Virtual Anchors)
        # 这里的 Key 是功能名，Value 是该功能的特征词
        self.anchor_seeds = dict(self.config.anchor_seeds)
        # 预计算锚点向量
        self.anchor_vectors = self._precompute_anchors()
        self.anchor_dim = len(self.anchor_vectors)

        # 计算总维度
        # 8个节点池化视图（global_all, app_topbar, footer, middle_region,
        # selected_target, body_actionable/body_focus/body_display）+ 锚点分数。
        self.page_dim = (self.element_dim * 8) + self.anchor_dim

    def _precompute_anchors(self) -> np.ndarray:
        """构造虚拟锚点的向量矩阵"""
        # 我们只关心文本特征，所以手动构造一个只包含 content_hash 的向量
        vectors = []

        # 新 API: get_feature_slice(feature_name) - 单参数
        # "content_hash" 是 Human Observation 的核心特征
        start_idx, end_idx = self.element_vectorizer.get_feature_slice("content_hash")

        for _, seeds in self.anchor_seeds.items():
            vec = np.zeros(self.element_dim, dtype=np.float32)
            hash_part = TextHashEncoder.encode(seeds, self.element_config)
            anchor_weight = self.element_config.semantic_weight
            vec[start_idx:end_idx] = hash_part * anchor_weight
            vectors.append(vec)

        return np.stack(vectors)  # (N_Anchors, Node_Dim)

    def _build_element_importance_weights(
        self,
        *,
        ui_tree: UITree,
        aligned_elements: List[Dict[str, Any]],
        texts: List[str],
        child_counts: np.ndarray,
        is_actionable: np.ndarray,
        is_focus_target: np.ndarray,
        cleaner: SemanticCleaner,
    ) -> np.ndarray:
        sibling_signatures: List[tuple[str, str, str, str]] = []
        for idx, elem in enumerate(aligned_elements):
            class_name = str(elem.get("class", "") or "").split(".")[-1]
            resource_key = UITree._normalize_resource_id(
                str(
                    elem.get("resource-id")
                    or elem.get("resource-id-raw")
                    or elem.get("resource_name")
                    or elem.get("resource_id")
                    or ""
                )
            )
            text_key = (
                texts[idx].strip().lower()[:24]
                if cleaner.is_valid(texts[idx], class_name)
                else ""
            )
            role_key = (
                "action"
                if bool(is_actionable[idx])
                else ("focus" if bool(is_focus_target[idx]) else "display")
            )
            sibling_signatures.append(
                (
                    str(elem.get("parent_id") or ""),
                    class_name,
                    resource_key or text_key,
                    role_key,
                )
            )

        signature_counts: Dict[tuple[str, str, str, str], int] = {}
        for signature in sibling_signatures:
            signature_counts[signature] = signature_counts.get(signature, 0) + 1

        weights = np.ones(len(aligned_elements), dtype=np.float32)
        for idx, elem in enumerate(aligned_elements):
            class_name = str(elem.get("class", "") or "").split(".")[-1]
            text = texts[idx]
            sibling_count = int(signature_counts.get(sibling_signatures[idx], 1))
            resource_text = UITree._normalize_resource_id(
                str(
                    elem.get("resource-id")
                    or elem.get("resource-id-raw")
                    or elem.get("resource_name")
                    or elem.get("resource_id")
                    or ""
                )
            )
            stable_text = cleaner.is_valid(text, class_name)
            has_anchor = bool(resource_text) or stable_text
            interactive = bool(is_actionable[idx]) or bool(is_focus_target[idx])
            is_root_elem = str(elem.get("id") or "") == "__aw_root__"

            weight = 1.0
            if sibling_count > 1:
                repeat_scale = 1.0 / (
                    1.0
                    + (
                        self.config.element_weight_repeat_penalty
                        * float(sibling_count - 1)
                    )
                )
                weight *= repeat_scale
            if has_anchor and not is_root_elem:
                weight *= 1.0 + self.config.element_weight_anchor_text_boost
            if interactive:
                weight *= 1.0 + self.config.element_weight_interactive_boost
            if int(child_counts[idx]) > 0 and has_anchor:
                weight *= 1.0 + (0.5 * self.config.element_weight_anchor_text_boost)

            weights[idx] = float(min(weight, self.config.element_weight_max))

        return weights

    @staticmethod
    def _package_counts(aligned_elements: List[Dict[str, Any]]) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for elem in aligned_elements:
            pkg = str(elem.get("package") or "").strip()
            if not pkg:
                continue
            counts[pkg] = counts.get(pkg, 0) + 1
        return counts

    def _resolve_primary_package(
        self,
        aligned_elements: List[Dict[str, Any]],
        encode_context: Optional[Dict[str, Any]],
    ) -> str:
        context = encode_context or {}
        for key in ("package_name", "package"):
            pkg = str(context.get(key) or "").strip()
            if pkg:
                return pkg

        if aligned_elements:
            root_pkg = str(aligned_elements[0].get("package") or "").strip()
            if root_pkg:
                return root_pkg

        counts = self._package_counts(aligned_elements)
        if not counts:
            return ""
        return max(counts.items(), key=lambda item: (item[1], -len(item[0]), item[0]))[
            0
        ]

    def analyze(
        self,
        ui_tree: UITree,
        encode_context: Optional[Dict[str, Any]] = None,
        *,
        top_n: int = 12,
    ) -> Dict[str, Any]:
        # Align vectors with parsed element order; duplicated element ids may collapse
        # ui_tree.vectors keys and cause mask/feature length mismatch.
        aligned_elements = []
        aligned_vectors = []
        for elem in ui_tree.elements:
            elem_id = elem.get("id")
            vec = ui_tree.vectors.get(elem_id)
            if vec is None:
                continue
            aligned_elements.append(elem)
            aligned_vectors.append(vec)

        if not aligned_vectors:
            empty_vec = np.zeros(self.page_dim, dtype=np.float32)
            return {
                "vector": empty_vec,
                "analysis": {
                    "primary_package": str(
                        (encode_context or {}).get("package_name")
                        or (encode_context or {}).get("package")
                        or ""
                    ),
                    "app_topbar_cut": None,
                    "footer_cut": None,
                    "app_topbar_element_ids": [],
                    "footer_element_ids": [],
                    "middle_region_element_ids": [],
                    "selected_target_element_ids": [],
                    "body_actionable_element_ids": [],
                    "body_focus_target_element_ids": [],
                    "body_display_text_element_ids": [],
                    "element_rows": [],
                },
            }

        element_matrix = np.stack(aligned_vectors)
        num_elements = len(aligned_elements)

        root_h = ui_tree.root_bounds[3] - ui_tree.root_bounds[1]
        if root_h <= 0:
            root_h = self.config.root_height_default
        y_ratios = np.array(
            [n.get("center", (0, 0))[1] / root_h for n in aligned_elements]
        )

        texts = [ui_tree.get_text(elem) for elem in aligned_elements]
        has_text = np.array([bool(str(t or "").strip()) for t in texts], dtype=bool)
        child_counts = np.array(
            [len(list(e.get("children_ids") or [])) for e in aligned_elements],
            dtype=np.int32,
        )

        def is_true(elem: Dict[str, object], *keys: str, default: bool = False) -> bool:
            for key in keys:
                value = elem.get(key)
                if value in (None, ""):
                    continue
                return str(value).lower() == "true"
            return default

        is_actionable = np.array(
            [
                (
                    is_true(n, "clickable")
                    or is_true(n, "checkable")
                    or is_true(n, "long-clickable")
                )
                and is_true(n, "enabled", default=True)
                and is_true(n, "visible", "visible-to-user", default=True)
                for n in aligned_elements
            ],
            dtype=bool,
        )
        is_focus_target = np.array(
            [
                (
                    is_true(n, "focusable")
                    or is_true(n, "editable")
                    or is_true(n, "focused")
                )
                and is_true(n, "enabled", default=True)
                and is_true(n, "visible", "visible-to-user", default=True)
                for n in aligned_elements
            ],
            dtype=bool,
        )
        is_display_text = np.array(
            [
                bool(has_text[idx])
                and int(child_counts[idx]) == 0
                and not bool(is_actionable[idx])
                and not bool(is_focus_target[idx])
                for idx in range(num_elements)
            ],
            dtype=bool,
        )

        cleaner = SemanticCleaner(self.config)
        element_weights = self._build_element_importance_weights(
            ui_tree=ui_tree,
            aligned_elements=aligned_elements,
            texts=texts,
            child_counts=child_counts,
            is_actionable=is_actionable,
            is_focus_target=is_focus_target,
            cleaner=cleaner,
        )
        weighted_element_matrix = element_matrix * element_weights[:, None]
        is_root = np.array(
            [str(n.get("id") or "") == "__aw_root__" for n in aligned_elements],
            dtype=bool,
        )

        def masked_weighted_max(mask: np.ndarray) -> np.ndarray:
            if not np.any(mask):
                return np.zeros(self.element_dim, dtype=np.float32)
            return np.max(weighted_element_matrix[mask], axis=0)

        global_mask = ~is_root
        f_global_all = masked_weighted_max(global_mask)

        footer_cut = float(np.quantile(y_ratios, self.config.footer_ratio))
        primary_package = self._resolve_primary_package(
            aligned_elements, encode_context
        )
        package_names = np.array(
            [str(n.get("package") or "").strip() for n in aligned_elements],
            dtype=object,
        )
        app_package_mask = np.ones(num_elements, dtype=bool)
        if primary_package:
            # Many stored XMLs omit child-package attributes; treat blank package as
            # inheriting the current app so local subspaces do not collapse to zero.
            app_package_mask = (package_names == primary_package) | (
                package_names == ""
            )

        topbar_y = y_ratios[app_package_mask]
        if topbar_y.size > 0:
            app_topbar_cut = float(np.quantile(topbar_y, self.config.header_ratio))
            app_topbar_mask = app_package_mask & (y_ratios <= app_topbar_cut)
        else:
            app_topbar_cut = float(np.quantile(y_ratios, self.config.header_ratio))
            app_topbar_mask = y_ratios <= app_topbar_cut

        footer_mask = (~is_root) & (y_ratios >= footer_cut)
        middle_region_mask = (
            app_package_mask & (~is_root) & (~app_topbar_mask) & (~footer_mask)
        )

        def is_selected_like(elem: Dict[str, object]) -> bool:
            return (
                is_true(elem, "selected")
                or is_true(elem, "activated")
                or (is_true(elem, "checkable") and is_true(elem, "checked"))
            )

        selected_like = np.array(
            [is_selected_like(n) for n in aligned_elements], dtype=bool
        )
        selected_target_mask = app_package_mask & (~is_root) & selected_like
        selected_footer_mask = selected_target_mask & footer_mask
        selected_middle_mask = selected_target_mask & middle_region_mask
        body_actionable_mask = middle_region_mask & is_actionable
        body_focus_target_mask = middle_region_mask & is_focus_target
        body_display_text_mask = middle_region_mask & is_display_text

        f_app_topbar = masked_weighted_max(app_topbar_mask & (~is_root))
        f_footer = masked_weighted_max(footer_mask)
        f_middle_region = masked_weighted_max(middle_region_mask)
        if np.any(selected_footer_mask):
            f_selected_target = masked_weighted_max(selected_footer_mask)
        elif np.any(selected_middle_mask):
            f_selected_target = masked_weighted_max(selected_middle_mask)
        else:
            f_selected_target = masked_weighted_max(selected_target_mask)
        f_body_actionable = masked_weighted_max(body_actionable_mask)
        f_body_focus_target = masked_weighted_max(body_focus_target_mask)
        f_body_display_text = masked_weighted_max(body_display_text_mask)

        sim_matrix = np.dot(weighted_element_matrix, self.anchor_vectors.T)
        anchor_scores = np.max(sim_matrix, axis=0)

        access_weight = float(
            (encode_context or {}).get("page_access_weight", 1.0) or 1.0
        )
        access_scale = 1.0 + (
            self.config.page_access_prior_scale * max(0.0, access_weight - 1.0)
        )
        if access_scale != 1.0:
            f_selected_target *= access_scale
            f_body_actionable *= access_scale
            f_body_focus_target *= access_scale
            f_body_display_text *= access_scale
            anchor_scores *= access_scale

        final_vec = np.concatenate(
            [
                f_global_all,
                f_app_topbar,
                f_footer,
                f_middle_region,
                f_selected_target,
                f_body_actionable,
                f_body_focus_target,
                f_body_display_text,
                anchor_scores,
            ]
        )
        norm = np.linalg.norm(final_vec)
        if norm > 1e-9:
            final_vec /= norm
        final_vec = final_vec.astype(np.float32)

        root_w = ui_tree.root_bounds[2] - ui_tree.root_bounds[0]
        root_h_full = ui_tree.root_bounds[3] - ui_tree.root_bounds[1]
        root_area = max(float(root_w * root_h_full), 1.0)
        sibling_signatures: List[tuple[str, str, str, str]] = []
        for idx, elem in enumerate(aligned_elements):
            class_name = str(elem.get("class", "") or "").split(".")[-1]
            resource_key = UITree._normalize_resource_id(
                str(
                    elem.get("resource-id")
                    or elem.get("resource-id-raw")
                    or elem.get("resource_name")
                    or elem.get("resource_id")
                    or ""
                )
            )
            text_key = (
                texts[idx].strip().lower()[:24]
                if cleaner.is_valid(texts[idx], class_name)
                else ""
            )
            role_key = (
                "action"
                if bool(is_actionable[idx])
                else ("focus" if bool(is_focus_target[idx]) else "display")
            )
            sibling_signatures.append(
                (
                    str(elem.get("parent_id") or ""),
                    class_name,
                    resource_key or text_key,
                    role_key,
                )
            )

        signature_counts: Dict[tuple[str, str, str, str], int] = {}
        for signature in sibling_signatures:
            signature_counts[signature] = signature_counts.get(signature, 0) + 1

        rows: List[Dict[str, Any]] = []
        for idx, elem in enumerate(aligned_elements):
            class_name = str(elem.get("class", "") or "").split(".")[-1]
            text = texts[idx]
            resource_text = UITree._normalize_resource_id(
                str(
                    elem.get("resource-id")
                    or elem.get("resource-id-raw")
                    or elem.get("resource_name")
                    or elem.get("resource_id")
                    or ""
                )
            )
            stable_text = cleaner.is_valid(text, class_name)
            has_anchor = bool(resource_text) or stable_text
            interactive = bool(is_actionable[idx]) or bool(is_focus_target[idx])
            is_root_elem = str(elem.get("id") or "") == "__aw_root__"
            area_ratio = float(elem.get("area", 0.0) or 0.0) / root_area
            sibling_count = int(signature_counts.get(sibling_signatures[idx], 1))
            repeat_scale = (
                1.0
                / (
                    1.0
                    + (
                        self.config.element_weight_repeat_penalty
                        * float(sibling_count - 1)
                    )
                )
                if sibling_count > 1
                else 1.0
            )
            anchor_boost = (
                (1.0 + self.config.element_weight_anchor_text_boost)
                if (has_anchor and not is_root_elem)
                else 1.0
            )
            interactive_boost = (
                (1.0 + self.config.element_weight_interactive_boost)
                if interactive
                else 1.0
            )
            container_boost = (
                (1.0 + (0.5 * self.config.element_weight_anchor_text_boost))
                if (int(child_counts[idx]) > 0 and has_anchor)
                else 1.0
            )
            memberships: List[str] = []
            if bool(global_mask[idx]):
                memberships.append("global_all")
            if bool(app_topbar_mask[idx]) and not bool(is_root[idx]):
                memberships.append("app_topbar")
            if bool(footer_mask[idx]):
                memberships.append("footer")
            if bool(middle_region_mask[idx]):
                memberships.append("middle_region")
            if bool(selected_target_mask[idx]):
                memberships.append("selected_target")
            if bool(body_actionable_mask[idx]):
                memberships.append("body_actionable")
            if bool(body_focus_target_mask[idx]):
                memberships.append("body_focus_target")
            if bool(body_display_text_mask[idx]):
                memberships.append("body_display_text")
            rows.append(
                {
                    "element_id": str(elem.get("id") or ""),
                    "package": str(elem.get("package") or ""),
                    "class": class_name,
                    "text": str(text or "")[:80],
                    "resource": resource_text[:60],
                    "y_ratio": round(float(y_ratios[idx]), 4),
                    "area_ratio": round(float(area_ratio), 4),
                    "children": int(child_counts[idx]),
                    "repeat_count": int(sibling_count),
                    "repeat_scale": round(float(repeat_scale), 3),
                    "anchor_boost": round(float(anchor_boost), 3),
                    "area_boost": 1.0,
                    "interactive_boost": round(float(interactive_boost), 3),
                    "container_boost": round(float(container_boost), 3),
                    "weight": round(float(element_weights[idx]), 4),
                    "memberships": memberships,
                }
            )
        rows.sort(
            key=lambda item: (
                -float(item.get("weight", 0.0)),
                float(item.get("y_ratio", 0.0)),
                str(item.get("class", "")),
                str(item.get("element_id", "")),
            )
        )
        element_rows = rows[: max(1, int(top_n or 1))]

        analysis = {
            "primary_package": primary_package,
            "app_topbar_cut": round(float(app_topbar_cut), 4)
            if app_topbar_cut is not None
            else None,
            "footer_cut": round(float(footer_cut), 4),
            "app_topbar_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(app_topbar_mask & (~is_root))
            ],
            "footer_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(footer_mask)
            ],
            "middle_region_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(middle_region_mask)
            ],
            "selected_target_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(selected_target_mask)
            ],
            "body_actionable_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_actionable_mask)
            ],
            "body_focus_target_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_focus_target_mask)
            ],
            "body_display_text_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_display_text_mask)
            ],
            "element_rows": element_rows,
        }
        return {"vector": final_vec, "analysis": analysis}

    def encode(
        self, ui_tree: UITree, encode_context: Optional[Dict[str, Any]] = None
    ) -> np.ndarray:
        return self.analyze(ui_tree, encode_context=encode_context)["vector"]


# ==============================================================================
# 3. 向量数据库 (Lite Vector DB) - 适配新 Encoder
# ==============================================================================


class LiteVectorDB:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or str(get_runtime_file("cache", "ui_auto_enhanced.db"))
        # 使用增强版编码器
        self.encoder = EnhancedPageEncoder()

        self.ids: List[str] = []
        self.vectors: Optional[np.ndarray] = None
        self.metadata: Dict[str, Dict] = {}
        self.load()

    def add_page(
        self,
        page_id: str,
        xml_content: str,
        meta: Dict = None,
        encode_context: Optional[Dict[str, Any]] = None,
    ):
        tree = UITree(xml_content, is_file=False)
        vec = self.encoder.encode(tree, encode_context=encode_context)

        if page_id in self.metadata:
            # Upsert existing page vector to avoid duplicate page_id rows.
            idx = self.ids.index(page_id)
            if self.vectors is None:
                self.vectors = np.array([vec], dtype=np.float32)
                self.ids = [page_id]
            else:
                self.vectors[idx] = vec
        else:
            if self.vectors is None:
                self.vectors = np.array([vec], dtype=np.float32)
            else:
                self.vectors = np.vstack([self.vectors, vec])
            self.ids.append(page_id)

        self.metadata[page_id] = meta or {}

    def search(
        self,
        xml_content: str,
        top_k: int = 3,
        threshold: float | None = None,
        encode_context: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[str, float, Dict]]:
        if self.vectors is None or len(self.vectors) == 0:
            return []

        tree = UITree(xml_content, is_file=False)
        query_vec = self.encoder.encode(tree, encode_context=encode_context)

        scores = np.dot(self.vectors, query_vec)

        k = min(top_k, len(scores))
        top_indices = np.argpartition(scores, -k)[-k:]
        top_indices = top_indices[np.argsort(scores[top_indices])[::-1]]

        results = []
        for idx in top_indices:
            pid = self.ids[idx]
            score = float(scores[idx])
            meta = self.metadata.get(pid, {})
            if threshold is None or score >= threshold:
                results.append((pid, score, meta))
        return results

    def save(self):
        try:
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
            with open(self.db_path, "wb") as f:
                pickle.dump(
                    {"ids": self.ids, "vectors": self.vectors, "meta": self.metadata}, f
                )
            print(f"[DB] Saved {len(self.ids)} pages.")
        except Exception as e:
            print(f"[DB] Save failed: {e}")

    def load(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "rb") as f:
                    data = pickle.load(f)
                    self.ids = data["ids"]
                    self.vectors = data["vectors"]
                    self.metadata = data.get("meta", {})
            except Exception:
                logger.warning("[DB] Load failed, starting fresh.")

    def clear(self):
        self.ids = []
        self.vectors = None
        self.metadata = {}
