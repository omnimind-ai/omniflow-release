from __future__ import annotations

from dataclasses import dataclass
import logging
import math
from time import perf_counter
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

from src.utg.assets.embedding.element_embedding import UITree
from src.utg.assets.embedding.stats import UTGStatsCollector
from src.utg.core.models import UTGGraph, UTGNode

# ---------- Matching Constants ----------
BEST_THRESHOLD = 0.87
THRESHOLD = 0.3

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    id: str
    score: float
    meta: Dict[str, str]


@dataclass
class UTGMatchConfig:
    top_k: int = 5
    best_threshold: float = BEST_THRESHOLD
    threshold: float = THRESHOLD
    enable_node_importance: bool = True
    node_importance_seq_weight: float = 0.7
    node_importance_cluster_weight: float = 0.3
    node_importance_growth_k: float = 0.6
    node_importance_max_weight: float = 3.0
    debug_embedding_breakdown: bool = False
    debug_embedding_top_n: int = 10


class UTGMatchEngine:
    def __init__(
        self,
        utg: UTGGraph,
        vector_db,
        node_lookup: Dict[str, UTGNode],
        config: Optional[UTGMatchConfig] = None,
        stats: Optional[UTGStatsCollector] = None,
    ) -> None:
        self.utg = utg
        self.vector_db = vector_db
        self.node_lookup = node_lookup
        self.config = config or UTGMatchConfig()
        self.stats = stats or UTGStatsCollector()
        self.last_match_debug: Dict[str, Any] = {}
        self._node_importance_weights: Dict[str, float] = {}
        self._node_importance_debug: Dict[str, Dict[str, float]] = {}
        self.recompute_node_importance()

    def recompute_node_importance(self) -> None:
        self._node_importance_weights = {}
        self._node_importance_debug = {}
        if not self.config.enable_node_importance:
            return

        max_weight = max(1.0, float(self.config.node_importance_max_weight or 1.0))
        growth_k = max(0.0, float(self.config.node_importance_growth_k or 0.0))
        seq_weight = max(0.0, float(self.config.node_importance_seq_weight or 0.0))
        cluster_weight = max(
            0.0, float(self.config.node_importance_cluster_weight or 0.0)
        )

        seq_hit_counts: Dict[str, int] = {}
        # Extract node_ids from function call_function actions
        for func_name, func in (self.utg.functions or {}).items():
            for action in getattr(func, "actions", []) or []:
                action_type = str(getattr(action, "type", "")).strip()
                if action_type == "call_function":
                    params = getattr(action, "params", None)
                    if params:
                        node_id = str(getattr(params, "node_id", "") or "").strip()
                        if node_id:
                            seq_hit_counts[node_id] = seq_hit_counts.get(node_id, 0) + 1

        for node in self.utg.nodes or []:
            node_id = node.id
            seq_hit_count = max(0, int(seq_hit_counts.get(node_id, 0)))
            # Cluster size: count from both vector_sets and legacy xmls
            cluster_size = max(
                1, len(node.repr.vector_sets or []) or len(node.repr.xmls or [])
            )

            score = (seq_weight * math.log1p(float(seq_hit_count))) + (
                cluster_weight * math.log(float(cluster_size))
            )
            if growth_k <= 0 or max_weight <= 1.0:
                weight = 1.0
            else:
                growth = 1.0 - math.exp(-growth_k * max(0.0, score))
                weight = 1.0 + ((max_weight - 1.0) * growth)
            weight = max(1.0, min(max_weight, weight))

            self._node_importance_weights[node_id] = float(weight)
            self._node_importance_debug[node_id] = {
                "seq_hit_count": float(seq_hit_count),
                "cluster_size": float(cluster_size),
                "importance_score": float(score),
                "importance_weight": float(weight),
            }

    @staticmethod
    def _cosine_stats(a: np.ndarray, b: np.ndarray) -> Dict[str, Any]:
        norm_a = float(np.linalg.norm(a))
        norm_b = float(np.linalg.norm(b))
        if norm_a <= 1e-9 and norm_b <= 1e-9:
            return {"cosine": 0.0, "cosine_defined": False, "zero_norm_side": "both"}
        if norm_a <= 1e-9:
            return {"cosine": 0.0, "cosine_defined": False, "zero_norm_side": "query"}
        if norm_b <= 1e-9:
            return {"cosine": 0.0, "cosine_defined": False, "zero_norm_side": "target"}
        cosine = float(np.dot(a, b) / (norm_a * norm_b))
        return {"cosine": cosine, "cosine_defined": True, "zero_norm_side": "none"}

    @staticmethod
    def _embedding_group_slices(encoder: Any) -> List[Tuple[str, int, int]]:
        node_dim = int(getattr(encoder, "node_dim", 0))
        anchor_dim = int(getattr(encoder, "anchor_dim", 0))
        names = [
            "global_all",
            "app_topbar",
            "footer",
            "middle_region",
            "selected_target",
            "body_actionable",
            "body_focus_target",
            "body_display_text",
        ]
        slices: List[Tuple[str, int, int]] = []
        offset = 0
        for name in names:
            slices.append((name, offset, offset + node_dim))
            offset += node_dim
        slices.append(("anchor", offset, offset + anchor_dim))
        return slices

    @staticmethod
    def _group_name_for_index(
        index: int, slices: List[Tuple[str, int, int]]
    ) -> Tuple[str, int]:
        for name, start, end in slices:
            if start <= index < end:
                return name, int(index - start)
        return "unknown", int(index)

    def _select_matched_page_id(self, selected_node_id: str) -> str:
        for item in list(self.last_match_debug.get("search_topk") or []):
            if str(item.get("node_id") or "") == selected_node_id:
                return str(item.get("page_id") or "")
        top1 = next(iter(list(self.last_match_debug.get("search_topk") or [])), {})
        return str(top1.get("page_id") or "")

    def _resolve_page_xml(self, page_id: str) -> str:
        page = str(page_id or "")
        if not page or "#" not in page:
            return ""
        node_id, xml_idx = page.rsplit("#", 1)
        node = self.node_lookup.get(str(node_id))
        if node is None:
            return ""
        try:
            idx = int(xml_idx)
        except ValueError:
            return ""
        xmls = list(getattr(getattr(node, "repr", None), "xmls", []) or [])
        if idx < 0 or idx >= len(xmls):
            return ""
        return str(xmls[idx] or "")

    def _build_embedding_breakdown(
        self, xml: str, selected_node_id: str
    ) -> Optional[Dict[str, Any]]:
        if not self.config.debug_embedding_breakdown:
            return None
        if not xml or not selected_node_id or self.vector_db is None:
            return None
        encoder = getattr(self.vector_db, "encoder", None)
        vectors = getattr(self.vector_db, "vectors", None)
        page_ids = list(getattr(self.vector_db, "ids", []) or [])
        if encoder is None or vectors is None or not page_ids:
            return None

        page_id = self._select_matched_page_id(selected_node_id)
        if not page_id:
            return None
        try:
            page_index = page_ids.index(page_id)
        except ValueError:
            return None
        if page_index < 0 or page_index >= len(vectors):
            return None

        target_xml = self._resolve_page_xml(page_id)
        target_meta = dict(
            getattr(self.vector_db, "metadata", {}).get(page_id, {}) or {}
        )

        query_tree = UITree(str(xml or ""), is_file=False)
        query_payload = encoder.analyze(
            query_tree,
            top_n=max(1, int(self.config.debug_embedding_top_n or 1)),
        )
        query_vec = np.asarray(query_payload.get("vector"), dtype=np.float32)

        target_vec = np.asarray(vectors[page_index], dtype=np.float32)
        target_analysis = None
        if target_xml:
            target_tree = UITree(str(target_xml or ""), is_file=False)
            target_analysis = encoder.analyze(
                target_tree,
                encode_context={
                    "package_name": str(target_meta.get("package") or ""),
                    "page_access_weight": float(
                        target_meta.get("page_access_weight", 1.0) or 1.0
                    ),
                },
                top_n=max(1, int(self.config.debug_embedding_top_n or 1)),
            )
            target_vec = np.asarray(target_analysis.get("vector"), dtype=np.float32)

        if (
            query_vec.size == 0
            or target_vec.size == 0
            or query_vec.shape != target_vec.shape
        ):
            return None

        slices = self._embedding_group_slices(encoder)
        groups: List[Dict[str, Any]] = []
        for name, start, end in slices:
            q_seg = query_vec[start:end]
            t_seg = target_vec[start:end]
            cos_stats = self._cosine_stats(q_seg, t_seg)
            groups.append(
                {
                    "name": name,
                    "start": int(start),
                    "end": int(end),
                    "dim": int(end - start),
                    "cosine": float(cos_stats["cosine"]),
                    "cosine_defined": bool(cos_stats["cosine_defined"]),
                    "zero_norm_side": str(cos_stats["zero_norm_side"]),
                    "dot": float(np.dot(q_seg, t_seg)),
                    "l2": float(np.linalg.norm(q_seg - t_seg)),
                    "query_norm": float(np.linalg.norm(q_seg)),
                    "target_norm": float(np.linalg.norm(t_seg)),
                }
            )

        contribution = (query_vec * target_vec).astype(np.float32)
        top_n = max(1, int(self.config.debug_embedding_top_n or 1))
        low_indices = np.argsort(contribution)[:top_n]
        low_dims: List[Dict[str, Any]] = []
        for idx in low_indices:
            group_name, group_offset = self._group_name_for_index(int(idx), slices)
            low_dims.append(
                {
                    "index": int(idx),
                    "group": group_name,
                    "group_offset": int(group_offset),
                    "contribution": float(contribution[idx]),
                    "query_value": float(query_vec[idx]),
                    "target_value": float(target_vec[idx]),
                    "abs_diff": float(abs(query_vec[idx] - target_vec[idx])),
                }
            )

        overall = self._cosine_stats(query_vec, target_vec)
        return {
            "matched_page_id": page_id,
            "overall_cosine": float(overall["cosine"]),
            "overall_cosine_defined": bool(overall["cosine_defined"]),
            "overall_zero_norm_side": str(overall["zero_norm_side"]),
            "group_cosine": groups,
            "lowest_contribution_dims": low_dims,
            "query_page_analysis": dict(query_payload.get("analysis") or {}),
            "target_page_analysis": dict((target_analysis or {}).get("analysis") or {}),
        }

    def _attach_embedding_breakdown(self, xml: str, selected_node_id: str) -> None:
        breakdown = self._build_embedding_breakdown(xml, selected_node_id)
        if breakdown is not None:
            self.last_match_debug["embedding_breakdown"] = breakdown

    def match_node(
        self,
        xml: str,
        package_name: str,
        path_node_ids: Optional[Iterable[str]] = None,
        forecast_nodes: Optional[List[UTGNode]] = None,
    ) -> Optional[UTGNode]:
        start_time = perf_counter()
        search_results = self._search_db(xml, package_name)
        self.last_match_debug = {
            "search_topk": [
                {
                    "page_id": item.id,
                    "node_id": item.meta.get("node_id"),
                    "vector_score": float(item.score),
                }
                for item in search_results
            ],
            "candidate_scores": [],
            "selected_node_id": None,
            "selected_score": None,
            "strategy": "none",
        }

        if forecast_nodes:
            node = self._match_with_forecast(search_results, forecast_nodes, xml)
            if node:
                self.stats.timed_match(node.id, None, "forecast", start_time)
                self.last_match_debug["selected_node_id"] = node.id
                self.last_match_debug["strategy"] = "forecast"
                self._attach_embedding_breakdown(xml, node.id)
                return node

        candidates, candidate_details = self._match_with_embedding_score(
            search_results,
            path_node_ids,
            package_name,
            xml,
        )
        self.last_match_debug["candidate_scores"] = candidate_details
        best_pair = self._match_with_node_filter(xml, candidates)
        if best_pair:
            node, score = best_pair
            self.stats.timed_match(node.id, score, "node_filter", start_time)
            self.last_match_debug["selected_node_id"] = node.id
            self.last_match_debug["selected_score"] = float(score)
            self.last_match_debug["strategy"] = "node_filter"
            self._attach_embedding_breakdown(xml, node.id)
            return node

        self.stats.timed_match(None, None, "none", start_time)
        return None

    def _search_db(self, xml: str, package_name: str = "") -> List[SearchResult]:
        if not xml or self.vector_db is None:
            return []
        results = self.vector_db.search(
            xml,
            top_k=self.config.top_k,
            threshold=self.config.threshold,
            encode_context={
                "package_name": str(package_name or ""),
                "package": str(package_name or ""),
            },
        )
        return [
            SearchResult(id=pid, score=score, meta=meta or {})
            for pid, score, meta in results
        ]

    def _match_with_forecast(
        self,
        search_results: List[SearchResult],
        forecast_nodes: List[UTGNode],
        xml: str,
    ) -> Optional[UTGNode]:
        candidate_nodes: Dict[str, float] = {}
        for node in forecast_nodes:
            result = next(
                (r for r in search_results if r.meta.get("node_id") == node.id), None
            )
            if not result:
                continue
            score = result.score
            if score > self.config.threshold:
                importance_weight = self._node_importance_weights.get(node.id, 1.0)
                candidate_nodes[node.id] = score * importance_weight

        if not candidate_nodes:
            return None
        if len(candidate_nodes) > 1:
            best_pair = self._match_with_node_filter(xml, candidate_nodes)
            return best_pair[0] if best_pair else None
        node_id = next(iter(candidate_nodes.keys()))
        return self.node_lookup.get(node_id)

    def _match_with_embedding_score(
        self,
        search_results: List[SearchResult],
        path_node_ids: Optional[Iterable[str]],
        package_name: str,
        xml: str,
    ) -> Tuple[Dict[str, float], List[Dict[str, Any]]]:
        candidate_nodes: Dict[str, float] = {}
        candidate_details: List[Dict[str, Any]] = []
        path_filter = set(path_node_ids) if path_node_ids else None

        for result in search_results:
            node_id = result.meta.get("node_id")
            if not node_id:
                continue
            node = self.node_lookup.get(node_id)
            if not node:
                continue
            if path_filter and node_id not in path_filter:
                candidate_details.append(
                    {
                        "node_id": node_id,
                        "vector_score": float(result.score),
                        "final_score": None,
                        "is_valid": False,
                        "reason": "path_scope_filtered",
                    }
                )
                continue
            if node.repr.packageName and node.repr.packageName != package_name:
                candidate_details.append(
                    {
                        "node_id": node.id,
                        "vector_score": float(result.score),
                        "final_score": None,
                        "is_valid": False,
                        "reason": "package_mismatch",
                    }
                )
                continue

            score = result.score
            if score > self.config.best_threshold:
                is_valid = True
            else:
                if node.repr.score and node.repr.score > 0:
                    is_valid = score >= node.repr.score
                else:
                    is_valid = score >= self.config.threshold

            if is_valid:
                importance_info = self._node_importance_debug.get(node.id, {})
                importance_weight = float(importance_info.get("importance_weight", 1.0))
                weighted_score = score * importance_weight
                existing = candidate_nodes.get(node.id)
                if existing is None or weighted_score > existing:
                    candidate_nodes[node.id] = weighted_score
                candidate_details.append(
                    {
                        "node_id": node.id,
                        "vector_score": float(score),
                        "importance_weight": float(importance_weight),
                        "importance_score": float(
                            importance_info.get("importance_score", 0.0)
                        ),
                        "seq_hit_count": float(
                            importance_info.get("seq_hit_count", 0.0)
                        ),
                        "cluster_size": float(importance_info.get("cluster_size", 1.0)),
                        "final_score": float(weighted_score),
                        "is_valid": True,
                        "reason": "accepted",
                    }
                )
            else:
                importance_info = self._node_importance_debug.get(node.id, {})
                candidate_details.append(
                    {
                        "node_id": node.id,
                        "vector_score": float(score),
                        "importance_weight": float(
                            importance_info.get("importance_weight", 1.0)
                        ),
                        "importance_score": float(
                            importance_info.get("importance_score", 0.0)
                        ),
                        "seq_hit_count": float(
                            importance_info.get("seq_hit_count", 0.0)
                        ),
                        "cluster_size": float(importance_info.get("cluster_size", 1.0)),
                        "final_score": None,
                        "is_valid": False,
                        "reason": "below_threshold",
                    }
                )

        candidate_details.sort(
            key=lambda item: (
                0.0 if item.get("final_score") is None else float(item["final_score"])
            ),
            reverse=True,
        )
        return candidate_nodes, candidate_details

    def _match_with_node_filter(
        self,
        xml: str,
        candidate_nodes: Dict[str, float],
    ) -> Optional[Tuple[UTGNode, float]]:
        to_remove: List[str] = []
        for node_id, score in candidate_nodes.items():
            node = self.node_lookup.get(node_id)
            if not node:
                to_remove.append(node_id)
                continue
            # Use new match_rules if available, fallback to legacy nodeFilter
            match_rules = node.repr.match_rules
            if match_rules:
                if match_rules.matches(xml):
                    return node, score
                to_remove.append(node_id)
            else:
                if score < self.config.threshold:
                    to_remove.append(node_id)

        for node_id in to_remove:
            candidate_nodes.pop(node_id, None)

        if not candidate_nodes:
            return None

        best_node_id, best_score = max(
            candidate_nodes.items(), key=lambda item: item[1]
        )
        best_node = self.node_lookup.get(best_node_id)
        if not best_node:
            return None
        return best_node, best_score
