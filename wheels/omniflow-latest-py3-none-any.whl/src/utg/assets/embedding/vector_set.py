"""
PageVectorSet: Privacy-safe representation for multi-user UTG aggregation.

This module provides data structures and utilities to convert XML UI hierarchies
into vector-only representations that:
1. Preserve all information needed for action coordinate mapping
2. Remove all raw text/content that could leak user data
3. Support the same matching algorithms as original XML

Use Cases:
- Multi-user data aggregation (shared vector DB)
- Privacy-safe UTG storage and transmission
- Cross-device action adaptation without XML exposure
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from src.utg.assets.embedding.element_embedding import UITree

logger = logging.getLogger(__name__)


# ==============================================================================
# Data Structures
# ==============================================================================


@dataclass
class NodeVectorRecord:
    """
    Privacy-safe vector representation of one XML/UI element.

    Contains all information needed for:
    1. Similarity computation (vector + feature_dict)
    2. Coordinate mapping (bounds, center, area)
    3. Matching quality assessment (flags, class_name)

    Does NOT contain:
    - Raw text content
    - Raw content-desc
    - Any user-identifiable information
    """

    id: str
    vector: np.ndarray  # Pre-computed feature vector

    # Geometry for coordinate mapping
    bounds: Tuple[int, int, int, int]  # [x1, y1, x2, y2]
    center: Tuple[float, float]
    area: float

    # Hashed text identifiers (one-way transformation)
    text_hash: str  # hash(text)
    content_desc_hash: str  # hash(content-desc)

    # Developer-defined identifiers (non-user data)
    resource_id: str
    class_name: str
    package: str

    # State flags bitmask: clickable|focusable|editable|scrollable|checkable|selected|enabled|visible
    flags: int

    # Structure info
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    subtree_size: int = 1
    depth: int = 0

    # Feature dict for calculate_embed_similarity (already anonymized)
    feature_dict: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        return {
            "id": self.id,
            "vector": self.vector.tolist(),
            "bounds": list(self.bounds),
            "center": list(self.center),
            "area": self.area,
            "text_hash": self.text_hash,
            "content_desc_hash": self.content_desc_hash,
            "resource_id": self.resource_id,
            "class_name": self.class_name,
            "package": self.package,
            "flags": self.flags,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "subtree_size": self.subtree_size,
            "depth": self.depth,
            "feature_dict": self.feature_dict,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NodeVectorRecord":
        """Deserialize from dict."""
        return cls(
            id=data["id"],
            vector=np.array(data["vector"], dtype=np.float32),
            bounds=tuple(data["bounds"]),
            center=tuple(data["center"]),
            area=data["area"],
            text_hash=data.get("text_hash", ""),
            content_desc_hash=data.get("content_desc_hash", ""),
            resource_id=data.get("resource_id", ""),
            class_name=data.get("class_name", ""),
            package=data.get("package", ""),
            flags=data.get("flags", 0),
            parent_id=data.get("parent_id"),
            children_ids=data.get("children_ids", []),
            subtree_size=data.get("subtree_size", 1),
            depth=data.get("depth", 0),
            feature_dict=data.get("feature_dict", {}),
        )


@dataclass
class PageVectorSet:
    """
    Privacy-safe vector representation of a full UI page.

    Replaces raw XML storage with pre-computed vectors while
    preserving all functionality needed for action mapping.
    """

    page_id: str
    root_bounds: Tuple[int, int, int, int]  # [x1, y1, x2, y2]
    nodes: List[NodeVectorRecord]
    package_name: str

    # Page-level vector for fast similarity search
    page_vector: Optional[np.ndarray] = None

    # Metadata
    created_at: str = ""
    source_device: str = ""
    fingerprint: str = ""  # Content hash for cache validation

    def get_node_by_id(self, node_id: str) -> Optional[NodeVectorRecord]:
        """Find node by ID."""
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None

    def get_node_at_coords(self, x: float, y: float) -> Optional[NodeVectorRecord]:
        """Find smallest node containing the coordinates."""
        candidates = []
        for node in self.nodes:
            b = node.bounds
            if b[0] <= x <= b[2] and b[1] <= y <= b[3]:
                candidates.append(node)
        if not candidates:
            return None
        return min(candidates, key=lambda n: n.area)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        return {
            "page_id": self.page_id,
            "root_bounds": list(self.root_bounds),
            "nodes": [n.to_dict() for n in self.nodes],
            "package_name": self.package_name,
            "page_vector": self.page_vector.tolist()
            if self.page_vector is not None
            else None,
            "created_at": self.created_at,
            "source_device": self.source_device,
            "fingerprint": self.fingerprint,
        }

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PageVectorSet":
        """Deserialize from dict."""
        page_vec = data.get("page_vector")
        return cls(
            page_id=data["page_id"],
            root_bounds=tuple(data["root_bounds"]),
            nodes=[NodeVectorRecord.from_dict(n) for n in data.get("nodes", [])],
            package_name=data.get("package_name", ""),
            page_vector=np.array(page_vec, dtype=np.float32) if page_vec else None,
            created_at=data.get("created_at", ""),
            source_device=data.get("source_device", ""),
            fingerprint=data.get("fingerprint", ""),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "PageVectorSet":
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))


# ==============================================================================
# Conversion Functions
# ==============================================================================


def _hash_text(text: str) -> str:
    """One-way hash of text content for privacy."""
    if not text:
        return ""
    clean = str(text).strip().lower()
    if not clean:
        return ""
    return hashlib.sha256(clean.encode("utf-8")).hexdigest()[:16]


def _encode_flags(node: Dict[str, Any]) -> int:
    """Encode boolean state flags into bitmask."""
    flags = 0
    if _is_true(node, "clickable"):
        flags |= 1
    if _is_true(node, "focusable"):
        flags |= 2
    if _is_true(node, "editable"):
        flags |= 4
    if _is_true(node, "scrollable"):
        flags |= 8
    if _is_true(node, "checkable"):
        flags |= 16
    if _is_true(node, "selected"):
        flags |= 32
    if _is_true(node, "enabled", default=True):
        flags |= 64
    if _is_true(node, "visible", "visible-to-user", default=True):
        flags |= 128
    return flags


def _is_true(node: Dict[str, Any], *keys: str, default: bool = False) -> bool:
    """Check if any of the keys is true in node attributes."""
    for key in keys:
        value = node.get(key)
        if value in (None, ""):
            continue
        return str(value).lower() == "true"
    return default


def _anonymize_feature_dict(feature_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remove raw text from feature dict while preserving computed features.

    The text hash is already computed in the features, so we just need to
    remove the raw_text field to ensure privacy.
    """
    result = {"features": {}}

    for category, features in feature_dict.get("features", {}).items():
        if category == "text":
            # Keep has_text flag but remove raw_text
            result["features"]["text"] = {
                "has_text": features.get("has_text", False),
                "has_content": features.get("has_content", False),
                # raw_text_hash is computed by processor, not stored as string
            }
        elif category == "human":
            sanitized = dict(features)
            if sanitized.get("content_hash"):
                sanitized["content_hash"] = _hash_text(str(sanitized["content_hash"]))
            result["features"]["human"] = sanitized
        else:
            # Copy other categories as-is (geometry, state, structure)
            result["features"][category] = dict(features)

    return result


def xml_to_vector_set(
    xml_content: str,
    page_id: str,
    *,
    screenshot: Optional[np.ndarray] = None,
    package_name: str = "",
    source_device: str = "",
    created_at: str = "",
) -> PageVectorSet:
    """
    Convert XML UI hierarchy to privacy-safe PageVectorSet.

    This function:
    1. Parses XML into UITree (with optional screenshot for visual hash)
    2. Extracts and vectorizes all nodes
    3. Hashes all text content
    4. Returns PageVectorSet without any raw text

    Args:
        xml_content: Raw XML string of UI hierarchy
        page_id: Unique identifier for this page
        screenshot: Optional screenshot (H, W, C) for visual hash of icon elements
        package_name: App package name (optional, will be extracted from XML if not provided)
        source_device: Device identifier (optional)
        created_at: Timestamp string (optional)

    Returns:
        PageVectorSet with all nodes vectorized and anonymized
    """
    # Parse XML with optional screenshot
    ui_tree = UITree(xml_content, is_file=False, screenshot=screenshot)

    if not ui_tree.elements:
        return PageVectorSet(
            page_id=page_id,
            root_bounds=(0, 0, 1080, 1920),
            nodes=[],
            package_name=package_name,
            created_at=created_at,
            source_device=source_device,
        )

    # Extract package from first node if not provided
    if not package_name:
        package_name = str(ui_tree.elements[0].get("package", "") or "")

    # Convert nodes
    node_records = []
    for node in ui_tree.elements:
        node_id = str(node.get("id", ""))

        # Get pre-computed vector
        vector = ui_tree.vectors.get(node_id)
        if vector is None:
            continue

        # Get and anonymize feature dict
        feature_dict = ui_tree.feature_dicts.get(node_id, {})
        anon_features = _anonymize_feature_dict(feature_dict)

        # Hash text content
        text = str(node.get("text", "") or "")
        content_desc = str(node.get("content-desc", "") or "")

        record = NodeVectorRecord(
            id=node_id,
            vector=vector,
            bounds=tuple(node.get("bound_list", [0, 0, 0, 0])),
            center=tuple(node.get("center", (0.0, 0.0))),
            area=float(node.get("area", 0.0)),
            text_hash=_hash_text(text),
            content_desc_hash=_hash_text(content_desc),
            resource_id=str(node.get("resource-id", "") or ""),
            class_name=str(node.get("class", "") or ""),
            package=str(node.get("package", "") or ""),
            flags=_encode_flags(node),
            parent_id=node.get("parent_id"),
            children_ids=list(node.get("children_ids", [])),
            subtree_size=int(node.get("subtree_size", 1)),
            depth=int(node.get("depth", 0)),
            feature_dict=anon_features,
        )
        node_records.append(record)

    # Compute page-level fingerprint
    fingerprint_data = json.dumps(
        {
            "node_count": len(node_records),
            "node_ids": sorted(n.id for n in node_records),
            "package": package_name,
        },
        sort_keys=True,
    )
    fingerprint = hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]

    return PageVectorSet(
        page_id=page_id,
        root_bounds=tuple(ui_tree.root_bounds),
        nodes=node_records,
        package_name=package_name,
        page_vector=None,  # Can be computed later by PageEncoder
        created_at=created_at,
        source_device=source_device,
        fingerprint=fingerprint,
    )


# ==============================================================================
# 坐标映射 (使用统一的 UTGMatcher)
# ==============================================================================


def match_coordinates(
    source: PageVectorSet,
    target: PageVectorSet,
    x: float,
    y: float,
) -> Dict[str, Any]:
    """
    坐标映射主入口。

    使用 UTGMatcher 的锚点扩散算法进行跨页面坐标映射。

    Args:
        source: 源 PageVectorSet
        target: 目标 PageVectorSet
        x: 源 X 坐标
        y: 源 Y 坐标

    Returns:
        包含目标坐标和映射信息的字典
    """
    from src.utg.assets.embedding.element_match import UTGMatcher

    try:
        matcher = UTGMatcher(source=source, target=target)
        result = matcher.map_coordinates(int(x), int(y))

        if result is None:
            return {
                "new_x": x,
                "new_y": y,
                "mapped": False,
                "debug": matcher.last_debug,
            }

        return {
            "new_x": float(result["new_x"]),
            "new_y": float(result["new_y"]),
            "mapped": True,
            "mapping_mode": "element_match",
            "debug": result.get("debug", {}),
        }
    except Exception as exc:
        return {
            "new_x": x,
            "new_y": y,
            "mapped": False,
            "debug": {"error": str(exc)},
        }
