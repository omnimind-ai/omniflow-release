"""
Element Embedding (64维，双视角 Observation 设计)

术语约定:
- Element: XML 中的 UI 控件 (<node> 标签)
- Node: UTG 图中的页面节点

Human Observation (32维) - 用户看到什么:
- content_hash: 16维 (内容指纹)
- content_type: 4维 (文字/图标/空/混合)
- affordance: 4维 (可操作感知)
- prominence: 4维 (视觉重要性)
- visual_state: 4维 (视觉状态)

Programmer Observation (32维) - 开发者定义什么:
- class_type: 8维 (控件类型 hash)
- attributes: 8维 (交互属性)
- struct_hash: 12维 (结构指纹)
- hierarchy: 2维 (层级信息)
- id_hint: 2维 (命名暗示)
"""

import hashlib
import re
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET

import numpy as np

from src.utg.assets.embedding.config import ElementEmbeddingConfig

# ==============================================================================
# Hash Encoders
# ==============================================================================


class VisualHashEncoder:
    """从截图区域提取 visual hash (16维)，用于无文本的图标节点"""

    @staticmethod
    def encode(
        image: np.ndarray,
        bounds: List[int],
        config: Optional["ElementEmbeddingConfig"] = None,
    ) -> np.ndarray:
        """
        从截图中提取节点区域的 visual hash

        Args:
            image: 完整截图 (H, W, C) 或 (H, W) 灰度图
            bounds: 节点边界 [x1, y1, x2, y2]
            config: 配置

        Returns:
            16 维 visual hash 向量 (与 content_hash 维度相同)
        """
        cfg = config or ElementEmbeddingConfig()
        dim = cfg.visual_hash_dim  # 16

        if image is None or len(bounds) < 4:
            return np.zeros(dim, dtype=np.float32)

        x1, y1, x2, y2 = int(bounds[0]), int(bounds[1]), int(bounds[2]), int(bounds[3])

        # 边界检查
        h, w = image.shape[:2]
        x1, x2 = max(0, x1), min(w, x2)
        y1, y2 = max(0, y1), min(h, y2)

        crop_h = y2 - y1
        crop_w = x2 - x1
        if crop_h <= 0 or crop_w <= 0:
            return np.zeros(dim, dtype=np.float32)

        # 裁剪并转灰度
        crop = image[y1:y2, x1:x2]
        if len(crop.shape) == 3:
            gray = np.mean(crop, axis=2).astype(np.float32)
        else:
            gray = crop.astype(np.float32)

        # 4x4 网格采样 (16个点)
        grid_h = np.linspace(0, crop_h - 1, 4, dtype=int)
        grid_w = np.linspace(0, crop_w - 1, 4, dtype=int)

        samples = []
        for i in grid_h:
            for j in grid_w:
                samples.append(gray[i, j])

        samples = np.array(samples, dtype=np.float32)

        # 归一化到 [-1, 1]
        mean_val = samples.mean()
        std_val = samples.std() + 1e-6
        normalized = (samples - mean_val) / std_val
        normalized = np.clip(normalized, -3, 3) / 3  # clip 到 [-1, 1]

        return normalized


class TextHashEncoder:
    """统一文本/结构签名的低维 signed hash 编码"""

    @staticmethod
    def _encode_clean_text(
        clean_text: str, dim: int, config: ElementEmbeddingConfig
    ) -> np.ndarray:
        vec = np.zeros(dim, dtype=np.float32)
        if not clean_text:
            return vec
        padded = f"{config.trigram_pad_prefix}{clean_text}{config.trigram_pad_suffix}"
        grams = [padded[i : i + 2] for i in range(max(1, len(padded) - 1))]
        for gram in grams:
            h_bytes = hashlib.md5(gram.encode("utf-8")).digest()
            idx = h_bytes[0] % max(1, dim)
            sign = 1.0 if (h_bytes[1] % 2 == 0) else -1.0
            vec[idx] += sign
        norm = np.linalg.norm(vec)
        if norm > 1e-6:
            vec /= norm
        return vec

    @classmethod
    def encode(
        cls,
        text: str,
        config: Optional[ElementEmbeddingConfig] = None,
        dim: Optional[int] = None,
    ) -> np.ndarray:
        cfg = config or ElementEmbeddingConfig()
        target_dim = dim if dim is not None else cfg.content_hash_dim
        clean_text = str(text or "").lower()
        clean_text = re.sub(r"\s+", "", clean_text)
        clean_text = re.sub(cfg.text_clean_regex, "", clean_text)[
            : cfg.text_truncate_len
        ]
        return cls._encode_clean_text(clean_text, target_dim, cfg)

    @classmethod
    def encode_class_suffix(
        cls, class_name: str, config: Optional[ElementEmbeddingConfig] = None
    ) -> np.ndarray:
        """编码类名后缀为 hash 向量"""
        cfg = config or ElementEmbeddingConfig()
        suffix = str(class_name or "").split(".")[-1].lower()
        return cls._encode_clean_text(suffix, cfg.class_type_dim, cfg)

    @classmethod
    def encode_structure_signature(
        cls, signature: str, config: Optional[ElementEmbeddingConfig] = None
    ) -> np.ndarray:
        cfg = config or ElementEmbeddingConfig()
        clean_text = re.sub(r"\s+", "", str(signature or "").lower())
        return cls._encode_clean_text(clean_text, cfg.struct_hash_dim, cfg)


# ==============================================================================
# Feature Processors
# ==============================================================================


def _bucket_onehot(value: float, bins: List[float]) -> np.ndarray:
    """将数值分桶并返回 one-hot 向量"""
    dim = len(bins) + 1
    vec = np.zeros(dim, dtype=np.float32)
    idx = 0
    for i, bound in enumerate(bins):
        if value <= bound:
            idx = i
            break
        idx = i + 1
    vec[idx] = 1.0
    return vec


def _content_type_onehot(has_text: bool, is_icon: bool) -> np.ndarray:
    """生成 content_type 的 4 维 one-hot: text/icon/empty/mixed"""
    vec = np.zeros(4, dtype=np.float32)
    if has_text and is_icon:
        vec[3] = 1.0  # mixed
    elif has_text:
        vec[0] = 1.0  # text
    elif is_icon:
        vec[1] = 1.0  # icon
    else:
        vec[2] = 1.0  # empty
    return vec


# ==============================================================================
# Node Vectorizer (64维)
# ==============================================================================


class ElementVectorizer:
    """
    64 维 Node Vector 生成器 (双视角 Observation 设计)

    Human Observation (32维):
    - content_hash: 16维
    - content_type: 4维
    - affordance: 4维
    - prominence: 4维
    - visual_state: 4维

    Programmer Observation (32维):
    - class_type: 8维
    - attributes: 8维
    - struct_hash: 12维
    - hierarchy: 2维
    - id_hint: 2维
    """

    def __init__(self, config: Optional[ElementEmbeddingConfig] = None):
        self.config = config or ElementEmbeddingConfig()
        self.total_dim = self.config.get_total_dim()  # 64

        # 构建特征切片映射
        self._feature_slices: Dict[str, Tuple[int, int]] = {}
        self._build_feature_slices()

    def _build_feature_slices(self):
        """构建特征名到向量切片的映射"""
        cfg = self.config
        idx = 0

        # Human Observation (32维)
        self._feature_slices["content_hash"] = (idx, idx + cfg.content_hash_dim)
        idx += cfg.content_hash_dim
        self._feature_slices["content_type"] = (idx, idx + cfg.content_type_dim)
        idx += cfg.content_type_dim
        self._feature_slices["affordance"] = (idx, idx + cfg.affordance_dim)
        idx += cfg.affordance_dim
        self._feature_slices["prominence"] = (idx, idx + cfg.prominence_dim)
        idx += cfg.prominence_dim
        self._feature_slices["visual_state"] = (idx, idx + cfg.visual_state_dim)
        idx += cfg.visual_state_dim

        # Programmer Observation (32维)
        self._feature_slices["class_type"] = (idx, idx + cfg.class_type_dim)
        idx += cfg.class_type_dim
        self._feature_slices["attributes"] = (idx, idx + cfg.attributes_dim)
        idx += cfg.attributes_dim
        self._feature_slices["struct_hash"] = (idx, idx + cfg.struct_hash_dim)
        idx += cfg.struct_hash_dim
        self._feature_slices["hierarchy"] = (idx, idx + cfg.hierarchy_dim)
        idx += cfg.hierarchy_dim
        self._feature_slices["id_hint"] = (idx, idx + cfg.id_hint_dim)
        idx += cfg.id_hint_dim

    def get_feature_slice(self, feature_name: str) -> Tuple[int, int]:
        """获取特征在向量中的切片位置"""
        # 兼容旧 API
        if feature_name == "raw_text_hash":
            feature_name = "content_hash"
        return self._feature_slices.get(feature_name, (0, 0))

    def to_vector(self, features: Dict) -> np.ndarray:
        """将特征字典转换为 64 维向量"""
        vec = np.zeros(self.total_dim, dtype=np.float32)
        cfg = self.config
        f = features.get("features", features)

        # ===== Human Observation (32维) =====
        human = f.get("human", {})

        # content_hash (16维)
        start, end = self._feature_slices["content_hash"]
        content_hash = human.get("content_hash")
        if content_hash is not None:
            if isinstance(content_hash, np.ndarray):
                vec[start:end] = content_hash[: cfg.content_hash_dim]
            elif isinstance(content_hash, str):
                vec[start:end] = TextHashEncoder.encode(content_hash, cfg)

        # content_type (4维)
        start, end = self._feature_slices["content_type"]
        ct = human.get("content_type")
        if ct is not None:
            if isinstance(ct, np.ndarray):
                vec[start:end] = ct[: cfg.content_type_dim]
            elif isinstance(ct, dict):
                vec[start:end] = _content_type_onehot(
                    ct.get("has_text", False), ct.get("is_icon", False)
                )

        # affordance (4维)
        start, end = self._feature_slices["affordance"]
        aff = human.get("affordance", {})
        for i, feat in enumerate(cfg.affordance_features):
            if i < cfg.affordance_dim:
                vec[start + i] = 1.0 if aff.get(feat) else 0.0

        # prominence (4维)
        start, end = self._feature_slices["prominence"]
        prom = human.get("prominence")
        if prom is not None:
            if isinstance(prom, np.ndarray):
                vec[start:end] = prom[: cfg.prominence_dim]
            elif isinstance(prom, (int, float)):
                vec[start:end] = _bucket_onehot(float(prom), cfg.prominence_bins)

        # visual_state (4维)
        start, end = self._feature_slices["visual_state"]
        vs = human.get("visual_state", {})
        for i, feat in enumerate(cfg.visual_state_features):
            if i < cfg.visual_state_dim:
                vec[start + i] = 1.0 if vs.get(feat) else 0.0

        # ===== Programmer Observation (32维) =====
        prog = f.get("programmer", {})

        # class_type (8维)
        start, end = self._feature_slices["class_type"]
        ct = prog.get("class_type")
        if ct is not None:
            if isinstance(ct, np.ndarray):
                vec[start:end] = ct[: cfg.class_type_dim]
            elif isinstance(ct, str):
                vec[start:end] = TextHashEncoder.encode_class_suffix(ct, cfg)

        # attributes (8维)
        start, end = self._feature_slices["attributes"]
        attrs = prog.get("attributes", {})
        for i, feat in enumerate(cfg.attribute_features):
            if i < cfg.attributes_dim:
                val = attrs.get(feat)
                vec[start + i] = 1.0 if val else 0.0

        # struct_hash (12维)
        start, end = self._feature_slices["struct_hash"]
        sh = prog.get("struct_hash")
        if sh is not None:
            if isinstance(sh, np.ndarray):
                vec[start:end] = sh[: cfg.struct_hash_dim]
            elif isinstance(sh, str):
                vec[start:end] = TextHashEncoder.encode_structure_signature(sh, cfg)

        # hierarchy (2维)
        start, end = self._feature_slices["hierarchy"]
        hier = prog.get("hierarchy", {})
        vec[start] = 1.0 if hier.get("is_leaf") else 0.0
        vec[start + 1] = 1.0 if hier.get("has_siblings") else 0.0

        # id_hint (2维)
        start, end = self._feature_slices["id_hint"]
        hint = prog.get("id_hint", {})
        vec[start] = 1.0 if hint.get("suggests_action") else 0.0
        vec[start + 1] = 1.0 if hint.get("suggests_input") else 0.0

        # 归一化 (分段归一化)
        vec = self._normalize_vector(vec)

        return vec

    def _normalize_vector(self, vec: np.ndarray) -> np.ndarray:
        """分段归一化向量"""
        cfg = self.config

        # Human 部分归一化
        human_start = 0
        human_end = (
            cfg.content_hash_dim
            + cfg.content_type_dim
            + cfg.affordance_dim
            + cfg.prominence_dim
            + cfg.visual_state_dim
        )
        human_part = vec[human_start:human_end]
        human_norm = np.linalg.norm(human_part)
        if human_norm > 1e-6:
            vec[human_start:human_end] = human_part / human_norm * cfg.human_weight

        # Programmer 部分归一化
        prog_start = human_end
        prog_end = self.total_dim
        prog_part = vec[prog_start:prog_end]
        prog_norm = np.linalg.norm(prog_part)
        if prog_norm > 1e-6:
            vec[prog_start:prog_end] = prog_part / prog_norm * cfg.programmer_weight

        return vec


# ==============================================================================
# XML Parser
# ==============================================================================


class XMLParser:
    @staticmethod
    def parse_bounds(bounds_str: str) -> List[int]:
        if not bounds_str:
            return [0, 0, 0, 0]
        nums = list(map(int, re.findall(r"\d+", bounds_str)))
        return nums if len(nums) == 4 else [0, 0, 0, 0]

    def parse(
        self, xml_input: str, is_file: bool = True
    ) -> Tuple[List[Dict], Dict[str, Dict]]:
        try:
            if is_file:
                with open(xml_input, "r", encoding="utf-8") as file_obj:
                    content = file_obj.read()
            else:
                content = xml_input
            content = re.sub(r'\sxmlns="[^"]+"', "", content, count=1)
            content = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", content)
            root = ET.fromstring(content)
        except Exception as exc:
            print(f"XML Parse Error: {exc}")
            return [], {}

        if root.tag == "hierarchy":
            children = list(root)
            if not children:
                return [], {}
            root = children[0]
        return self._build_recursive(root, 0, None)

    def _build_recursive(
        self, xml_element: ET.Element, depth: int, parent: Optional[Dict]
    ) -> Tuple[List[Dict], Dict[str, Dict]]:
        """递归解析 XML，构建 element 列表和映射"""
        elements: List[Dict] = []
        element_map: Dict[str, Dict] = {}

        element_id = (
            xml_element.attrib.get("id")
            or xml_element.attrib.get("resource-id")
            or str(id(xml_element))
        )
        bounds_str = xml_element.attrib.get("bounds")
        # 注意: element.tag == "node" 是 XML 的 <node> 标签名
        valid_element = xml_element.tag == "node" and bool(bounds_str)

        element_data = None
        if valid_element:
            bounds = self.parse_bounds(bounds_str)
            element_data = dict(xml_element.attrib)
            element_data.update(
                {
                    "id": element_id,
                    "parent_id": parent["id"] if parent else None,
                    "bound_list": bounds,
                    "center": (
                        (bounds[0] + bounds[2]) / 2,
                        (bounds[1] + bounds[3]) / 2,
                    ),
                    "area": max(0, bounds[2] - bounds[0])
                    * max(0, bounds[3] - bounds[1]),
                    "depth": depth,
                    "children_ids": [],
                }
            )
            elements.append(element_data)
            element_map[element_id] = element_data

        effective_parent = element_data if valid_element else parent
        effective_depth = depth + 1 if valid_element else depth
        for child in xml_element:
            child_elements, child_map = self._build_recursive(
                child, effective_depth, effective_parent
            )
            elements.extend(child_elements)
            element_map.update(child_map)
            if valid_element:
                for child_elem in child_elements:
                    if child_elem["parent_id"] == element_id:
                        element_data["children_ids"].append(child_elem["id"])
        return elements, element_map


# ==============================================================================
# UITree
# ==============================================================================


class UITree:
    def __init__(
        self,
        xml_input: str,
        is_file: bool = True,
        screenshot: Optional[np.ndarray] = None,
    ):
        """
        解析 XML 并为每个 element 生成 64 维向量

        Args:
            xml_input: XML 文件路径或 XML 字符串
            is_file: True 表示 xml_input 是文件路径
            screenshot: 可选的截图 (H, W, C)，传入时对图标 element 使用 visual hash
        """
        self.parser = XMLParser()
        self.elements, self.element_map = self.parser.parse(xml_input, is_file)
        self.root_bounds = (
            self.elements[0]["bound_list"] if self.elements else [0, 0, 1080, 1920]
        )
        self.screenshot = screenshot
        self._post_process_structure()
        self.vectorizer = ElementVectorizer()
        self.vectors: Dict[str, np.ndarray] = {}
        self.feature_dicts: Dict[str, Dict] = {}
        for elem in self.elements:
            extractor = ElementFeatureExtractor(elem, self, screenshot=screenshot)
            raw_features = extractor.extract_all()
            self.feature_dicts[elem["id"]] = raw_features
            self.element_map[elem["id"]]["features"] = raw_features["features"]
            self.vectors[elem["id"]] = self.vectorizer.to_vector(raw_features)

    def _post_process_structure(self):
        for elem in reversed(self.elements):
            children_ids = elem.get("children_ids", [])
            subtree_size = 1
            for child_id in children_ids:
                child = self.element_map.get(child_id)
                if child:
                    subtree_size += child.get("subtree_size", 1)
            elem["subtree_size"] = subtree_size
            parent = self.element_map.get(elem.get("parent_id"))
            if parent:
                siblings = parent.get("children_ids", [])
                elem["sibling_count"] = len(siblings)
                elem["has_siblings"] = len(siblings) > 1
            else:
                elem["sibling_count"] = 0
                elem["has_siblings"] = False

    @staticmethod
    def _normalize_resource_id(raw: str) -> str:
        text = str(raw or "").strip()
        if not text:
            return ""
        text = text.split("/")[-1]
        text = text.split(":")[-1]
        text = text.replace("_", " ").replace("-", " ")
        return re.sub(r"\s+", " ", text).strip()

    def get_text(self, element: Dict) -> str:
        """获取 element 的文本内容"""
        keys = ("text", "content-desc", "hint-text", "hint_text", "tooltip")
        chunks: List[str] = []
        seen = set()
        for key in keys:
            value = str(element.get(key) or "").strip()
            if not value:
                continue
            normalized = re.sub(r"\s+", " ", value).strip()
            if not normalized:
                continue
            dedup_key = normalized.lower()
            if dedup_key in seen:
                continue
            seen.add(dedup_key)
            chunks.append(normalized)

        resource_tail = self._normalize_resource_id(
            str(
                element.get("resource-id")
                or element.get("id")
                or element.get("data-testid")
                or ""
            ).strip()
        )
        if resource_tail:
            dedup_key = resource_tail.lower()
            if dedup_key not in seen:
                seen.add(dedup_key)
                chunks.append(resource_tail)
        return " ".join(chunks).strip()

    def get_element_at_coords(self, x: float, y: float) -> Optional[Dict]:
        """根据坐标查找最小的包含该点的 element"""
        candidates = []
        for elem in self.elements:
            bounds = elem["bound_list"]
            if bounds[0] <= x <= bounds[2] and bounds[1] <= y <= bounds[3]:
                candidates.append(elem)
        if not candidates:
            return None
        return min(candidates, key=lambda e: e["area"])


# ==============================================================================
# Element Feature Extractor (双视角)
# ==============================================================================


class ElementFeatureExtractor:
    """
    从 XML element 提取 64 维向量所需的特征 (双视角 Observation)

    Human Observation: content_hash, content_type, affordance, prominence, visual_state
    Programmer Observation: class_type, attributes, struct_hash, hierarchy, id_hint
    """

    def __init__(
        self,
        element: Dict,
        tree_context: "UITree",
        screenshot: Optional[np.ndarray] = None,
    ):
        self.element = element
        self.tree = tree_context
        self.screenshot = screenshot
        self.root_w = max(1.0, self.tree.root_bounds[2] - self.tree.root_bounds[0])
        self.root_h = max(1.0, self.tree.root_bounds[3] - self.tree.root_bounds[1])
        self.parent = self.tree.element_map.get(element.get("parent_id"))
        self.cfg = self.tree.vectorizer.config
        self._signature_cache: Dict[Tuple[str, int], str] = {}

    def extract_all(self) -> Dict[str, Dict[str, Any]]:
        return {
            "features": {
                "human": self._extract_human_observation(),
                "programmer": self._extract_programmer_observation(),
            }
        }

    # ==================== Human Observation ====================

    def _extract_human_observation(self) -> Dict[str, Any]:
        """提取用户视角的观察特征"""
        raw_text = self.tree.get_text(self.element)
        class_name = str(self.element.get("class", "") or "").split(".")[-1]
        is_icon = class_name in self.cfg.icon_class_names
        has_text = bool(raw_text) and len(raw_text) >= self.cfg.visual_hash_min_text_len

        # 计算面积比例 (用于 prominence 和 visual_hash 判断)
        area = float(self.element.get("area", 0))
        area_ratio = area / (self.root_w * self.root_h)

        # content_hash: 优先文本，无文本时用 visual hash (如果有 screenshot)
        # 条件: 有 screenshot + (是图标类 或 文本太短) + 面积不太大
        use_visual_hash = (
            self.screenshot is not None
            and (is_icon or not has_text)
            and area_ratio <= self.cfg.visual_hash_max_area_ratio
        )

        if use_visual_hash:
            bounds = self.element.get("bound_list", [0, 0, 0, 0])
            content_hash = VisualHashEncoder.encode(self.screenshot, bounds, self.cfg)
        else:
            content_hash = raw_text  # 文本，后续由 to_vector 转为 hash

        return {
            # content_hash: 内容指纹 (文本 hash 或 visual hash)
            "content_hash": content_hash,
            # content_type: 内容类型
            "content_type": {"has_text": has_text, "is_icon": is_icon},
            # affordance: 可操作感知
            "affordance": self._extract_affordance(),
            # prominence: 视觉重要性 (面积)
            "prominence": area_ratio,
            # visual_state: 视觉状态
            "visual_state": self._extract_visual_state(),
        }

    def _extract_affordance(self) -> Dict[str, bool]:
        """提取可操作感知 - 用户看起来能做什么"""
        class_name = str(self.element.get("class", "") or "").lower()

        # 看起来能点击: 按钮类控件
        looks_tappable = any(
            kw in class_name for kw in ["button", "imagebutton", "fab", "chip", "card"]
        ) or self._optional_bool("clickable")

        # 看起来能输入: 输入框类控件
        looks_typeable = any(
            kw in class_name
            for kw in ["edittext", "textinput", "searchview", "autocomplete"]
        ) or self._optional_bool("editable")

        # 看起来能滚动: 列表/滚动类控件
        looks_scrollable = any(
            kw in class_name
            for kw in [
                "recyclerview",
                "listview",
                "scrollview",
                "gridview",
                "viewpager",
            ]
        ) or self._optional_bool("scrollable")

        # 看起来能切换: 开关类控件
        looks_toggleable = any(
            kw in class_name
            for kw in ["switch", "checkbox", "radiobutton", "togglebutton"]
        ) or self._optional_bool("checkable")

        return {
            "looks_tappable": looks_tappable,
            "looks_typeable": looks_typeable,
            "looks_scrollable": looks_scrollable,
            "looks_toggleable": looks_toggleable,
        }

    def _extract_visual_state(self) -> Dict[str, bool]:
        """提取视觉状态 - 用户看到的状态"""
        return {
            "appears_selected": self._optional_bool("selected", "activated"),
            "appears_disabled": not self._optional_bool("enabled", default=True),
            "appears_focused": self._optional_bool("focused"),
            "appears_primary": self._is_primary_action(),
        }

    def _is_primary_action(self) -> bool:
        """判断是否看起来是主要操作 (大尺寸 + 可点击)"""
        area = float(self.element.get("area", 0))
        area_ratio = area / (self.root_w * self.root_h)
        is_clickable = self._optional_bool("clickable")
        # 面积较大且可点击，可能是主要操作按钮
        return area_ratio > 0.02 and is_clickable

    # ==================== Programmer Observation ====================

    def _extract_programmer_observation(self) -> Dict[str, Any]:
        """提取开发者视角的观察特征"""
        class_name = str(self.element.get("class", "") or "")
        resource_id = str(self.element.get("resource-id") or "")
        children_ids = self.element.get("children_ids", [])

        return {
            # class_type: 控件类型
            "class_type": class_name,
            # attributes: 交互属性
            "attributes": self._extract_attributes(),
            # struct_hash: 结构指纹
            "struct_hash": self._subtree_signature(
                str(self.element["id"]), self.cfg.struct_hash_depth
            ),
            # hierarchy: 层级信息
            "hierarchy": {
                "is_leaf": len(children_ids) == 0,
                "has_siblings": self.element.get("has_siblings", False),
            },
            # id_hint: 命名暗示
            "id_hint": self._extract_id_hint(resource_id),
        }

    def _extract_attributes(self) -> Dict[str, bool]:
        """提取开发者设置的交互属性"""
        return {
            "clickable": self._optional_bool("clickable"),
            "long_clickable": self._optional_bool("long-clickable", "long_clickable"),
            "focusable": self._optional_bool("focusable"),
            "editable": self._optional_bool("editable"),
            "scrollable": self._optional_bool("scrollable"),
            "checkable": self._optional_bool("checkable"),
            "enabled": self._optional_bool("enabled", default=True),
            "selected": self._optional_bool("selected"),
        }

    def _extract_id_hint(self, resource_id: str) -> Dict[str, bool]:
        """提取 resource-id 的命名暗示"""
        rid_lower = resource_id.lower()
        suggests_action = any(
            prefix in rid_lower for prefix in self.cfg.id_action_prefixes
        )
        suggests_input = any(
            prefix in rid_lower for prefix in self.cfg.id_input_prefixes
        )
        return {
            "suggests_action": suggests_action,
            "suggests_input": suggests_input,
        }

    # ==================== Helpers ====================

    def _optional_bool(self, *keys: str, default: bool = False) -> bool:
        for key in keys:
            value = self.element.get(key)
            if value in (None, ""):
                continue
            return str(value).lower() == "true"
        return default

    def _subtree_signature(self, element_id: str, depth: int) -> str:
        """生成子树结构签名"""
        cache_key = (element_id, depth)
        if cache_key in self._signature_cache:
            return self._signature_cache[cache_key]

        elem = self.tree.element_map[element_id]
        class_name = str(elem.get("class", "") or "").split(".")[-1]
        text_flag = "1" if self.tree.get_text(elem) else "0"
        child_count = len(elem.get("children_ids", []))
        token = f"{class_name}|t{text_flag}|c{min(child_count, 5)}"

        if depth <= 0 or not elem.get("children_ids"):
            self._signature_cache[cache_key] = token
            return token

        child_signatures: Dict[str, int] = {}
        for child_id in elem.get("children_ids", []):
            child_sig = self._subtree_signature(str(child_id), depth - 1)
            child_signatures[child_sig] = child_signatures.get(child_sig, 0) + 1

        parts = sorted(child_signatures.keys())[:3]  # 最多3个子签名
        signature = token + "->[" + ",".join(parts) + "]"
        self._signature_cache[cache_key] = signature
        return signature
