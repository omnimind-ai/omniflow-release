from __future__ import annotations

import contextvars
from dataclasses import dataclass
from datetime import datetime, timezone
import os
from typing import Any, Dict, Optional

from src.foundation.paths import get_runtime_dir
from src.foundation.source_tools import dump_json

_EVAL_CONTEXT: contextvars.ContextVar[Dict[str, Any]] = contextvars.ContextVar(
    "eval_context", default={}
)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def set_eval_context(**kwargs: Any):
    ctx = dict(_EVAL_CONTEXT.get())
    for key, value in kwargs.items():
        if value is not None:
            ctx[key] = value
    return _EVAL_CONTEXT.set(ctx)


def reset_eval_context(token) -> None:
    _EVAL_CONTEXT.reset(token)


def get_eval_context() -> Dict[str, Any]:
    return dict(_EVAL_CONTEXT.get())


@dataclass
class EvalLogger:
    enabled: bool = True
    path: Optional[str] = None

    def __post_init__(self) -> None:
        if self.path is None:
            log_dir = get_runtime_dir("logs")
            self.path = str(log_dir / "evaluation.jsonl")

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = bool(enabled)

    def set_path(self, path: str) -> None:
        self.path = path

    def write_event(self, event_type: str, payload: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        if not self.path:
            return
        ctx = get_eval_context()
        enriched = dict(ctx)
        enriched.update(payload)
        event = {
            "ts_utc": _utc_now_iso(),
            "event_type": event_type,
            "payload": enriched,
        }
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(dump_json(event, indent=None))
            f.write("\n")


def build_eval_logger() -> EvalLogger:
    enabled = os.getenv("EVAL_LOG_ENABLED", "1").lower() not in ("0", "false", "no")
    path = os.getenv("EVAL_LOG_PATH")
    return EvalLogger(enabled=enabled, path=path)
