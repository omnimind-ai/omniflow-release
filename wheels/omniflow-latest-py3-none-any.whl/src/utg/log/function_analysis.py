"""
Function → 自动机分解模块

基于执行时的 Node 匹配结果，将 Function 分解为自动机结构（NodeSegment 序列）。

核心概念:
- 执行每个 action 前，通过 match_node 匹配当前 XML 到一个 Node
- 连续匹配到同一个 node_id 的 actions 归入同一个 NodeSegment
- node_id 变化时开始新的 segment（发生了页面跳转）

使用方法:
    from src.utg.log.function_analysis import decompose_function_by_node

    # 基于 baseline_trace 中记录的 node_id 分解 Function
    segments = decompose_function_by_node(function, action_traces)

旧的 LLM 分类方法仍然保留，可用于离线分析或作为备选方案。
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from src.foundation.ai.litellm_client import acomplete_json
from src.utg.core.actions import AnyAction, serialize_action_for_storage
from src.utg.core.models import (
    ActionMeta,
    ActionTrace,
    Function,
    NodeSegment,
    SegmentCluster,
)

logger = logging.getLogger(__name__)


# ========== LLM Classification Prompt ==========

CLASSIFY_PROMPT = """
分析以下 Function 中每个 action 的类型。

Function: {function_name}
描述: {description}

Actions:
{actions_text}

对每个 action 判断：
- navigation: 导致页面跳转（进入新页面/Node），例如点击按钮进入下一页、点击返回键
- interaction: 页面内操作（不改变当前 Node），例如输入文本、滚动、等待

常见 Navigation 动作:
- click 某个导航按钮（如"下一步"、"登录"、"返回"、"确认"等）
- press_key(back) 返回键
- open_app 打开应用

常见 Interaction 动作:
- input_text 输入文本
- swipe/scroll 滚动
- wait 等待
- click 页面内元素（如关闭弹窗、选择选项等，不导致页面跳转）

输出 JSON:
{{"actions": [{{"index": 0, "type": "navigation", "reason": "点击后进入设置页面"}}, ...]}}
"""


def _format_action_params(action: AnyAction) -> str:
    """Format action parameters for display in prompt."""
    payload = serialize_action_for_storage(action)
    params = payload.get("params", {})
    if not params:
        return ""

    # Format key parameters based on action type
    action_type = payload.get("type", "")

    if action_type in ("click", "long_press"):
        parts = []
        if "clickPrompt" in params:
            parts.append(f'target="{params["clickPrompt"]}"')
        elif "x" in params and "y" in params:
            parts.append(f"({params['x']}, {params['y']})")
        return ", ".join(parts)

    if action_type == "input_text":
        text = params.get("text", "")
        if len(text) > 30:
            text = text[:30] + "..."
        return f'text="{text}"'

    if action_type in ("swipe", "scroll"):
        direction = params.get("direction", "")
        return f"direction={direction}"

    if action_type == "press_key":
        return f'key="{params.get("key", "")}"'

    if action_type == "open_app":
        return f'package="{params.get("package_name", "")}"'

    if action_type == "wait":
        time_s = params.get("time_s", 0)
        return f"time={time_s}s"

    if action_type == "call_function":
        func_name = params.get("function_name", "")
        node_id = params.get("node_id", "")
        return f'function="{func_name}", node="{node_id}"'

    # Fallback: show all params
    param_strs = [f'{k}="{v}"' for k, v in list(params.items())[:3]]
    return ", ".join(param_strs)


def _build_actions_text(actions: List[AnyAction]) -> str:
    """Build human-readable action list for LLM prompt."""
    lines = []
    for i, action in enumerate(actions):
        payload = serialize_action_for_storage(action)
        action_type = payload.get("type", "unknown")
        params_str = _format_action_params(action)
        description = payload.get("description", "")

        if params_str:
            line = f"{i}. {action_type}({params_str})"
        else:
            line = f"{i}. {action_type}()"

        if description:
            line += f"  # {description}"

        lines.append(line)

    return "\n".join(lines)


async def classify_actions(
    function: Function,
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
) -> List[ActionMeta]:
    """
    使用 LLM 分类 Function 中每个 Action 的类型。

    Args:
        function: 要分析的 Function
        provider: LLM 提供商 (openai, dashscope)
        model: 模型名称（可选）
        timeout: 请求超时时间

    Returns:
        ActionMeta 列表，每个元素对应一个 action 的分类结果

    Example:
        >>> func = Function(name="login", actions=[...])
        >>> meta = await classify_actions(func)
        >>> for m in meta:
        ...     print(f"Action {m.index}: {m.action_type} - {m.reason}")
    """
    if not function.actions:
        return []

    # Build prompt
    actions_text = _build_actions_text(function.actions)
    prompt = CLASSIFY_PROMPT.format(
        function_name=function.name,
        description=function.description or "(无描述)",
        actions_text=actions_text,
    )

    # Call LLM
    result = await acomplete_json(
        prompt,
        provider=provider,
        model=model,
        timeout=timeout,
    )

    # Parse response
    action_list = result.get("actions", [])
    meta_list: List[ActionMeta] = []

    for item in action_list:
        if not isinstance(item, dict):
            continue

        index = item.get("index")
        action_type = item.get("type", "").strip().lower()
        reason = item.get("reason", "")

        # Validate index
        if not isinstance(index, int) or index < 0 or index >= len(function.actions):
            logger.warning(f"Invalid action index: {index}")
            continue

        # Validate action_type
        if action_type not in ("navigation", "interaction"):
            logger.warning(
                f"Invalid action type: {action_type}, defaulting to interaction"
            )
            action_type = "interaction"

        meta_list.append(
            ActionMeta(
                index=index,
                action_type=action_type,  # type: ignore
                reason=reason or None,
            )
        )

    # Fill in missing indices with default classification
    classified_indices = {m.index for m in meta_list}
    for i in range(len(function.actions)):
        if i not in classified_indices:
            # Use heuristic: assume most actions are interactions
            meta_list.append(
                ActionMeta(
                    index=i,
                    action_type="interaction",
                    reason="默认分类：未被 LLM 明确分类",
                )
            )

    # Sort by index
    meta_list.sort(key=lambda m: m.index)

    return meta_list


def classify_actions_heuristic(function: Function) -> List[ActionMeta]:
    """
    使用启发式规则分类 Function 中每个 Action 的类型（无需 LLM）。

    这是一个快速的本地分类方法，适用于不需要 LLM 或作为备选方案。

    Args:
        function: 要分析的 Function

    Returns:
        ActionMeta 列表

    Heuristics:
        - click with navigation keywords → navigation
        - press_key(back/home) → navigation
        - open_app → navigation
        - input_text, swipe, scroll, wait → interaction
        - call_function → navigation (跨节点调用)
    """
    # Navigation keywords in click targets
    nav_keywords = {
        # Navigation verbs
        "下一步",
        "上一步",
        "返回",
        "back",
        "next",
        "prev",
        "previous",
        "进入",
        "enter",
        "go",
        "跳转",
        "去",
        "前往",
        # Auth actions
        "登录",
        "login",
        "sign in",
        "signin",
        "注册",
        "register",
        "logout",
        "退出",
        # Confirmation actions
        "确认",
        "confirm",
        "ok",
        "确定",
        "取消",
        "cancel",
        "提交",
        "submit",
        "完成",
        "done",
        "finish",
        "结算",
        "支付",
        "pay",
        # Shopping actions
        "购买",
        "buy",
        "checkout",
        "结账",
        "下单",
        "order",
    }

    meta_list: List[ActionMeta] = []

    for i, action in enumerate(function.actions):
        payload = serialize_action_for_storage(action)
        action_type = payload.get("type", "").lower()
        params = payload.get("params", {})

        classified_type: str = "interaction"
        reason: str = ""

        # Check action type
        if action_type == "open_app":
            classified_type = "navigation"
            reason = "open_app 总是导致页面跳转"

        elif action_type == "press_key":
            key = str(params.get("key", "")).lower()
            if key in ("back", "home"):
                classified_type = "navigation"
                reason = f"press_key({key}) 导致页面跳转"
            else:
                reason = f"press_key({key}) 通常不导致页面跳转"

        elif action_type == "call_function":
            classified_type = "navigation"
            reason = "call_function 跨节点调用，视为页面跳转"

        elif action_type in ("click", "click_node"):
            # Check click target for navigation keywords
            # Handle both raw params and serialized format
            target = str(
                params.get("clickPrompt", "")
                or params.get("target_description", "")
                or payload.get("prompt", "")  # serialized format uses 'prompt'
                or ""
            ).lower()

            # Also check the action's original params if available
            if hasattr(action, "params") and isinstance(action.params, dict):
                original_target = str(
                    action.params.get("clickPrompt", "")
                    or action.params.get("target_description", "")
                    or ""
                ).lower()
                if original_target:
                    target = original_target

            for keyword in nav_keywords:
                if keyword.lower() in target:
                    classified_type = "navigation"
                    reason = f"点击目标包含导航关键词: {keyword}"
                    break
            else:
                reason = "点击操作，未检测到导航关键词"

        elif action_type in ("input_text", "type"):
            reason = "文本输入是页面内操作"

        elif action_type in ("swipe", "scroll"):
            reason = "滑动是页面内操作"

        elif action_type == "wait":
            reason = "等待是页面内操作"

        elif action_type == "long_press":
            reason = "长按通常是页面内操作"

        elif action_type == "finished":
            classified_type = "navigation"
            reason = "finished 表示任务结束"

        else:
            reason = f"未知操作类型 {action_type}，默认为页面内操作"

        meta_list.append(
            ActionMeta(
                index=i,
                action_type=classified_type,  # type: ignore
                reason=reason,
            )
        )

    return meta_list


def decompose_function_by_node(
    function: Function,
    action_traces: List[ActionTrace],
) -> List[NodeSegment]:
    """
    基于执行时的 node_id 匹配结果分解 Function。

    这是**首选**的分解方法，基于实际执行时每个 action 所在的 Node。

    分解规则:
    - 连续匹配到同一个 node_id 的 actions 归入同一个 NodeSegment
    - node_id 变化时开始新的 segment（发生了页面跳转）

    Args:
        function: 要分解的 Function
        action_traces: Action 执行记录列表，每个记录包含 node_id

    Returns:
        NodeSegment 列表

    Example:
        执行记录:
            Action 0: match_node → node_A
            Action 1: match_node → node_A
            Action 2: match_node → node_A
            Action 3: match_node → node_B  ← 跳转发生
            Action 4: match_node → node_B
            Action 5: match_node → node_C  ← 跳转发生

        分解为:
        [
            NodeSegment(node_id="node_A", actions=[A0,A1,A2], action_indices=[0,1,2], next_node_id="node_B"),
            NodeSegment(node_id="node_B", actions=[A3,A4], action_indices=[3,4], next_node_id="node_C"),
            NodeSegment(node_id="node_C", actions=[A5], action_indices=[5], next_node_id=None),
        ]
    """
    if not function.actions or not action_traces:
        return []

    # Build trace index -> node_id mapping
    trace_map: Dict[int, Optional[str]] = {}
    for trace in action_traces:
        trace_map[trace.action_index] = trace.node_id

    segments: List[NodeSegment] = []
    current_node_id: Optional[str] = None
    current_actions: List[AnyAction] = []
    current_indices: List[int] = []

    for i, action in enumerate(function.actions):
        node_id = trace_map.get(i)

        # Skip actions without node_id (shouldn't happen in normal flow)
        if node_id is None:
            logger.warning(f"Action {i} has no node_id, skipping")
            continue

        # Check if node changed
        if node_id != current_node_id:
            # Save current segment if exists
            if current_node_id is not None and current_actions:
                segments.append(
                    NodeSegment(
                        node_id=current_node_id,
                        actions=list(current_actions),
                        action_indices=list(current_indices),
                        next_node_id=node_id,  # 下一个 segment 的 node_id
                    )
                )
            # Start new segment
            current_node_id = node_id
            current_actions = []
            current_indices = []

        current_actions.append(action)
        current_indices.append(i)

    # Save last segment
    if current_node_id is not None and current_actions:
        segments.append(
            NodeSegment(
                node_id=current_node_id,
                actions=list(current_actions),
                action_indices=list(current_indices),
                next_node_id=None,  # 最后一个 segment 没有下一个
            )
        )

    return segments


def decompose_function_to_automaton(
    function: Function,
    action_meta: List[ActionMeta],
) -> List[NodeSegment]:
    """
    [已废弃] 基于 LLM 分类的分解方法。

    推荐使用 decompose_function_by_node()，它基于实际执行时的 node_id 匹配结果，
    而不是依赖 LLM 对 action 类型的分类。

    此函数保留用于兼容旧代码或作为备选方案。

    分解规则:
    - 连续的 interaction 操作归入同一个 NodeSegment
    - 遇到 navigation 操作时，当前 segment 结束

    Args:
        function: 要分解的 Function
        action_meta: Action 分类信息列表

    Returns:
        NodeSegment 列表（使用占位 node_id）
    """
    if not function.actions:
        return []

    # Build index -> action_type mapping
    meta_map: Dict[int, str] = {}
    for meta in action_meta:
        meta_map[meta.index] = meta.action_type

    segments: List[NodeSegment] = []
    current_actions: List[AnyAction] = []
    current_indices: List[int] = []
    segment_count = 0

    for i, action in enumerate(function.actions):
        action_type = meta_map.get(i, "interaction")

        if action_type == "interaction":
            current_actions.append(action)
            current_indices.append(i)
        else:  # navigation
            current_actions.append(action)
            current_indices.append(i)
            segment_count += 1
            segments.append(
                NodeSegment(
                    node_id=f"segment_{segment_count}",  # 占位 node_id
                    actions=list(current_actions),
                    action_indices=list(current_indices),
                    next_node_id=None,
                )
            )
            current_actions = []
            current_indices = []

    # Handle trailing actions (if any)
    if current_actions:
        segment_count += 1
        segments.append(
            NodeSegment(
                node_id=f"segment_{segment_count}",
                actions=list(current_actions),
                action_indices=list(current_indices),
                next_node_id=None,
            )
        )

    # Fill in next_node_id for each segment
    for i in range(len(segments) - 1):
        segments[i].next_node_id = segments[i + 1].node_id

    return segments


def visualize_decomposition(
    function: Function,
    segments: List[NodeSegment],
) -> str:
    """
    生成分解结果的可视化文本表示。

    Args:
        function: 原始 Function
        segments: 分解后的 NodeSegment 列表

    Returns:
        ASCII 图形化表示
    """
    lines = [
        f"Function: {function.name}",
        f"Description: {function.description or '(none)'}",
        f"Total Actions: {len(function.actions)}",
        f"Segments: {len(segments)}",
        "",
        "Decomposition (by Node):",
    ]

    for i, segment in enumerate(segments):
        # Format actions
        action_strs = []
        for action in segment.actions:
            payload = serialize_action_for_storage(action)
            action_type = payload.get("type", "unknown")
            params_str = _format_action_params(action)
            if params_str:
                action_strs.append(f"{action_type}({params_str})")
            else:
                action_strs.append(f"{action_type}()")

        actions_display = ", ".join(action_strs) if action_strs else "(empty)"
        indices_display = f"[{','.join(map(str, segment.action_indices))}]"

        lines.append("")
        lines.append("┌─────────────────────────────────────┐")
        lines.append(f"│  {segment.node_id:<33} │")
        lines.append(f"│  Actions: {indices_display:<25} │")
        lines.append(
            f"│  [{actions_display[:30]}{'...' if len(actions_display) > 30 else ''}] │"
        )
        lines.append("└─────────────────────────────────────┘")

        # Format edge to next node
        if segment.next_node_id:
            lines.append("        │")
            lines.append(f"        │  → {segment.next_node_id}")
            lines.append("        ▼")

    return "\n".join(lines)


# ========== Hierarchical Clustering ==========

CLUSTER_PROMPT = """
分析以下 UI 操作段落序列，进行层次化聚合。

## 输入 Segments

{segments_text}

## 任务

1. **任务级聚合 (Level 1)**：识别哪些相邻 segments 属于同一个"逻辑任务"
   - 例如：[输入用户名, 输入密码, 点击登录] → "登录任务"
   - 例如：[浏览商品, 加入购物车] → "选品任务"

2. **流程级聚合 (Level 2)**：识别哪些任务属于同一个"业务流程"
   - 例如：[选品任务, 结算任务] → "购买流程"

3. **意图标注**：给每个聚合组标注简洁的意图标签

## 输出 JSON

```json
{{
  "clusters": [
    {{
      "intent": "完成购买",
      "level": 2,
      "description": "从浏览商品到完成支付的完整流程",
      "children": [
        {{
          "intent": "浏览选品",
          "level": 1,
          "segment_indices": [0, 1, 2]
        }},
        {{
          "intent": "结算支付",
          "level": 1,
          "segment_indices": [3, 4]
        }}
      ]
    }}
  ]
}}
```

## 规则

- segment_indices 是从 0 开始的索引，对应输入的 segments 列表
- 相邻的 segments 才能聚合，不能跳跃合并
- 如果整个序列就是一个任务，可以只输出一个 Level 1 的 cluster
- intent 应该简洁（2-6 个字），如 "登录", "填写表单", "确认订单"
"""


def _format_segments_for_prompt(segments: List[NodeSegment]) -> str:
    """将 segments 格式化为 LLM 可读的文本"""
    lines = []
    for i, seg in enumerate(segments):
        action_strs = []
        for action in seg.actions:
            payload = serialize_action_for_storage(action)
            action_type = payload.get("type", "unknown")
            params_str = _format_action_params(action)
            if params_str:
                action_strs.append(f"{action_type}({params_str})")
            else:
                action_strs.append(f"{action_type}()")

        actions_display = ", ".join(action_strs) if action_strs else "(empty)"
        lines.append(f"[{i}] Node: {seg.node_id}")
        lines.append(f"    Actions: {actions_display}")
        if seg.next_node_id:
            lines.append(f"    → Next: {seg.next_node_id}")
        lines.append("")

    return "\n".join(lines)


def _build_cluster_from_llm_result(
    result: Dict[str, Any],
    segments: List[NodeSegment],
    cluster_id_prefix: str = "cluster",
) -> List[SegmentCluster]:
    """从 LLM 结果构建 SegmentCluster 对象"""
    clusters_data = result.get("clusters", [])
    clusters: List[SegmentCluster] = []
    cluster_counter = 0

    for item in clusters_data:
        if not isinstance(item, dict):
            continue

        cluster_counter += 1
        cluster_id = f"{cluster_id_prefix}_{cluster_counter}"

        intent = item.get("intent", "未知")
        level = item.get("level", 1)
        description = item.get("description")

        # 处理子聚类
        children_data = item.get("children", [])
        children: List[SegmentCluster] = []
        leaf_segments: List[NodeSegment] = []
        leaf_indices: List[int] = []

        if children_data:
            # 非叶子节点：递归构建子聚类
            for j, child_item in enumerate(children_data):
                if not isinstance(child_item, dict):
                    continue

                child_id = f"{cluster_id}_child_{j + 1}"
                child_intent = child_item.get("intent", "未知")
                child_level = child_item.get("level", 1)
                child_indices = child_item.get("segment_indices", [])

                # 收集子聚类的 segments
                child_segments = []
                for idx in child_indices:
                    if 0 <= idx < len(segments):
                        child_segments.append(segments[idx])

                child_node_ids = [seg.node_id for seg in child_segments]
                child_action_count = sum(len(seg.actions) for seg in child_segments)

                children.append(
                    SegmentCluster(
                        cluster_id=child_id,
                        intent=child_intent,
                        level=child_level,
                        segments=child_segments,
                        segment_indices=child_indices,
                        node_ids=child_node_ids,
                        action_count=child_action_count,
                    )
                )
        else:
            # 叶子节点：直接包含 segment_indices
            leaf_indices = item.get("segment_indices", [])
            for idx in leaf_indices:
                if 0 <= idx < len(segments):
                    leaf_segments.append(segments[idx])

        # 构建当前聚类
        if children:
            # 非叶子节点
            all_node_ids = []
            total_actions = 0
            for child in children:
                all_node_ids.extend(child.node_ids)
                total_actions += child.action_count
            all_node_ids = list(dict.fromkeys(all_node_ids))  # 去重保序

            clusters.append(
                SegmentCluster(
                    cluster_id=cluster_id,
                    intent=intent,
                    level=level,
                    description=description,
                    children=children,
                    node_ids=all_node_ids,
                    action_count=total_actions,
                )
            )
        else:
            # 叶子节点
            node_ids = [seg.node_id for seg in leaf_segments]
            action_count = sum(len(seg.actions) for seg in leaf_segments)

            clusters.append(
                SegmentCluster(
                    cluster_id=cluster_id,
                    intent=intent,
                    level=level,
                    description=description,
                    segments=leaf_segments,
                    segment_indices=leaf_indices,
                    node_ids=node_ids,
                    action_count=action_count,
                )
            )

    return clusters


async def cluster_segments(
    segments: List[NodeSegment],
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 60.0,
) -> List[SegmentCluster]:
    """
    使用 LLM 对 segments 进行层次化聚类。

    Args:
        segments: 原子 segments 列表（由 decompose_function_by_node 产生）
        provider: LLM 提供商
        model: 模型名称
        timeout: 请求超时时间

    Returns:
        SegmentCluster 列表（层次化结构）

    Example:
        >>> segments = decompose_function_by_node(function, traces)
        >>> clusters = await cluster_segments(segments)
        >>> for c in clusters:
        ...     print(f"{c.intent} (level={c.level})")
    """
    if not segments:
        return []

    # 单个 segment 不需要聚类
    if len(segments) == 1:
        seg = segments[0]
        return [
            SegmentCluster(
                cluster_id="cluster_1",
                intent="单一操作",
                level=1,
                segments=[seg],
                segment_indices=[0],
                node_ids=[seg.node_id],
                action_count=len(seg.actions),
            )
        ]

    # 构建 prompt
    segments_text = _format_segments_for_prompt(segments)
    prompt = CLUSTER_PROMPT.format(segments_text=segments_text)

    # 调用 LLM
    result = await acomplete_json(
        prompt,
        provider=provider,
        model=model,
        timeout=timeout,
    )

    # 解析结果
    clusters = _build_cluster_from_llm_result(result, segments)

    # 如果 LLM 没有返回有效结果，回退到简单聚类
    if not clusters:
        logger.warning("LLM clustering failed, falling back to single cluster")
        return [
            SegmentCluster(
                cluster_id="cluster_1",
                intent="操作序列",
                level=1,
                segments=segments,
                segment_indices=list(range(len(segments))),
                node_ids=[seg.node_id for seg in segments],
                action_count=sum(len(seg.actions) for seg in segments),
            )
        ]

    return clusters


def cluster_segments_heuristic(
    segments: List[NodeSegment],
    max_cluster_size: int = 5,
) -> List[SegmentCluster]:
    """
    使用启发式规则对 segments 进行聚类（无需 LLM）。

    简单策略：每 max_cluster_size 个 segments 聚合为一个 cluster。

    Args:
        segments: 原子 segments 列表
        max_cluster_size: 每个聚类最多包含的 segments 数量

    Returns:
        SegmentCluster 列表
    """
    if not segments:
        return []

    clusters: List[SegmentCluster] = []
    cluster_counter = 0

    for i in range(0, len(segments), max_cluster_size):
        cluster_counter += 1
        chunk = segments[i : i + max_cluster_size]
        indices = list(range(i, min(i + max_cluster_size, len(segments))))

        clusters.append(
            SegmentCluster(
                cluster_id=f"cluster_{cluster_counter}",
                intent=f"操作组 {cluster_counter}",
                level=1,
                segments=chunk,
                segment_indices=indices,
                node_ids=[seg.node_id for seg in chunk],
                action_count=sum(len(seg.actions) for seg in chunk),
            )
        )

    return clusters


async def decompose_and_cluster(
    function: Function,
    action_traces: List[ActionTrace],
    *,
    provider: str = "openai",
    model: Optional[str] = None,
) -> List[SegmentCluster]:
    """
    完整的分解 + 聚类流程。

    Step 1: 按 Node 切分（L0 层，确定性）
    Step 2: LLM 聚类（L1/L2 层，语义聚合）

    Args:
        function: 要分解的 Function
        action_traces: Action 执行记录（包含 node_id）
        provider: LLM 提供商
        model: 模型名称

    Returns:
        层次化的 SegmentCluster 列表
    """
    # Step 1: 按 Node 切分
    segments = decompose_function_by_node(function, action_traces)

    if not segments:
        return []

    # Step 2: LLM 聚类
    clusters = await cluster_segments(
        segments,
        provider=provider,
        model=model,
    )

    return clusters


def visualize_clusters(clusters: List[SegmentCluster], indent: int = 0) -> str:
    """
    生成聚类结果的可视化文本表示。

    Args:
        clusters: SegmentCluster 列表
        indent: 缩进级别

    Returns:
        ASCII 树形表示
    """
    lines = []
    prefix = "  " * indent

    for cluster in clusters:
        level_marker = "●" if cluster.level == 2 else "○" if cluster.level == 1 else "·"
        lines.append(
            f"{prefix}{level_marker} [{cluster.intent}] "
            f"(level={cluster.level}, nodes={len(cluster.node_ids)}, "
            f"actions={cluster.action_count})"
        )

        if cluster.description:
            lines.append(f"{prefix}  └─ {cluster.description}")

        if cluster.children:
            # 非叶子节点：递归显示子聚类
            lines.append(visualize_clusters(cluster.children, indent + 1))
        else:
            # 叶子节点：显示 segments
            for seg in cluster.segments:
                action_types = [
                    serialize_action_for_storage(a).get("type", "?")
                    for a in seg.actions[:3]
                ]
                actions_preview = ", ".join(action_types)
                if len(seg.actions) > 3:
                    actions_preview += ", ..."
                lines.append(f"{prefix}  ├─ {seg.node_id}: [{actions_preview}]")

    return "\n".join(lines)


__all__ = [
    # 主要分解函数（推荐）
    "decompose_function_by_node",
    # 层次聚类
    "cluster_segments",
    "cluster_segments_heuristic",
    "decompose_and_cluster",
    # LLM 分类相关（备选方案）
    "classify_actions",
    "classify_actions_heuristic",
    "decompose_function_to_automaton",
    # 可视化
    "visualize_decomposition",
    "visualize_clusters",
    # Prompts
    "CLASSIFY_PROMPT",
    "CLUSTER_PROMPT",
]
