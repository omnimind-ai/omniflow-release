from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
from time import perf_counter
from typing import Any, Dict, Optional
import uuid

from src.foundation.paths import get_runtime_file
from src.foundation.source_tools import to_serializable
from src.utg.core.actions import (
    canonical_action_payload,
    canonical_tool_call_name,
    list_tool_call_names,
)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_run_event_stream_path() -> str:
    """Return the single persisted run-event-stream path used by all entrypoints."""

    return str(get_runtime_file("logs", "run_logs.jsonl"))


def _event_error_fields(result: Any) -> tuple[str | None, str | None]:
    """Extract stable error fields from one action result payload."""

    payload = dict(result or {}) if isinstance(result, dict) else {}
    error_code = str(payload.get("error_code") or "").strip() or None
    error_message = str(payload.get("error_message") or "").strip() or None
    nested_error = payload.get("error")
    if isinstance(nested_error, dict):
        if error_code is None:
            error_code = str(nested_error.get("code") or "").strip() or None
        if error_message is None:
            error_message = str(nested_error.get("message") or "").strip() or None
    return error_code, error_message


def _event_success(result: Any) -> bool:
    """Resolve one stable success bit from an action result payload."""

    if isinstance(result, dict):
        if result.get("success") is not None:
            return bool(result.get("success"))
        nested_error = result.get("error")
        if isinstance(nested_error, dict):
            return False
    if hasattr(result, "success"):
        return bool(getattr(result, "success"))
    return False


def _androidworld_raw_to_canonical(action: dict[str, Any]) -> dict[str, Any]:
    """Normalize the only AndroidWorld raw action shapes still tolerated here."""

    if str(action.get("type") or "").strip() != "android_world_raw":
        return action
    params = dict(action.get("params") or {})
    payload = dict(params.get("payload") or {})
    action_type = str(payload.get("action_type") or "").strip().lower()
    if action_type == "open_app":
        package_name = str(
            payload.get("package_name") or payload.get("package") or ""
        ).strip()
        if package_name:
            return {"type": "open_app", "params": {"package_name": package_name}}
    return action


def _build_action_description(action: dict[str, Any]) -> str:
    """Convert one canonical action payload into one readable operation string."""

    if not isinstance(action, dict):
        return ""
    action = _androidworld_raw_to_canonical(dict(action))
    action_type = str(action.get("type") or "").strip()
    params = (
        dict(action.get("params") or {})
        if isinstance(action.get("params"), dict)
        else {}
    )
    target = str(
        params.get("targetDescription") or params.get("target_description") or ""
    ).strip()
    package_name = str(params.get("package_name") or "").strip()
    text = str(params.get("text") or params.get("content") or "").strip()
    key = str(params.get("key") or "").strip()
    direction = str(params.get("direction") or "").strip()
    function_id = str(params.get("function_id") or "").strip()
    tool_name = str(params.get("tool_name") or params.get("toolName") or "").strip()
    x = params.get("x")
    y = params.get("y")
    x1 = params.get("x1")
    y1 = params.get("y1")
    x2 = params.get("x2")
    y2 = params.get("y2")
    duration_ms = params.get("duration_ms")
    time_s = params.get("time_s")
    if action_type == "open_app":
        return f"打开应用 {package_name}" if package_name else "打开应用"
    if action_type == "click":
        if x is not None and y is not None:
            return f"click ({x}, {y})"
        if target:
            return f"click {target}"
        return "click"
    if action_type == "click_node":
        return f"点击节点 {target}" if target else "点击节点"
    if action_type == "long_press":
        if target:
            return f"长按 {target}"
        if x is not None and y is not None:
            return f"长按坐标 ({x}, {y})"
        return "长按"
    if action_type in {"type", "input_text"}:
        return f"输入文本 {text}" if text else "输入文本"
    if action_type in {"scroll", "swipe"}:
        if target:
            return f"滑动到 {target}"
        if direction:
            return f"向{direction}滑动"
        if all(value is not None for value in (x1, y1, x2, y2)):
            return f"滑动 ({x1}, {y1}) -> ({x2}, {y2})"
        return "滑动"
    if action_type == "press_key":
        return f"按键 {key}" if key else "按键"
    if action_type == "wait":
        if duration_ms is not None:
            return f"等待 {duration_ms}ms"
        if time_s is not None:
            return f"等待 {time_s}s"
        return "等待"
    if action_type == "external_tool":
        arguments = (
            dict(params.get("arguments") or {})
            if isinstance(params.get("arguments"), dict)
            else {}
        )
        if tool_name and arguments:
            rendered_arguments = []
            for key, value in list(arguments.items())[:2]:
                key_text = str(key or "").strip()
                value_text = str(value or "").strip()
                if not key_text or not value_text:
                    continue
                if len(value_text) > 24:
                    value_text = value_text[:24] + "..."
                rendered_arguments.append(f"{key_text}={value_text}")
            if rendered_arguments:
                return f"调用工具 {tool_name}({', '.join(rendered_arguments)})"
        return f"调用工具 {tool_name}" if tool_name else "调用工具"
    if action_type == "call_tool":
        return f"执行 Function {function_id}" if function_id else "执行 Function"
    if action_type == "finished":
        return f"结束任务{text and f'：{text}'}"
    if action_type == "record":
        return f"记录{text and f'：{text}'}"
    if action_type == "feedback":
        return f"反馈{text and f'：{text}'}"
    if action_type == "info":
        return f"信息{text and f'：{text}'}"
    if action_type == "waiting_input":
        return f"等待用户输入{text and f'：{text}'}"
    if action_type == "abort":
        return f"中止{text and f'：{text}'}"
    return action_type


def _step_execution_request(step: dict[str, Any]) -> dict[str, Any]:
    """Build one normalized execution request view from canonical step fields."""

    tool_call = (
        dict(step.get("tool_call") or {})
        if isinstance(step.get("tool_call"), dict)
        else {}
    )
    tool_name = str(tool_call.get("name") or "").strip()
    if tool_name:
        tool_params = (
            dict(tool_call.get("params") or {})
            if isinstance(tool_call.get("params"), dict)
            else {}
        )
        request: dict[str, Any] = {"tool_name": tool_name}
        canonical_name = canonical_tool_call_name(tool_name)
        tool_call_names = list_tool_call_names()
        is_function_like = (
            "-" in tool_name
            or "_" in tool_name
            or tool_name.startswith("fn")
            or tool_name.startswith("global")
        )
        if tool_name in {"run_function", "execute_function", "call_function"}:
            function_id = str(
                tool_call.get("function_id")
                or tool_params.get("function_id")
                or tool_params.get("function_name")
                or ""
            ).strip()
            if function_id:
                request["function_id"] = function_id
                request["arguments"] = (
                    dict(tool_params.get("arguments") or {})
                    if isinstance(tool_params.get("arguments"), dict)
                    else {}
                )
                return request
        if canonical_name in tool_call_names:
            request["tool_name"] = canonical_name
            request["action"] = {
                "type": "click_node"
                if canonical_name == "go_to_node"
                else canonical_name,
                "params": tool_params,
            }
            return request
        if tool_name == "external_tool":
            request["action"] = {
                "type": "external_tool",
                "params": {
                    "tool_name": str(tool_params.get("tool_name") or "").strip(),
                    "arguments": (
                        dict(tool_params.get("arguments") or {})
                        if isinstance(tool_params.get("arguments"), dict)
                        else {}
                    ),
                },
            }
            return request
        if is_function_like:
            request["function_id"] = tool_name
            request["arguments"] = dict(tool_params)
            return request
        request["action"] = {
            "type": "external_tool",
            "params": {
                "tool_name": tool_name,
                "arguments": dict(tool_params),
            },
        }
        return request

    plan = dict(step.get("plan") or {}) if isinstance(step.get("plan"), dict) else {}
    tool_args = (
        dict(plan.get("tool_args") or {})
        if isinstance(plan.get("tool_args"), dict)
        else {}
    )
    tool_name = str(plan.get("tool_name") or "").strip()
    request: dict[str, Any] = {"tool_name": tool_name}

    # 判断 tool_name 是 function_id 还是 action type
    # function_id 通常包含 - 或 _，或者以 fn_ / global- 开头
    is_function_id = (
        "-" in tool_name
        or "_" in tool_name
        or tool_name.startswith("fn_")
        or tool_name.startswith("global-")
    )

    if is_function_id:
        # 这是 function 调用
        request["function_id"] = tool_name
        if tool_args:
            request["arguments"] = tool_args
    elif tool_name and tool_name not in ("none", "unknown", "finish"):
        # 这是 action
        request["action"] = {
            "type": tool_name,
            "params": tool_args,
        }

    if tool_name == "finish" and tool_args.get("content") is not None:
        request["content"] = tool_args.get("content")
    return request


def _build_run_source(raw: dict[str, Any]) -> str | None:
    """Derive one stable run source string from canonical run payload fields."""

    direct_source = str(raw.get("source") or "").strip()
    if direct_source:
        return direct_source
    extra = dict(raw.get("extra") or {}) if isinstance(raw.get("extra"), dict) else {}
    extra_source = str(extra.get("source") or "").strip()
    if extra_source:
        return extra_source
    for raw_step in list(raw.get("steps") or []):
        if not isinstance(raw_step, dict):
            continue
        for candidate in [
            raw_step.get("act_result"),
            raw_step.get("utg_context_summary"),
            raw_step.get("provider_detail"),
        ]:
            if not isinstance(candidate, dict):
                continue
            source = str(candidate.get("source") or "").strip()
            if source:
                return source
    return None


@dataclass
class MethodTimings:
    count: int = 0
    total_ms: float = 0.0

    def add(self, elapsed_ms: float) -> None:
        self.count += 1
        self.total_ms += float(elapsed_ms)

    def to_dict(self) -> Dict[str, Any]:
        return {"count": self.count, "total_ms": self.total_ms}


@dataclass
class AgentIOStats:
    observe_xml: MethodTimings = field(default_factory=MethodTimings)
    observe_screenshot: MethodTimings = field(default_factory=MethodTimings)
    observe_app_info: MethodTimings = field(default_factory=MethodTimings)
    act: MethodTimings = field(default_factory=MethodTimings)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "observe_xml": self.observe_xml.to_dict(),
            "observe_screenshot": self.observe_screenshot.to_dict(),
            "observe_app_info": self.observe_app_info.to_dict(),
            "act": self.act.to_dict(),
        }


class InstrumentedAgentIO:
    """
    Thin wrapper around live `observe/act` callables that records call counts + timing.

    This avoids modifying UTGExecutor/UTGMatchEngine to collect per-run telemetry.
    """

    def __init__(
        self,
        observe,
        act,
        stats: AgentIOStats,
        *,
        event_logger=None,
        event_goal: str = "",
        event_step_index: int | None = None,
        event_selection_source: str = "",
        event_execution_source: str = "",
        event_run_id: str = "",
        trace_logger=None,
        trace_run_id: str = "",
        trace_function_id: str = "",
    ):
        self._observe = observe
        self._act = act
        self._stats = stats
        self._event_logger = event_logger
        self._event_goal = str(event_goal or "")
        self._event_step_index = event_step_index
        self._event_selection_source = str(event_selection_source or "").strip()
        self._event_execution_source = str(event_execution_source or "").strip()
        self._event_run_id = str(event_run_id or "").strip()
        self._trace_logger = trace_logger
        self._trace_run_id = str(trace_run_id or "")
        self._trace_function_id = str(trace_function_id or "")
        self._omniflow_local_stabilize = bool(
            getattr(observe, "_omniflow_local_stabilize", False)
            or getattr(
                getattr(observe, "__self__", None), "_omniflow_local_stabilize", False
            )
        )

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs,
    ):
        t0 = perf_counter()
        observed = None
        try:
            observed = await self._observe(
                xml=xml,
                screenshot=screenshot,
                app_info=app_info,
                **kwargs,
            )
            return observed
        finally:
            elapsed_ms = (perf_counter() - t0) * 1000
            if xml:
                self._stats.observe_xml.add(elapsed_ms)
            if screenshot:
                self._stats.observe_screenshot.add(elapsed_ms)
            if app_info:
                self._stats.observe_app_info.add(elapsed_ms)
            if getattr(self._event_logger, "enabled", False) and self._event_run_id:
                self._event_logger.write_event(
                    self._event_logger.build_stream_event(
                        event_type="observe_finished",
                        run_id=self._event_run_id,
                        goal=self._event_goal,
                        step_index=self._event_step_index,
                        selection_source=self._event_selection_source or None,
                        execution_source=self._event_execution_source or None,
                        payload={
                            "xml": getattr(observed, "xml", None),
                            "image_base64": getattr(observed, "image_base64", None),
                            "package_name": getattr(observed, "package_name", None),
                            "activity_name": getattr(observed, "activity_name", None),
                            "duration_ms": float(elapsed_ms),
                        },
                    )
                )
            if getattr(self._trace_logger, "enabled", False):
                self._trace_logger.write_event(
                    self._trace_logger.build_trace_event(
                        event_type="io",
                        run_id=self._trace_run_id,
                        function_id=self._trace_function_id,
                        payload={
                            "method": "observe",
                            "xml": bool(xml),
                            "screenshot": bool(screenshot),
                            "app_info": bool(app_info),
                            "duration_ms": float(elapsed_ms),
                        },
                    )
                )

    async def act(self, action, *, observation=None, **kwargs):
        t0 = perf_counter()
        result = None
        try:
            result = await self._act(action, observation=observation, **kwargs)
            return result
        finally:
            elapsed_ms = (perf_counter() - t0) * 1000
            self._stats.act.add(elapsed_ms)
            if getattr(self._event_logger, "enabled", False) and self._event_run_id:
                error_code, error_message = _event_error_fields(result)
                action_payload = canonical_action_payload(action)
                self._event_logger.write_event(
                    self._event_logger.build_stream_event(
                        event_type="act_finished",
                        run_id=self._event_run_id,
                        goal=self._event_goal,
                        step_index=self._event_step_index,
                        selection_source=self._event_selection_source or None,
                        execution_source=self._event_execution_source or None,
                        payload={
                            "raw_action": action_payload,
                            "formal_action": action_payload,
                            "executed_action": action_payload,
                            "success": _event_success(result),
                            "error_code": error_code,
                            "error_message": error_message,
                            "result": dict(result or {})
                            if isinstance(result, dict)
                            else {},
                            "duration_ms": float(elapsed_ms),
                        },
                    )
                )
            if getattr(self._trace_logger, "enabled", False):
                self._trace_logger.write_event(
                    self._trace_logger.build_trace_event(
                        event_type="io",
                        run_id=self._trace_run_id,
                        function_id=self._trace_function_id,
                        payload={
                            "method": "act",
                            "action_type": str(
                                getattr(action, "type", "")
                                or getattr(action, "action_type", "")
                                or ""
                            ),
                            "duration_ms": float(elapsed_ms),
                        },
                    )
                )


class UTGRunLogger:
    def __init__(self, enabled: bool = True, path: Optional[str] = None) -> None:
        self.enabled = bool(enabled)
        self.path = path or ""

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = bool(enabled)

    def set_path(self, path: str) -> None:
        self.path = path

    def new_run_id(self) -> str:
        return str(uuid.uuid4())

    def write_event(self, event: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        if not self.path:
            return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(
                json.dumps(
                    to_serializable(event),
                    ensure_ascii=False,
                    default=str,
                )
            )
            f.write("\n")

    def build_stream_event(
        self,
        *,
        event_type: str,
        run_id: str,
        goal: str = "",
        step_index: int | None = None,
        selection_source: str | None = None,
        execution_source: str | None = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Build one normalized run-event-stream record.

        Args:
            event_type: Stable event name inside the unified event stream.
            run_id: High-level run session id.
            goal: User-visible task goal for this run.
            step_index: Zero-based high-level step index when applicable.
            selection_source: Who selected the action/plan (`utg/vlm/human/backend`).
            execution_source: Who executed the action
                (`utg/native_step/autodevice_step/human_step/local_manual`).
            payload: Event-specific structured payload.

        Returns:
            One JSON-safe stream event used as the single source of truth.
        """

        return {
            "ts_utc": _utc_now_iso(),
            "run_id": str(run_id or "").strip(),
            "step_index": (None if step_index is None else max(0, int(step_index))),
            "event_type": str(event_type or "").strip(),
            "goal": str(goal or ""),
            "selection_source": str(selection_source or "").strip() or None,
            "execution_source": str(execution_source or "").strip() or None,
            "payload": dict(to_serializable(payload) or {}),
        }

    @staticmethod
    def _materialize_step_defaults(step_index: int) -> Dict[str, Any]:
        return {
            "step_index": int(step_index),
            "source": "",  # 新增：来源标识
            "observation_before_act": None,
            "compile_result": {},
            "plan": {},
            "act_source": None,
            "act_result": {},
            "provider_detail": {},
            "target_element": None,  # 新增：目标元素
            "intent": None,  # 新增：意图
            "started_at": None,
            "finished_at": None,
            "duration_ms": None,
            "selection_source": None,
            "execution_source": None,
        }

    @staticmethod
    def _step_function_description(step: dict[str, Any], *, goal: str) -> str:
        execution_request = _step_execution_request(step)
        compile_result = (
            dict(step.get("compile_result") or {})
            if isinstance(step.get("compile_result"), dict)
            else {}
        )
        utg_context = (
            dict(step.get("utg_context_summary") or {})
            if isinstance(step.get("utg_context_summary"), dict)
            else {}
        )
        function_id = str(
            execution_request.get("function_id")
            or compile_result.get("function_id")
            or ""
        ).strip()
        if not function_id:
            return goal
        for hint in list(utg_context.get("function_hints") or []):
            if not isinstance(hint, dict):
                continue
            if str(hint.get("function_id") or "").strip() != function_id:
                continue
            description = str(hint.get("description") or "").strip()
            if description:
                return description
        return goal or function_id

    @classmethod
    def _build_step_selector(
        cls,
        step: dict[str, Any],
        *,
        goal: str,
        run_source: str,
    ) -> dict[str, str]:
        plan = (
            dict(step.get("plan") or {}) if isinstance(step.get("plan"), dict) else {}
        )
        act_result = (
            dict(step.get("act_result") or {})
            if isinstance(step.get("act_result"), dict)
            else {}
        )
        existing_reason = str(step.get("selector_reason") or "").strip()
        if existing_reason:
            existing_source = (
                str(step.get("selector_source") or "").strip() or "unknown"
            )
            existing_label = (
                str(step.get("selector_label") or "").strip() or existing_source
            )
            return {
                "selector_source": existing_source,
                "selector_label": existing_label,
                "selector_reason": existing_reason,
            }

        source_candidates = [
            str(act_result.get("source") or "").strip(),
            str(step.get("selection_source") or "").strip(),
            str(step.get("selector_source") or "").strip(),
            run_source,
        ]
        joined_sources = " ".join(value.lower() for value in source_candidates if value)
        function_description = cls._step_function_description(step, goal=goal).strip()
        plan_reason = str(plan.get("reason") or "").strip()

        if any(
            token in joined_sources for token in ("manual_human", "human_step", "human")
        ):
            return {
                "selector_source": "human",
                "selector_label": "Human",
                "selector_reason": f"人工执行：{goal or '当前动作'}",
            }
        if (
            "utg_fast_path" in joined_sources
            or "utg_manual_dashboard" in joined_sources
            or "omniflow" in joined_sources
            or str(step.get("selection_source") or "").strip() == "utg"
        ):
            reason = (
                f"按 OmniFlow Function 执行：{function_description}"
                if function_description
                else "OmniFlow 执行当前 Function"
            )
            return {
                "selector_source": "omniflow",
                "selector_label": "OmniFlow",
                "selector_reason": reason,
            }
        if (
            any(token in joined_sources for token in ("vlm", "agent", "oob_vlm_task"))
            or bool(plan.get("planner_used"))
            or str(step.get("selection_source") or "").strip() == "vlm"
            or str(plan.get("tool_name") or "").strip() == "run_action"
        ):
            normalized_reason = ""
            if plan_reason and plan_reason not in {
                "planner_tool",
                "compile_hit",
                "compile_miss",
            }:
                normalized_reason = plan_reason
            if not normalized_reason:
                normalized_reason = goal or "VLM 选择执行当前动作"
            return {
                "selector_source": "vlm",
                "selector_label": "VLM",
                "selector_reason": normalized_reason,
            }
        if str(step.get("selection_source") or "").strip() == "backend":
            return {
                "selector_source": "backend",
                "selector_label": "Backend",
                "selector_reason": goal or "Backend 执行当前动作",
            }
        return {
            "selector_source": "unknown",
            "selector_label": "Unknown",
            "selector_reason": goal or "未记录选择原因",
        }

    @classmethod
    def _build_step_description(
        cls,
        step: dict[str, Any],
        *,
        goal: str,
    ) -> str:
        plan = (
            dict(step.get("plan") or {}) if isinstance(step.get("plan"), dict) else {}
        )
        execution_request = _step_execution_request(step)
        compile_result = (
            dict(step.get("compile_result") or {})
            if isinstance(step.get("compile_result"), dict)
            else {}
        )
        existing_description = str(
            step.get("operation_description")
            or plan.get("description")
            or execution_request.get("action_description")
            or ""
        ).strip()
        if existing_description:
            return existing_description
        action = None
        if isinstance(execution_request.get("action"), dict):
            action = dict(execution_request.get("action") or {})
        elif isinstance(plan.get("tool_args"), dict) and isinstance(
            plan.get("tool_args", {}).get("action"), dict
        ):
            action = dict(plan.get("tool_args", {}).get("action") or {})
        action_description = _build_action_description(action or {})
        if action_description:
            return action_description
        function_id = str(
            execution_request.get("function_id")
            or compile_result.get("function_id")
            or ""
        ).strip()
        if function_id:
            function_description = cls._step_function_description(step, goal=goal)
            if function_description:
                return f"执行 Function：{function_description}"
            return f"执行 Function {function_id}"
        tool_name = str(
            plan.get("tool_name") or execution_request.get("tool_name") or ""
        ).strip()
        if tool_name == "finish":
            return "结束任务"
        if compile_result.get("success") is False:
            candidate_function_ids = [
                str(item or "").strip()
                for item in list(compile_result.get("candidate_function_ids") or [])
                if str(item or "").strip()
            ]
            if candidate_function_ids:
                return f"未命中 Function，候选：{', '.join(candidate_function_ids[:3])}"
            return "未命中 Function"
        reason = str(plan.get("reason") or compile_result.get("reason") or "").strip()
        if reason:
            return reason
        return goal or "未记录动作"

    def normalize_materialized_run(self, run_log: Dict[str, Any]) -> Dict[str, Any]:
        """Return the final canonical run view used by all read APIs."""

        normalized = dict(to_serializable(run_log) or {})
        goal = str(normalized.get("goal") or "").strip()
        source = _build_run_source(normalized)
        if source:
            normalized["source"] = source
        raw_steps = list(normalized.get("steps") or [])
        normalized_steps: list[dict[str, Any]] = []
        for step_index, raw_step in enumerate(raw_steps):
            if not isinstance(raw_step, dict):
                normalized_steps.append(raw_step)
                continue
            step = dict(raw_step)
            plan = (
                dict(step.get("plan") or {})
                if isinstance(step.get("plan"), dict)
                else {}
            )
            execution_request = _step_execution_request(step)
            tool_call = (
                dict(step.get("tool_call") or {})
                if isinstance(step.get("tool_call"), dict)
                else {}
            )
            if not tool_call:
                if isinstance(execution_request.get("action"), dict):
                    action = dict(execution_request.get("action") or {})
                    action_type = str(action.get("type") or "").strip()
                    action_params = (
                        dict(action.get("params") or {})
                        if isinstance(action.get("params"), dict)
                        else {}
                    )
                    if action_type == "click_node":
                        tool_call = {
                            "name": "go_to_node",
                            "params": action_params,
                        }
                    elif action_type == "external_tool":
                        tool_call = {
                            "name": str(
                                action_params.get("tool_name") or "external_tool"
                            ).strip(),
                            "params": (
                                dict(action_params.get("arguments") or {})
                                if isinstance(action_params.get("arguments"), dict)
                                else {}
                            ),
                        }
                    elif action_type:
                        tool_call = {
                            "name": canonical_tool_call_name(action_type)
                            or action_type,
                            "params": action_params,
                        }
                elif str(execution_request.get("function_id") or "").strip():
                    tool_call = {
                        "name": str(execution_request.get("function_id") or "").strip(),
                        "params": (
                            dict(execution_request.get("arguments") or {})
                            if isinstance(execution_request.get("arguments"), dict)
                            else {}
                        ),
                    }
            if tool_call:
                step["tool_call"] = tool_call
            plan_tool_args = (
                dict(plan.get("tool_args") or {})
                if isinstance(plan.get("tool_args"), dict)
                else {}
            )
            for key in (
                "function_id",
                "arguments",
                "action",
                "raw_action",
                "content",
                "source",
            ):
                if key not in plan_tool_args and execution_request.get(key) is not None:
                    plan_tool_args[key] = to_serializable(execution_request.get(key))
            if plan_tool_args:
                plan["tool_args"] = plan_tool_args
            action = None
            if isinstance(execution_request.get("action"), dict):
                action = dict(execution_request.get("action") or {})
            elif isinstance(plan.get("tool_args"), dict) and isinstance(
                plan.get("tool_args", {}).get("action"), dict
            ):
                action = dict(plan.get("tool_args", {}).get("action") or {})
            action_description = _build_action_description(action or {})
            if action is not None:
                plan["tool_args"] = {
                    **dict(plan.get("tool_args") or {}),
                    "action": action,
                }
            if action_description:
                plan["action_description"] = action_description
            if tool_call:
                plan["tool_name"] = str(tool_call.get("name") or "").strip()
            elif not str(plan.get("tool_name") or "").strip() and action:
                plan["tool_name"] = "run_action"
            operation_description = self._build_step_description(
                step,
                goal=goal,
            )
            if operation_description:
                step["operation_description"] = operation_description
                plan["description"] = operation_description
            step["plan"] = plan
            selector = self._build_step_selector(
                step,
                goal=goal,
                run_source=source or "",
            )
            step.update(selector)
            normalized_steps.append(step)
        normalized["steps"] = normalized_steps
        normalized["step_count"] = int(
            normalized.get("step_count") or len(normalized_steps)
        )
        return normalized

    def materialize_run_events(
        self,
        events: list[dict[str, Any]],
    ) -> Dict[str, Any]:
        """Materialize one canonical run log from unified stream events.

        Args:
            events: Ordered stream events belonging to one `run_id`.

        Returns:
            One canonical run log derived purely from the event stream.
        """

        ordered_events = [
            dict(to_serializable(item) or {})
            for item in list(events or [])
            if isinstance(item, dict)
        ]
        if not ordered_events:
            return {
                "run_id": "",
                "goal": "",
                "success": False,
                "done_reason": None,
                "started_at": None,
                "finished_at": None,
                "duration_ms": 0.0,
                "step_count": 0,
                "steps": [],
            }

        first = ordered_events[0]
        run_id = str(first.get("run_id") or "").strip()
        goal = str(first.get("goal") or "").strip()
        top_level: Dict[str, Any] = {
            "run_id": run_id,
            "goal": goal,
            "success": False,
            "done_reason": None,
            "started_at": None,
            "finished_at": None,
            "duration_ms": 0.0,
            "step_count": 0,
            "steps": [],
        }
        steps_by_index: Dict[int, Dict[str, Any]] = {}

        def _ensure_step(step_index: int) -> Dict[str, Any]:
            step_key = max(0, int(step_index))
            existing = steps_by_index.get(step_key)
            if existing is None:
                existing = self._materialize_step_defaults(step_key)
                steps_by_index[step_key] = existing
            return existing

        for event in ordered_events:
            event_type = str(event.get("event_type") or "").strip()
            payload = (
                dict(event.get("payload") or {})
                if isinstance(event.get("payload"), dict)
                else {}
            )
            ts_utc = str(event.get("ts_utc") or "").strip() or None
            event_goal = str(event.get("goal") or "").strip()
            if event_goal:
                top_level["goal"] = event_goal
            step_index_raw = event.get("step_index")
            step_index = None if step_index_raw is None else max(0, int(step_index_raw))

            if event_type == "run_started":
                top_level["started_at"] = (
                    str(payload.get("started_at") or "").strip() or ts_utc
                )
                extra = dict(payload.get("extra") or {})
                if extra:
                    top_level["extra"] = extra
                continue

            if event_type == "run_finished":
                top_level["success"] = bool(payload.get("success", False))
                top_level["done_reason"] = (
                    str(payload.get("done_reason") or "").strip() or None
                )
                top_level["finished_at"] = (
                    str(payload.get("finished_at") or "").strip() or ts_utc
                )
                top_level["duration_ms"] = float(payload.get("duration_ms") or 0.0)
                final_observation = dict(payload.get("final_observation") or {})
                if final_observation:
                    top_level["final_observation"] = final_observation
                llm_usage = payload.get("llm_usage")
                if llm_usage:
                    top_level["llm_usage"] = llm_usage
                continue

            if step_index is None:
                continue
            step = _ensure_step(step_index)
            if not str(step.get("started_at") or "").strip():
                step["started_at"] = (
                    str(payload.get("started_at") or "").strip() or ts_utc
                )

            if event_type == "observe_finished":
                observation_payload = {
                    "xml": payload.get("xml"),
                    "image_base64": payload.get("image_base64"),
                    "package_name": payload.get("package_name"),
                    "activity_name": payload.get("activity_name"),
                }
                if not isinstance(step.get("observation_before_act"), dict):
                    step["observation_before_act"] = observation_payload
                continue

            if event_type == "compile_decided":
                step["compile_result"] = dict(payload or {})
                step["selection_source"] = (
                    str(event.get("selection_source") or "").strip()
                    or str(step.get("selection_source") or "").strip()
                    or None
                )
                continue

            if event_type == "plan_selected":
                plan_payload = dict(payload or {})
                tool_call = (
                    dict(plan_payload.pop("tool_call") or {})
                    if isinstance(plan_payload.get("tool_call"), dict)
                    else {}
                )
                step["plan"] = plan_payload
                if tool_call:
                    step["tool_call"] = tool_call
                step["selection_source"] = (
                    str(event.get("selection_source") or "").strip()
                    or str(step.get("selection_source") or "").strip()
                    or None
                )
                step["execution_source"] = (
                    str(event.get("execution_source") or "").strip()
                    or str(step.get("execution_source") or "").strip()
                    or None
                )
                continue

            if event_type == "act_finished":
                step["act_source"] = (
                    str(event.get("execution_source") or "").strip()
                    or str(step.get("act_source") or "").strip()
                    or None
                )
                step["selection_source"] = (
                    str(event.get("selection_source") or "").strip()
                    or str(step.get("selection_source") or "").strip()
                    or None
                )
                step["execution_source"] = (
                    str(event.get("execution_source") or "").strip()
                    or str(step.get("execution_source") or "").strip()
                    or None
                )
                step["act_result"] = {
                    "success": bool(payload.get("success", False)),
                    "error_code": (
                        str(payload.get("error_code") or "").strip() or None
                    ),
                    "error_message": (
                        str(payload.get("error_message") or "").strip() or None
                    ),
                    "source": (
                        str(event.get("execution_source") or "").strip() or None
                    ),
                }
                result_summary = dict(payload.get("result") or {})
                if result_summary:
                    step["act_result"]["result_summary"] = result_summary
                continue

            if event_type == "control_applied":
                provider_detail = dict(step.get("provider_detail") or {})
                control_trace = list(provider_detail.get("control_trace") or [])
                control_trace.append(dict(payload or {}))
                provider_detail["control_trace"] = control_trace
                step["provider_detail"] = provider_detail
                continue

            if event_type == "step_closed":
                provider_detail = (
                    dict(step.get("provider_detail") or {})
                    if isinstance(step.get("provider_detail"), dict)
                    else {}
                )
                payload_provider_detail = (
                    dict(payload.get("provider_detail") or {})
                    if isinstance(payload.get("provider_detail"), dict)
                    else {}
                )
                if payload_provider_detail:
                    provider_detail.update(payload_provider_detail)
                act_source = str(payload.get("act_source") or "").strip()
                if act_source:
                    step["act_source"] = act_source
                step["selection_source"] = (
                    str(event.get("selection_source") or "").strip()
                    or str(step.get("selection_source") or "").strip()
                    or None
                )
                step["execution_source"] = (
                    str(event.get("execution_source") or "").strip()
                    or str(step.get("execution_source") or "").strip()
                    or None
                )
                act_result = dict(payload.get("act_result") or {})
                if act_result:
                    step["act_result"] = act_result
                terminal_state = dict(payload.get("terminal_state") or {})
                if terminal_state:
                    step["terminal_state"] = terminal_state
                final_observation = dict(payload.get("final_observation") or {})
                if final_observation:
                    provider_detail["final_observation"] = final_observation
                if provider_detail:
                    step["provider_detail"] = provider_detail
                step["finished_at"] = (
                    str(payload.get("finished_at") or "").strip() or ts_utc
                )
                if payload.get("duration_ms") is not None:
                    step["duration_ms"] = float(payload.get("duration_ms") or 0.0)
                continue

        materialized_steps = [
            steps_by_index[index] for index in sorted(steps_by_index.keys())
        ]
        top_level["steps"] = materialized_steps
        top_level["step_count"] = len(materialized_steps)
        return top_level

    def decompose_materialized_run(
        self,
        run_log: Dict[str, Any],
    ) -> list[Dict[str, Any]]:
        """Convert one canonical/materialized run log into stream events."""

        normalized = dict(to_serializable(run_log) or {})
        run_id = str(normalized.get("run_id") or "").strip() or self.new_run_id()
        goal = str(normalized.get("goal") or "").strip()
        events: list[Dict[str, Any]] = [
            self.build_stream_event(
                event_type="run_started",
                run_id=run_id,
                goal=goal,
                payload={
                    "started_at": normalized.get("started_at"),
                    "extra": dict(normalized.get("extra") or {}),
                },
            )
        ]
        for raw_step in list(normalized.get("steps") or []):
            if not isinstance(raw_step, dict):
                continue
            step_index = max(0, int(raw_step.get("step_index") or 0))
            step_started_at = str(raw_step.get("started_at") or "").strip() or None
            observation = (
                dict(raw_step.get("observation_before_act") or {})
                if isinstance(raw_step.get("observation_before_act"), dict)
                else {}
            )
            if observation:
                observation["started_at"] = step_started_at
                events.append(
                    self.build_stream_event(
                        event_type="observe_finished",
                        run_id=run_id,
                        goal=goal,
                        step_index=step_index,
                        selection_source="utg",
                        execution_source=str(raw_step.get("act_source") or "").strip()
                        or None,
                        payload=observation,
                    )
                )
            compile_result = (
                dict(raw_step.get("compile_result") or {})
                if isinstance(raw_step.get("compile_result"), dict)
                else {}
            )
            if compile_result:
                compile_result["started_at"] = step_started_at
                events.append(
                    self.build_stream_event(
                        event_type="compile_decided",
                        run_id=run_id,
                        goal=goal,
                        step_index=step_index,
                        selection_source="utg"
                        if bool(compile_result.get("success", False))
                        else None,
                        execution_source="utg"
                        if bool(compile_result.get("success", False))
                        else None,
                        payload=compile_result,
                    )
                )
            plan = (
                dict(raw_step.get("plan") or {})
                if isinstance(raw_step.get("plan"), dict)
                else {}
            )
            tool_call = (
                dict(raw_step.get("tool_call") or {})
                if isinstance(raw_step.get("tool_call"), dict)
                else {}
            )
            if plan or tool_call:
                plan_payload = dict(plan)
                if tool_call:
                    plan_payload["tool_call"] = tool_call
                plan_payload["started_at"] = step_started_at
                events.append(
                    self.build_stream_event(
                        event_type="plan_selected",
                        run_id=run_id,
                        goal=goal,
                        step_index=step_index,
                        selection_source=str(
                            raw_step.get("selection_source") or ""
                        ).strip()
                        or str(raw_step.get("act_source") or "").strip()
                        or None,
                        execution_source=str(raw_step.get("act_source") or "").strip()
                        or None,
                        payload=plan_payload,
                    )
                )
            step_act_result = (
                dict(raw_step.get("act_result") or {})
                if isinstance(raw_step.get("act_result"), dict)
                else {}
            )
            provider_detail = (
                dict(raw_step.get("provider_detail") or {})
                if isinstance(raw_step.get("provider_detail"), dict)
                else {}
            )
            for control_item in list(provider_detail.get("control_trace") or []):
                if not isinstance(control_item, dict):
                    continue
                control_payload = dict(control_item)
                control_payload["started_at"] = step_started_at
                events.append(
                    self.build_stream_event(
                        event_type="control_applied",
                        run_id=run_id,
                        goal=goal,
                        step_index=step_index,
                        selection_source="utg",
                        execution_source=str(raw_step.get("act_source") or "").strip()
                        or None,
                        payload=control_payload,
                    )
                )
            events.append(
                self.build_stream_event(
                    event_type="step_closed",
                    run_id=run_id,
                    goal=goal,
                    step_index=step_index,
                    selection_source=str(raw_step.get("selection_source") or "").strip()
                    or str(raw_step.get("act_source") or "").strip()
                    or None,
                    execution_source=str(raw_step.get("act_source") or "").strip()
                    or None,
                    payload={
                        "act_source": raw_step.get("act_source"),
                        "act_result": step_act_result,
                        "terminal_state": dict(raw_step.get("terminal_state") or {}),
                        "provider_detail": provider_detail,
                        "final_observation": dict(
                            provider_detail.get("final_observation") or {}
                        ),
                        "started_at": step_started_at,
                        "finished_at": raw_step.get("finished_at"),
                        "duration_ms": raw_step.get("duration_ms"),
                    },
                )
            )
        extra = dict(normalized.get("extra") or {})
        llm_usage = (
            dict(extra.get("llm_usage") or {}) if extra.get("llm_usage") else None
        )
        events.append(
            self.build_stream_event(
                event_type="run_finished",
                run_id=run_id,
                goal=goal,
                payload={
                    "success": bool(normalized.get("success", False)),
                    "done_reason": normalized.get("done_reason"),
                    "finished_at": normalized.get("finished_at"),
                    "duration_ms": float(normalized.get("duration_ms") or 0.0),
                    "final_observation": dict(
                        normalized.get("final_observation") or {}
                    ),
                    "llm_usage": llm_usage,
                },
            )
        )
        return events

    def load_materialized_runs(self) -> list[Dict[str, Any]]:
        """Load and materialize all runs from the current event-stream file."""

        if not self.path or not os.path.exists(self.path):
            return []
        runs_by_id: Dict[str, list[Dict[str, Any]]] = {}
        run_order: list[str] = []
        with open(self.path, "r", encoding="utf-8") as handle:
            for raw_line in handle:
                raw_line = str(raw_line or "").strip()
                if not raw_line:
                    continue
                try:
                    payload = json.loads(raw_line)
                except Exception:
                    continue
                if not isinstance(payload, dict):
                    continue
                run_id = str(payload.get("run_id") or "").strip()
                if not run_id:
                    continue
                if run_id not in runs_by_id:
                    runs_by_id[run_id] = []
                    run_order.append(run_id)
                runs_by_id[run_id].append(payload)
        return [
            self.normalize_materialized_run(
                self.materialize_run_events(runs_by_id[run_id])
            )
            for run_id in run_order
        ]

    def load_materialized_run(self, *, run_id: str) -> Dict[str, Any] | None:
        """Load and materialize one run from the current event-stream file."""

        normalized_run_id = str(run_id or "").strip()
        if not normalized_run_id or not self.path or not os.path.exists(self.path):
            return None
        collected: list[Dict[str, Any]] = []
        with open(self.path, "r", encoding="utf-8") as handle:
            for raw_line in handle:
                raw_line = str(raw_line or "").strip()
                if not raw_line:
                    continue
                try:
                    payload = json.loads(raw_line)
                except Exception:
                    continue
                if not isinstance(payload, dict):
                    continue
                if str(payload.get("run_id") or "").strip() != normalized_run_id:
                    continue
                collected.append(payload)
        if not collected:
            return None
        return self.normalize_materialized_run(self.materialize_run_events(collected))

    def build_trace_event(
        self,
        *,
        event_type: str,
        run_id: str,
        function_id: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        event = {
            "ts_utc": _utc_now_iso(),
            "event": str(event_type or "").strip(),
            "run_id": str(run_id or "").strip(),
            "function_id": str(function_id or "").strip(),
        }
        if isinstance(payload, dict) and payload:
            event.update(payload)
        return event
