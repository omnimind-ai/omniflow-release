# utg/runtime/__init__.py
"""
UTG 运行时门面：只暴露 `UTGRuntime` facade。
goal -> plan/act 统一由 `src.agents.base_agent.OmniFlow` 编排。
"""

from .utg_runtime import UTGRuntime

__all__ = [
    "UTGRuntime",
]
