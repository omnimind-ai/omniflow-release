from __future__ import annotations

from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
import tempfile
from time import perf_counter
from typing import Any, Dict, List, Optional, Sequence, Union

from src.foundation.paths import get_runtime_file
from src.utg.assets.embedding import UTGMatchEngine, UTGStatsCollector
from src.utg.assets.embedding.vector_db_builder import build_utg_vector_db
from src.utg.assets.mutation.graph_merge import merge_utg
from src.utg.core.actions import AnyAction
from src.utg.core.graph_ops import find_node_distance_bfs
from src.utg.core.models import (
    DEFAULT_UTG_VERSION,
    AppInfo,
    Function,
    NodeRepr,
    UTGGraph,
    UTGNode,
)
from src.utg.execution.compile import (
    CompileConfig,
    CompileContext,
    CompileDecision,
    Compiler,
    CompileResult,
    FunctionCandidate,
    FunctionScope,
)
from src.utg.execution.control import ControlEngine
from src.utg.execution.execution_policy import (
    ExecutionPolicyBundle,
    ExecutionPolicyProvider,
    get_runtime_trigger_pool_enabled,
    get_runtime_trigger_pool_file,
    get_runtime_utg_store_path,
    get_utg_bundle_file_for_execution,
)
from src.utg.execution.executor import (
    RunFunctionResult,
    UTGExecutor,
)
from src.utg.execution.protocol import (
    DeviceObservation,
    Observation,
    observe_app_info,
    observe_xml,
)
from src.utg.execution.utils import format_score, safe_float, slice_length
from src.utg.log.eval_logger import (
    build_eval_logger,
)
from src.utg.log.run_logger import (
    AgentIOStats,
    UTGRunLogger,
    default_run_event_stream_path,
)
from src.utg.retrieval import FunctionRetriever

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    """Return the current UTC timestamp in ISO-8601 format."""

    return datetime.now(timezone.utc).isoformat()


def _default_run_log_path() -> str:
    return default_run_event_stream_path()


def _default_execution_trace_log_path() -> str:
    return str(get_runtime_file("logs", "utg_execution_trace.jsonl"))


class UTGRuntime:
    """
    UTG 运行时统一门面：
    - plan：编译用户查询为 `function_id + arguments`
    - act：执行 UTG function
    - UTG 图管理/匹配能力
    """

    _filepath: Optional[str] = None
    _app_info_cache_path: Optional[str] = None

    def __init__(
        self,
        filepath: Optional[str] = None,
        utg_graph: Optional[UTGGraph] = None,
        trigger_pool_config_path: Optional[str] = None,
        trigger_pool_enabled: Optional[bool] = None,
        asset_utg_paths: Optional[Union[str, Sequence[str]]] = None,
        *,
        enable_run_log: Optional[bool] = None,
        run_log_path: Optional[str] = None,
        execution_policy: Optional[ExecutionPolicyProvider] = None,
        execution_policy_path: Optional[str] = None,
    ) -> None:
        self._filepath = filepath or get_runtime_utg_store_path()
        self._app_info_cache_path = str(
            get_utg_bundle_file_for_execution("app_info_auto.json", self._filepath)
        )
        effective_trigger_pool_enabled = (
            get_runtime_trigger_pool_enabled(default=True)
            if trigger_pool_enabled is None
            else bool(trigger_pool_enabled)
        )
        effective_trigger_pool_file = (
            trigger_pool_config_path
            if trigger_pool_config_path is not None
            else get_runtime_trigger_pool_file()
        )
        self.execution_policy = execution_policy or ExecutionPolicyBundle.from_file(
            path=execution_policy_path,
            utg_path=self._filepath,
            trigger_pool_config_path=effective_trigger_pool_file,
            trigger_pool_enabled=effective_trigger_pool_enabled,
        )
        compile_cfg = self.execution_policy.compile_config()
        self.compile_candidate_limit = max(1, int(compile_cfg.candidate_limit))
        # Compiler configuration
        self._compile_config = CompileConfig.from_env()
        self._compiler: Optional[Compiler] = None
        # Log configuration from unified settings
        from src.foundation.settings import settings

        self.enable_run_log = (
            bool(enable_run_log)
            if enable_run_log is not None
            else settings.log.run_log_enabled
        )
        self.run_log_path = str(
            run_log_path or settings.log.run_log_path or _default_run_log_path()
        )
        self.execution_trace_enabled = settings.log.execution_trace_enabled
        self.execution_trace_path = str(
            settings.log.execution_trace_path or _default_execution_trace_log_path()
        )
        self.execution_trace_echo = settings.log.execution_trace_echo

        if utg_graph is not None:
            self._utg = utg_graph
        else:
            if not self._filepath:
                logger.error("No valid file path provided for loading UTG.")
                self._utg = UTGGraph(version=DEFAULT_UTG_VERSION, nodes=[])
                return
            try:
                self._bootstrap_utg_store_if_needed(self._filepath)
                absolute_filepath = os.path.abspath(self._filepath)
                logger.info(f"📖 UTG READING FROM: {absolute_filepath}")
                self._utg = UTGGraph.load_model_from_json_file(self._filepath)
            except Exception as e:
                logger.error(f"Failed to load UTG from {self._filepath}: {e}")
                self._utg = UTGGraph(
                    version=DEFAULT_UTG_VERSION, nodes=[], functions={}
                )
        self._merge_explicit_asset_utgs(asset_utg_paths)
        self._load_app_info_cache()

        self._vector_db, self._node_lookup = build_utg_vector_db(self._utg)
        self._function_lookup: dict[str, Function] = dict(self._utg.functions or {})
        self._function_retriever = FunctionRetriever([])
        self._stats = UTGStatsCollector()
        self._control_engine = ControlEngine(self.execution_policy)
        self._executor = UTGExecutor(
            stats=self._stats,
            policy_provider=self.execution_policy,
            control_engine=self._control_engine,
        )
        self._matcher = UTGMatchEngine(
            utg=self._utg,
            vector_db=self._vector_db,
            node_lookup=self._node_lookup,
            stats=self._stats,
        )
        self._build_compiler()

        self._run_logger = UTGRunLogger(
            enabled=self.enable_run_log,
            path=self.run_log_path,
        )
        self._execution_trace_logger = UTGRunLogger(
            enabled=self.execution_trace_enabled,
            path=self.execution_trace_path,
        )
        self._eval_logger = build_eval_logger()

        logger.info("UTGRuntime initialized.")

    def _normalize_asset_utg_paths(
        self,
        asset_utg_paths: Optional[Union[str, Sequence[str]]],
    ) -> list[Path]:
        """
        Normalize caller-provided UTG asset paths into concrete existing files.

        Args:
            asset_utg_paths: One path or many paths containing extra UTG assets to
                merge into the runtime graph. Paths are merged in order.

        Returns:
            Existing filesystem paths only. Missing entries are skipped with a log.
        """

        if asset_utg_paths is None:
            return []
        raw_paths: list[str] = []
        if isinstance(asset_utg_paths, str):
            raw_paths = [asset_utg_paths]
        else:
            raw_paths = [str(item) for item in list(asset_utg_paths or [])]
        normalized: list[Path] = []
        for raw_path in raw_paths:
            candidate = Path(str(raw_path or "").strip()).expanduser()
            if not str(candidate):
                continue
            if not candidate.is_absolute():
                candidate = Path.cwd() / candidate
            candidate = candidate.resolve()
            if not candidate.exists():
                logger.warning("Skip missing UTG asset path: %s", candidate)
                continue
            normalized.append(candidate)
        return normalized

    def _merge_explicit_asset_utgs(
        self,
        asset_utg_paths: Optional[Union[str, Sequence[str]]],
    ) -> None:
        """
        Merge extra UTG asset files into the primary runtime graph explicitly.

        Args:
            asset_utg_paths: Optional UTG JSON files provided by the caller. This is
                the only supported way to layer extra builtin/global assets into the
                runtime after the refactor.
        """

        primary_path = (
            Path(self._filepath).expanduser().resolve()
            if str(self._filepath or "").strip()
            else None
        )
        for asset_path in self._normalize_asset_utg_paths(asset_utg_paths):
            if primary_path is not None and asset_path == primary_path:
                logger.info("Skip self-merge UTG asset: %s", asset_path)
                continue
            try:
                asset_payload = json.loads(asset_path.read_text(encoding="utf-8"))
                merged_payload = merge_utg(
                    self._utg.model_dump(exclude_none=True, by_alias=True),
                    asset_payload,
                )
                merged_graph = UTGGraph.model_validate(merged_payload)
            except Exception as exc:
                logger.warning(
                    "Failed to merge explicit UTG asset %s: %s", asset_path, exc
                )
                continue
            added_nodes = max(0, len(merged_graph.nodes) - len(self._utg.nodes))
            added_functions = max(
                0, len(merged_graph.functions) - len(self._utg.functions)
            )
            self._utg = merged_graph
            logger.info(
                "Merged explicit UTG asset: source=%s added_nodes=%d added_functions=%d",
                asset_path,
                added_nodes,
                added_functions,
            )

    def _load_app_info_cache(self) -> None:
        path = self._app_info_cache_path
        if not path or not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = json.load(file)
        except Exception as exc:
            logger.warning("Failed to read app info cache %s: %s", path, exc)
            return

        if isinstance(payload, list):
            raw_entries = payload
        elif isinstance(payload, dict):
            candidate = payload.get("appInfo")
            if not isinstance(candidate, list):
                candidate = payload.get("entries")
            raw_entries = candidate if isinstance(candidate, list) else []
        else:
            raw_entries = []
        if not raw_entries:
            return

        existing_packages = {
            str(getattr(app, "packageName", "")).strip()
            for app in self._utg.appInfo
            if str(getattr(app, "packageName", "")).strip()
        }
        added = 0
        for item in raw_entries:
            if not isinstance(item, dict):
                continue
            package_name = str(
                item.get("packageName") or item.get("package_name") or ""
            ).strip()
            app_name = str(
                item.get("appName") or item.get("app_name") or package_name
            ).strip()
            if not package_name or package_name in existing_packages:
                continue
            self._utg.appInfo.append(
                AppInfo(appName=app_name or package_name, packageName=package_name)
            )
            existing_packages.add(package_name)
            added += 1
        if added > 0:
            logger.info(
                "Loaded app info cache: source=%s added=%d total=%d",
                path,
                added,
                len(self._utg.appInfo),
            )

    def _persist_app_info_cache(self) -> None:
        path = self._app_info_cache_path
        if not path:
            return
        try:
            payload = {
                "appInfo": [
                    {
                        "appName": str(getattr(app, "appName", "") or "").strip(),
                        "packageName": str(
                            getattr(app, "packageName", "") or ""
                        ).strip(),
                    }
                    for app in self._utg.appInfo
                    if str(getattr(app, "packageName", "") or "").strip()
                ]
            }
            with open(path, "w", encoding="utf-8") as file:
                file.write(json.dumps(payload, ensure_ascii=False, indent=2))
        except Exception as exc:
            logger.warning("Failed to persist app info cache %s: %s", path, exc)

    @staticmethod
    def _default_utg_graph() -> UTGGraph:
        return UTGGraph(
            version=DEFAULT_UTG_VERSION,
            appInfo=[],
            nodes=[],
            functions={},
        )

    @classmethod
    def _bootstrap_utg_store_if_needed(cls, filepath: str) -> None:
        """
        Ensure UTG store file exists and is non-empty JSON.
        If file is missing or empty, write a standard UTG skeleton.
        """
        reason: Optional[str] = None
        if not os.path.exists(filepath):
            reason = "missing"
        elif os.path.isfile(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    if not f.read().strip():
                        reason = "empty"
            except Exception:
                # Keep original behavior for non-empty files with read/permission issues.
                return

        if reason is None:
            return

        directory = os.path.dirname(filepath)
        if directory:
            os.makedirs(directory, exist_ok=True)

        graph = cls._default_utg_graph()
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(
                json.dumps(
                    graph.model_dump(exclude_none=True), ensure_ascii=False, indent=2
                )
            )
        logger.warning("UTG store %s at %s; wrote default skeleton.", reason, filepath)

    def _build_compiler(self) -> None:
        """Build Compiler and register functions from UTG."""
        self._compiler = Compiler(self._compile_config)

        # Register global functions
        for func_name, func in (self._utg.functions or {}).items():
            func_name = str(func_name or "").strip()
            if not func_name:
                continue
            func_metadata = dict(getattr(func, "metadata", {}) or {})
            if func_metadata.get("asset_state") == "temporary":
                continue
            description = str(getattr(func, "description", "") or "").strip()
            if not description:
                continue
            parameter_names = tuple(
                getattr(func, "get_parameter_names", lambda: [])() or []
            )
            self._compiler.register_function(
                FunctionCandidate(
                    function_id=func_name,
                    description=description,
                    scope=FunctionScope.GLOBAL,
                    parameter_names=parameter_names,
                    recall_phrases=(description,),
                )
            )

        # Register node-level entry_point functions
        for node in self._utg.nodes or []:
            node_id = str(getattr(node, "id", "") or "").strip()
            if not node_id:
                continue
            node_functions = getattr(node, "functions", None)
            if not isinstance(node_functions, dict):
                continue
            package_name = str(
                getattr(getattr(node, "repr", None), "packageName", "") or ""
            ).strip()
            for fn_name, fn in node_functions.items():
                fn_name = str(fn_name or "").strip()
                if not fn_name:
                    continue
                fn_metadata = dict(getattr(fn, "metadata", {}) or {})
                if not fn_metadata.get("entry_point"):
                    continue
                description = str(getattr(fn, "description", "") or "").strip()
                if not description:
                    continue
                parameter_names = tuple(
                    getattr(fn, "get_parameter_names", lambda: [])() or []
                )
                self._compiler.register_function(
                    FunctionCandidate(
                        function_id=f"{node_id}:{fn_name}",
                        description=description,
                        scope=FunctionScope.PAGE,
                        parameter_names=parameter_names,
                        recall_phrases=(description,),
                        source_app=package_name or None,
                        source_node_id=node_id,
                        from_node_id=node_id,
                    )
                )

        self._compiler.build_index()
        logger.info(
            f"Compiler built with {len(self._compiler._global_functions)} global + "
            f"{sum(len(v) for v in self._compiler._page_functions.values())} page functions"
        )

    # ---------- Plan / Compile ----------

    def compile(
        self,
        goal: str,
        *,
        context: Optional[CompileContext | Dict[str, Any]] = None,
    ) -> CompileResult:
        """Compile one natural-language goal into one UTG function decision.

        Args:
            goal: Current user goal text for this compile turn.
            context: Optional compile context with current_node_id, current_package,
                recent_function_ids.

        Returns:
            CompileResult with decision (HIT/AMBIGUOUS/MISS) and function_id.
        """
        if self._compiler is None:
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="compiler_not_initialized",
            )

        # Build CompileContext
        compile_context: CompileContext
        if isinstance(context, CompileContext):
            compile_context = context
        elif isinstance(context, dict):
            compile_context = CompileContext(
                current_node_id=str(context.get("current_node_id") or "").strip()
                or None,
                current_package=str(context.get("current_package") or "").strip()
                or None,
                recent_function_ids=[
                    str(item or "").strip()
                    for item in list(context.get("recent_function_ids") or [])
                    if str(item or "").strip()
                ],
            )
        else:
            compile_context = CompileContext()

        return self._compiler.compile(goal, compile_context)

    async def run_function(
        self,
        observe,
        act,
        function_id: str,
        *,
        node_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> RunFunctionResult:
        """Execute a function by ID.

        Unified API for executing both node-level and global functions.

        Args:
            observe: Live observe function.
            act: Live act function.
            function_id: Function name/ID to execute.
            node_id: Optional node ID to scope the function lookup.
                - If provided: look in node.functions (atomic)
                - If None: look in graph.functions (global/composite)
            context: Optional execution context.

        Returns:
            RunFunctionResult with execution status.

        Examples:
            # Execute global composite function
            await runtime.run_function(observe, act, "open_settings")

            # Execute node-scoped atomic function
            await runtime.run_function(observe, act, "click_wifi", node_id="settings_main")
        """
        func = None
        node = None
        runtime_context = context if context is not None else {}
        before_stats = self._stats.to_dict()
        started_at = perf_counter()

        if node_id:
            # Scoped to specific node
            node = self.get_node_by_id(node_id)
            if node is None:
                return RunFunctionResult(
                    success=False,
                    error_message=f"Node not found: {node_id}",
                    error_code="EXEC_NODE_NOT_FOUND",
                )
            func = node.functions.get(function_id)
        else:
            # Global lookup - graph.functions
            func = self.get_function_by_id(function_id)

        if func is None:
            return RunFunctionResult(
                success=False,
                error_message=f"Function not found: {function_id}",
                error_code="EXEC_FUNCTION_NOT_FOUND",
            )

        # Delegate to executor for proper control plane integration
        result = await self._executor.run_function(
            observe, act, node, func, context=runtime_context, runtime=self
        )
        self._attach_run_log(
            run_id=(f"run_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')}"),
            function_id=function_id,
            result=result,
            duration_ms=(perf_counter() - started_at) * 1000.0,
            before_stats=before_stats,
            after_stats=self._stats.to_dict(),
            port_stats=AgentIOStats(),
            runtime_context=runtime_context,
        )
        return result

    async def run_action(
        self,
        observe,
        act,
        node: Union[str, UTGNode],
        action: AnyAction,
        *,
        context: Optional[Dict[str, Any]] = None,
    ):
        node_obj = self.get_node_by_id(node) if isinstance(node, str) else node
        if node_obj is None:
            return RunFunctionResult(
                success=False,
                error_message=f"Node {node} not found",
                error_code="EXEC_NODE_NOT_FOUND",
            )
        return await self._executor.run_action(
            observe, act, node_obj, action, context=context
        )

    async def controlled_act(
        self,
        observe,
        act,
        action: AnyAction,
        *,
        observation: DeviceObservation | None = None,
        context: Optional[Dict[str, Any]] = None,
        **_: Any,
    ) -> Dict[str, Any]:
        """Execute one external action through the shared control hook.

        Args:
            observe: Live observe function used for fresh observations.
            act: Live act function used for device execution.
            action: One normalized device action proposed by an external agent.
            observation: Optional caller-provided observation captured right before act.
            context: Extra source/goal/path metadata forwarded into control.

        Returns:
            A compact result payload containing success, final observation,
            control trace, and prompt_context for the caller's next prompt.
        """

        control_context = dict(context or {})
        control_context.setdefault("__utg_control_scope__", "act_hook")
        if (
            "source" in control_context
            and "__utg_control_source__" not in control_context
        ):
            control_context["__utg_control_source__"] = control_context["source"]
        return await self._executor.controlled_act(
            observe,
            act,
            action,
            context=control_context,
            runtime=self,
            observation=Observation(
                xml=str(getattr(observation, "xml", "") or ""),
                package_name=str(getattr(observation, "package_name", "") or ""),
                activity_name=str(getattr(observation, "activity_name", "") or ""),
            )
            if observation is not None
            else None,
        )

    # ---------- Compile Index ----------

    def _rebuild_compiler_index(self) -> None:
        """重建编译器索引。"""
        self._build_compiler()

    def load_from_utg(self, utg_graph: UTGGraph) -> Dict:
        """使用给定 UTG 图替换当前图并重建 compiler 索引。"""
        self._utg = utg_graph
        self._rebuild_compiler_index()
        return {"functions": len(utg_graph.functions), "rebuilt": True}

    def set_run_log_enabled(self, enabled: bool) -> None:
        self.enable_run_log = bool(enabled)
        self._run_logger.set_enabled(enabled)

    def set_run_log_path(self, path: str) -> None:
        self.run_log_path = str(path)
        self._run_logger.set_path(path)

    def get_run_log_path(self) -> str:
        return str(getattr(self._run_logger, "path", self.run_log_path))

    def _stats_delta_snapshot(self, before: Dict, after: Dict) -> Dict:
        """计算统计快照的增量。"""
        before_match = before.get("match", {})
        after_match = after.get("match", {})
        before_exec = before.get("execution", {})
        after_exec = after.get("execution", {})
        return {
            "match": {
                "attempts": after_match.get("attempts", 0)
                - before_match.get("attempts", 0),
                "hits": after_match.get("hits", 0) - before_match.get("hits", 0),
                "timings_ms": after_match.get("timings_ms", [])[
                    slice_length(before_match.get("timings_ms", [])) :
                ],
                "last_strategy": after_match.get("last_strategy"),
                "last_node_id": after_match.get("last_node_id"),
                "last_score": after_match.get("last_score"),
            },
            "execution": {
                "function_assets_run": after_exec.get("function_assets_run", 0)
                - before_exec.get("function_assets_run", 0),
                "functions_run": after_exec.get("functions_run", 0)
                - before_exec.get("functions_run", 0),
                "actions_run": after_exec.get("actions_run", 0)
                - before_exec.get("actions_run", 0),
                "timings_ms": after_exec.get("timings_ms", [])[
                    slice_length(before_exec.get("timings_ms", [])) :
                ],
                "errors": after_exec.get("errors", [])[
                    slice_length(before_exec.get("errors", [])) :
                ],
                "last_function_id": after_exec.get("last_function_id"),
            },
        }

    # ---------- UTG 图管理 ----------

    async def get_current_node(
        self,
        observe,
        description: str = "",
        function_id: Optional[str] = None,
    ) -> UTGNode:
        logger.info("[get_current_node] Starting XML capture...")
        xml = await observe_xml(observe)
        logger.info(
            f"[get_current_node] XML captured, length: {len(xml) if xml else 0}"
        )

        logger.info(
            f"[get_current_node] Starting node matching against {len(self._utg.nodes)} existing nodes..."
        )
        package_name, _ = await observe_app_info(observe)
        function_node_ids = None
        if function_id:
            func = self.get_function_by_id(function_id)
            if func:
                # Extract node_ids from call_function actions
                function_node_ids = []
                for action in getattr(func, "actions", []) or []:
                    if str(getattr(action, "type", "")).strip() == "call_function":
                        params = getattr(action, "params", None)
                        node_id = (
                            str(getattr(params, "node_id", "") or "").strip()
                            if params
                            else ""
                        )
                        if node_id and node_id not in function_node_ids:
                            function_node_ids.append(node_id)
        match_node = self.match_node(
            xml,
            package_name=package_name or "",
            path_node_ids=function_node_ids,
        )
        if match_node:
            logger.info(f"match_node: {match_node.id}")
            return match_node
        logger.info("do not match any existing node, create a new one.")

        app_package_name = "com.example.app"
        node_id = description if description else f"tmp_{str(len(self._utg.nodes) + 1)}"
        new_node = UTGNode(
            id=node_id,
            repr=NodeRepr(
                xmls=[xml],
                packageName=app_package_name,
                description=description,
            ),
            functions={},
        )
        logger.info(
            f"[get_current_node] Created new node: {node_id} with temporary package name"
        )
        return new_node

    def match_node(
        self,
        xml: str,
        package_name: str,
        path_node_ids: Optional[list[str]] = None,
        forecast_nodes: Optional[list[UTGNode]] = None,
    ) -> Optional[UTGNode]:
        """
        基于向量检索 + node_filter 的匹配链路。
        """
        matched_node = self._matcher.match_node(
            xml=xml,
            package_name=package_name,
            path_node_ids=path_node_ids,
            forecast_nodes=forecast_nodes,
        )
        self._log_match_debug(matched_node)
        return matched_node

    def match_node_by_vector_set(
        self,
        vector_set: Any,
        package_name: str = "",
    ) -> Optional[UTGNode]:
        """
        通过 PageVectorSet 匹配节点

        Args:
            vector_set: PageVectorSet 对象
            package_name: 包名（用于包过滤）

        Returns:
            匹配到的 UTGNode，或 None
        """
        from src.utg.assets.embedding.vector_set import PageVectorSet

        if vector_set is None:
            return None
        if not isinstance(vector_set, PageVectorSet):
            return None

        # 尝试使用 matcher 的 vector_set 匹配方法
        try:
            matched_node = self._matcher.match_node_from_vector_set(
                vector_set=vector_set,
                package_name=package_name,
            )
            self._log_match_debug(matched_node)
            return matched_node
        except AttributeError:
            # matcher 不支持 vector_set 匹配，fallback 到指纹匹配
            pass

        # Fallback: 使用指纹直接匹配
        fingerprint = getattr(vector_set, "fingerprint", "")
        if not fingerprint:
            return None

        for node in self._utg.nodes:
            # 检查 vector_sets 中的指纹
            for vs_dict in node.repr.vector_sets or []:
                if vs_dict.get("fingerprint") == fingerprint:
                    self._matcher.last_match_debug = {
                        "search_topk": [],
                        "candidate_scores": [],
                        "selected_node_id": node.id,
                        "selected_score": 1.0,
                        "strategy": "fingerprint_fallback",
                    }
                    self._log_match_debug(node)
                    return node

        return None

    def _log_match_debug(self, matched_node: Optional[UTGNode]) -> None:
        debug_info = getattr(self._matcher, "last_match_debug", None) or {}
        if not debug_info:
            return

        search_topk = list(debug_info.get("search_topk") or [])
        if search_topk:
            vector_parts: List[str] = []
            for item in search_topk[:3]:
                node_id = str(item.get("node_id") or "?")
                vector_parts.append(
                    f"{node_id}:{format_score(item.get('vector_score'))}"
                )
            logger.info("[match_node] search_topk=%s", " | ".join(vector_parts))

        candidate_scores = list(debug_info.get("candidate_scores") or [])
        if candidate_scores:
            candidate_parts: List[str] = []
            for item in candidate_scores[:3]:
                node_id = str(item.get("node_id") or "?")
                valid = "Y" if bool(item.get("is_valid")) else "N"
                reason = str(item.get("reason") or "-")
                candidate_parts.append(
                    f"{node_id}(vec={format_score(item.get('vector_score'))},"
                    f"final={format_score(item.get('final_score'))},"
                    f"ok={valid},reason={reason})"
                )
            logger.info("[match_node] candidate_topk=%s", " | ".join(candidate_parts))

        selected_node_id = str(
            debug_info.get("selected_node_id")
            or (matched_node.id if matched_node is not None else "none")
        )
        selected_score = format_score(debug_info.get("selected_score"))
        strategy = str(debug_info.get("strategy") or "none")
        logger.info(
            "[match_node] selected=%s strategy=%s score=%s",
            selected_node_id,
            strategy,
            selected_score,
        )

    def _snapshot_page_match_debug(self) -> Optional[Dict[str, Any]]:
        """快照页面匹配调试信息。"""
        debug_info = getattr(self._matcher, "last_match_debug", None)
        if not isinstance(debug_info, dict) or not debug_info:
            return None
        return {
            "strategy": str(debug_info.get("strategy") or ""),
            "selected_node_id": debug_info.get("selected_node_id"),
            "selected_score": safe_float(debug_info.get("selected_score")),
            "search_topk": list(debug_info.get("search_topk") or [])[:3],
            "candidate_topk": list(debug_info.get("candidate_scores") or [])[:3],
        }

    def get_node_by_id(self, node_id: str) -> Optional[UTGNode]:
        for node in self._utg.nodes:
            if node.id == node_id:
                return node
        return None

    def get_function_by_id(self, function_id: str) -> Optional[Function]:
        """Return global Function by id from current UTG graph."""
        return self._utg.functions.get(function_id)

    def get_node_distance_bfs(
        self,
        start_node_id: str,
        end_node_id: str,
    ) -> Optional[int]:
        """
        Return shortest node-to-node transition distance on current UTG graph.
        - same node -> 0
        - unreachable -> None
        """
        return find_node_distance_bfs(self._utg, start_node_id, end_node_id)

    async def save(self, observe=None) -> None:
        if not self._filepath:
            logger.error("No valid file path provided for saving UTG.")
            return

        if observe:
            await self._update_temporary_package_names(observe)

        # Atomic write: write to temp file first, then rename
        absolute_filepath = os.path.abspath(self._filepath)
        logger.info(f"💾 UTG SAVING TO: {absolute_filepath}")

        dir_path = os.path.dirname(absolute_filepath)
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                dir=dir_path,
                suffix=".tmp",
                delete=False,
                encoding="utf-8",
            ) as tmp_file:
                tmp_file.write(
                    json.dumps(
                        self._utg.model_dump(exclude_none=True, by_alias=True),
                        ensure_ascii=False,
                        indent=2,
                    )
                )
                tmp_path = tmp_file.name
            os.replace(tmp_path, absolute_filepath)  # Atomic operation
            logger.info(f"UTG saved to {self._filepath}.")
        except Exception as e:
            logger.error(f"Failed to save UTG: {e}")
            if tmp_path and os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

    def rebuild_vector_db(self) -> None:
        self._vector_db, self._node_lookup = build_utg_vector_db(self._utg)
        self._matcher.vector_db = self._vector_db
        self._matcher.node_lookup = self._node_lookup
        self._matcher.recompute_node_importance()

    def _rebuild_function_lookup(self) -> None:
        """Rebuild function lookup cache."""
        self._function_lookup = dict(self._utg.functions or {})
        # Build function retriever from global functions
        self._function_retriever = FunctionRetriever(list(self._utg.functions.values()))

    def refresh_after_mutation(self) -> None:
        """Refresh in-memory matcher state after nodes/functions are mutated and persisted."""
        self.rebuild_vector_db()
        self._rebuild_function_lookup()
        self._rebuild_compiler_index()

    def get_stats(self) -> Dict:
        return self._stats.to_dict()

    async def _update_temporary_package_names(self, observe) -> None:
        logger.info("🔍 [save] Checking for temporary package names to update...")

        try:
            current_package_name, current_app_name = await observe_app_info(observe)
            if not current_package_name:
                logger.warning(
                    "[save] Failed to get current app info, keeping temporary names"
                )
                return

            logger.info(
                f"🎯 [save] Got current app info: {current_package_name} -> {current_app_name}"
            )

            updated_count = 0
            for node in self._utg.nodes:
                if node.repr.packageName == "com.example.app":
                    logger.info(
                        f"📝 [save] Updating node {node.id}: com.example.app -> {current_package_name}"
                    )
                    node.repr.packageName = current_package_name
                    updated_count += 1

            if updated_count > 0:
                self.ensure_app_info(current_package_name, current_app_name)
                logger.info(
                    f"✅ [save] Updated {updated_count} nodes with real app info: {current_package_name}"
                )

        except Exception as e:
            logger.error(f"[save] Error updating temporary package names: {e}")

    def update_node(self, node: UTGNode) -> None:
        """Update or add a node to the UTG graph.

        Supports both legacy XML-based and new vector_set-based nodes.
        When vector_sets are available, they are used for vector DB indexing
        with a fallback to legacy xmls for backward compatibility.
        """
        for idx, existing_node in enumerate(self._utg.nodes):
            if existing_node.id == node.id:
                self._utg.nodes[idx] = node
                self._node_lookup[node.id] = node
                self._index_node_to_vector_db(node)
                self._matcher.recompute_node_importance()
                logger.info(f"Updated existing node with id {node.id}.")
                return
        self._utg.nodes.append(node)
        self._node_lookup[node.id] = node
        self._index_node_to_vector_db(node)
        self._matcher.recompute_node_importance()
        logger.info(f"Added new node with id {node.id}.")

    def _index_node_to_vector_db(self, node: UTGNode) -> None:
        """Index a node's pages to the vector DB.

        Uses vector_sets if available, falls back to legacy xmls.
        """
        if not self._vector_db:
            return

        meta = {
            "node_id": node.id,
            "package": node.repr.packageName,
            "desc": node.repr.description or "No Description",
        }

        # Priority 1: Use vector_sets (new asset separation model)
        if node.repr.vector_sets:
            for idx_vs, vs_dict in enumerate(node.repr.vector_sets):
                page_id = f"{node.id}#vs_{idx_vs}"
                # For vector_sets, we need to reconstruct the page vector
                # The vector DB can accept pre-computed vectors via metadata
                vs_meta = dict(meta)
                vs_meta["vector_set"] = vs_dict
                # Extract page_vector if available
                page_vector = vs_dict.get("page_vector")
                if page_vector is not None:
                    vs_meta["precomputed_vector"] = page_vector
                # Use fingerprint as a pseudo-XML for the encoder
                fingerprint = vs_dict.get("fingerprint", "")
                package = vs_dict.get("package_name", node.repr.packageName)
                # Add to vector DB - if it supports pre-computed vectors, use them
                # Otherwise fall back to using a minimal XML representation
                try:
                    # Try to add with pre-computed vector
                    if hasattr(self._vector_db, "add_page_with_vector") and page_vector:
                        import numpy as np

                        vec = np.array(page_vector, dtype=np.float32)
                        self._vector_db.add_page_with_vector(page_id, vec, vs_meta)
                    else:
                        # Fall back: create minimal XML-like representation for indexing
                        # This ensures backward compatibility
                        self._vector_db.add_page(
                            page_id,
                            f"<page package='{package}' fingerprint='{fingerprint}'/>",
                            vs_meta,
                        )
                except Exception as e:
                    logger.debug(
                        f"Failed to index vector_set {idx_vs} for node {node.id}: {e}"
                    )
            return

        # Priority 2: Use legacy xmls (backward compatibility)
        if node.repr.xmls:
            for idx_xml, xml in enumerate(node.repr.xmls):
                page_id = f"{node.id}#{idx_xml}"
                self._vector_db.add_page(page_id, xml, meta)

    def add_function(self, func: Function) -> None:
        """Add a global composite function."""
        self._utg.functions[func.name] = func
        self._function_lookup[func.name] = func
        self._build_compiler()
        self._matcher.recompute_node_importance()
        logger.info(f"Added new function with id {func.name}.")

    def update_function(self, func: Function) -> None:
        """Update or add a global composite function."""
        self._utg.functions[func.name] = func
        self._function_lookup[func.name] = func
        self._build_compiler()
        self._matcher.recompute_node_importance()
        logger.info(f"Updated function with id {func.name}.")

    def ensure_app_info(
        self,
        package_name: str,
        app_name: str,
        *,
        persist: bool = True,
        rebuild: bool = True,
    ) -> bool:
        if not package_name:
            logger.warning("Cannot ensure app info: package_name is empty")
            return False

        for app_info in self._utg.appInfo:
            if app_info.packageName != package_name:
                continue
            if (
                not app_info.appName or app_info.appName == app_info.packageName
            ) and app_name:
                app_info.appName = app_name
                if persist:
                    self._persist_app_info_cache()
                if rebuild:
                    self._rebuild_compiler_index()
                logger.info(
                    "Updated app info name for package '%s' -> %s",
                    package_name,
                    app_name,
                )
                return True
            logger.info("App info already exists for package '%s'", package_name)
            return False

        self._utg.appInfo.append(
            AppInfo(packageName=package_name, appName=app_name or package_name)
        )
        if persist:
            self._persist_app_info_cache()
        if rebuild:
            self._rebuild_compiler_index()
        logger.info("Added new app info: %s -> %s", package_name, app_name)
        return True

    def ensure_app_info_map(self, app_name_to_package: Dict[str, str]) -> int:
        changed = 0
        for app_name, package_name in (app_name_to_package or {}).items():
            normalized_package = str(package_name or "").strip()
            if not normalized_package:
                continue
            if self.ensure_app_info(
                normalized_package,
                str(app_name or normalized_package),
                persist=False,
                rebuild=False,
            ):
                changed += 1
        if changed > 0:
            self._persist_app_info_cache()
            self._rebuild_compiler_index()
        return changed

    def get_app_info(self, package_name: str):
        for app_info in self._utg.appInfo:
            if app_info.packageName == package_name:
                return app_info
        return None

    def _attach_run_log(
        self,
        *,
        run_id: str,
        function_id: str,
        result: RunFunctionResult,
        duration_ms: float,
        before_stats: Dict[str, Any],
        after_stats: Dict[str, Any],
        port_stats: AgentIOStats,
        runtime_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        control_trace = self._snapshot_control_trace(runtime_context)
        device_actions = None
        main_action_frames = None
        if isinstance(runtime_context, dict):
            raw_device_actions = runtime_context.get("__utg_device_actions__")
            if isinstance(raw_device_actions, list):
                device_actions = [
                    dict(item) for item in raw_device_actions if isinstance(item, dict)
                ]
            raw_main_action_frames = runtime_context.get("__utg_main_action_frames__")
            if isinstance(raw_main_action_frames, list):
                main_action_frames = [
                    dict(item)
                    for item in raw_main_action_frames
                    if isinstance(item, dict)
                ]
        final_state = dict(
            (runtime_context or {}).get("__utg_last_observation__") or {}
        )
        provider_detail = dict(getattr(result, "provider_detail", None) or {})
        provider_detail.update(
            {
                "run_id": run_id,
                "function_id": function_id,
                "control_trace": control_trace,
                "device_actions": device_actions,
                "main_action_frames": main_action_frames,
                "final_state": final_state,
            }
        )
        setattr(result, "control_trace", control_trace)
        setattr(result, "device_actions", device_actions)
        setattr(result, "main_action_frames", main_action_frames)
        setattr(result, "final_state", final_state)
        setattr(result, "provider_detail", provider_detail)
        setattr(
            result,
            "provider_detail_summary",
            {
                "run_id": run_id,
                "function_id": function_id,
                "success": bool(result.success),
                "error_code": result.error_code,
                "error_message": result.error_message,
                "duration_ms": float(duration_ms),
                "stats": self._stats_delta_snapshot(before_stats, after_stats),
                "port": port_stats.to_dict(),
                "action_effect": self._executor.snapshot_last_action_effect_debug(),
                "coordinate_adaptation": self._executor.snapshot_last_coordinate_adaptation_debug(),
                "control_trace": control_trace,
                "device_actions": device_actions,
                "main_action_frames": main_action_frames,
                "final_state": final_state,
            },
        )

    @staticmethod
    def _snapshot_control_trace(
        runtime_context: Optional[Dict[str, Any]],
    ) -> Optional[list[Dict[str, Any]]]:
        if not isinstance(runtime_context, dict):
            return None
        raw = runtime_context.get("__utg_control_trace__")
        if not isinstance(raw, dict):
            return None
        out: list[Dict[str, Any]] = []
        for step_index in sorted(raw.keys(), key=lambda value: int(value)):
            entries = raw.get(step_index)
            if not isinstance(entries, list) or not entries:
                continue
            out.append(
                {
                    "step_index": int(step_index),
                    "controls": [
                        dict(item) for item in entries if isinstance(item, dict)
                    ],
                }
            )
        return out or None

    # ---------- Execute ----------

    def _function_end_node_id(self, function_id: str) -> Optional[str]:
        """Get the end_node_id for a global function (for terminal verification)."""
        func = self._utg.functions.get(function_id)
        if not func:
            return None
        # Check explicit end_node_id on Function model
        explicit_end_node_id = str(getattr(func, "end_node_id", "") or "").strip()
        if explicit_end_node_id:
            return explicit_end_node_id
        # Check metadata for persisted end-node hints
        metadata = getattr(func, "metadata", {}) or {}
        metadata_end_node_id = str(metadata.get("end_node_id") or "").strip()
        if metadata_end_node_id:
            return metadata_end_node_id
        # Infer from last call_function action
        actions = list(getattr(func, "actions", []) or [])
        for action in reversed(actions):
            action_type = str(getattr(action, "type", "") or "").strip()
            if action_type == "call_function":
                params = getattr(action, "params", None)
                if params:
                    node_id = str(getattr(params, "node_id", "") or "").strip()
                    if node_id:
                        return node_id
        return None

    async def verify_terminal_state(
        self,
        observe,
        *,
        function_id: Optional[str] = None,
        function: Optional[Any] = None,
        arguments: Optional[Dict[str, Any]] = None,
        execution_result: Any = None,
        action_type: Optional[str] = None,
        respect_env: bool = True,
        include_app_identity: bool = True,
    ) -> Dict[str, Any]:
        """Delegate terminal verification to the unified control-plane verifier.

        Args:
            observe: Live observe function used for fresh observation.
            function_id: Optional compiled function id.
            function: Optional resolved function object. When set it overrides `function_id`.
            arguments: Parameter values rendered for the current run.
            execution_result: Optional run result carrying last-action metadata.
            action_type: Optional last action type override from runtime context.
            respect_env: Whether env gate should disable the verifier.

        Returns:
            Shared terminal-state payload.
        """
        return await self._control_engine.verify_terminal_state(
            self,
            observe,
            function_id=function_id,
            function=function,
            arguments=arguments,
            execution_result=execution_result,
            action_type=action_type,
            respect_env=respect_env,
            include_app_identity=include_app_identity,
        )

    def _is_current_page_match_node(
        self, current_xml: str, expected_node: UTGNode
    ) -> bool:
        """已废弃，使用 _is_current_page_match_node_from_vector_set() 代替."""
        if not expected_node.repr.xmls:
            return False
        # Fast path: exact XML match against stored snapshots (avoids false negatives when vector DB is cold/empty).
        try:
            cur = (current_xml or "").strip()
            for snap in expected_node.repr.xmls:
                if snap and snap.strip() == cur:
                    self._matcher.last_match_debug = {
                        "search_topk": [],
                        "candidate_scores": [],
                        "selected_node_id": expected_node.id,
                        "selected_score": 1.0,
                        "strategy": "exact_xml",
                    }
                    return True
        except Exception:
            pass
        match = self.match_node(
            xml=current_xml,
            package_name=expected_node.repr.packageName,
        )
        if match is not None and match.id == expected_node.id:
            return True
        return False

    def _is_current_page_match_node_from_vector_set(
        self, vector_set, expected_node: UTGNode
    ) -> bool:
        """Check if current page (as PageVectorSet) matches expected node.

        Args:
            vector_set: Current page as PageVectorSet
            expected_node: Expected UTG node

        Returns:
            True if page matches expected node
        """
        from src.utg.assets.embedding.vector_set import PageVectorSet

        if vector_set is None:
            return False
        if not isinstance(vector_set, PageVectorSet):
            return False

        # Fast path: fingerprint match against stored snapshots
        current_fingerprint = vector_set.fingerprint
        if current_fingerprint and hasattr(expected_node.repr, "fingerprints"):
            for stored_fingerprint in expected_node.repr.fingerprints:
                if stored_fingerprint and stored_fingerprint == current_fingerprint:
                    self._matcher.last_match_debug = {
                        "search_topk": [],
                        "candidate_scores": [],
                        "selected_node_id": expected_node.id,
                        "selected_score": 1.0,
                        "strategy": "exact_fingerprint",
                    }
                    return True

        # Fallback: use vector-based matching
        try:
            match = self._matcher.match_node_from_vector_set(
                vector_set=vector_set,
                package_name=expected_node.repr.packageName,
            )
            if match is not None and match.id == expected_node.id:
                return True
        except AttributeError:
            # matcher doesn't support vector_set yet, fallback to fingerprint-only
            pass

        return False
