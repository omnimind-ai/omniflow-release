"""UTG trigger schema.

Trigger 在这里是 observation-driven reflex dispatch：
- 描述在什么 phase、什么绑定范围下触发
- 描述触发后要执行的 effect

它不是完整 planner，而是 control plane 的即时触发入口。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field

from src.utg.core.actions import AnyAction

if TYPE_CHECKING:
    from src.utg.core.models import UTGGraph, UTGNode


TriggerPhase = Literal[
    "before_step",
    "before_action",
    "execute_action",
    "after_action",
    "terminal",
]


class TriggerScope(BaseModel):
    """Dynamic trigger bindings for the current runtime context."""

    package_names: List[str] = Field(
        default_factory=list,
        description="Only bind when current package is in this allowlist.",
    )
    node_ids: List[str] = Field(
        default_factory=list,
        description="Only bind when current expected/matched node is in this allowlist.",
    )
    function_ids: List[str] = Field(
        default_factory=list,
        description="Only bind when current function is in this allowlist.",
    )
    step_indexes: List[int] = Field(
        default_factory=list,
        description="Only bind on the listed function step indexes.",
    )
    action_types: List[str] = Field(
        default_factory=list,
        description="Only bind when current action type is in this allowlist.",
    )


class AlwaysCondition(BaseModel):
    """Always matches."""

    kind: Literal["always"] = "always"


class NeverCondition(BaseModel):
    """Never matches."""

    kind: Literal["never"] = "never"


class NodeExistsCondition(BaseModel):
    """Match when a referenced XML element exists in the current page snapshot."""

    kind: Literal["node_exists"] = "node_exists"
    node_id: Optional[str] = Field(
        None,
        description="Optional UTG node id; falls back to the current node when empty.",
    )
    xml_selector: str = Field(
        ...,
        description="XPath-like selector used against UTGNode.repr.xmls.",
    )


class XmlMatchCondition(BaseModel):
    """Match the current XML snapshot using simple text and attribute filters."""

    kind: Literal["xml_match"] = "xml_match"
    package_allowlist: List[str] = Field(default_factory=list)
    package_denylist: List[str] = Field(default_factory=list)
    xml_contains_any: List[str] = Field(default_factory=list)
    text_contains_any: List[str] = Field(default_factory=list)
    content_desc_contains_any: List[str] = Field(default_factory=list)
    resource_id_contains_any: List[str] = Field(default_factory=list)


TriggerCondition = Union[
    NodeExistsCondition,
    XmlMatchCondition,
    AlwaysCondition,
    NeverCondition,
]


class RunActionsEffect(BaseModel):
    """Execute concrete device actions."""

    kind: Literal["run_actions"] = "run_actions"
    actions: List[AnyAction] = Field(default_factory=list)


class TriggerActionTemplate(BaseModel):
    """Resolve a device action from the current XML snapshot."""

    kind: Literal[
        "press_back",
        "click_bounds",
        "click_content_desc",
        "click_text",
        "click_resource_id",
    ] = "press_back"
    values: List[str] = Field(default_factory=list)
    bounds: Optional[str] = None
    fallback_kind: Optional[Literal["press_back"]] = None


class DeviceActionEffect(BaseModel):
    """Resolve one device action from the current UI snapshot and execute it."""

    kind: Literal["device_action"] = "device_action"
    action: TriggerActionTemplate = Field(default_factory=TriggerActionTemplate)


class CapabilityEffect(BaseModel):
    """Dispatch to a named control capability."""

    kind: Literal["capability"] = "capability"
    capability_id: str = Field(..., description="Registered control capability id.")
    params: Dict[str, Any] = Field(
        default_factory=dict,
        description="Capability-specific parameters.",
    )


class IgnoreEffect(BaseModel):
    """No-op effect."""

    kind: Literal["ignore"] = "ignore"


TriggerEffect = Union[
    RunActionsEffect,
    DeviceActionEffect,
    CapabilityEffect,
    IgnoreEffect,
]


class TriggerSpec(BaseModel):
    """Single trigger record used by graph/node/path/runtime trigger pools."""

    id: Optional[str] = Field(None, description="Optional trigger id for tracing.")
    description: Optional[str] = Field(
        default=None,
        description="Human-readable summary of the trigger intent.",
    )
    phase: TriggerPhase = Field(
        default="before_step",
        description="Control phase in which the trigger is evaluated.",
    )
    scope: TriggerScope = Field(
        default_factory=TriggerScope,
        description="Dynamic binding filters for package/path/node/action context.",
    )
    condition: TriggerCondition = Field(
        default_factory=AlwaysCondition,
        description="Trigger When: predicate evaluated against the current observation.",
    )
    effect: TriggerEffect = Field(
        default_factory=IgnoreEffect,
        description="Trigger Then: effect dispatched when the condition matches.",
    )
    priority: int = 0
    enabled: bool = True
    source: str = Field(
        default="",
        description="Optional provenance marker such as global/path/node/template.",
    )


Trigger = TriggerSpec


def normalize_trigger(
    trigger: Optional[Trigger | Dict[str, Any]],
) -> Optional[TriggerSpec]:
    """Normalize raw trigger payloads into `TriggerSpec`.

    Args:
        trigger: Trigger object or trigger-like dict.

    Returns:
        `TriggerSpec` when normalization succeeds, otherwise `None`.
    """
    if trigger is None:
        return None
    if isinstance(trigger, TriggerSpec):
        return trigger
    if isinstance(trigger, dict):
        try:
            return TriggerSpec.model_validate(trigger)
        except Exception:
            return None
    return None


def evaluate_node_exists(
    condition: NodeExistsCondition,
    *,
    utg_node: Optional["UTGNode"] = None,
    utg_graph: Optional["UTGGraph"] = None,
    has_xml_node: Optional[Any] = None,
) -> bool:
    """Evaluate `node_exists` against persisted XML snapshots.

    Args:
        condition: `node_exists` condition to evaluate.
        utg_node: Current UTG node when already resolved by the caller.
        utg_graph: Optional graph used to resolve `condition.node_id`.
        has_xml_node: Optional XML selector predicate for the page snapshot.

    Returns:
        `True` when the selector matches at least one stored XML snapshot.
    """
    target_node = utg_node
    target_node_id = str(condition.node_id or "").strip()
    if target_node is None and utg_graph is not None and target_node_id:
        try:
            target_node = utg_graph.find_node_by_id(target_node_id)
        except Exception:
            target_node = None
    if target_node is None:
        return False
    xml_selector = str(condition.xml_selector or "").strip()
    if not xml_selector:
        return False
    checker = has_xml_node
    if checker is None:
        try:
            from src.foundation.source_tools import has_xml_node as default_has_xml_node
        except Exception:
            default_has_xml_node = None
        checker = default_has_xml_node
    if checker is None:
        return False
    for xml_text in list(getattr(getattr(target_node, "repr", None), "xmls", []) or []):
        try:
            if checker(xml_text, xml_selector):
                return True
        except Exception:
            continue
    return False


__all__ = [
    "AlwaysCondition",
    "CapabilityEffect",
    "DeviceActionEffect",
    "IgnoreEffect",
    "NeverCondition",
    "NodeExistsCondition",
    "RunActionsEffect",
    "Trigger",
    "TriggerActionTemplate",
    "TriggerCondition",
    "TriggerEffect",
    "TriggerPhase",
    "TriggerScope",
    "TriggerSpec",
    "XmlMatchCondition",
    "evaluate_node_exists",
    "normalize_trigger",
]
