"""UTG graph operations helpers."""

from __future__ import annotations

from collections import deque
from typing import Dict, List, Optional, Tuple

from src.utg.core.models import UTGGraph


def _build_node_adjacency(utg: UTGGraph) -> Dict[str, List[Tuple[str, str]]]:
    """Build directed adjacency from current UTG global functions.

    Composite functions with `call_function` actions keep their internal hop
    structure. Plain global functions without child calls still contribute one
    direct `start_node_id -> end_node_id` edge so graph features such as
    shortest-path bridging can reuse ordinary function assets.
    """
    adjacency: Dict[str, List[Tuple[str, str]]] = {}
    for func_name, func in (utg.functions or {}).items():
        ordered_nodes: List[str] = []
        for action in getattr(func, "actions", []) or []:
            action_type = str(getattr(action, "type", "")).strip()
            if action_type == "call_function":
                params = getattr(action, "params", None)
                if params:
                    node_id = str(getattr(params, "node_id", "") or "").strip()
                    if node_id:
                        ordered_nodes.append(node_id)
        if len(ordered_nodes) >= 2:
            for index in range(len(ordered_nodes) - 1):
                src = ordered_nodes[index]
                dst = ordered_nodes[index + 1]
                adjacency.setdefault(src, []).append((dst, func_name))
            continue
        start_node_id = str(getattr(func, "start_node_id", "") or "").strip()
        end_node_id = str(getattr(func, "end_node_id", "") or "").strip()
        if start_node_id and end_node_id and start_node_id != end_node_id:
            adjacency.setdefault(start_node_id, []).append((end_node_id, func_name))
    return adjacency


def find_node_distance_bfs(
    utg: UTGGraph, start_node_id: str, end_node_id: str
) -> Optional[int]:
    """Calculate shortest node-to-node distance by BFS over the UI state graph."""
    if not start_node_id or not end_node_id:
        return None
    if start_node_id == end_node_id:
        return 0

    adjacency = _build_node_adjacency(utg)
    queue = deque([(start_node_id, 0)])
    visited = {start_node_id}

    while queue:
        node_id, dist = queue.popleft()
        for next_node, _function_id in adjacency.get(node_id, []):
            if next_node in visited:
                continue
            next_dist = dist + 1
            if next_node == end_node_id:
                return next_dist
            visited.add(next_node)
            queue.append((next_node, next_dist))
    return None


def find_shortest_path_edges(
    utg: UTGGraph, start_node_id: str, end_node_id: str
) -> List[Dict[str, str]]:
    """Find a shortest path between two nodes as edge records."""
    if start_node_id == end_node_id:
        return []

    adjacency = _build_node_adjacency(utg)
    queue = deque([start_node_id])
    visited = {start_node_id}
    prev: Dict[str, Tuple[str, str]] = {}

    while queue:
        node_id = queue.popleft()
        if node_id == end_node_id:
            break
        for next_node, function_id in adjacency.get(node_id, []):
            if next_node in visited:
                continue
            visited.add(next_node)
            prev[next_node] = (node_id, function_id)
            queue.append(next_node)

    if end_node_id not in visited:
        return []

    edges: List[Dict[str, str]] = []
    current = end_node_id
    while current != start_node_id:
        prev_node, function_id = prev[current]
        edges.append(
            {
                "function_id": function_id,
                "from_node": prev_node,
                "to_node": current,
            }
        )
        current = prev_node
    edges.reverse()
    return edges
