"""
UTG Graph Runtime: Function-as-Edge 图结构的运行时实现.

核心思想：
- Node = 页面状态 (UTGNode)
- Edge = Function (start_node_id → end_node_id)
- 加载 UTG 后构建邻接索引，支持 O(1) 查询和图算法
"""

from __future__ import annotations

from dataclasses import dataclass
import heapq
import logging
from typing import Dict, List, Optional, Set, Tuple

from .models import Function, UTGGraph, UTGNode

logger = logging.getLogger(__name__)


@dataclass
class FunctionEdge:
    """Function 作为图的边.

    from_node_id 在构建时确定：
    - Atomic function: 来自 node.functions，起点 = node.id
    - Composite function: 起点 = function.start_node_id
    - Global function: 起点 = None
    """

    function: Function
    from_node_id: Optional[str] = None  # 边的起点（构建时确定）

    @property
    def to_node_id(self) -> Optional[str]:
        """边的终点."""
        return self.function.end_node_id

    @property
    def function_name(self) -> str:
        return self.function.name

    @property
    def cost(self) -> float:
        """边的代价（用于最短路径）."""
        # 默认代价 = action 数量，可扩展
        return float(len(self.function.actions)) if self.function.actions else 1.0

    def __repr__(self) -> str:
        return (
            f"Edge({self.from_node_id} --[{self.function_name}]--> {self.to_node_id})"
        )


@dataclass
class PathResult:
    """路径搜索结果."""

    edges: List[FunctionEdge]
    total_cost: float

    @property
    def node_sequence(self) -> List[str]:
        """节点序列."""
        if not self.edges:
            return []
        nodes = [self.edges[0].from_node_id]
        for edge in self.edges:
            if edge.to_node_id:
                nodes.append(edge.to_node_id)
        return [n for n in nodes if n]  # 过滤 None

    @property
    def function_sequence(self) -> List[str]:
        """Function 名称序列."""
        return [e.function_name for e in self.edges]

    def __repr__(self) -> str:
        path_str = " -> ".join(self.function_sequence)
        return f"Path({path_str}, cost={self.total_cost:.1f})"


class UTGGraphRuntime:
    """UTG 图的运行时结构.

    从 UTGGraph 加载后构建邻接索引，支持：
    1. O(1) 查询节点的出边/入边
    2. 最短路径算法
    3. 可达性分析

    Example:
        >>> graph = UTGGraph.load_model_from_json_file("app.utg.json")
        >>> runtime = UTGGraphRuntime.from_utg_graph(graph)
        >>>
        >>> # 查询从 home 可执行的 functions
        >>> edges = runtime.get_outgoing_edges("home")
        >>>
        >>> # 找到从 home 到 settings 的最短路径
        >>> path = runtime.shortest_path("home", "settings")
    """

    def __init__(self, graph: UTGGraph):
        self.graph = graph

        # 节点索引
        self._nodes: Dict[str, UTGNode] = {}

        # 所有边（FunctionEdge 列表）
        self._edges: List[FunctionEdge] = []

        # 邻接索引
        self._outgoing: Dict[str, List[FunctionEdge]] = {}  # node_id -> 出边
        self._incoming: Dict[str, List[FunctionEdge]] = {}  # node_id -> 入边

        # 全局边（from_node_id=None，任意节点可执行）
        self._global_edges: List[FunctionEdge] = []

        # 构建索引
        self._build_index()

    @classmethod
    def from_utg_graph(cls, graph: UTGGraph) -> "UTGGraphRuntime":
        """从 UTGGraph 创建运行时结构."""
        return cls(graph)

    @classmethod
    def from_json_file(cls, file_path: str) -> "UTGGraphRuntime":
        """从 JSON 文件加载."""
        graph = UTGGraph.load_model_from_json_file(file_path)
        return cls(graph)

    def _build_index(self) -> None:
        """构建邻接索引."""
        # 1. 索引节点
        for node in self.graph.nodes:
            self._nodes[node.id] = node
            self._outgoing[node.id] = []
            self._incoming[node.id] = []

        # 2. 处理节点级 Functions (atomic)
        #    起点 = 所属节点 (node.id)
        for node in self.graph.nodes:
            for func_name, func in node.functions.items():
                # atomic function 的起点是它所属的 node
                # 如果 function 有显式 start_node_id，优先使用
                from_id = func.start_node_id if func.start_node_id else node.id
                edge = FunctionEdge(function=func, from_node_id=from_id)
                self._edges.append(edge)
                self._add_edge_to_index(edge)

        # 3. 处理全局 Functions (composite)
        #    起点 = function.start_node_id（可能为 None = 全局）
        for func_name, func in (self.graph.functions or {}).items():
            from_id = func.start_node_id if func.start_node_id else None
            edge = FunctionEdge(function=func, from_node_id=from_id)
            self._edges.append(edge)
            self._add_edge_to_index(edge)

        logger.info(
            f"Built graph index: {len(self._nodes)} nodes, "
            f"{len(self._edges)} edges, {len(self._global_edges)} global"
        )

    def _add_edge_to_index(self, edge: FunctionEdge) -> None:
        """将边添加到索引."""
        from_id = edge.from_node_id
        to_id = edge.to_node_id

        if from_id is None:
            # 全局边，任意节点可执行
            self._global_edges.append(edge)
        else:
            # 局部边
            if from_id not in self._outgoing:
                self._outgoing[from_id] = []
            self._outgoing[from_id].append(edge)

        if to_id is not None:
            if to_id not in self._incoming:
                self._incoming[to_id] = []
            self._incoming[to_id].append(edge)

    # ========== 节点操作 ==========

    def get_node(self, node_id: str) -> Optional[UTGNode]:
        """获取节点."""
        return self._nodes.get(node_id)

    def get_all_node_ids(self) -> List[str]:
        """获取所有节点 ID."""
        return list(self._nodes.keys())

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        return len(self._edges)

    # ========== 边操作 ==========

    def get_outgoing_edges(
        self, node_id: str, include_global: bool = True
    ) -> List[FunctionEdge]:
        """获取从节点出发的所有边.

        Args:
            node_id: 节点 ID
            include_global: 是否包含全局边

        Returns:
            FunctionEdge 列表
        """
        edges = list(self._outgoing.get(node_id, []))
        if include_global:
            edges.extend(self._global_edges)
        return edges

    def get_incoming_edges(self, node_id: str) -> List[FunctionEdge]:
        """获取到达节点的所有边."""
        return list(self._incoming.get(node_id, []))

    def get_edge_by_function_name(
        self, node_id: str, function_name: str
    ) -> Optional[FunctionEdge]:
        """根据 Function 名称获取边."""
        for edge in self.get_outgoing_edges(node_id):
            if edge.function_name == function_name:
                return edge
        return None

    def get_all_edges(self) -> List[FunctionEdge]:
        """获取所有边."""
        return list(self._edges)

    # ========== 图算法 ==========

    def shortest_path(
        self, from_node_id: str, to_node_id: str, max_depth: int = 20
    ) -> Optional[PathResult]:
        """Dijkstra 最短路径算法.

        Args:
            from_node_id: 起始节点
            to_node_id: 目标节点
            max_depth: 最大搜索深度

        Returns:
            PathResult 或 None（无路径）
        """
        if from_node_id == to_node_id:
            return PathResult(edges=[], total_cost=0.0)

        if from_node_id not in self._nodes or to_node_id not in self._nodes:
            return None

        # Dijkstra: (cost, node_id, path)
        heap: List[Tuple[float, str, List[FunctionEdge]]] = [(0.0, from_node_id, [])]
        visited: Set[str] = set()

        while heap:
            cost, current, path = heapq.heappop(heap)

            if current in visited:
                continue
            visited.add(current)

            if current == to_node_id:
                return PathResult(edges=path, total_cost=cost)

            if len(path) >= max_depth:
                continue

            for edge in self.get_outgoing_edges(current, include_global=False):
                next_node = edge.to_node_id
                if next_node and next_node not in visited:
                    new_cost = cost + edge.cost
                    new_path = path + [edge]
                    heapq.heappush(heap, (new_cost, next_node, new_path))

        return None  # 无路径

    def all_paths(
        self,
        from_node_id: str,
        to_node_id: str,
        max_depth: int = 10,
        max_paths: int = 100,
    ) -> List[PathResult]:
        """找到所有路径（DFS）.

        Args:
            from_node_id: 起始节点
            to_node_id: 目标节点
            max_depth: 最大深度
            max_paths: 最大路径数

        Returns:
            PathResult 列表，按代价排序
        """
        if from_node_id not in self._nodes or to_node_id not in self._nodes:
            return []

        results: List[PathResult] = []

        def dfs(current: str, path: List[FunctionEdge], cost: float, visited: Set[str]):
            if len(results) >= max_paths:
                return

            if current == to_node_id:
                results.append(PathResult(edges=list(path), total_cost=cost))
                return

            if len(path) >= max_depth:
                return

            for edge in self.get_outgoing_edges(current, include_global=False):
                next_node = edge.to_node_id
                if next_node and next_node not in visited:
                    visited.add(next_node)
                    path.append(edge)
                    dfs(next_node, path, cost + edge.cost, visited)
                    path.pop()
                    visited.remove(next_node)

        dfs(from_node_id, [], 0.0, {from_node_id})
        results.sort(key=lambda r: r.total_cost)
        return results

    def reachable_nodes(self, from_node_id: str, max_depth: int = 10) -> Dict[str, int]:
        """从节点可达的所有节点（BFS）.

        Returns:
            {node_id: distance} 字典
        """
        if from_node_id not in self._nodes:
            return {}

        distances: Dict[str, int] = {from_node_id: 0}
        queue = [(from_node_id, 0)]

        while queue:
            current, depth = queue.pop(0)

            if depth >= max_depth:
                continue

            for edge in self.get_outgoing_edges(current, include_global=False):
                next_node = edge.to_node_id
                if next_node and next_node not in distances:
                    distances[next_node] = depth + 1
                    queue.append((next_node, depth + 1))

        return distances

    def is_reachable(self, from_node_id: str, to_node_id: str) -> bool:
        """检查节点是否可达."""
        return to_node_id in self.reachable_nodes(from_node_id)

    # ========== 图统计 ==========

    def get_statistics(self) -> Dict:
        """获取图统计信息."""
        out_degrees = [len(self._outgoing.get(n, [])) for n in self._nodes]
        in_degrees = [len(self._incoming.get(n, [])) for n in self._nodes]

        # 找到没有 end_node_id 的边
        incomplete_edges = [e for e in self._edges if e.to_node_id is None]

        return {
            "node_count": len(self._nodes),
            "edge_count": len(self._edges),
            "global_edge_count": len(self._global_edges),
            "avg_out_degree": sum(out_degrees) / len(out_degrees) if out_degrees else 0,
            "avg_in_degree": sum(in_degrees) / len(in_degrees) if in_degrees else 0,
            "max_out_degree": max(out_degrees) if out_degrees else 0,
            "max_in_degree": max(in_degrees) if in_degrees else 0,
            "incomplete_edges": len(incomplete_edges),  # 缺少 end_node_id
        }

    def validate(self) -> List[str]:
        """验证图结构，返回问题列表."""
        issues = []

        # 检查边的端点是否存在
        for edge in self._edges:
            if edge.from_node_id and edge.from_node_id not in self._nodes:
                issues.append(
                    f"Edge {edge.function_name}: from_node_id '{edge.from_node_id}' not found"
                )
            if edge.to_node_id and edge.to_node_id not in self._nodes:
                issues.append(
                    f"Edge {edge.function_name}: to_node_id '{edge.to_node_id}' not found"
                )

        # 检查孤立节点
        for node_id in self._nodes:
            out_edges = self._outgoing.get(node_id, [])
            in_edges = self._incoming.get(node_id, [])
            if not out_edges and not in_edges:
                issues.append(f"Node '{node_id}' is isolated (no edges)")

        # 检查缺少 end_node_id 的边
        for edge in self._edges:
            if edge.to_node_id is None:
                issues.append(f"Edge {edge.function_name}: missing end_node_id")

        return issues

    # ========== 导出 ==========

    def export_dot(self, highlight_path: Optional[PathResult] = None) -> str:
        """导出 Graphviz DOT 格式.

        Args:
            highlight_path: 高亮显示的路径

        Returns:
            DOT 格式字符串
        """
        lines = [
            "digraph UTG {",
            "  rankdir=LR;",
            "  node [shape=box, style=rounded];",
        ]

        # 高亮路径的边
        highlight_edges = set()
        if highlight_path:
            for edge in highlight_path.edges:
                key = (edge.from_node_id, edge.to_node_id, edge.function_name)
                highlight_edges.add(key)

        # 节点
        for node_id in self._nodes:
            node = self._nodes[node_id]
            label = node_id
            if node.repr.description:
                label = f"{node_id}\\n{node.repr.description}"
            lines.append(f'  "{node_id}" [label="{label}"];')

        # 边
        for edge in self._edges:
            if edge.from_node_id and edge.to_node_id:
                key = (edge.from_node_id, edge.to_node_id, edge.function_name)
                style = ""
                if key in highlight_edges:
                    style = ", color=red, penwidth=2"
                lines.append(
                    f'  "{edge.from_node_id}" -> "{edge.to_node_id}" '
                    f'[label="{edge.function_name}"{style}];'
                )

        # 全局边（用虚线）
        for edge in self._global_edges:
            if edge.to_node_id:
                lines.append(
                    f'  "global" -> "{edge.to_node_id}" '
                    f'[label="{edge.function_name}", style=dashed];'
                )

        lines.append("}")
        return "\n".join(lines)

    def export_mermaid(self, highlight_path: Optional[PathResult] = None) -> str:
        """导出 Mermaid 格式（支持 Markdown 渲染）.

        Args:
            highlight_path: 高亮显示的路径

        Returns:
            Mermaid 格式字符串
        """
        lines = ["graph LR"]

        highlight_edges = set()
        if highlight_path:
            for edge in highlight_path.edges:
                key = (edge.from_node_id, edge.to_node_id)
                highlight_edges.add(key)

        # 边
        for edge in self._edges:
            if edge.from_node_id and edge.to_node_id:
                key = (edge.from_node_id, edge.to_node_id)
                arrow = "-->" if key not in highlight_edges else "==>"
                lines.append(
                    f"  {edge.from_node_id}{arrow}|{edge.function_name}|{edge.to_node_id}"
                )

        # 全局边
        for edge in self._global_edges:
            if edge.to_node_id:
                lines.append(f"  global-.->|{edge.function_name}|{edge.to_node_id}")

        return "\n".join(lines)

    def export_json(self) -> Dict:
        """导出 JSON 格式（用于前端可视化）.

        Returns:
            {nodes: [...], edges: [...]} 格式
        """
        nodes = []
        for node_id, node in self._nodes.items():
            nodes.append(
                {
                    "id": node_id,
                    "label": node_id,
                    "description": node.repr.description,
                    "package": node.repr.packageName,
                    "function_count": len(node.functions),
                }
            )

        edges = []
        for edge in self._edges:
            if edge.from_node_id and edge.to_node_id:
                edges.append(
                    {
                        "from": edge.from_node_id,
                        "to": edge.to_node_id,
                        "label": edge.function_name,
                        "cost": edge.cost,
                    }
                )

        # 全局边
        for edge in self._global_edges:
            if edge.to_node_id:
                edges.append(
                    {
                        "from": None,  # 全局
                        "to": edge.to_node_id,
                        "label": edge.function_name,
                        "cost": edge.cost,
                        "global": True,
                    }
                )

        return {
            "nodes": nodes,
            "edges": edges,
            "statistics": self.get_statistics(),
        }

    def save_dot(
        self, file_path: str, highlight_path: Optional[PathResult] = None
    ) -> None:
        """保存 DOT 文件."""
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(self.export_dot(highlight_path))

    def save_svg(
        self, file_path: str, highlight_path: Optional[PathResult] = None
    ) -> None:
        """保存 SVG 文件（需要安装 graphviz）."""
        import subprocess
        import tempfile

        dot_content = self.export_dot(highlight_path)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".dot", delete=False) as f:
            f.write(dot_content)
            dot_file = f.name

        try:
            subprocess.run(
                ["dot", "-Tsvg", dot_file, "-o", file_path],
                check=True,
                capture_output=True,
            )
        except FileNotFoundError:
            raise RuntimeError("graphviz not installed. Run: brew install graphviz")


# ========== 便捷函数 ==========


def build_graph_runtime(graph: UTGGraph) -> UTGGraphRuntime:
    """从 UTGGraph 构建运行时图结构."""
    return UTGGraphRuntime.from_utg_graph(graph)


__all__ = [
    "UTGGraphRuntime",
    "FunctionEdge",
    "PathResult",
    "build_graph_runtime",
]
