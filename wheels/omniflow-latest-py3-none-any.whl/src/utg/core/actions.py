from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Literal, Optional, Union, get_args

from pydantic import BaseModel, Field

UTG_ACTION_SCHEMA_VERSION = "1.0.0"
UTG_TOOL_CALL_SCHEMA_VERSION = "1.0.0"


class ScrollDirection(str, Enum):
    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"


class DeviceKey(str, Enum):
    HOME = "home"
    BACK = "back"
    ENTER = "enter"


CANONICAL_DEVICE_ACTION_TYPES = (
    "click",
    "click_node",
    "long_press",
    "input_text",
    "swipe",
    "open_app",
    "press_key",
    "wait",
    "external_tool",
    "finished",
    "call_function",
)

CANONICAL_TOOL_CALL_NAMES = (
    # Base action tool names
    "click",
    "go_to_node",
    "long_press",
    "input_text",
    "swipe",
    "open_app",
    "press_key",
    "wait",
    "finished",
)

TOOL_CALL_CATALOG: Dict[str, Dict[str, Any]] = {
    "click": {
        "description": "Click at screen coordinates",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "Screen X coordinate"},
                "y": {"type": "integer", "description": "Screen Y coordinate"},
                "clickPrompt": {
                    "type": "string",
                    "description": "Optional description of the target element",
                },
            },
            "required": ["x", "y"],
        },
        "aliases": (),
    },
    "go_to_node": {
        "description": "Navigate to a target UI state/node in the UTG graph",
        "parameters": {
            "type": "object",
            "properties": {
                "node_id": {
                    "type": "string",
                    "description": "Target UI node ID from UTG graph",
                },
            },
            "required": ["node_id"],
        },
        "aliases": ("click_node", "node_click"),
    },
    "long_press": {
        "description": "Long press at screen coordinates",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "Screen X coordinate"},
                "y": {"type": "integer", "description": "Screen Y coordinate"},
            },
            "required": ["x", "y"],
        },
        "aliases": (),
    },
    "input_text": {
        "description": "Input text into the current focused field",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to input"},
            },
            "required": ["text"],
        },
        "aliases": (),
    },
    "swipe": {
        "description": "Swipe in a direction",
        "parameters": {
            "type": "object",
            "properties": {
                "direction": {
                    "type": "string",
                    "enum": ["up", "down", "left", "right"],
                    "description": "Swipe direction",
                },
            },
            "required": ["direction"],
        },
        "aliases": (),
    },
    "open_app": {
        "description": "Open an app by package name",
        "parameters": {
            "type": "object",
            "properties": {
                "package_name": {
                    "type": "string",
                    "description": "App package name to open",
                },
            },
            "required": ["package_name"],
        },
        "aliases": (),
    },
    "press_key": {
        "description": "Press a device key",
        "parameters": {
            "type": "object",
            "properties": {
                "key": {
                    "type": "string",
                    "enum": ["back", "home", "enter"],
                    "description": "Device key to press",
                },
            },
            "required": ["key"],
        },
        "aliases": (),
    },
    "wait": {
        "description": "Wait for a specified duration",
        "parameters": {
            "type": "object",
            "properties": {
                "time_s": {
                    "type": "number",
                    "description": "Wait duration in seconds",
                },
            },
            "required": ["time_s"],
        },
        "aliases": (),
    },
    "finished": {
        "description": "Mark the task as completed",
        "parameters": {
            "type": "object",
            "properties": {},
        },
        "aliases": (),
    },
}


# OpenAI-compatible tool schemas - one tool per action type
def build_tool_schemas() -> list[Dict[str, Any]]:
    """Build OpenAI-compatible base tool schemas from TOOL_CALL_CATALOG.

    Returns:
        List of base tool schemas (click, go_to_node, input_text, swipe, etc.)
    """
    tools = []
    for tool_name in [
        "click",
        "go_to_node",
        "long_press",
        "input_text",
        "swipe",
        "open_app",
        "press_key",
        "wait",
        "finished",
    ]:
        if tool_name in TOOL_CALL_CATALOG:
            tool_def = TOOL_CALL_CATALOG[tool_name]
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "description": tool_def["description"],
                        "parameters": tool_def["parameters"],
                    },
                }
            )
    return tools


def extract_function_parameters(function: Any) -> Dict[str, Any]:
    """Extract parameter schema from a Function object.

    Args:
        function: UTG Function object

    Returns:
        Parameter schema dict with properties and required fields.
    """
    import re

    # Check if function has explicit parameters field
    if hasattr(function, "parameters") and function.parameters:
        return function.parameters

    # Fallback: scan actions for ${param} references
    param_names = set()
    actions = getattr(function, "actions", [])

    for action in actions:
        # Convert action to string and scan for ${...} patterns
        action_str = str(action)
        matches = re.findall(r"\$\{(\w+)\}", action_str)
        param_names.update(matches)

    # Build simple schema
    if param_names:
        return {
            "properties": {
                name: {"type": "string", "description": f"Parameter: {name}"}
                for name in sorted(param_names)
            },
            "required": list(sorted(param_names)),
        }

    # No parameters found
    return {"properties": {}, "required": []}


def build_function_tool(function: Any) -> Dict[str, Any]:
    """Convert a Function object to an OpenAI tool definition.

    Args:
        function: UTG Function object

    Returns:
        OpenAI tool schema for the function.
    """
    params_schema = extract_function_parameters(function)
    function_name = str(getattr(function, "name", "") or getattr(function, "id", ""))
    description = str(
        getattr(function, "description", "") or f"Execute function {function_name}"
    )

    return {
        "type": "function",
        "function": {
            "name": function_name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": params_schema.get("properties", {}),
                "required": params_schema.get("required", []),
            },
        },
    }


def build_dynamic_tool_set(
    base_tools: list[Dict[str, Any]],
    functions: list[Any],
) -> list[Dict[str, Any]]:
    """Build dynamic tool set = base tools + function tools.

    Args:
        base_tools: Base action tools (click, input_text, etc.)
        functions: List of Function objects to add as tools

    Returns:
        Combined tool list.
    """
    all_tools = list(base_tools)

    for func in functions:
        try:
            tool = build_function_tool(func)
            all_tools.append(tool)
        except Exception:
            # Skip functions that fail to convert
            pass

    return all_tools


# Pre-built base tool schemas for convenience
EXECUTE_TOOL_SCHEMAS = build_tool_schemas()


class ClickAction(BaseModel):
    type: Literal["click"]
    params: Dict[Literal["x", "y", "clickPrompt", "xml_ref"], Any]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class ClickNodeAction(BaseModel):
    type: Literal["click_node"]
    params: Dict[Literal["node_id"], str]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class LongPressAction(BaseModel):
    type: Literal["long_press"]
    params: Dict[Literal["x", "y", "xml_ref"], Any]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class TypeAction(BaseModel):
    type: Literal["type"]
    params: Dict[Literal["text"], str]
    description: Optional[str] = Field(
        default=None, description="Legacy alias of input_text kept only for parsing."
    )


class InputTextAction(BaseModel):
    type: Literal["input_text"]
    params: Dict[Literal["text"], str]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class ScrollActionParams(BaseModel):
    x: int
    y: int
    direction: ScrollDirection
    distance: int
    xml_ref: Optional[str] = None


class ScrollAction(BaseModel):
    type: Literal["scroll"]
    params: ScrollActionParams
    description: Optional[str] = Field(
        default=None, description="Legacy alias of swipe kept only for parsing."
    )


class SwipeActionParams(BaseModel):
    x: int
    y: int
    direction: ScrollDirection
    distance: int
    xml_ref: Optional[str] = None


class SwipeAction(BaseModel):
    type: Literal["swipe"]
    params: SwipeActionParams
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class OpenAppAction(BaseModel):
    type: Literal["open_app"]
    params: Dict[Literal["package_name"], str]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class PressHomeAction(BaseModel):
    type: Literal["press_home"]
    params: Dict[str, Any] = Field(default_factory=dict)
    description: Optional[str] = Field(
        default=None,
        description="Legacy alias of press_key(home) kept only for parsing.",
    )


class PressBackAction(BaseModel):
    type: Literal["press_back"]
    params: Dict[str, Any] = Field(default_factory=dict)
    description: Optional[str] = Field(
        default=None,
        description="Legacy alias of press_key(back) kept only for parsing.",
    )


class PressKeyAction(BaseModel):
    type: Literal["press_key"]
    params: Dict[Literal["key"], DeviceKey | str]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class WaitAction(BaseModel):
    type: Literal["wait"]
    params: Dict[Literal["time_s"], float]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class ExternalToolAction(BaseModel):
    type: Literal["external_tool"]
    params: Dict[Literal["tool_name", "arguments"], Any]
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class FinishedAction(BaseModel):
    type: Literal["finished"]
    params: Dict[Literal["content", "enable_summary", "summary_prompt"], Any] = Field(
        default_factory=dict
    )
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class CallFunctionParams(BaseModel):
    """Parameters for calling a function on a target node."""

    node_id: str = Field(..., description="Target node ID")
    function_name: str = Field(..., description="Function name to call")
    arguments: Dict[str, str] = Field(
        default_factory=dict,
        description="Arguments to pass, supports ${param} reference",
    )


class CallFunctionAction(BaseModel):
    """Action to call another function, enabling programmatic composition."""

    type: Literal["call_function"] = "call_function"
    params: CallFunctionParams
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


class UnknownAction(BaseModel):
    type: str = Field(..., description="Unknown or placeholder action type")
    params: Dict[str, Any] = Field(default_factory=dict)
    description: Optional[str] = Field(
        default=None, description="Optional human-readable description for this action."
    )


AnyAction = Union[
    ClickAction,
    ClickNodeAction,
    LongPressAction,
    TypeAction,
    InputTextAction,
    ScrollAction,
    SwipeAction,
    OpenAppAction,
    PressHomeAction,
    PressBackAction,
    PressKeyAction,
    WaitAction,
    ExternalToolAction,
    FinishedAction,
    CallFunctionAction,
    UnknownAction,
]


ACTION_CATALOG: Dict[str, Dict[str, Any]] = {
    "click": {
        "description": "Tap at screen coordinates.",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "clickPrompt": {"type": "string"},
                "xml_ref": {"type": "string"},
            },
            "required": ["x", "y"],
        },
        "required_capabilities": ("click",),
        "aliases": ("tap",),
        "recordable": True,
    },
    "click_node": {
        "description": "Tap a UI node by id.",
        "parameters": {
            "type": "object",
            "properties": {"node_id": {"type": "string"}},
            "required": ["node_id"],
        },
        "required_capabilities": ("click_node",),
        "aliases": ("node_click",),
        "recordable": True,
    },
    "long_press": {
        "description": "Long press at screen coordinates.",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "xml_ref": {"type": "string"},
            },
            "required": ["x", "y"],
        },
        "required_capabilities": ("long_press",),
        "aliases": ("longpress",),
        "recordable": True,
    },
    "input_text": {
        "description": "Type text into the focused input.",
        "parameters": {
            "type": "object",
            "properties": {"text": {"type": "string"}},
            "required": ["text"],
        },
        "required_capabilities": ("input_text",),
        "aliases": ("type", "input", "text"),
        "recordable": True,
    },
    "swipe": {
        "description": "Swipe from a point in one direction.",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "direction": {
                    "type": "string",
                    "enum": [direction.value for direction in ScrollDirection],
                },
                "distance": {"type": "number"},
                "xml_ref": {"type": "string"},
            },
            "required": ["x", "y", "direction", "distance"],
        },
        "required_capabilities": ("swipe",),
        "aliases": ("scroll",),
        "recordable": True,
    },
    "open_app": {
        "description": "Launch an app by package name.",
        "parameters": {
            "type": "object",
            "properties": {"package_name": {"type": "string"}},
            "required": ["package_name"],
        },
        "required_capabilities": ("open_app",),
        "aliases": ("openapp",),
        "recordable": True,
    },
    "press_key": {
        "description": "Press a device key.",
        "parameters": {
            "type": "object",
            "properties": {
                "key": {
                    "type": "string",
                    "enum": [key.value for key in DeviceKey],
                }
            },
            "required": ["key"],
        },
        "required_capabilities": ("press_key",),
        "aliases": ("press_home", "press_back", "home", "back", "enter"),
        "recordable": True,
    },
    "wait": {
        "description": "Wait for a number of seconds.",
        "parameters": {
            "type": "object",
            "properties": {"time_s": {"type": "number"}},
            "required": ["time_s"],
        },
        "required_capabilities": ("wait",),
        "aliases": ("sleep",),
        "recordable": True,
    },
    "external_tool": {
        "description": "Call one non-device external tool.",
        "parameters": {
            "type": "object",
            "properties": {
                "tool_name": {"type": "string"},
                "arguments": {"type": "object"},
            },
            "required": ["tool_name"],
        },
        "required_capabilities": (),
        "aliases": ("call_tool", "tool_call"),
        "recordable": False,
    },
    "finished": {
        "description": "Finish the task successfully.",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string"},
                "enable_summary": {"type": "boolean"},
                "summary_prompt": {"type": "string"},
            },
        },
        "required_capabilities": (),
        "aliases": ("finish", "done"),
        "recordable": True,
    },
    "call_function": {
        "description": "Call another function on a target node.",
        "parameters": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "function_name": {"type": "string"},
                "arguments": {"type": "object"},
            },
            "required": ["node_id", "function_name"],
        },
        "required_capabilities": (),
        "aliases": (),
        "recordable": False,
    },
}

ACTION_ALIAS_MAP: Dict[str, str] = {}
for _canonical_name, _meta in ACTION_CATALOG.items():
    ACTION_ALIAS_MAP[_canonical_name] = _canonical_name
    for _alias in tuple(_meta.get("aliases") or ()):
        ACTION_ALIAS_MAP[str(_alias).strip().lower()] = _canonical_name

TOOL_CALL_ALIAS_MAP: Dict[str, str] = {}
for _canonical_name, _meta in TOOL_CALL_CATALOG.items():
    TOOL_CALL_ALIAS_MAP[_canonical_name] = _canonical_name
    for _alias in tuple(_meta.get("aliases") or ()):
        TOOL_CALL_ALIAS_MAP[str(_alias).strip().lower()] = _canonical_name


def _as_plain_dict(value: Any) -> Dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "model_dump"):
        return dict(value.model_dump(exclude_none=True))
    return dict(value)


def _drop_none(mapping: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in mapping.items() if value is not None}


def action_type_name(action_or_type: Any) -> str:
    if isinstance(action_or_type, str):
        raw = action_or_type
    else:
        raw = getattr(action_or_type, "type", action_or_type)
    return str(raw or "").strip().lower()


def resolve_action_alias(name: str) -> str:
    key = action_type_name(name)
    return ACTION_ALIAS_MAP.get(key, key)


def canonical_action_type(action_or_type: Any) -> str:
    return resolve_action_alias(action_type_name(action_or_type))


def tool_call_name(tool_call_or_name: Any) -> str:
    """Return one normalized tool-call name string from a raw payload or name."""

    if isinstance(tool_call_or_name, str):
        raw = tool_call_or_name
    elif isinstance(tool_call_or_name, dict):
        raw = (
            tool_call_or_name.get("tool_name")
            or tool_call_or_name.get("tool")
            or tool_call_or_name.get("name")
            or ""
        )
    else:
        raw = getattr(tool_call_or_name, "tool_name", "") or getattr(
            tool_call_or_name, "name", ""
        )
    return str(raw or "").strip().lower()


def resolve_tool_call_alias(name: str) -> str:
    """Map one raw tool-call name to its canonical tool name."""

    key = tool_call_name(name)
    return TOOL_CALL_ALIAS_MAP.get(key, key)


def canonical_tool_call_name(tool_call_or_name: Any) -> str:
    """Return the canonical tool-call name used inside UTG ingestion."""

    return resolve_tool_call_alias(tool_call_name(tool_call_or_name))


def list_action_names(*, recordable_only: bool = True) -> tuple[str, ...]:
    names = []
    for name, meta in ACTION_CATALOG.items():
        if recordable_only and not bool(meta.get("recordable", True)):
            continue
        names.append(name)
    return tuple(names)


def list_tool_call_names() -> tuple[str, ...]:
    """Return the canonical high-level tool calls recognized by UTG."""

    return tuple(CANONICAL_TOOL_CALL_NAMES)


def action_params_of(action: Any) -> Dict[str, Any]:
    params = getattr(action, "params", None)
    if isinstance(action, dict):
        params = action.get("params", params)
    return _as_plain_dict(params)


def canonical_action_payload(
    action: Any,
    *,
    fallback_external_tool: bool = False,
) -> Dict[str, Any] | None:
    """Normalize one action-like payload into canonical `type/params` form.

    Args:
        action: Raw action dict/model/object that should describe one UTG action.
        fallback_external_tool: When `True`, unsupported host/private payloads are
            wrapped into canonical `external_tool` instead of being dropped.

    Returns:
        Canonical JSON-safe action dict, or `None` when the payload cannot be
        parsed into one recognized action schema. `finished` is intentionally
        filtered because it is a terminal decision rather than a device action.
    """

    if action is None:
        return None
    serialized = action if isinstance(action, dict) else None
    if serialized is None and hasattr(action, "model_dump"):
        serialized = action.model_dump(exclude_none=True)
    if serialized is None:
        serialized = {
            "type": getattr(action, "type", None),
            "params": action_params_of(action),
            "description": getattr(action, "description", None),
        }
    if not isinstance(serialized, dict):
        return None
    try:
        parsed = parse_action_payload(serialized)
    except Exception:
        if not fallback_external_tool:
            action_type = str(serialized.get("type") or "").strip()
            return dict(serialized) if action_type else None
        raw_tool_name = (
            str(serialized.get("type") or "host_action").strip() or "host_action"
        )
        return {
            "type": "external_tool",
            "params": {
                "tool_name": raw_tool_name,
                "arguments": {"raw_action": dict(serialized)},
            },
        }
    payload = (
        parsed.model_dump()
        if hasattr(parsed, "model_dump")
        else dict(parsed)
        if isinstance(parsed, dict)
        else None
    )
    if not isinstance(payload, dict):
        return None
    if str(payload.get("type") or "").strip() == "finished":
        return None
    if fallback_external_tool and str(payload.get("type") or "").strip() == "unknown":
        raw_tool_name = (
            str(serialized.get("type") or "host_action").strip() or "host_action"
        )
        return {
            "type": "external_tool",
            "params": {
                "tool_name": raw_tool_name,
                "arguments": {"raw_action": dict(serialized)},
            },
        }
    return dict(payload) if str(payload.get("type") or "").strip() else None


def extract_executed_actions_from_detail(
    detail: Dict[str, Any],
) -> list[Dict[str, Any]]:
    """Extract executed device actions from provider detail using one shared priority.

    Args:
        detail: Provider-specific execution detail attached to one canonical step.

    Returns:
        Ordered canonical actions actually executed on device. The priority is:
        host/native `executed_actions` -> `main_action_frames` -> UTG `device_actions`.
    """

    out: list[Dict[str, Any]] = []
    raw_host_actions = list(detail.get("executed_actions") or [])
    for item in raw_host_actions:
        if not isinstance(item, dict):
            continue
        payload = canonical_action_payload(
            item.get("executed_action")
            or item.get("formal_action")
            or item.get("action")
        )
        if payload is not None:
            out.append(payload)
    if out:
        return out

    raw_frames = list(detail.get("main_action_frames") or [])
    for item in raw_frames:
        if not isinstance(item, dict):
            continue
        payload = canonical_action_payload(
            item.get("executed_action") or item.get("action")
        )
        if payload is not None:
            out.append(payload)
    if out:
        return out

    raw_device_actions = list(detail.get("device_actions") or [])
    for item in raw_device_actions:
        if not isinstance(item, dict):
            continue
        if str(item.get("kind") or "").strip() != "act":
            continue
        if str(item.get("controller_id") or "").strip() not in {"", "main_action"}:
            continue
        payload = canonical_action_payload(item.get("action"))
        if payload is not None:
            out.append(payload)
    return out


def _normalize_action_params_for_schema(
    action_type: str,
    params: Dict[str, Any],
) -> Dict[str, Any]:
    """Filter raw action params against the canonical action schema.

    Args:
        action_type: Canonical action name after alias resolution.
        params: Raw params dictionary from one host/device/tool payload.

    Returns:
        Params dictionary containing only keys accepted by the canonical action
        schema, with a few stable alias rewrites such as `xmlRef -> xml_ref`.
    """

    if not isinstance(params, dict):
        return {}
    schema = dict(ACTION_CATALOG.get(action_type, {}) or {})
    properties = dict(schema.get("parameters", {}).get("properties", {}) or {})
    if not properties:
        return dict(params)
    allowed = {str(key).strip() for key in properties.keys() if str(key).strip()}
    key_aliases = {
        "xmlRef": "xml_ref",
        "packageName": "package_name",
        "click_prompt": "clickPrompt",
        "target_description": "clickPrompt",  # OOB VLM task uses target_description
    }
    normalized: Dict[str, Any] = {}
    for raw_key, value in params.items():
        key = key_aliases.get(str(raw_key), str(raw_key))
        if key in allowed:
            normalized[key] = value
    return normalized


def device_key_value(value: Any) -> str:
    if isinstance(value, DeviceKey):
        return value.value
    enum_value = getattr(value, "value", None)
    if isinstance(enum_value, str) and enum_value.strip():
        return enum_value.strip().lower()
    text = str(value or "").strip().lower()
    if text.startswith("devicekey."):
        return text.split(".", 1)[1]
    return text


def action_key_value(action: Any) -> str:
    action_type = action_type_name(action)
    if action_type == "press_back":
        return DeviceKey.BACK.value
    if action_type == "press_home":
        return DeviceKey.HOME.value
    if action_type == "press_key":
        return device_key_value(action_params_of(action).get("key"))
    if action_type in {"back", "home", "enter"}:
        return action_type
    return ""


def make_press_key_action(
    key: DeviceKey | str, *, description: str | None = None
) -> PressKeyAction:
    return PressKeyAction(
        type="press_key",
        params={"key": device_key_value(key)},
        description=description,
    )


def make_press_back_action(*, description: str | None = None) -> PressKeyAction:
    return make_press_key_action(DeviceKey.BACK, description=description)


def make_press_home_action(*, description: str | None = None) -> PressKeyAction:
    return make_press_key_action(DeviceKey.HOME, description=description)


def normalize_action(action: AnyAction) -> AnyAction:
    if isinstance(
        action,
        (
            ClickAction,
            ClickNodeAction,
            LongPressAction,
            InputTextAction,
            SwipeAction,
            OpenAppAction,
            PressKeyAction,
            WaitAction,
            FinishedAction,
            UnknownAction,
        ),
    ):
        return action
    if isinstance(action, TypeAction):
        return InputTextAction(
            type="input_text",
            params={"text": str(action.params.get("text", ""))},
            description=action.description,
        )
    if isinstance(action, ScrollAction):
        return SwipeAction(
            type="swipe",
            params=SwipeActionParams(**action_params_of(action)),
            description=action.description,
        )
    if isinstance(action, PressBackAction):
        return make_press_back_action(description=action.description)
    if isinstance(action, PressHomeAction):
        return make_press_home_action(description=action.description)
    return action


def is_input_text_action(action: Any) -> bool:
    return canonical_action_type(action) == "input_text"


def is_swipe_action(action: Any) -> bool:
    return canonical_action_type(action) == "swipe"


def is_press_key_action(action: Any, *, key: str | None = None) -> bool:
    if canonical_action_type(action) != "press_key":
        return False
    if key is None:
        return True
    return action_key_value(action) == device_key_value(key)


def is_system_level_action(action: Any) -> bool:
    if canonical_action_type(action) == "open_app":
        return True
    return is_press_key_action(action, key=DeviceKey.BACK.value) or is_press_key_action(
        action, key=DeviceKey.HOME.value
    )


def _target_from_xy_params(params: Dict[str, Any]) -> Dict[str, Any]:
    return _drop_none(
        {
            "kind": "coords",
            "x": params.get("x"),
            "y": params.get("y"),
            "xmlRef": params.get("xml_ref"),
        }
    )


def serialize_action_for_storage(action: AnyAction) -> Dict[str, Any]:
    action = normalize_action(action)
    description = getattr(action, "description", None)

    if isinstance(action, ClickNodeAction):
        payload = {
            "type": "click",
            "target": {
                "kind": "node_ref",
                "nodeId": str(action.params.get("node_id", "") or ""),
            },
        }
    elif isinstance(action, ClickAction):
        params = action_params_of(action)
        prompt = str(params.get("clickPrompt") or "").strip() or None
        has_coords = params.get("x") is not None and params.get("y") is not None
        if has_coords:
            payload = {
                "type": "click",
                "target": _target_from_xy_params(params),
                "prompt": prompt,
            }
        else:
            payload = {
                "type": "click",
                "target": {"kind": "prompt", "prompt": prompt or ""},
            }
    elif isinstance(action, LongPressAction):
        payload = {
            "type": "long_press",
            "target": _target_from_xy_params(action_params_of(action)),
        }
    elif isinstance(action, InputTextAction):
        payload = {
            "type": "input_text",
            "text": str(action_params_of(action).get("text", "") or ""),
        }
    elif isinstance(action, SwipeAction):
        params = action_params_of(action)
        direction = params.get("direction")
        if isinstance(direction, ScrollDirection):
            direction = direction.value
        payload = {
            "type": "swipe",
            "target": _target_from_xy_params(params),
            "direction": str(direction or ""),
            "distance": params.get("distance"),
        }
    elif isinstance(action, OpenAppAction):
        payload = {
            "type": "open_app",
            "packageName": str(action_params_of(action).get("package_name", "") or ""),
        }
    elif isinstance(action, PressKeyAction):
        payload = {"type": "press_key", "key": action_key_value(action)}
    elif isinstance(action, WaitAction):
        time_s = float(action_params_of(action).get("time_s", 0.0) or 0.0)
        payload = {"type": "wait", "timeMs": int(round(time_s * 1000))}
    elif isinstance(action, ExternalToolAction):
        params = action_params_of(action)
        payload = {
            "type": "external_tool",
            "toolName": str(params.get("tool_name", "") or ""),
            "arguments": params.get("arguments")
            if isinstance(params.get("arguments"), dict)
            else {},
        }
    elif isinstance(action, FinishedAction):
        params = action_params_of(action)
        payload = {
            "type": "finished",
            "content": params.get("content"),
            "enableSummary": params.get("enable_summary"),
            "summaryPrompt": params.get("summary_prompt"),
        }
    else:
        payload = {
            "type": str(getattr(action, "type", "unknown") or "unknown"),
            "params": action_params_of(action),
        }

    if description is not None:
        payload["description"] = description
    return _drop_none(payload)


def _extract_text_param(data: Dict[str, Any]) -> str | None:
    if "text" in data:
        return str(data.get("text", "") or "")
    params = data.get("params")
    if isinstance(params, dict) and "text" in params:
        return str(params.get("text", "") or "")
    return None


def _extract_coords_target(data: Dict[str, Any]) -> Dict[str, Any]:
    target = data.get("target")
    if isinstance(target, dict):
        return dict(target)
    params = data.get("params")
    if isinstance(params, dict):
        return dict(params)
    return {}


def parse_action_payload(payload: Any) -> AnyAction:
    if isinstance(payload, BaseModel):
        return normalize_action(payload)
    if not isinstance(payload, dict):
        raise TypeError(f"Unsupported action payload: {type(payload)!r}")

    data = dict(payload)
    raw_type = action_type_name(data.get("type"))
    action_type = canonical_action_type(raw_type)
    description = data.get("description")

    if raw_type == "click" and isinstance(data.get("target"), dict):
        target = dict(data.get("target") or {})
        kind = str(target.get("kind", "") or "").strip()
        if kind == "node_ref":
            node_id = str(target.get("nodeId") or target.get("node_id") or "").strip()
            return ClickNodeAction(
                type="click_node", params={"node_id": node_id}, description=description
            )
        if kind == "prompt":
            prompt = str(target.get("prompt") or data.get("prompt") or "").strip()
            return ClickAction(
                type="click", params={"clickPrompt": prompt}, description=description
            )
        params: Dict[str, Any] = {}
        if target.get("x") is not None:
            params["x"] = target.get("x")
        if target.get("y") is not None:
            params["y"] = target.get("y")
        xml_ref = target.get("xmlRef") or target.get("xml_ref")
        if xml_ref is not None:
            params["xml_ref"] = xml_ref
        prompt = str(data.get("prompt") or "").strip()
        if prompt:
            params["clickPrompt"] = prompt
        return ClickAction(type="click", params=params, description=description)

    if raw_type == "click_node":
        params = data.get("params") if isinstance(data.get("params"), dict) else data
        node_id = str(params.get("node_id") or "").strip()
        return ClickNodeAction(
            type="click_node", params={"node_id": node_id}, description=description
        )

    if action_type == "long_press":
        target = _extract_coords_target(data)
        params: Dict[str, Any] = {}
        x = target.get("x")
        y = target.get("y")
        if x is not None:
            params["x"] = x
        if y is not None:
            params["y"] = y
        xml_ref = target.get("xmlRef") or target.get("xml_ref")
        if xml_ref is not None:
            params["xml_ref"] = xml_ref
        return LongPressAction(
            type="long_press", params=params, description=description
        )

    if action_type == "input_text":
        text = _extract_text_param(data)
        if text is not None:
            return InputTextAction(
                type="input_text",
                params={"text": text},
                description=description,
            )

    if action_type == "swipe":
        target = _extract_coords_target(data)
        params = SwipeActionParams(
            x=int(target.get("x") or 0),
            y=int(target.get("y") or 0),
            direction=str(
                data.get("direction")
                or target.get("direction")
                or ScrollDirection.DOWN.value
            ),
            distance=int(data.get("distance") or target.get("distance") or 0),
            xml_ref=target.get("xmlRef") or target.get("xml_ref"),
        )
        return SwipeAction(type="swipe", params=params, description=description)

    if action_type == "press_key":
        key = data.get("key")
        if key is None and raw_type in {"press_back", "back"}:
            key = DeviceKey.BACK.value
        if key is None and raw_type in {"press_home", "home"}:
            key = DeviceKey.HOME.value
        if key is None and raw_type in {"enter", "press_enter"}:
            key = DeviceKey.ENTER.value
        params = data.get("params")
        if key is None and isinstance(params, dict):
            key = params.get("key")
        if key is not None:
            return make_press_key_action(key, description=description)

    if action_type == "open_app":
        package_name = str(
            data.get("packageName")
            or data.get("package_name")
            or (data.get("params") or {}).get("package_name")
            or ""
        )
        return OpenAppAction(
            type="open_app",
            params={"package_name": package_name},
            description=description,
        )

    if action_type == "wait":
        time_ms = data.get("timeMs")
        if time_ms is None:
            time_ms = data.get("time_ms")
        if time_ms is None:
            params = data.get("params")
            if isinstance(params, dict):
                if "timeMs" in params:
                    time_ms = params.get("timeMs")
                elif "time_ms" in params:
                    time_ms = params.get("time_ms")
                elif "time_s" in params:
                    return WaitAction(
                        type="wait",
                        params={"time_s": float(params.get("time_s") or 0.0)},
                        description=description,
                    )
        if time_ms is not None:
            return WaitAction(
                type="wait",
                params={"time_s": float(time_ms) / 1000.0},
                description=description,
            )

    if action_type == "external_tool":
        params = data.get("params")
        tool_name = (
            data.get("toolName")
            or data.get("tool_name")
            or (params.get("tool_name") if isinstance(params, dict) else None)
            or ""
        )
        arguments = data.get("arguments")
        if arguments is None and isinstance(params, dict):
            arguments = params.get("arguments")
        return ExternalToolAction(
            type="external_tool",
            params={
                "tool_name": str(tool_name or ""),
                "arguments": dict(arguments) if isinstance(arguments, dict) else {},
            },
            description=description,
        )

    if action_type == "finished" and "params" not in data:
        params = {
            "content": data.get("content"),
            "enable_summary": data.get("enableSummary")
            if "enableSummary" in data
            else data.get("enable_summary"),
            "summary_prompt": data.get("summaryPrompt")
            if "summaryPrompt" in data
            else data.get("summary_prompt"),
        }
        return FinishedAction(
            type="finished", params=_drop_none(params), description=description
        )

    if action_type == "call_function":
        params = data.get("params")
        if isinstance(params, dict):
            node_id = str(params.get("node_id") or "").strip()
            function_name = str(params.get("function_name") or "").strip()
            arguments = params.get("arguments")
            return CallFunctionAction(
                type="call_function",
                params=CallFunctionParams(
                    node_id=node_id,
                    function_name=function_name,
                    arguments=dict(arguments) if isinstance(arguments, dict) else {},
                ),
                description=description,
            )

    action_classes = get_action_classes()
    action_cls = action_classes.get(raw_type) or action_classes.get(action_type)
    if action_cls is not None:
        filtered = dict(data)
        params = data.get("params")
        if isinstance(params, dict):
            filtered["params"] = _normalize_action_params_for_schema(
                action_type or raw_type,
                params,
            )
        return normalize_action(action_cls(**filtered))
    return UnknownAction(
        type=raw_type or "unknown",
        params=dict(data.get("params") or {}),
        description=description,
    )


def parse_tool_call_payload(payload: Any) -> Dict[str, Any]:
    """Normalize one high-level tool-call payload while preserving host shape.

    Args:
        payload: Raw tool-call payload such as one canonical `plan` / `tool_args`
            dictionary.

    Returns:
        Canonical tool-call dictionary with a normalized `tool_name`.
    """

    data = _as_plain_dict(payload)
    tool_name = canonical_tool_call_name(data)
    tool_args = _as_plain_dict(data.get("tool_args"))
    if not tool_args:
        tool_args = _as_plain_dict(data.get("args"))
    if not tool_args:
        tool_args = _as_plain_dict(data.get("arguments"))
    result: Dict[str, Any] = {
        "tool_name": tool_name or tool_call_name(data),
        "tool_args": dict(tool_args),
    }
    return result


def build_utg_tool_call_schema_document() -> Dict[str, Any]:
    """Return one JSON-schema-like document for the UTG high-level tool calls."""

    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": f"OmniFlow UTG Tool Call Schema {UTG_TOOL_CALL_SCHEMA_VERSION}",
        "type": "object",
        "oneOf": [],
    }


def get_action_classes() -> Dict[str, Any]:
    action_classes = get_args(AnyAction)
    result: Dict[str, Any] = {}
    for cls in action_classes:
        try:
            type_annotation = cls.model_fields["type"].annotation
            if hasattr(type_annotation, "__args__"):
                type_name = get_args(type_annotation)[0]
            else:
                type_name = cls.__name__.replace("Action", "").lower()
            result[type_name] = cls
        except (KeyError, IndexError, AttributeError):
            type_name = cls.__name__.replace("Action", "").lower()
            result[type_name] = cls
    return result


def build_utg_action_schema_document() -> Dict[str, Any]:
    target_coords = {
        "type": "object",
        "additionalProperties": False,
        "required": ["kind", "x", "y"],
        "properties": {
            "kind": {"const": "coords"},
            "x": {"type": ["integer", "number"]},
            "y": {"type": ["integer", "number"]},
            "xmlRef": {"type": "string"},
        },
    }
    target_node_ref = {
        "type": "object",
        "additionalProperties": False,
        "required": ["kind", "nodeId"],
        "properties": {
            "kind": {"const": "node_ref"},
            "nodeId": {"type": "string"},
        },
    }
    target_prompt = {
        "type": "object",
        "additionalProperties": False,
        "required": ["kind", "prompt"],
        "properties": {
            "kind": {"const": "prompt"},
            "prompt": {"type": "string"},
        },
    }
    target_union = {
        "oneOf": [
            {"$ref": "#/$defs/targetCoords"},
            {"$ref": "#/$defs/targetNodeRef"},
            {"$ref": "#/$defs/targetPrompt"},
        ]
    }
    action_defs = {
        "clickAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "target"],
            "properties": {
                "type": {"const": "click"},
                "target": target_union,
                "prompt": {"type": "string"},
                "description": {"type": "string"},
            },
        },
        "longPressAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "target"],
            "properties": {
                "type": {"const": "long_press"},
                "target": {"$ref": "#/$defs/targetCoords"},
                "description": {"type": "string"},
            },
        },
        "inputTextAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "text"],
            "properties": {
                "type": {"const": "input_text"},
                "text": {"type": "string"},
                "description": {"type": "string"},
            },
        },
        "swipeAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "target", "direction", "distance"],
            "properties": {
                "type": {"const": "swipe"},
                "target": {"$ref": "#/$defs/targetCoords"},
                "direction": {
                    "enum": [direction.value for direction in ScrollDirection]
                },
                "distance": {"type": ["integer", "number"]},
                "description": {"type": "string"},
            },
        },
        "pressKeyAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "key"],
            "properties": {
                "type": {"const": "press_key"},
                "key": {"enum": [key.value for key in DeviceKey]},
                "description": {"type": "string"},
            },
        },
        "openAppAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "packageName"],
            "properties": {
                "type": {"const": "open_app"},
                "packageName": {"type": "string"},
                "description": {"type": "string"},
            },
        },
        "waitAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type", "timeMs"],
            "properties": {
                "type": {"const": "wait"},
                "timeMs": {"type": "integer", "minimum": 0},
                "description": {"type": "string"},
            },
        },
        "finishedAction": {
            "type": "object",
            "additionalProperties": False,
            "required": ["type"],
            "properties": {
                "type": {"const": "finished"},
                "content": {"type": "string"},
                "enableSummary": {"type": "boolean"},
                "summaryPrompt": {"type": "string"},
                "description": {"type": "string"},
            },
        },
    }

    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": f"OmniFlow UTG Action Schema {UTG_ACTION_SCHEMA_VERSION}",
        "type": "object",
        "additionalProperties": False,
        "required": ["version", "actionSchemaVersion", "nodes", "functions"],
        "properties": {
            "version": {"type": "string"},
            "actionSchemaVersion": {"const": UTG_ACTION_SCHEMA_VERSION},
            "appInfo": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["appName", "packageName"],
                    "properties": {
                        "appName": {"type": "string"},
                        "packageName": {"type": "string"},
                    },
                },
            },
            "nodes": {
                "type": "array",
                "items": {"$ref": "#/$defs/node"},
            },
            "functions": {
                "type": "object",
                "additionalProperties": {"$ref": "#/$defs/function"},
            },
        },
        "$defs": {
            "targetCoords": target_coords,
            "targetNodeRef": target_node_ref,
            "targetPrompt": target_prompt,
            **action_defs,
            "action": {
                "oneOf": [
                    {"$ref": "#/$defs/clickAction"},
                    {"$ref": "#/$defs/longPressAction"},
                    {"$ref": "#/$defs/inputTextAction"},
                    {"$ref": "#/$defs/swipeAction"},
                    {"$ref": "#/$defs/pressKeyAction"},
                    {"$ref": "#/$defs/openAppAction"},
                    {"$ref": "#/$defs/waitAction"},
                    {"$ref": "#/$defs/finishedAction"},
                ]
            },
            "function": {
                "type": "object",
                "additionalProperties": False,
                "required": ["name", "actions"],
                "properties": {
                    "name": {"type": "string"},
                    "parameters": {"type": "object"},
                    "description": {"type": "string"},
                    "actions": {
                        "type": "array",
                        "items": {
                            "oneOf": [
                                {"$ref": "#/$defs/clickAction"},
                                {"$ref": "#/$defs/longPressAction"},
                                {"$ref": "#/$defs/inputTextAction"},
                                {"$ref": "#/$defs/swipeAction"},
                                {"$ref": "#/$defs/pressKeyAction"},
                                {"$ref": "#/$defs/openAppAction"},
                                {"$ref": "#/$defs/waitAction"},
                                {"$ref": "#/$defs/finishedAction"},
                            ]
                        },
                    },
                },
            },
            "nodeRepr": {
                "type": "object",
                "additionalProperties": True,
                "properties": {
                    "packageName": {"type": "string"},
                    "activityName": {"type": "string"},
                    "xmls": {"type": "array", "items": {"type": "string"}},
                },
            },
            "node": {
                "type": "object",
                "additionalProperties": True,
                "required": ["id", "repr"],
                "properties": {
                    "id": {"type": "string"},
                    "repr": {"$ref": "#/$defs/nodeRepr"},
                    "functions": {
                        "type": "object",
                        "additionalProperties": {"$ref": "#/$defs/function"},
                    },
                    "triggers": {"type": "array"},
                },
            },
        },
    }


__all__ = [
    "ACTION_ALIAS_MAP",
    "ACTION_CATALOG",
    "AnyAction",
    "CANONICAL_TOOL_CALL_NAMES",
    "CANONICAL_DEVICE_ACTION_TYPES",
    "CallFunctionAction",
    "CallFunctionParams",
    "ClickAction",
    "ClickNodeAction",
    "DeviceKey",
    "EXECUTE_TOOL_SCHEMAS",
    "FinishedAction",
    "InputTextAction",
    "LongPressAction",
    "OpenAppAction",
    "PressBackAction",
    "PressHomeAction",
    "PressKeyAction",
    "ScrollAction",
    "ScrollActionParams",
    "ScrollDirection",
    "SwipeAction",
    "SwipeActionParams",
    "TOOL_CALL_ALIAS_MAP",
    "TOOL_CALL_CATALOG",
    "TypeAction",
    "UTG_ACTION_SCHEMA_VERSION",
    "UTG_TOOL_CALL_SCHEMA_VERSION",
    "UnknownAction",
    "WaitAction",
    "action_key_value",
    "action_params_of",
    "action_type_name",
    "build_dynamic_tool_set",
    "build_function_tool",
    "build_tool_schemas",
    "build_utg_action_schema_document",
    "build_utg_tool_call_schema_document",
    "extract_function_parameters",
    "canonical_action_payload",
    "canonical_tool_call_name",
    "canonical_action_type",
    "device_key_value",
    "extract_executed_actions_from_detail",
    "get_action_classes",
    "is_input_text_action",
    "is_press_key_action",
    "is_swipe_action",
    "is_system_level_action",
    "list_action_names",
    "list_tool_call_names",
    "make_press_back_action",
    "make_press_home_action",
    "make_press_key_action",
    "normalize_action",
    "parse_action_payload",
    "parse_tool_call_payload",
    "resolve_action_alias",
    "resolve_tool_call_alias",
    "serialize_action_for_storage",
    "tool_call_name",
    "convert_tool_call_to_action",
]


def convert_tool_call_to_action(
    tool_name: str, tool_args: Dict[str, Any]
) -> Dict[str, Any]:
    """Convert tool calling result to standard action object format.

    Args:
        tool_name: The name of the called tool (e.g., "click", "input_text", "call_function")
        tool_args: Parameters from tool calling (e.g., {"x": 100, "y": 200})

    Returns:
        Standard action object with type and params structure.

    Example:
        >>> convert_tool_call_to_action("click", {"x": 100, "y": 200})
        {"type": "click", "params": {"x": 100, "y": 200}}

        >>> convert_tool_call_to_action("call_function", {"function_id": "login", "arguments": {"user": "test"}})
        {"type": "call_function", "params": {"function_id": "login", "arguments": {"user": "test"}}}

        >>> convert_tool_call_to_action("finished", {})
        {"type": "finished", "params": {}}
    """
    if not tool_name:
        return {}

    return {
        "type": tool_name,
        "params": dict(tool_args or {}),
    }
