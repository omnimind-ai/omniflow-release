# utg/core/models.py
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Literal, Optional

from jsonschema import Draft202012Validator
from pydantic import (
    BaseModel,
    Field,
    field_serializer,
    field_validator,
    model_validator,
)

from src.utg.core.actions import (
    UTG_ACTION_SCHEMA_VERSION,
    AnyAction,
    parse_action_payload,
    serialize_action_for_storage,
)
from src.utg.core.params import ParamRenderer, ParamTemplate
from src.utg.core.triggers import Trigger

logger = logging.getLogger(__name__)


# ========== 1. Action Classification Models ==========


class ActionMeta(BaseModel):
    """Action 分类元信息 - 标识 action 是导航还是交互"""

    index: int = Field(..., description="Action 在 Function 中的索引")
    action_type: Literal["navigation", "interaction"] = Field(
        ..., description="navigation: 导致页面跳转; interaction: 页面内操作"
    )
    reason: Optional[str] = Field(default=None, description="分类原因（由 LLM 提供）")


class NodeSegment(BaseModel):
    """一个 Node 上的操作段 - Function 分解后的基本单元

    基于执行时的 match_node 结果分组：
    - 连续匹配到同一个 node_id 的 actions 归为一个 segment
    - node_id 变化时开始新的 segment
    """

    node_id: str = Field(..., description="这个 segment 对应的 Node ID")
    actions: List[AnyAction] = Field(
        default_factory=list, description="在这个 Node 上执行的 actions"
    )
    action_indices: List[int] = Field(
        default_factory=list, description="对应的 action 索引列表"
    )
    next_node_id: Optional[str] = Field(
        default=None, description="下一个 segment 的 Node ID（即跳转目标）"
    )

    @field_validator("actions", mode="before")
    @classmethod
    def _parse_actions(cls, value: Any) -> List[AnyAction]:
        if value is None:
            return []
        parsed: List[AnyAction] = []
        for item in value:
            parsed.append(parse_action_payload(item))
        return parsed

    @field_serializer("actions", when_used="always")
    def _serialize_actions(self, actions: List[AnyAction]) -> List[Dict[str, Any]]:
        return [serialize_action_for_storage(action) for action in actions]


class ActionTrace(BaseModel):
    """单个 Action 的执行记录"""

    action_index: int = Field(..., description="Action 在 Function 中的索引")
    action_type: str = Field(..., description="Action 类型")
    executed: bool = Field(default=True, description="是否实际执行")
    node_id: Optional[str] = Field(
        default=None, description="执行前 match_node 匹配到的 Node ID"
    )
    state_snapshot: Optional[Dict[str, Any]] = Field(
        default=None, description="执行时的 UI 状态快照"
    )


class SegmentCluster(BaseModel):
    """聚合后的 segment 组 - 层次聚类的节点

    层次结构:
        Level 0: NodeSegment (原子 segment，按 Node 切分)
        Level 1: Task (任务级，如 "登录", "填写表单")
        Level 2: Flow (流程级，如 "完整购买流程")

    Example:
        SegmentCluster(
            cluster_id="purchase_flow",
            intent="完成购买",
            level=2,
            children=[
                SegmentCluster(intent="浏览选品", level=1, segments=[seg0, seg1, seg2]),
                SegmentCluster(intent="结算支付", level=1, segments=[seg3, seg4]),
            ]
        )
    """

    cluster_id: str = Field(..., description="聚类 ID")
    intent: str = Field(..., description="语义意图标签")
    level: int = Field(
        default=0, description="聚合层级 (0=原子segment, 1=任务, 2=流程)"
    )
    description: Optional[str] = Field(default=None, description="详细描述")

    # 叶子节点：直接包含 segments
    segments: List[NodeSegment] = Field(
        default_factory=list, description="包含的原子 segments (叶子节点)"
    )
    segment_indices: List[int] = Field(
        default_factory=list, description="在原始 segment 列表中的索引"
    )

    # 非叶子节点：包含子 cluster
    children: List["SegmentCluster"] = Field(
        default_factory=list, description="子聚类 (非叶子节点)"
    )

    # 汇总信息
    node_ids: List[str] = Field(default_factory=list, description="涉及的所有 Node ID")
    action_count: int = Field(default=0, description="总 action 数量")

    def is_leaf(self) -> bool:
        """是否为叶子节点（直接包含 segments）"""
        return len(self.children) == 0

    def get_all_segments(self) -> List[NodeSegment]:
        """递归获取所有叶子 segments"""
        if self.is_leaf():
            return self.segments
        result = []
        for child in self.children:
            result.extend(child.get_all_segments())
        return result

    def get_all_node_ids(self) -> List[str]:
        """递归获取所有涉及的 Node ID"""
        if self.is_leaf():
            return [seg.node_id for seg in self.segments]
        result = []
        for child in self.children:
            result.extend(child.get_all_node_ids())
        return list(dict.fromkeys(result))  # 去重保序

    def total_action_count(self) -> int:
        """递归统计总 action 数量"""
        if self.is_leaf():
            return sum(len(seg.actions) for seg in self.segments)
        return sum(child.total_action_count() for child in self.children)


DEFAULT_UTG_VERSION = "1.0.0"


def _empty_parameters_schema() -> Dict[str, Any]:
    """Return the canonical empty JSON Schema used by UTG functions."""

    return {
        "type": "object",
        "properties": {},
        "required": [],
        "additionalProperties": False,
    }


# ========== 2. AppInfo Definition ==========


class AppInfo(BaseModel):
    appName: str = Field(..., description="Application name")
    packageName: str = Field(..., description="Application package name")


# ========== 3. Function Definition ==========


class Function(BaseModel):
    name: str
    description: Optional[str] = Field(
        default=None,
        description="Optional human-readable description for the function (supports parameters).",
    )
    parameters: Dict[str, Any] = Field(
        default_factory=_empty_parameters_schema,
        description="OpenAI-compatible JSON Schema object describing the function arguments.",
    )
    actions: List[AnyAction]

    # Compile locality and terminal verification fields (migrated from Path)
    start_node_id: Optional[str] = Field(
        default=None,
        description="Optional explicit start node id for compile locality scoring.",
    )
    end_node_id: Optional[str] = Field(
        default=None,
        description="Optional explicit end node id for terminal state verification.",
    )

    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Optional function metadata. Common keys: "
            "function_type ('atomic' | 'composite'), "
            "entry_point (bool - can serve as task entry)."
        ),
    )

    # Action classification metadata (populated by LLM analysis)
    action_meta: Optional[List["ActionMeta"]] = Field(
        default=None,
        description="LLM-classified action types (navigation/interaction) for automaton decomposition.",
    )

    # Baseline execution trace (from first recording)
    baseline_trace: Optional[List["ActionTrace"]] = Field(
        default=None,
        description="Execution trace from first recording, used for comparison.",
    )

    # Execution statistics
    run_stats: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Execution statistics. Keys: "
            "call_count (int), success_count (int), "
            "last_run_id (str), last_run_at (str), last_success (bool)."
        ),
    )

    # Asset references (for stored functions)
    asset_refs: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "References to stored assets. Keys: "
            "xml_refs (list[str]), screenshot_refs (list[str]), "
            "function_dir (str)."
        ),
    )

    @field_validator("parameters", mode="before")
    @classmethod
    def _validate_parameters(cls, value: Any) -> Dict[str, Any]:
        schema = (
            dict(value or {}) if isinstance(value, dict) else _empty_parameters_schema()
        )
        if not schema:
            schema = _empty_parameters_schema()
        if str(schema.get("type") or "object").strip() != "object":
            raise ValueError("Function.parameters must be a JSON Schema object")
        schema.setdefault("type", "object")
        schema.setdefault("properties", {})
        schema.setdefault("required", [])
        schema.setdefault("additionalProperties", False)
        if not isinstance(schema.get("properties"), dict):
            raise ValueError("Function.parameters.properties must be an object")
        if not isinstance(schema.get("required"), list):
            raise ValueError("Function.parameters.required must be a list")
        Draft202012Validator.check_schema(schema)
        return schema

    @field_validator("actions", mode="before")
    @classmethod
    def _parse_actions(cls, value: Any) -> List[AnyAction]:
        if value is None:
            return []
        parsed: List[AnyAction] = []
        for item in value:
            parsed.append(parse_action_payload(item))
        return parsed

    @field_serializer("actions", when_used="always")
    def _serialize_actions(self, actions: List[AnyAction]) -> List[Dict[str, Any]]:
        return [serialize_action_for_storage(action) for action in actions]

    def is_terminal_function(self) -> bool:
        """Return whether this function semantically finishes the current path."""
        return "finish" in self.name.lower() or "complete" in self.name.lower()

    def get_description_template(self) -> Optional[ParamTemplate]:
        """
        获取描述模板（带参数占位符）

        Returns:
            ParamTemplate 对象，如果 description 为 None 则返回 None
        """
        if self.description is None:
            return None
        return ParamTemplate(template=self.description)

    def render_description(
        self, arguments: Dict[str, Any], strict: bool = False
    ) -> Optional[str]:
        """
        渲染描述（将参数占位符替换为实际值）

        Args:
            arguments: 参数值字典
            strict: 是否严格模式

        Returns:
            渲染后的描述字符串
        """
        if self.description is None:
            return None
        return ParamRenderer.render_nullable(self.description, arguments, strict)

    def get_parameter_names(self) -> List[str]:
        """Return parameter names declared by JSON Schema or description template."""

        names: List[str] = []
        properties = self.parameters.get("properties")
        if isinstance(properties, dict):
            for key in properties.keys():
                parameter_name = str(key or "").strip()
                if parameter_name and parameter_name not in names:
                    names.append(parameter_name)
        template = self.get_description_template()
        if template is not None:
            for key in template.get_parameter_names():
                parameter_name = str(key or "").strip()
                if parameter_name and parameter_name not in names:
                    names.append(parameter_name)
        return names

    def validate_arguments(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Validate runtime arguments against the function JSON Schema."""

        valid_names = set(self.get_parameter_names())
        validated = {
            str(key): value
            for key, value in dict(arguments or {}).items()
            if str(key or "").strip() in valid_names
        }
        Draft202012Validator(self.parameters).validate(validated)
        return validated

    def to_function_schema(self) -> Dict[str, Any]:
        """Export one OpenAI-compatible function schema payload."""

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description or "",
                "parameters": dict(self.parameters or _empty_parameters_schema()),
            },
        }

    def render_actions(
        self, arguments: Dict[str, Any], strict: bool = False
    ) -> List[AnyAction]:
        """
        渲染动作列表中的参数占位符

        Args:
            arguments: 参数值字典
            strict: 是否严格模式

        Returns:
            渲染后的动作列表
        """
        validated_arguments = self.validate_arguments(arguments)
        return ParamRenderer.render_actions(self.actions, validated_arguments, strict)

    @classmethod
    def from_function_chain(
        cls,
        steps_chain: List[tuple],
        name: str = "composite",
        description: str = "",
        parameters: Optional[Dict[str, Any]] = None,
        start_node_id: Optional[str] = None,
        end_node_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "Function":
        """Build a composite Function from (node_id, function_name) tuples.

        This is a convenience constructor for creating functions that call
        other functions in sequence (composite pattern).

        Args:
            steps_chain: List of (node_id, function_name) tuples
            name: Function identifier
            description: Human-readable description
            parameters: JSON Schema for arguments
            start_node_id: Explicit start node (defaults to first step)
            end_node_id: Explicit end node (defaults to last step)
            metadata: Optional metadata

        Returns:
            A composite Function with call_function actions.
        """
        from src.utg.core.actions import CallFunctionAction, CallFunctionParams

        actions = [
            CallFunctionAction(
                type="call_function",
                params=CallFunctionParams(
                    node_id=node_id,
                    function_name=func_name,
                    arguments={},
                ),
            )
            for node_id, func_name in steps_chain
        ]
        explicit_start = str(start_node_id or "").strip() or (
            steps_chain[0][0] if steps_chain else None
        )
        explicit_end = str(end_node_id or "").strip() or (
            steps_chain[-1][0] if steps_chain else None
        )
        return cls(
            name=name,
            description=description or "",
            parameters=dict(parameters or _empty_parameters_schema()),
            actions=actions,
            start_node_id=explicit_start,
            end_node_id=explicit_end,
            metadata={
                **(metadata or {}),
                "function_type": "composite",
                "entry_point": True,
            },
        )


# ========== 4. Node Definition ==========


class MatchRules(BaseModel):
    """页面匹配规则 - 用于确定当前页面是否匹配某个 Node。

    匹配逻辑：
    - required: 所有元素必须在 XML 中出现（AND）
    - excluded: 任一元素出现则不匹配
    - activity_pattern: 可选的 activity 名称匹配
    """

    required: List[str] = Field(
        default_factory=list,
        description="必须包含的元素（resource-id 或 text 片段），全部匹配才通过",
    )
    excluded: List[str] = Field(
        default_factory=list,
        description="必须排除的元素，任一出现则不匹配",
    )
    activity_pattern: Optional[str] = Field(
        default=None,
        description="可选的 activity 名称模式（支持通配符）",
    )

    def matches(self, xml: str, activity: str | None = None) -> bool:
        """检查 XML 是否匹配规则。

        Args:
            xml: 页面 XML 内容
            activity: 可选的当前 activity 名称

        Returns:
            True 如果匹配所有规则
        """
        # Check activity pattern if specified
        if self.activity_pattern and activity:
            import fnmatch

            if not fnmatch.fnmatch(activity, self.activity_pattern):
                return False

        # Check required elements (all must be present)
        for req in self.required:
            if req not in xml:
                return False

        # Check excluded elements (none should be present)
        for exc in self.excluded:
            if exc in xml:
                return False

        return True

    @classmethod
    def from_legacy_node_filter(cls, node_filter: List[Dict[str, str]]) -> "MatchRules":
        """从旧版 nodeFilter 格式转换。

        旧格式: [{"resource-id": "btn"}, {"text": "设置"}]
        新格式: MatchRules(required=["resource-id", "btn", "text", "设置"])
        """
        required: List[str] = []
        for rule in node_filter:
            for key, value in rule.items():
                if key and key not in required:
                    required.append(key)
                if value and value not in required:
                    required.append(value)
        return cls(required=required)


class NodeRepr(BaseModel):
    # === New fields (asset separation architecture) ===
    # Local path indices (pointing to raw/ directory, not uploaded)
    xml_paths: List[str] = Field(
        default_factory=list,
        description="Local XML file paths (e.g., 'raw/nodes/xxx/v0.xml'). Not uploaded.",
    )
    image_paths: List[str] = Field(
        default_factory=list,
        description="Local screenshot paths (e.g., 'raw/nodes/xxx/v0.png'). Not uploaded.",
    )
    refs: List[str] = Field(
        default_factory=list,
        description="SHA256 dedup keys for xml_paths (content hash).",
    )

    # Privacy-safe data (can be uploaded)
    vector_sets: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="PageVectorSet.to_dict() representations. Privacy-safe, uploadable.",
    )

    # === Legacy fields (backward compatible, deprecated for new writes) ===
    xmls: List[str] = Field(
        default_factory=list,
        description="@deprecated: Raw XML content. Use xml_paths + vector_sets instead.",
    )
    xmlRefs: List[str] = Field(
        default_factory=list,
        description="@deprecated: Stable XML refs aligned with xmls.",
    )
    images: List[str] = Field(
        default_factory=list,
        description="@deprecated: Screenshot data/paths aligned with xmls.",
    )
    imageRefs: List[str] = Field(
        default_factory=list,
        description="@deprecated: Stable image refs aligned with images.",
    )

    # === Core fields ===
    packageName: str = Field(..., description="App package name")
    match_rules: Optional[MatchRules] = Field(default=None, description="页面匹配规则")
    description: Optional[str] = Field(default=None, description="Node description")

    # === Legacy fields for backward compatibility ===
    nodeFilter: Optional[List[Dict[str, str]]] = Field(
        default=None,
        description="@deprecated: Use match_rules instead. Auto-migrated on read.",
    )
    score: Optional[float] = Field(
        default=None,
        description="@deprecated: No longer used.",
    )

    @staticmethod
    def build_xml_ref(xml_text: str) -> str:
        normalized = str(xml_text or "").strip().encode("utf-8")
        return f"sha256:{hashlib.sha256(normalized).hexdigest()}"

    @staticmethod
    def build_image_ref(image_data: str) -> str:
        """Build a stable ref for an image (base64 data URL or file path)."""
        data = str(image_data or "").strip()
        if not data:
            return ""
        # For base64 data URLs, hash the actual image data
        if data.startswith("data:image/"):
            # Extract base64 portion after comma
            parts = data.split(",", 1)
            if len(parts) == 2:
                data = parts[1]
        return f"sha256:{hashlib.sha256(data.encode('utf-8')).hexdigest()}"

    @model_validator(mode="after")
    def _ensure_xml_refs(self) -> "NodeRepr":
        refs = [str(item or "").strip() for item in (self.xmlRefs or [])]
        resolved: List[str] = []
        for index, xml in enumerate(self.xmls or []):
            existing = refs[index] if index < len(refs) else ""
            resolved.append(existing or self.build_xml_ref(str(xml or "")))
        self.xmlRefs = resolved
        # Also ensure imageRefs are aligned with images
        img_refs = [str(item or "").strip() for item in (self.imageRefs or [])]
        resolved_img_refs: List[str] = []
        for index, img in enumerate(self.images or []):
            existing = img_refs[index] if index < len(img_refs) else ""
            resolved_img_refs.append(existing or self.build_image_ref(str(img or "")))
        self.imageRefs = resolved_img_refs
        return self

    @model_validator(mode="after")
    def _migrate_node_filter(self) -> "NodeRepr":
        """Auto-migrate legacy nodeFilter to match_rules."""
        if self.nodeFilter and not self.match_rules:
            self.match_rules = MatchRules.from_legacy_node_filter(self.nodeFilter)
        return self

    @model_validator(mode="after")
    def _migrate_legacy_fields(self) -> "NodeRepr":
        """Auto-migrate legacy xmls to vector_sets if needed.

        When reading old UTG files that have xmls but no vector_sets,
        this validator converts them to the new format.
        """
        # Only migrate if we have legacy xmls but no vector_sets
        if self.xmls and not self.vector_sets:
            try:
                from src.utg.assets.embedding.vector_set import xml_to_vector_set

                for i, xml in enumerate(self.xmls):
                    if not xml:
                        continue
                    try:
                        vs = xml_to_vector_set(
                            xml,
                            page_id=f"migrated_{i}",
                            package_name=self.packageName,
                        )
                        self.vector_sets.append(vs.to_dict())
                    except Exception:
                        # Skip failed conversions silently
                        pass
            except ImportError:
                # Module not available, skip migration
                pass
        return self

    def to_uploadable_dict(self) -> Dict[str, Any]:
        """Export a privacy-safe dict suitable for upload.

        Returns only the desensitized data that can be shared:
        - vector_sets (PageVectorSet data, fully anonymized)
        - packageName, match_rules, description

        Does NOT include:
        - xml_paths, image_paths (local file paths)
        - xmls, images (raw content)
        - refs, xmlRefs, imageRefs (internal tracking)
        """
        return {
            "vector_sets": list(self.vector_sets),
            "packageName": self.packageName,
            "match_rules": self.match_rules.model_dump() if self.match_rules else None,
            "description": self.description,
        }

    def has_vector_sets(self) -> bool:
        """Check if this node has any vector_sets available."""
        return bool(self.vector_sets)

    def primary_vector_set(self) -> Optional[Dict[str, Any]]:
        """Get the first available vector_set."""
        if self.vector_sets:
            return self.vector_sets[0]
        return None

    def resolve_xml_by_ref(self, xml_ref: str) -> str:
        key = str(xml_ref or "").strip()
        if not key:
            return ""
        for index, ref in enumerate(self.xmlRefs or []):
            if ref == key and index < len(self.xmls or []):
                return str((self.xmls or [])[index] or "").strip()
        return ""

    def resolve_image_by_xml_ref(self, xml_ref: str) -> str:
        """Get the screenshot image associated with a given XML ref."""
        key = str(xml_ref or "").strip()
        if not key:
            return ""
        for index, ref in enumerate(self.xmlRefs or []):
            if ref == key and index < len(self.images or []):
                return str((self.images or [])[index] or "").strip()
        return ""

    def resolve_image_by_index(self, index: int) -> str:
        """Get the screenshot image at a given index."""
        if 0 <= index < len(self.images or []):
            return str((self.images or [])[index] or "").strip()
        return ""

    def primary_xml_ref(self) -> str:
        for item in self.xmlRefs or []:
            text = str(item or "").strip()
            if text:
                return text
        return ""

    def primary_image(self) -> str:
        """Get the first available screenshot image."""
        for item in self.images or []:
            text = str(item or "").strip()
            if text:
                return text
        return ""


class UTGNode(BaseModel):
    id: str = Field(..., description="Unique node identifier")
    repr: NodeRepr
    functions: Dict[str, Function] = Field(
        default_factory=dict,
        description="Atomic functions bound to the node. Legacy UTG files may omit this field.",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Optional node-level metadata such as capture mode, screenshot path, and source action.",
    )
    triggers: List[Trigger] = Field(
        default_factory=list,
        description="Observation-driven control triggers bound to this node.",
    )

    def __str__(self):
        return super().__str__()


Function.model_rebuild()

# Rebuild trigger models to resolve forward references.
from src.utg.core import triggers as _triggers  # noqa: E402

_triggers.TriggerSpec.model_rebuild(
    _types_namespace={"TriggerCondition": _triggers.TriggerCondition}
)


# ========== 5. Graph Root Definition ==========


class UTGGraph(BaseModel):
    version: str = Field(..., pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$")
    actionSchemaVersion: str = Field(
        default=UTG_ACTION_SCHEMA_VERSION, pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$"
    )
    appInfo: List[AppInfo] = Field(
        default_factory=list, description="Application information"
    )
    nodes: List[UTGNode]
    functions: Dict[str, Function] = Field(
        default_factory=dict,
        description="Global composite functions (cross-node tasks). Atomic functions live in node.functions.",
    )
    triggers: List[Trigger] = Field(
        default_factory=list,
        description="Graph-wide trigger pool evaluated with runtime bindings.",
    )

    @classmethod
    def load_model_from_json_file(cls, file_path: str) -> "UTGGraph":
        """从 JSON 文件加载 UTG 图。"""
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "version" not in data:
            data["version"] = DEFAULT_UTG_VERSION
        if "triggers" not in data:
            data["triggers"] = []
        if "functions" not in data:
            data["functions"] = {}
        if "paths" in data:
            raise ValueError(
                "Legacy UTG schema is no longer supported: top-level 'paths' "
                "must be migrated to top-level 'functions'."
            )
        for node in list(data.get("nodes") or []):
            if not isinstance(node, dict):
                continue
            if "functions" not in node:
                node["functions"] = {}
            if "sequences" in node:
                node_id = str(node.get("id") or "").strip() or "<unknown>"
                raise ValueError(
                    "Legacy UTG schema is no longer supported: "
                    f"node '{node_id}' still uses 'sequences'; migrate it to "
                    "'functions'."
                )
        return cls(**data)

    def find_app_info_by_package_name(self, package_name: str) -> Optional[AppInfo]:
        """
        通过包名查找应用信息

        Args:
            package_name: 应用包名

        Returns:
            AppInfo 或 None
        """
        for app_info in self.appInfo:
            if app_info.packageName == package_name:
                return app_info
        return None

    def find_node_by_id(self, node_id: str) -> Optional[UTGNode]:
        """
        通过 ID 查找节点

        Args:
            node_id: 节点 ID

        Returns:
            UTGNode 或 None
        """
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None

    def find_function_by_name(
        self, node_id: str, function_name: str
    ) -> Optional[Function]:
        """
        通过节点 ID 和函数名查找函数

        Args:
            node_id: 节点 ID
            function_name: 函数名称

        Returns:
            Function 或 None
        """
        node = self.find_node_by_id(node_id)
        if node and function_name in node.functions:
            return node.functions[function_name]
        return None

    def find_global_function_by_name(self, function_name: str) -> Optional[Function]:
        """
        通过名称查找全局函数（composite function）

        Args:
            function_name: 函数名称

        Returns:
            Function 或 None
        """
        return self.functions.get(function_name)

    def merge(self, other: "UTGGraph") -> "UTGGraph":
        """
        合并另一个 UTG 图

        Args:
            other: 另一个 UTG 图

        Returns:
            合并后的新 UTG 图
        """
        # 合并节点（以当前图的节点为准，如果有冲突）
        node_dict = {node.id: node for node in self.nodes}
        for node in other.nodes:
            if node.id not in node_dict:
                node_dict[node.id] = node

        # 合并全局函数（以当前图为准，如果有冲突）
        func_dict = dict(self.functions or {})
        for func_name, func in (other.functions or {}).items():
            if func_name not in func_dict:
                func_dict[func_name] = func

        # 合并应用信息（去重）
        app_info_dict = {app.packageName: app for app in self.appInfo}
        for app in other.appInfo:
            if app.packageName not in app_info_dict:
                app_info_dict[app.packageName] = app

        return UTGGraph(
            version=self.version,
            actionSchemaVersion=self.actionSchemaVersion,
            appInfo=list(app_info_dict.values()),
            nodes=list(node_dict.values()),
            functions=func_dict,
        )
