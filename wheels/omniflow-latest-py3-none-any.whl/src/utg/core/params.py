"""
参数模板与抽取工具。

- 模板格式统一为 `${parameter_name}`
- 提供模板渲染与模板匹配抽取
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from enum import Enum
import logging
import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

from src.utg.core.actions import AnyAction

logger = logging.getLogger(__name__)


def normalize_template(template: str) -> str:
    """将 `{parameter}` 统一归一为 `${parameter}`。"""
    if not template:
        return ""
    return re.sub(r"(?<!\$)\{(\w+)\}", r"${\1}", template)


class ParameterExtractionMethod(str, Enum):
    """参数提取方法。"""

    TEMPLATE = "template"
    L1 = "template"


@dataclass
class ParameterValue:
    """参数值，与 `ParamTemplate` 配合使用。"""

    parameter_name: str
    value: str
    confidence: float
    method: ParameterExtractionMethod


PARAMETER_TOKEN_RE = re.compile(r"\$\{(\w+)\}")


@dataclass
class CompiledTemplate:
    """模板编译结果，可直接用于抽取参数。"""

    template: str
    segments: List[str]
    parameter_names: List[str]
    prefix: str
    has_parameters: bool
    has_suffix: bool

    @classmethod
    def from_template(cls, template: str) -> "CompiledTemplate":
        normalized = normalize_template(template)
        segments: List[str] = []
        parameter_names: List[str] = []
        last = 0
        for match in PARAMETER_TOKEN_RE.finditer(normalized):
            segments.append(normalized[last : match.start()])
            parameter_name = match.group(1) or ""
            if parameter_name:
                parameter_names.append(parameter_name)
            last = match.end()
        segments.append(normalized[last:])
        prefix = segments[0] if segments else ""
        has_parameters = bool(parameter_names)
        has_suffix = bool(segments[-1]) if segments else False
        return cls(
            template=normalized,
            segments=segments,
            parameter_names=parameter_names,
            prefix=prefix,
            has_parameters=has_parameters,
            has_suffix=has_suffix,
        )

    def extract(self, query: str) -> Dict[str, ParameterValue]:
        """Extract bound arguments from one rendered query string."""
        if not self.template or not query or not self.has_parameters:
            return {}

        min_len = sum(len(seg) for seg in self.segments)
        if len(query) < min_len:
            return {}

        arguments: Dict[str, ParameterValue] = {}
        pos = 0

        prefix = self.segments[0]
        if prefix:
            if not query.startswith(prefix):
                return {}
            pos = len(prefix)

        for idx, parameter_name in enumerate(self.parameter_names):
            next_seg = self.segments[idx + 1]
            if next_seg:
                if idx == len(self.parameter_names) - 1:
                    suffix_pos = len(query) - len(next_seg)
                    if suffix_pos < pos or not query.endswith(next_seg):
                        return {}
                    value = query[pos:suffix_pos]
                    pos = suffix_pos + len(next_seg)
                else:
                    next_idx = query.find(next_seg, pos)
                    if next_idx < 0:
                        return {}
                    value = query[pos:next_idx]
                    pos = next_idx + len(next_seg)
            else:
                value = query[pos:]
                pos = len(query)

            if not value.strip():
                return {}

            if parameter_name not in arguments:
                arguments[parameter_name] = ParameterValue(
                    parameter_name=parameter_name,
                    value=value,
                    confidence=0.99,
                    method=ParameterExtractionMethod.TEMPLATE,
                )

        return arguments


class ParameterExtractor:
    """统一参数提取器，内置模板编译缓存。"""

    def __init__(self, max_cache_size: int = 256) -> None:
        self.max_cache_size = max_cache_size
        self._cache: "OrderedDict[str, CompiledTemplate]" = OrderedDict()

    def _get_compiled(self, template: str) -> CompiledTemplate:
        normalized = normalize_template(template)
        cached = self._cache.get(normalized)
        if cached is not None:
            self._cache.move_to_end(normalized)
            return cached
        compiled = CompiledTemplate.from_template(normalized)
        self._cache[normalized] = compiled
        if len(self._cache) > self.max_cache_size:
            self._cache.popitem(last=False)
        return compiled

    def extract(self, template: str, query: str) -> Dict[str, ParameterValue]:
        if not template or not query:
            return {}
        return self._get_compiled(template).extract(query)

    def extract_by_template(
        self, template: str, query: str
    ) -> Dict[str, ParameterValue]:
        return self.extract(template, query)

    def batch_extract(
        self, templates: List[str], queries: List[str]
    ) -> List[Dict[str, ParameterValue]]:
        return [
            self.extract(template, query) for template, query in zip(templates, queries)
        ]


class ParamTemplate(BaseModel):
    """
    参数模板，封装带占位参数的字符串。

    统一格式：`${parameter_name}`
    """

    template: str = Field(..., description="模板字符串，包含参数占位符。")
    parameter_names: List[str] = Field(
        default_factory=list,
        description="模板里的参数名称列表。",
    )

    @field_validator("template")
    @classmethod
    def validate_template(cls, v: str) -> str:
        if not v or not isinstance(v, str):
            raise ValueError("Template must be a non-empty string")
        return v

    def __init__(
        self,
        template: str,
        parameter_names: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        template = normalize_template(template)
        if parameter_names is None:
            parameter_names = ParamTemplate._extract_parameter_names(template)
        super().__init__(template=template, parameter_names=parameter_names, **kwargs)

    @staticmethod
    def _extract_parameter_names(template: str) -> List[str]:
        utg_parameters = re.findall(r"\$\{(\w+)\}", template)
        return sorted(list(set(utg_parameters)))

    def get_parameter_names(self) -> List[str]:
        if self.parameter_names:
            return self.parameter_names
        return self._extract_parameter_names(self.template)

    def has_parameters(self) -> bool:
        return len(self.get_parameter_names()) > 0

    def render(self, arguments: Dict[str, Any], strict: bool = False) -> str:
        """Render one template with concrete arguments."""
        result = normalize_template(self.template)
        parameter_names = self.get_parameter_names()
        missing_parameters = set(parameter_names) - set(arguments.keys())
        if missing_parameters and strict:
            raise ValueError(f"Missing required parameters: {missing_parameters}")
        for parameter_name in parameter_names:
            value = arguments.get(parameter_name, "")
            if value is None:
                value = ""
            result = result.replace(f"${{{parameter_name}}}", str(value))
        return result

    def render_nullable(
        self, arguments: Dict[str, Any], strict: bool = False
    ) -> Optional[str]:
        if not self.template:
            return None
        try:
            return self.render(arguments, strict)
        except Exception as e:
            logger.warning("Failed to render template: %s", e)
            return self.template

    def to_compiler_format(self) -> str:
        return self.template

    def to_utg_format(self) -> str:
        return normalize_template(self.template)

    def validate_arguments(self, arguments: Dict[str, Any]) -> Dict[str, str]:
        """Return one string-only argument map aligned to template parameters."""
        validated = {}
        for parameter_name in self.get_parameter_names():
            if parameter_name in arguments:
                value = arguments[parameter_name]
                validated[parameter_name] = str(value) if value is not None else ""
            else:
                validated[parameter_name] = ""
        return validated

    def __str__(self) -> str:
        return self.template

    def __repr__(self) -> str:
        parameters_str = (
            ", ".join(self.get_parameter_names())
            if self.has_parameters()
            else "no parameters"
        )
        return (
            f"ParamTemplate(template='{self.template}', parameters=[{parameters_str}])"
        )


class ParamRenderer:
    """参数渲染器，用于渲染带参数模板的字符串和动作。"""

    @staticmethod
    def render(template: str, arguments: Dict[str, Any], strict: bool = False) -> str:
        parameter_template = ParamTemplate(template=template)
        return parameter_template.render(arguments, strict)

    @staticmethod
    def render_nullable(
        template: Optional[str],
        arguments: Dict[str, Any],
        strict: bool = False,
    ) -> Optional[str]:
        if template is None or not template:
            return template
        return ParamRenderer.render(template, arguments, strict)

    @staticmethod
    def render_actions(
        actions: List[Any],
        arguments: Dict[str, Any],
        strict: bool = False,
    ) -> List[Any]:
        rendered_actions = []
        for action in actions:
            if not isinstance(action, AnyAction):
                rendered_actions.append(action)
                continue
            rendered_action = action.model_copy(deep=True)
            action_type = type(action).__name__
            try:
                if hasattr(rendered_action, "params"):
                    params = rendered_action.params
                    if action_type == "TypeAction" and hasattr(params, "text"):
                        params.text = ParamRenderer.render(
                            params.text, arguments, strict
                        )
                    elif action_type == "FinishedAction":
                        if hasattr(params, "content"):
                            params.content = ParamRenderer.render_nullable(
                                params.content, arguments, strict
                            )
                        if hasattr(params, "summaryPrompt"):
                            params.summaryPrompt = ParamRenderer.render_nullable(
                                params.summaryPrompt, arguments, strict
                            )
                rendered_actions.append(rendered_action)
            except Exception as e:
                logger.warning("Failed to render action %s: %s", action_type, e)
                rendered_actions.append(action)
        return rendered_actions
