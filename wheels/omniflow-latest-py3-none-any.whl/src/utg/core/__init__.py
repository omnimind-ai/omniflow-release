# utg/core: 核心数据模型（models, actions, triggers）
#
# NOTE:
# Keep this package init lightweight to avoid circular imports:
# core.params -> core.actions -> core.__init__ -> models -> core.params.
__all__ = [
    # models
    "AppInfo",
    "Function",
    "NodeRepr",
    "Suggestion",
    "UTGGraph",
    "UTGNode",
    # graph_runtime
    "UTGGraphRuntime",
    "FunctionEdge",
    "PathResult",
    "build_graph_runtime",
]


def __getattr__(name: str):
    if name in {
        "AppInfo",
        "Function",
        "NodeRepr",
        "Suggestion",
        "UTGGraph",
        "UTGNode",
    }:
        from . import models as _models

        return getattr(_models, name)
    if name in {
        "UTGGraphRuntime",
        "FunctionEdge",
        "PathResult",
        "build_graph_runtime",
    }:
        from . import graph_runtime as _graph_runtime

        return getattr(_graph_runtime, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
