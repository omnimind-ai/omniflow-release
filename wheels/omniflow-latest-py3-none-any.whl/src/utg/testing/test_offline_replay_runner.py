from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from src.utg.core.actions import (
    CallFunctionAction,
    CallFunctionParams,
    ClickAction,
)
from src.utg.core.models import (
    Function,
    NodeRepr,
    UTGGraph,
    UTGNode,
)
from src.utg.execution.protocol import DeviceObservation
from src.utg.runtime.utg_runtime import UTGRuntime
from src.utg.testing.offline_replay import (
    OFFLINE_REPLAY_DATA_ROOT,
    RecordingPort,
    build_main_action_frames_from_run_log,
    discover_offline_replay_cases,
    run_offline_replay_case,
    write_offline_replay_case,
)

_REPLAY_CASES = discover_offline_replay_cases()


class _StepwiseOperator:
    def __init__(self, xmls: list[str], package: str = "com.test.app") -> None:
        self._xmls = list(xmls)
        self._package = package
        self._index = 0

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs,
    ):
        del screenshot, kwargs
        current_xml = self._xmls[min(self._index, len(self._xmls) - 1)]
        return DeviceObservation(
            xml=current_xml if xml else None,
            package_name=self._package if app_info else None,
            activity_name="TestActivity" if app_info else None,
        )

    async def act(self, action_payload, *, observation=None, **kwargs):
        del action_payload, observation, kwargs
        if self._index < len(self._xmls) - 1:
            self._index += 1
        return {"success": True}


def _write_utg_case_file(case_dir: Path, utg_graph: UTGGraph) -> Path:
    utg_path = case_dir / "source_utg.json"
    utg_path.write_text(
        json.dumps(
            utg_graph.model_dump(exclude_none=True, by_alias=True),
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return utg_path


def _build_multi_action_utg() -> UTGGraph:
    xml_1 = "<hierarchy><node text='home' resource-id='id/home'/></hierarchy>"
    node = UTGNode(
        id="n1",
        repr=NodeRepr(
            xmls=[xml_1],
            packageName="com.test.app",
            description="home",
        ),
        functions={
            "s1": Function(
                name="s1",
                description="two_clicks",
                actions=[
                    ClickAction(type="click", params={"x": 10, "y": 20}),
                    ClickAction(type="click", params={"x": 30, "y": 40}),
                ],
            )
        },
    )
    composite_func = Function(
        name="p1",
        description="two_clicks",
        actions=[
            CallFunctionAction(
                type="call_function",
                params=CallFunctionParams(node_id="n1", function_name="s1"),
            )
        ],
        start_node_id="n1",
        metadata={"function_type": "composite", "entry_point": True},
    )
    return UTGGraph(
        version="1.0.0",
        appInfo=[],
        nodes=[node],
        functions={"p1": composite_func},
    )


def _build_single_action_utg() -> UTGGraph:
    xml_1 = (
        "<hierarchy><node text='control-page' resource-id='id/control'/></hierarchy>"
    )
    node = UTGNode(
        id="n1",
        repr=NodeRepr(
            xmls=[xml_1],
            packageName="com.test.app",
            description="control-page",
        ),
        functions={
            "s1": Function(
                name="s1",
                description="single_click",
                actions=[ClickAction(type="click", params={"x": 30, "y": 45})],
            )
        },
    )
    composite_func = Function(
        name="p1",
        description="autodevice_click",
        actions=[
            CallFunctionAction(
                type="call_function",
                params=CallFunctionParams(node_id="n1", function_name="s1"),
            )
        ],
        start_node_id="n1",
        metadata={"function_type": "composite", "entry_point": True},
    )
    return UTGGraph(
        version="1.0.0",
        appInfo=[],
        nodes=[node],
        functions={"p1": composite_func},
    )


@pytest.mark.parametrize("case", _REPLAY_CASES, ids=lambda case: case.case_id)
def test_offline_replay_case_runs_through_real_base_agent(case, tmp_path: Path) -> None:
    trace_path = tmp_path / f"{case.trace_id}_execution.jsonl"
    summary = run_offline_replay_case(case, execution_trace_path=trace_path)
    expected = dict(case.expected)

    assert summary["done"] is bool(expected["done"])
    assert summary["data"]["source"] == expected["source"]
    assert summary["data"]["function_id"] == expected["function_id"]
    assert summary["data"]["action"]["status"] == expected["action_status"]
    assert summary["data"]["terminal_state"]["terminal_page_reached"] is expected.get(
        "terminal_page_reached"
    )
    assert summary["action_types"] == list(expected["action_types"])
    assert summary["events_consumed"] == summary["events_total"]
    assert summary["execution_trace_path"] == str(trace_path.resolve())
    assert summary["execution_event_count"] > 0
    assert isinstance(summary["control_plane_ids"], list)


def test_offline_replay_task_can_hold_multiple_traces() -> None:
    case_ids = [
        case.case_id for case in _REPLAY_CASES if case.task_id == "demo_open_settings"
    ]

    assert case_ids == [
        "demo_open_settings/trace_001",
        "demo_open_settings/trace_002",
    ]
    assert (OFFLINE_REPLAY_DATA_ROOT / "demo_open_settings").exists()


def test_androidworld_contacts_add_contact_live_run_refs_are_pinned() -> None:
    refs_path = (
        OFFLINE_REPLAY_DATA_ROOT
        / "androidworld_contacts_add_contact"
        / "live_run_refs.json"
    )
    payload = json.loads(refs_path.read_text(encoding="utf-8"))
    runs = list(payload.get("runs") or [])

    assert payload["task_id"] == "ContactsAddContact"
    assert len(runs) == 3
    assert [run["run_id"] for run in runs] == [
        "run_20260325T222804914939",
        "run_20260325T231208474496",
        "run_20260326T005738428454",
    ]
    assert [run["label"] for run in runs] == [
        "m3a_native",
        "utg_only",
        "autodevice_native",
    ]
    assert [run["is_successful"] for run in runs] == [1.0, 1.0, 0.0]


def test_androidworld_open_app_contacts_live_run_refs_are_pinned() -> None:
    refs_path = (
        OFFLINE_REPLAY_DATA_ROOT
        / "androidworld_open_app_contacts"
        / "live_run_refs.json"
    )
    payload = json.loads(refs_path.read_text(encoding="utf-8"))
    runs = list(payload.get("runs") or [])

    assert payload["task_id"] == "OpenAppTaskEval"
    assert len(runs) == 2
    assert [run["run_id"] for run in runs] == [
        "6d7643fd-63ad-4f2d-b7a7-b57f7f806c38",
        "42a48b63-7075-444a-839c-65197fb0cbd0",
    ]
    assert [run["label"] for run in runs] == [
        "native_step_source_run",
        "raw_replay_live_replay",
    ]
    assert [run["is_successful"] for run in runs] == [1.0, 1.0]


def test_build_main_action_frames_from_run_log_supports_generic_step_fallback() -> None:
    run_log = {
        "steps": [
            {
                "step_index": 0,
                "act_source": "native_step",
                "observation_before_act": {
                    "xml": "<hierarchy><node text='home'/></hierarchy>",
                    "package_name": "com.test.app",
                    "activity_name": "Main",
                },
                "plan": {
                    "tool_name": "click",
                    "tool_args": {"x": 10, "y": 20},
                },
                "provider_detail": {},
            }
        ]
    }

    frames = build_main_action_frames_from_run_log(run_log)

    assert len(frames) == 1
    assert frames[0]["act_source"] == "native_step"
    assert (
        frames[0]["before_observation"]["xml"]
        == "<hierarchy><node text='home'/></hierarchy>"
    )
    assert frames[0]["expected_action"] == {
        "type": "click",
        "params": {"x": 10, "y": 20},
    }
    assert frames[0]["meta"]["frame_source"] == "step_plan_tool_args"


def test_build_main_action_frames_from_run_log_prefers_provider_main_action_frames() -> (
    None
):
    run_log = {
        "steps": [
            {
                "step_index": 0,
                "act_source": "autodevice_step",
                "observation_before_act": {
                    "xml": "<hierarchy><node text='step-home'/></hierarchy>",
                    "package_name": "com.test.app",
                    "activity_name": "Main",
                },
                "plan": {"tool_name": "", "tool_args": {}},
                "provider_detail": {
                    "main_action_frames": [
                        {
                            "before_observation": {
                                "xml": "<hierarchy><node text='control-home'/></hierarchy>",
                                "package_name": "com.test.app",
                                "activity_name": "Main",
                            },
                            "executed_action": {
                                "type": "click",
                                "params": {"x": 30, "y": 45},
                            },
                            "formal_action": {
                                "type": "click",
                                "params": {"x": 999, "y": 999},
                            },
                            "function_id": "f_control_click",
                        }
                    ]
                },
            }
        ]
    }

    frames = build_main_action_frames_from_run_log(run_log)

    assert len(frames) == 1
    assert frames[0]["act_source"] == "autodevice_step"
    assert (
        frames[0]["before_observation"]["xml"]
        == "<hierarchy><node text='control-home'/></hierarchy>"
    )
    assert frames[0]["expected_action"] == {
        "type": "click",
        "params": {"x": 30, "y": 45},
    }
    assert frames[0]["function_id"] == "f_control_click"
    assert frames[0]["meta"]["frame_source"] == "provider_main_action_frames"


def test_main_action_frames_case_runs_through_real_base_agent(tmp_path: Path) -> None:
    utg_graph = _build_multi_action_utg()
    source_dir = tmp_path / "build"
    source_dir.mkdir(parents=True, exist_ok=True)
    utg_path = _write_utg_case_file(source_dir, utg_graph)
    runtime = UTGRuntime(filepath=None, utg_graph=utg_graph, enable_run_log=True)
    live_operator = _StepwiseOperator(
        [
            "<hierarchy><node text='home' resource-id='id/home'/></hierarchy>",
            "<hierarchy><node text='form' resource-id='id/form'/></hierarchy>",
            "<hierarchy><node text='done' resource-id='id/done'/></hierarchy>",
        ]
    )
    provider_result = asyncio.run(
        runtime.run_function(live_operator.observe, live_operator.act, "p1")
    )
    assert provider_result.success is True
    assert len(list(getattr(provider_result, "main_action_frames", None) or [])) == 2
    assert len(list(getattr(provider_result, "device_actions", None) or [])) == 2
    assert isinstance(getattr(provider_result, "provider_detail_summary", None), dict)
    canonical_run_log = {
        "run_id": "run_test_main_action_frames",
        "goal": "two_clicks",
        "success": True,
        "done_reason": "success",
        "steps": [
            {
                "step_index": 0,
                "act_source": "utg",
                "observation_before_act": {
                    "xml": "<hierarchy><node text='home' resource-id='id/home'/></hierarchy>",
                    "package_name": "com.test.app",
                    "activity_name": "TestActivity",
                },
                "plan": {
                    "tool_name": "p1",
                    "tool_args": {
                        "parameters": {
                            "type": "object",
                            "properties": {},
                            "required": [],
                            "additionalProperties": False,
                        },
                    },
                },
                "provider_detail": {
                    "function_id": "p1",
                    "main_action_frames": getattr(
                        provider_result, "main_action_frames", None
                    ),
                    "device_actions": getattr(provider_result, "device_actions", None),
                    "control_trace": getattr(provider_result, "control_trace", None),
                    "final_state": getattr(provider_result, "final_state", None),
                },
            }
        ],
    }
    case_dir = tmp_path / "offline" / "demo_utg_multi_action" / "trace_001"
    case = write_offline_replay_case(
        case_dir,
        goal="two_clicks",
        utg_path=utg_path,
        port_trace_path=None,
        replay_mode="main_action_frames",
        result_payload={
            "done": True,
            "data": {
                "source": "utg",
                "function_id": "p1",
                "action": {"status": "complete"},
                "terminal_state": {"terminal_page_reached": False},
                "run_log": canonical_run_log,
            },
        },
        match_scope=["p1"],
        max_steps=1,
        runtime_env={"UTG_EXPLICIT_TERMINAL_NODE_VERIFY": "0"},
    )

    summary = run_offline_replay_case(case)

    assert case.replay_mode == "main_action_frames"
    assert case.main_action_frames_path.exists()
    assert summary["done"] is True
    assert summary["data"]["source"] == "cache"
    assert summary["data"]["function_id"] == "p1"
    assert summary["action_types"] == ["click", "click"]
    assert summary["events_consumed"] == 2
    assert summary["events_total"] == 2


def test_main_action_frames_case_runs_from_controlled_executed_actions(
    tmp_path: Path,
) -> None:
    utg_graph = _build_single_action_utg()
    source_dir = tmp_path / "build_autodevice"
    source_dir.mkdir(parents=True, exist_ok=True)
    utg_path = _write_utg_case_file(source_dir, utg_graph)
    canonical_run_log = {
        "run_id": "run_test_controlled_executed_actions",
        "goal": "autodevice_click",
        "success": True,
        "done_reason": "success",
        "steps": [
            {
                "step_index": 0,
                "act_source": "autodevice_step",
                "observation_before_act": {
                    "xml": "<hierarchy><node text='unused-step-page'/></hierarchy>",
                    "package_name": "com.test.app",
                    "activity_name": "TestActivity",
                },
                "plan": {"tool_name": "", "tool_args": {}},
                "provider_detail": {
                    "main_action_frames": [
                        {
                            "before_observation": {
                                "xml": "<hierarchy><node text='control-page' resource-id='id/control'/></hierarchy>",
                                "package_name": "com.test.app",
                                "activity_name": "TestActivity",
                            },
                            "executed_action": {
                                "type": "click",
                                "params": {"x": 30, "y": 45},
                            },
                            "formal_action": {
                                "type": "click",
                                "params": {"x": 30, "y": 45},
                            },
                            "function_id": "p1",
                        }
                    ]
                },
            }
        ],
    }
    case_dir = tmp_path / "offline" / "demo_controlled_executed_actions" / "trace_001"
    case = write_offline_replay_case(
        case_dir,
        goal="autodevice_click",
        utg_path=utg_path,
        port_trace_path=None,
        replay_mode="main_action_frames",
        result_payload={
            "done": True,
            "data": {
                "source": "autodevice_step",
                "function_id": "",
                "action": {"status": "complete"},
                "terminal_state": {"terminal_page_reached": False},
                "run_log": canonical_run_log,
            },
        },
        match_scope=["p1"],
        max_steps=1,
        runtime_env={"UTG_EXPLICIT_TERMINAL_NODE_VERIFY": "0"},
    )

    summary = run_offline_replay_case(case)

    assert case.replay_mode == "main_action_frames"
    assert case.main_action_frames_path.exists()
    assert summary["done"] is True
    assert summary["data"]["source"] == "cache"
    assert summary["action_types"] == ["click"]
    assert summary["events_consumed"] == 1
    assert summary["events_total"] == 1


def test_write_offline_replay_case_preserves_unverified_terminal_state(
    tmp_path: Path,
) -> None:
    utg_graph = _build_single_action_utg()
    source_dir = tmp_path / "build_unverified"
    source_dir.mkdir(parents=True, exist_ok=True)
    utg_path = _write_utg_case_file(source_dir, utg_graph)
    port_trace_path = source_dir / "trace.jsonl"
    port_trace_path.write_text("", encoding="utf-8")

    case = write_offline_replay_case(
        tmp_path / "offline" / "demo_unverified" / "trace_001",
        goal="open settings",
        utg_path=utg_path,
        port_trace_path=port_trace_path,
        result_payload={
            "done": True,
            "data": {
                "source": "oob_vlm_task",
                "function_id": "",
                "action": {"status": "complete"},
                "terminal_state": {"terminal_page_reached": None},
                "run_log": {},
            },
        },
    )

    assert "terminal_page_reached" in case.expected
    assert case.expected["terminal_page_reached"] is None


@pytest.mark.asyncio
async def test_recording_port_writes_observe_and_act_transcript(tmp_path: Path) -> None:
    class _LiveOperator:
        async def observe(self, **kwargs):
            del kwargs
            return DeviceObservation(
                xml="<hierarchy><node text='settings'/></hierarchy>",
                package_name="com.test",
                activity_name="Main",
            )

        async def act(self, action, *, observation=None, **kwargs):
            del observation, kwargs
            return {"success": True, "type": getattr(action, "type", None)}

    trace_path = tmp_path / "port_trace.jsonl"
    port = RecordingPort(_LiveOperator(), trace_path)

    await port.observe(xml=True, app_info=True)
    await port.act(type("_Action", (), {"type": "finished", "params": {}})())

    lines = [
        line
        for line in trace_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(lines) == 2
    assert '"event": "observe"' in lines[0]
    assert '"event": "act"' in lines[1]
