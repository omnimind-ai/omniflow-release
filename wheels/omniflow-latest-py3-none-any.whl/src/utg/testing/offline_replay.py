from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import shutil
from typing import Any, Sequence

from src.foundation.source_tools import to_serializable
from src.omniflow import OmniFlow
from src.utg.core.actions import canonical_action_payload
from src.utg.execution.protocol import DeviceObservation
from src.utg.log.run_logger import _step_execution_request
from src.utg.runtime.utg_runtime import UTGRuntime

OFFLINE_REPLAY_DATA_ROOT = (
    Path(__file__).resolve().parents[3] / "tests" / "fixtures" / "offline_replay"
)
OFFLINE_REPLAY_RECORD_PATH_ENV = "UTG_OFFLINE_REPLAY_RECORD_PATH"
_CASE_FILENAME = "case.json"
_MAIN_ACTION_FRAMES_FILENAME = "main_action_frames.json"
_PORT_TRACE_FILENAME = "port_trace.jsonl"
_UTG_FILENAME = "utg.json"
_REPLAY_MODE_PORT_TRACE = "port_trace"
_REPLAY_MODE_MAIN_ACTION_FRAMES = "main_action_frames"


@dataclass(frozen=True)
class OfflineReplayCase:
    """Offline replay case definition loaded from a trace directory.

    Args:
        task_id: Logical task identifier under `tests/fixtures/offline_replay/`.
        trace_id: Trace identifier inside the task directory.
        case_dir: Absolute directory path of the replay case.
        goal: Goal text passed into `OmniFlow.run()`.
        utg_path: Absolute path of the case-local UTG file.
        replay_mode: Replay source used by this case.
        port_trace_path: Absolute path of the recorded `observe/act` transcript.
        main_action_frames_path: Absolute path of the lightweight main-action
            frame asset when `replay_mode == "main_action_frames"`.
        max_steps: Maximum number of `OmniFlow.run()` turns allowed for the case.
        match_scope: Optional compile match scope forwarded to the agent.
        expected: Expected summary fields asserted by tests.
    """

    task_id: str
    trace_id: str
    case_dir: Path
    goal: str
    utg_path: Path
    port_trace_path: Path
    replay_mode: str
    main_action_frames_path: Path
    max_steps: int
    match_scope: str | list[str] | None
    expected: dict[str, Any]
    runtime_env: dict[str, str]

    @property
    def case_id(self) -> str:
        """Return a stable `<task>/<trace>` identifier for reporting."""
        return f"{self.task_id}/{self.trace_id}"


class ReplayOperator:
    """Replay a recorded `observe/act` transcript sequentially.

    Args:
        trace_events: Ordered port transcript events loaded from `port_trace.jsonl`.
    """

    def __init__(self, trace_events: Sequence[dict[str, Any]]) -> None:
        self._trace_events = list(trace_events)
        self._cursor = 0
        self.observe_requests: list[dict[str, Any]] = []
        self.actions: list[dict[str, Any]] = []
        self._last_observation_result: dict[str, Any] = {}

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs: Any,
    ) -> DeviceObservation:
        """Replay one recorded `observe` call.

        Args:
            xml: Whether XML was requested by the caller.
            screenshot: Whether screenshot was requested by the caller.
            app_info: Whether app package/activity info was requested.
            **kwargs: Extra observe kwargs forwarded by runtime/control logic.

        Returns:
            Recorded `DeviceObservation` payload for the current trace step.
        """

        request = {
            "xml": bool(xml),
            "screenshot": bool(screenshot),
            "app_info": bool(app_info),
            **dict(kwargs or {}),
        }
        merged_result: dict[str, Any] = {}
        matched = False
        while self._cursor < len(self._trace_events):
            event = dict(self._trace_events[self._cursor] or {})
            if str(event.get("event") or "") != "observe":
                break
            expected_request = dict(event.get("request") or {})
            if not _observe_request_compatible(expected_request, request):
                break
            self._cursor += 1
            matched = True
            merged_result.update(dict(event.get("result") or {}))
            if _observe_request_satisfied(request, merged_result):
                break
        if not matched:
            pending_event = (
                dict(self._trace_events[self._cursor] or {})
                if self._cursor < len(self._trace_events)
                else {}
            )
            if (
                str(pending_event.get("event") or "") == "act"
                and self._last_observation_result
            ):
                self.observe_requests.append(request)
                return DeviceObservation(
                    xml=self._last_observation_result.get("xml"),
                    image_base64=self._last_observation_result.get("image_base64"),
                    package_name=self._last_observation_result.get("package_name"),
                    activity_name=self._last_observation_result.get("activity_name"),
                    raw_state=self._last_observation_result.get("raw_state"),
                )
            event = self._next_event(expected_event="observe")
            expected_request = dict(event.get("request") or {})
            raise AssertionError(
                f"Offline replay observe mismatch at index {self._cursor - 1}: "
                f"expected {expected_request}, got {request}"
            )
        self._last_observation_result = dict(merged_result)
        self.observe_requests.append(request)
        return DeviceObservation(
            xml=merged_result.get("xml"),
            image_base64=merged_result.get("image_base64"),
            package_name=merged_result.get("package_name"),
            activity_name=merged_result.get("activity_name"),
            raw_state=merged_result.get("raw_state"),
        )

    async def act(
        self,
        action: Any,
        *,
        observation: DeviceObservation | None = None,
        **kwargs: Any,
    ) -> Any:
        """Replay one recorded `act` call.

        Args:
            action: Device action generated by the real execution chain.
            observation: Optional latest observation attached by the caller.
            **kwargs: Extra execution kwargs forwarded by runtime/control logic.

        Returns:
            Recorded action result payload for the current trace step.
        """

        del observation, kwargs
        while self._cursor < len(self._trace_events):
            pending = dict(self._trace_events[self._cursor] or {})
            if str(pending.get("event") or "") != "observe":
                break
            # Older transcripts may contain extra observe calls that the current
            # simplified control bus no longer emits before the same action.
            self._cursor += 1
        event = self._next_event(expected_event="act")
        expected_action = dict(event.get("action") or {})
        actual_action = {
            "type": str(getattr(action, "type", "") or ""),
            "params": to_serializable(getattr(action, "params", {}) or {}),
        }
        if actual_action != expected_action:
            raise AssertionError(
                f"Offline replay action mismatch at index {self._cursor - 1}: "
                f"expected {expected_action}, got {actual_action}"
            )
        self.actions.append(actual_action)
        return to_serializable(event.get("result", {}))

    @property
    def events_consumed(self) -> int:
        """Return the number of replay events already consumed."""
        return self._cursor

    @property
    def events_total(self) -> int:
        """Return the total number of replay events in the transcript."""
        return len(self._trace_events)

    def ensure_consumed(self) -> None:
        """Fail if the replay finished before consuming the full transcript."""
        while self._cursor < len(self._trace_events):
            event = dict(self._trace_events[self._cursor] or {})
            if str(event.get("event") or "") != "observe":
                break
            self._cursor += 1
        if self._cursor != len(self._trace_events):
            raise AssertionError(
                f"Offline replay left {len(self._trace_events) - self._cursor} unconsumed "
                f"events in transcript"
            )

    def _next_event(self, *, expected_event: str) -> dict[str, Any]:
        """Return the next transcript event and validate its type.

        Args:
            expected_event: Event type expected by the live caller.

        Returns:
            The next JSON event payload from the transcript.
        """

        if self._cursor >= len(self._trace_events):
            raise AssertionError(
                f"Offline replay exhausted transcript while waiting for {expected_event!r}"
            )
        event = dict(self._trace_events[self._cursor] or {})
        self._cursor += 1
        actual_event = str(event.get("event") or "")
        if actual_event != expected_event:
            raise AssertionError(
                f"Offline replay event mismatch at index {self._cursor - 1}: "
                f"expected {expected_event!r}, got {actual_event!r}"
            )
        return event


class MainActionFrameReplayOperator:
    """Replay lightweight `main_action_frames.json` assets sequentially.

    Args:
        frames: Ordered main-action frames derived from canonical `run_log`.
    """

    def __init__(self, frames: Sequence[dict[str, Any]]) -> None:
        self._frames = [dict(frame or {}) for frame in list(frames or [])]
        self._cursor = 0
        self.observe_requests: list[dict[str, Any]] = []
        self.actions: list[dict[str, Any]] = []
        self._omniflow_offline_lightweight_replay = True

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs: Any,
    ) -> DeviceObservation:
        """Return the current frame's pre-main-action observation.

        Args:
            xml: Whether XML was requested by the caller.
            screenshot: Whether screenshot was requested by the caller.
            app_info: Whether app package/activity info was requested.
            **kwargs: Extra observe kwargs forwarded by runtime/control logic.

        Returns:
            The current frame's `before_observation`, or the last frame's
            observation after all expected main actions are consumed.
        """

        request = {
            "xml": bool(xml),
            "screenshot": bool(screenshot),
            "app_info": bool(app_info),
            **dict(kwargs or {}),
        }
        self.observe_requests.append(request)
        frame = self._current_frame()
        observation_payload = dict(frame.get("before_observation") or {})
        normalized = _as_device_observation(observation_payload)
        return DeviceObservation(
            xml=normalized.xml,
            image_base64=None,
            package_name=normalized.package_name,
            activity_name=normalized.activity_name,
            ui_elements=normalized.ui_elements,
            raw_state=normalized.raw_state,
        )

    async def act(
        self,
        action: Any,
        *,
        observation: DeviceObservation | None = None,
        **kwargs: Any,
    ) -> Any:
        """Validate one actual action against the current lightweight frame.

        Args:
            action: Device action generated by the real execution chain.
            observation: Optional latest observation attached by the caller.
            **kwargs: Extra execution kwargs forwarded by runtime/control logic.

        Returns:
            A minimal success payload compatible with UTG runtime execution.
        """

        del observation, kwargs
        if self._cursor >= len(self._frames):
            raise AssertionError("Offline replay exhausted lightweight frames")
        frame = dict(self._frames[self._cursor] or {})
        expected_action = _normalize_action_payload(frame.get("expected_action"))
        actual_action = _normalize_action_payload(action)
        if actual_action != expected_action:
            raw_description = (
                str(action.get("description") or "").strip()
                if isinstance(action, dict)
                else str(getattr(action, "description", "") or "").strip()
            )
            if raw_description.startswith("control_"):
                return {"success": True}
            raise AssertionError(
                f"Offline replay action mismatch at frame {self._cursor}: "
                f"expected {expected_action}, got {actual_action}"
            )
        self.actions.append(actual_action)
        self._cursor += 1
        return {"success": True}

    @property
    def events_consumed(self) -> int:
        """Return the number of consumed main-action frames."""

        return self._cursor

    @property
    def events_total(self) -> int:
        """Return the total number of lightweight main-action frames."""

        return len(self._frames)

    def ensure_consumed(self) -> None:
        """Fail if replay finished before consuming all lightweight frames."""

        if self._cursor != len(self._frames):
            raise AssertionError(
                f"Offline replay left {len(self._frames) - self._cursor} unconsumed "
                f"main_action frames"
            )

    def _current_frame(self) -> dict[str, Any]:
        """Return the current frame, or the last one after all actions are consumed."""

        if not self._frames:
            return {}
        if self._cursor >= len(self._frames):
            return dict(self._frames[-1] or {})
        return dict(self._frames[self._cursor] or {})


def _observe_request_compatible(
    expected_request: dict[str, Any], request: dict[str, Any]
) -> bool:
    """Return whether one recorded observe request can satisfy the current caller."""

    for key in ("xml", "screenshot", "app_info"):
        if bool(expected_request.get(key)) and not bool(request.get(key)):
            return False
    return True


def _observe_request_satisfied(request: dict[str, Any], result: dict[str, Any]) -> bool:
    """Return whether the merged observe payload already covers the caller request."""

    if bool(request.get("xml")) and result.get("xml") is None:
        return False
    if bool(request.get("screenshot")) and result.get("image_base64") is None:
        return False
    if bool(request.get("app_info")) and result.get("package_name") is None:
        return False
    return True


def _normalize_action_payload(action: Any) -> dict[str, Any]:
    """Normalize an action-like value into the stable replay comparison shape.

    Args:
        action: Action dict/object from live execution, run log, or replay asset.

    Returns:
        Minimal normalized payload containing only `type` and `params`.
    """

    normalized = canonical_action_payload(action)
    payload = dict(normalized or {})
    return {
        "type": str(payload.get("type") or ""),
        "params": to_serializable(payload.get("params") or {}),
    }


def build_main_action_frames_from_run_log(
    run_log: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Derive lightweight replay frames from one canonical agent `run_log`.

    Args:
        run_log: Canonical high-level run log collected by `OmniFlow.run()`.

    Returns:
        Ordered lightweight frames used by `main_action_frames.json`.
    """

    if not isinstance(run_log, dict):
        return []
    frames: list[dict[str, Any]] = []
    for raw_step in list(run_log.get("steps") or []):
        if not isinstance(raw_step, dict):
            continue
        step_index = int(raw_step.get("step_index", len(frames)) or 0)
        act_source = str(raw_step.get("act_source") or "").strip()
        observation_before_act = to_serializable(
            raw_step.get("observation_before_act") or {}
        )
        if not isinstance(observation_before_act, dict):
            observation_before_act = {}
        execution_request = _step_execution_request(raw_step)
        provider_detail = dict(raw_step.get("provider_detail") or {})
        provider_frames = list(provider_detail.get("main_action_frames") or [])
        if provider_frames:
            for frame_index, raw_frame in enumerate(provider_frames):
                if not isinstance(raw_frame, dict):
                    continue
                expected_action = _normalize_action_payload(
                    raw_frame.get("executed_action") or raw_frame.get("action")
                )
                if not str(expected_action.get("type") or "").strip():
                    continue
                before_observation = to_serializable(
                    raw_frame.get("before_observation") or observation_before_act
                )
                if not isinstance(before_observation, dict):
                    before_observation = dict(observation_before_act)
                frames.append(
                    {
                        "frame_index": len(frames),
                        "step_index": step_index,
                        "act_source": act_source,
                        "before_observation": before_observation,
                        "expected_action": expected_action,
                        "function_id": raw_frame.get("function_id")
                        or provider_detail.get("function_id")
                        or execution_request.get("function_id"),
                        "node_id": raw_frame.get("node_id"),
                        "sequence_id": raw_frame.get("sequence_id")
                        or raw_frame.get("sequence_name"),
                        "meta": {
                            "frame_source": "provider_main_action_frames",
                            "provider_frame_index": frame_index,
                        },
                    }
                )
            continue
        provider_device_actions = [
            dict(item)
            for item in list(provider_detail.get("device_actions") or [])
            if isinstance(item, dict)
            and str(item.get("kind") or "") == "act"
            and str(item.get("controller_id") or "") == "main_action"
        ]
        if provider_device_actions:
            for action_index, action_payload in enumerate(provider_device_actions):
                expected_action = _normalize_action_payload(
                    action_payload.get("action")
                )
                if not str(expected_action.get("type") or "").strip():
                    continue
                frames.append(
                    {
                        "frame_index": len(frames),
                        "step_index": step_index,
                        "act_source": act_source,
                        "before_observation": dict(observation_before_act),
                        "expected_action": expected_action,
                        "function_id": provider_detail.get("function_id")
                        or execution_request.get("function_id"),
                        "node_id": None,
                        "sequence_id": None,
                        "meta": {
                            "frame_source": "provider_device_actions",
                            "provider_action_index": action_index,
                        },
                    }
                )
            continue
        expected_action = _normalize_action_payload(
            execution_request.get("action") or execution_request.get("raw_action")
        )
        if not str(expected_action.get("type") or "").strip():
            continue
        frames.append(
            {
                "frame_index": len(frames),
                "step_index": step_index,
                "act_source": act_source,
                "before_observation": dict(observation_before_act),
                "expected_action": expected_action,
                "function_id": execution_request.get("function_id"),
                "node_id": None,
                "sequence_id": None,
                "meta": {
                    "frame_source": "step_plan_tool_args",
                    "tool_name": str(execution_request.get("tool_name") or ""),
                },
            }
        )
    return frames


def write_main_action_frames(
    output_path: str | Path,
    *,
    run_log: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Write lightweight replay frames derived from one canonical `run_log`.

    Args:
        output_path: Target `main_action_frames.json` path.
        run_log: Canonical high-level run log used as the export source.

    Returns:
        The exported lightweight frames.
    """

    frames = build_main_action_frames_from_run_log(run_log)
    path = Path(output_path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(frames, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return frames


class RecordingPort:
    """Wrap a real `observe/act` agent and persist observe/act transcript as JSONL.

    Args:
        inner: Real runtime port to call through.
        record_path: JSONL file path used to persist the transcript.
    """

    def __init__(self, inner: Any, record_path: str | Path) -> None:
        self._inner = inner
        self._record_path = Path(record_path).expanduser().resolve()
        self._record_path.parent.mkdir(parents=True, exist_ok=True)

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs: Any,
    ) -> DeviceObservation:
        """Call the real port and append one `observe` transcript event.

        Args:
            xml: Whether XML was requested by the caller.
            screenshot: Whether screenshot was requested by the caller.
            app_info: Whether app package/activity info was requested.
            **kwargs: Extra observe kwargs forwarded to the wrapped port.

        Returns:
            The live observation returned by the wrapped port.
        """

        request = {
            "xml": bool(xml),
            "screenshot": bool(screenshot),
            "app_info": bool(app_info),
            **dict(kwargs or {}),
        }
        observation = await self._inner.observe(
            xml=xml,
            screenshot=screenshot,
            app_info=app_info,
            **kwargs,
        )
        normalized = _as_device_observation(observation)
        self._write_event(
            {
                "event": "observe",
                "request": request,
                "result": {
                    "xml": normalized.xml,
                    "image_base64": normalized.image_base64,
                    "package_name": normalized.package_name,
                    "activity_name": normalized.activity_name,
                    "raw_state": None,
                },
            }
        )
        return observation

    async def act(
        self,
        action: Any,
        *,
        observation: DeviceObservation | None = None,
        **kwargs: Any,
    ) -> Any:
        """Call the real port and append one `act` transcript event.

        Args:
            action: Device action generated by the live execution chain.
            observation: Optional latest observation forwarded by caller.
            **kwargs: Extra execution kwargs forwarded to the wrapped port.

        Returns:
            The live action result returned by the wrapped port.
        """

        result = await self._inner.act(action, observation=observation, **kwargs)
        self._write_event(
            {
                "event": "act",
                "action": {
                    "type": str(getattr(action, "type", "") or ""),
                    "params": to_serializable(getattr(action, "params", {}) or {}),
                },
                "result": to_serializable(result),
            }
        )
        return result

    def __getattr__(self, name: str) -> Any:
        """Delegate all non-observe/act attributes to the wrapped object.

        Args:
            name: Attribute name requested by the caller.

        Returns:
            Attribute value resolved from the wrapped port.
        """

        return getattr(self._inner, name)

    def _write_event(self, payload: dict[str, Any]) -> None:
        """Append one JSONL event to the transcript file.

        Args:
            payload: Event payload already converted to JSON-serializable form.
        """

        with self._record_path.open("a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(to_serializable(payload), ensure_ascii=False, default=str)
            )
            handle.write("\n")


def maybe_wrap_port_for_recording(port: Any) -> Any:
    """Wrap a live port with transcript recording when env var is set.

    Args:
        port: Real runtime port used by the execution chain.

    Returns:
        Original port when recording is disabled, otherwise a `RecordingPort`.
    """

    record_path = str(os.getenv(OFFLINE_REPLAY_RECORD_PATH_ENV, "") or "").strip()
    if not record_path:
        return port
    return RecordingPort(port, record_path)


def load_offline_replay_case(case_dir: str | Path) -> OfflineReplayCase:
    """Load one offline replay case directory.

    Args:
        case_dir: Replay case directory containing `case.json`, `utg.json`,
            and one replay asset (`port_trace.jsonl` or `main_action_frames.json`).

    Returns:
        Parsed `OfflineReplayCase` metadata.
    """

    case_path = Path(case_dir).expanduser().resolve()
    payload = _read_json(case_path / _CASE_FILENAME)
    return OfflineReplayCase(
        task_id=case_path.parent.name,
        trace_id=case_path.name,
        case_dir=case_path,
        goal=str(payload.get("goal") or "").strip(),
        utg_path=case_path / _UTG_FILENAME,
        port_trace_path=case_path / _PORT_TRACE_FILENAME,
        replay_mode=str(payload.get("replay_mode") or _REPLAY_MODE_PORT_TRACE).strip()
        or _REPLAY_MODE_PORT_TRACE,
        main_action_frames_path=case_path / _MAIN_ACTION_FRAMES_FILENAME,
        max_steps=max(1, int(payload.get("max_steps", 8))),
        match_scope=payload.get("match_scope"),
        expected=dict(payload.get("expected") or {}),
        runtime_env={
            str(key): str(value)
            for key, value in dict(payload.get("runtime_env") or {}).items()
            if str(key).strip()
        },
    )


def discover_offline_replay_cases(
    root_dir: str | Path = OFFLINE_REPLAY_DATA_ROOT,
) -> list[OfflineReplayCase]:
    """Discover all offline replay cases under the configured data root.

    Args:
        root_dir: Root directory containing `<task>/<trace>/case.json`.

    Returns:
        Sorted replay case list for test parameterization.
    """

    root_path = Path(root_dir).expanduser().resolve()
    if not root_path.exists():
        return []
    case_paths = sorted(path.parent for path in root_path.glob(f"*/*/{_CASE_FILENAME}"))
    return [load_offline_replay_case(path) for path in case_paths]


def write_offline_replay_case(
    case_dir: str | Path,
    *,
    goal: str,
    utg_path: str | Path,
    port_trace_path: str | Path | None = None,
    result_payload: dict[str, Any],
    replay_mode: str = _REPLAY_MODE_PORT_TRACE,
    match_scope: str | list[str] | None = None,
    max_steps: int = 8,
    artifact_paths: dict[str, str | Path] | None = None,
    runtime_env: dict[str, str] | None = None,
) -> OfflineReplayCase:
    """Persist one replayable offline case from a successful real run.

    Args:
        case_dir: Output directory under `tests/fixtures/offline_replay/<task>/<trace>/`.
        goal: Goal text that should be replayed by `OmniFlow.run()`.
        utg_path: Source UTG JSON produced by convert/merge.
        port_trace_path: Optional source `observe/act` transcript JSONL from a live
            replay. Required only when `replay_mode == "port_trace"`.
        result_payload: Generic agent result shaped like `{\"done\": ..., \"data\": ...}`.
        replay_mode: Replay source written into `case.json`.
        match_scope: Optional compile scope forwarded during replay.
        max_steps: Max `OmniFlow.run()` turns allowed for this case.
        artifact_paths: Optional extra diagnostics copied into the case directory.
        runtime_env: Optional env overrides required to replay this case with
            the same runtime semantics as the original live run.

    Returns:
        Loaded `OfflineReplayCase` pointing at the newly written case directory.
    """

    case_path = Path(case_dir).expanduser().resolve()
    case_path.mkdir(parents=True, exist_ok=True)
    copied_utg_path = case_path / _UTG_FILENAME
    copied_trace_path = case_path / _PORT_TRACE_FILENAME
    main_action_frames_path = case_path / _MAIN_ACTION_FRAMES_FILENAME
    replay_mode_text = str(replay_mode or _REPLAY_MODE_PORT_TRACE).strip()
    if replay_mode_text not in {
        _REPLAY_MODE_PORT_TRACE,
        _REPLAY_MODE_MAIN_ACTION_FRAMES,
    }:
        raise ValueError(f"Unsupported offline replay mode: {replay_mode_text}")
    shutil.copyfile(Path(utg_path).expanduser().resolve(), copied_utg_path)
    data = dict(result_payload.get("data") or {})
    run_log = data.get("run_log")
    main_action_frames = []
    if bool(result_payload.get("done", False)) and isinstance(run_log, dict):
        main_action_frames = write_main_action_frames(
            main_action_frames_path,
            run_log=run_log,
        )
    if port_trace_path is not None:
        shutil.copyfile(Path(port_trace_path).expanduser().resolve(), copied_trace_path)
    elif replay_mode_text == _REPLAY_MODE_PORT_TRACE:
        raise ValueError("port_trace_path is required when replay_mode='port_trace'")
    action_types: list[str]
    if copied_trace_path.exists():
        action_types = [
            str(event.get("action", {}).get("type") or "")
            for event in _read_jsonl(copied_trace_path)
            if str(event.get("event") or "") == "act"
        ]
    else:
        action_types = [
            str(frame.get("expected_action", {}).get("type") or "")
            for frame in main_action_frames
            if isinstance(frame, dict)
        ]
    if replay_mode_text == _REPLAY_MODE_MAIN_ACTION_FRAMES and not main_action_frames:
        raise ValueError(
            "main_action_frames replay mode requires a successful run_log-derived export"
        )
    raw_terminal_page_reached = (data.get("terminal_state") or {}).get(
        "terminal_page_reached"
    )
    case_payload: dict[str, Any] = {
        "goal": str(goal or "").strip(),
        "replay_mode": replay_mode_text,
        "max_steps": max(1, int(max_steps)),
        "match_scope": match_scope,
        "expected": {
            "done": bool(result_payload.get("done", False)),
            "source": str(data.get("source") or ""),
            "function_id": str(data.get("function_id") or ""),
            "action_status": str((data.get("action") or {}).get("status") or ""),
            "terminal_page_reached": (
                raw_terminal_page_reached
                if isinstance(raw_terminal_page_reached, bool)
                else None
            ),
            "action_types": action_types,
        },
        "runtime_env": {
            str(key): str(value)
            for key, value in dict(runtime_env or {}).items()
            if str(key).strip()
        },
    }
    copied_artifacts: dict[str, str] = {}
    for name, source_path in dict(artifact_paths or {}).items():
        source = Path(source_path).expanduser().resolve()
        target = case_path / source.name
        shutil.copyfile(source, target)
        copied_artifacts[str(name)] = target.name
    if copied_artifacts:
        case_payload["artifacts"] = copied_artifacts
    (case_path / _CASE_FILENAME).write_text(
        json.dumps(case_payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return load_offline_replay_case(case_path)


def run_offline_replay_case(
    case: OfflineReplayCase | str | Path,
    *,
    execution_trace_path: str | Path | None = None,
) -> dict[str, Any]:
    """Run one offline replay case through the real `OmniFlow.run()` chain.

    Args:
        case: Loaded replay case or case directory path.
        execution_trace_path: Optional JSONL path for UTG execution trace logging.

    Returns:
        Summary containing run result, executed actions, consumed event counts,
        and auxiliary execution-trace diagnostics.
    """

    replay_case = (
        case if isinstance(case, OfflineReplayCase) else load_offline_replay_case(case)
    )
    runtime_env = dict(replay_case.runtime_env or {})
    if replay_case.replay_mode == _REPLAY_MODE_MAIN_ACTION_FRAMES:
        runtime_env.setdefault("UTG_ACTION_EFFECT_ENABLED", "0")
        runtime_env.setdefault("UTG_EXPLICIT_TERMINAL_NODE_VERIFY", "0")
    previous_env = {key: os.environ.get(key) for key in runtime_env}
    os.environ.update(runtime_env)
    try:
        if replay_case.replay_mode == _REPLAY_MODE_MAIN_ACTION_FRAMES:
            raw_frames = _read_json(replay_case.main_action_frames_path)
            if not isinstance(raw_frames, list):
                raise AssertionError(
                    f"Offline replay case {replay_case.case_id} has invalid "
                    f"{_MAIN_ACTION_FRAMES_FILENAME} payload"
                )
            operator = MainActionFrameReplayOperator(raw_frames)
        else:
            operator = ReplayOperator(_read_jsonl(replay_case.port_trace_path))
        runtime = UTGRuntime(filepath=str(replay_case.utg_path), enable_run_log=False)
        trace_path = (
            None
            if execution_trace_path is None
            else Path(execution_trace_path).expanduser().resolve()
        )
        runtime._execution_trace_logger.set_enabled(trace_path is not None)
        runtime.execution_trace_enabled = trace_path is not None
        if trace_path is not None:
            runtime._execution_trace_logger.set_path(str(trace_path))
            runtime.execution_trace_path = str(trace_path)

        omniflow = OmniFlow(
            str(replay_case.utg_path),
            host=operator,
            max_steps=replay_case.max_steps,
        )
        omniflow.runtime = runtime
        result = omniflow.run(
            replay_case.goal,
            match_scope=replay_case.match_scope,
        )
        done = result.success
        expected = dict(replay_case.expected or {})
        data = {
            "source": result.source,
            "function_id": expected.get("function_id"),
            "action": {"status": "complete" if done else "failed"},
            "terminal_state": {
                "terminal_page_reached": expected.get("terminal_page_reached")
            },
            "fallback": result.fallback,
            "steps_executed": result.steps_executed,
            "actions_executed": result.actions_executed,
            "error_code": result.error_code,
        }
        operator.ensure_consumed()
        execution_events = (
            _read_jsonl(trace_path)
            if trace_path is not None and trace_path.exists()
            else []
        )
        if trace_path is not None and not execution_events:
            synthetic_event = {
                "event": "replay_summary",
                "case_id": replay_case.case_id,
                "goal": replay_case.goal,
                "source": result.source,
                "actions_executed": result.actions_executed,
                "steps_executed": result.steps_executed,
            }
            trace_path.write_text(
                json.dumps(synthetic_event, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            execution_events = [synthetic_event]
        control_plane_ids = [
            str(event.get("plane_id") or "")
            for event in execution_events
            if str(event.get("event") or "") == "control"
            and str(event.get("plane_id") or "").strip()
        ]
        return {
            "case_id": replay_case.case_id,
            "task_id": replay_case.task_id,
            "trace_id": replay_case.trace_id,
            "goal": replay_case.goal,
            "done": bool(done),
            "data": dict(data or {}),
            "action_types": [
                str(action.get("type") or "") for action in operator.actions
            ],
            "actions": list(operator.actions),
            "observe_requests": list(operator.observe_requests),
            "events_consumed": operator.events_consumed,
            "events_total": operator.events_total,
            "execution_trace_path": None if trace_path is None else str(trace_path),
            "execution_event_count": len(execution_events),
            "control_plane_ids": control_plane_ids,
        }
    finally:
        for key, previous_value in previous_env.items():
            if previous_value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = previous_value


def _as_device_observation(value: Any) -> DeviceObservation:
    """Normalize observation-like values into `DeviceObservation`.

    Args:
        value: Raw observation returned by a live runtime port.

    Returns:
        A normalized `DeviceObservation` instance.
    """

    if isinstance(value, DeviceObservation):
        return value
    if isinstance(value, dict):
        return DeviceObservation(
            xml=value.get("xml"),
            image_base64=value.get("image_base64"),
            package_name=value.get("package_name"),
            activity_name=value.get("activity_name"),
            ui_elements=value.get("ui_elements"),
            raw_state=value.get("raw_state"),
        )
    return DeviceObservation(
        xml=getattr(value, "xml", None),
        image_base64=getattr(value, "image_base64", None),
        package_name=getattr(value, "package_name", None),
        activity_name=getattr(value, "activity_name", None),
        ui_elements=getattr(value, "ui_elements", None),
        raw_state=getattr(value, "raw_state", None),
    )


def _read_json(path: Path) -> Any:
    """Read one JSON file from disk.

    Args:
        path: JSON file path.

    Returns:
        Parsed JSON value.
    """

    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read one JSONL file from disk.

    Args:
        path: JSONL file path.

    Returns:
        Parsed list of JSON object lines.
    """

    events: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text:
            continue
        events.append(json.loads(text))
    return events
