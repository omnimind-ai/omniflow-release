from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any, Iterable, Sequence

from src.foundation.paths import get_runtime_dir
from src.foundation.source_tools import to_serializable
from src.utg.core.actions import canonical_action_payload
from src.utg.execution.control.error_codes import EXEC_ACTION_NO_EFFECT
from src.utg.execution.protocol import DeviceObservation, observations_equal
from src.utg.testing.offline_replay import (
    build_main_action_frames_from_run_log,
    discover_offline_replay_cases,
    load_offline_replay_case,
)

_NODE_MATCH_FILENAME = "node_match.jsonl"
_ACTION_EFFECT_FILENAME = "action_effect.jsonl"
_MANIFEST_FILENAME = "manifest.json"


def export_observation_benchmark_bundle(
    *,
    source_paths: Sequence[str | Path],
    output_dir: str | Path | None = None,
    benchmark_kind: str = "both",
    run_id: str | None = None,
) -> dict[str, Any]:
    """Export reusable observation benchmark rows from existing replay artifacts.

    Args:
        source_paths: Input run-log files or offline replay directories. Files may
            be single `run_log.json` payloads or `run_logs.jsonl` collections.
            Directories may be one replay case dir or an offline replay root.
        output_dir: Optional target bundle directory. The exporter appends into
            existing datasets and deduplicates by `sample_id`.
        benchmark_kind: `node_match`, `action_effect`, or `both`.
        run_id: Optional canonical run id filter used only for JSONL run-log files.

    Returns:
        Stable bundle manifest including output paths and added/total counts.
    """

    normalized_kind = str(benchmark_kind or "both").strip() or "both"
    if normalized_kind not in {"node_match", "action_effect", "both"}:
        raise ValueError(f"Unsupported benchmark kind: {benchmark_kind}")
    bundle_dir = (
        Path(output_dir).expanduser().resolve()
        if output_dir is not None
        else get_runtime_dir(
            "evals",
            "observation",
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f"),
        )
    )
    bundle_dir.mkdir(parents=True, exist_ok=True)
    node_match_path = bundle_dir / _NODE_MATCH_FILENAME
    action_effect_path = bundle_dir / _ACTION_EFFECT_FILENAME
    existing_node_rows = _load_jsonl(node_match_path)
    existing_action_rows = _load_jsonl(action_effect_path)
    node_row_ids = {
        str(row.get("sample_id") or "").strip()
        for row in existing_node_rows
        if str(row.get("sample_id") or "").strip()
    }
    action_row_ids = {
        str(row.get("sample_id") or "").strip()
        for row in existing_action_rows
        if str(row.get("sample_id") or "").strip()
    }
    node_rows: list[dict[str, Any]] = list(existing_node_rows)
    action_rows: list[dict[str, Any]] = list(existing_action_rows)
    source_summaries: list[dict[str, Any]] = []
    node_added = 0
    action_added = 0

    for raw_source_path in list(source_paths or []):
        source_path = Path(raw_source_path).expanduser().resolve()
        if not source_path.exists():
            raise FileNotFoundError(source_path)
        export_payload = _extract_source_records(
            source_path,
            benchmark_kind=normalized_kind,
            run_id=run_id,
        )
        source_summaries.append(
            {
                "source_path": str(source_path),
                "source_kind": str(export_payload.get("source_kind") or ""),
                "node_match_count": len(export_payload.get("node_match_rows") or []),
                "action_effect_count": len(
                    export_payload.get("action_effect_rows") or []
                ),
            }
        )
        for row in list(export_payload.get("node_match_rows") or []):
            sample_id = str(row.get("sample_id") or "").strip()
            if not sample_id or sample_id in node_row_ids:
                continue
            node_rows.append(dict(row))
            node_row_ids.add(sample_id)
            node_added += 1
        for row in list(export_payload.get("action_effect_rows") or []):
            sample_id = str(row.get("sample_id") or "").strip()
            if not sample_id or sample_id in action_row_ids:
                continue
            action_rows.append(dict(row))
            action_row_ids.add(sample_id)
            action_added += 1

    if normalized_kind in {"node_match", "both"}:
        _write_jsonl(node_match_path, node_rows)
    if normalized_kind in {"action_effect", "both"}:
        _write_jsonl(action_effect_path, action_rows)

    manifest = {
        "success": True,
        "benchmark_kind": normalized_kind,
        "bundle_dir": str(bundle_dir),
        "node_match_path": str(node_match_path.resolve()),
        "action_effect_path": str(action_effect_path.resolve()),
        "node_match_added": int(node_added),
        "action_effect_added": int(action_added),
        "node_match_total": len(node_rows),
        "action_effect_total": len(action_rows),
        "run_id_filter": str(run_id or "").strip() or None,
        "sources": source_summaries,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    (bundle_dir / _MANIFEST_FILENAME).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return manifest


def score_node_match_benchmark(
    runtime: Any,
    dataset_path: str | Path,
    *,
    output_dir: str | Path | None = None,
    top_k: int = 3,
) -> dict[str, Any]:
    """Score node-match accuracy on one exported observation dataset.

    Args:
        runtime: Runtime exposing `match_node(...)` and `get_function_by_id(...)`.
        dataset_path: Bundle directory or direct `node_match.jsonl` file path.
        output_dir: Optional explicit report directory.
        top_k: Candidate cut used by `recall_at_k`.

    Returns:
        Summary payload written alongside a `per_case.jsonl` report.
    """

    rows = _load_jsonl(_resolve_dataset_file(dataset_path, kind="node_match"))
    per_case: list[dict[str, Any]] = []
    positive_cases = 0
    global_top1_hits = 0
    global_recall_hits = 0
    global_no_match_hits = 0
    function_scoped_cases = 0
    function_scoped_top1_hits = 0
    function_scoped_recall_hits = 0

    for row in rows:
        xml = str(row.get("xml") or "").strip()
        package_name = str(row.get("package_name") or "").strip()
        expected_node_id = str(row.get("expected_node_id") or "").strip()
        expected_function_id = str(row.get("expected_function_id") or "").strip()
        global_match = runtime.match_node(xml, package_name=package_name)
        global_debug = _snapshot_match_debug(runtime)
        global_candidates = _topk_node_ids(global_debug, top_k=top_k)
        global_match_id = (
            str(getattr(global_match, "id", "") or "").strip() if global_match else ""
        )
        if expected_node_id:
            positive_cases += 1
            if global_match_id == expected_node_id:
                global_top1_hits += 1
            if expected_node_id in global_candidates:
                global_recall_hits += 1
        elif not global_match_id:
            global_no_match_hits += 1

        function_scoped_match_id = ""
        function_scoped_candidates: list[str] = []
        if expected_function_id:
            func_obj = runtime.get_function_by_id(expected_function_id)
            # Extract node IDs from call_function actions
            function_node_ids = []
            if func_obj is not None:
                for action in getattr(func_obj, "actions", []) or []:
                    if getattr(action, "type", None) == "call_function":
                        params = getattr(action, "params", None)
                        if params:
                            node_id = getattr(params, "node_id", None)
                            if node_id:
                                function_node_ids.append(str(node_id))
            if function_node_ids:
                function_scoped_cases += 1
                function_match = runtime.match_node(
                    xml,
                    package_name=package_name,
                    path_node_ids=function_node_ids,
                )
                function_debug = _snapshot_match_debug(runtime)
                function_scoped_candidates = _topk_node_ids(function_debug, top_k=top_k)
                function_scoped_match_id = (
                    str(getattr(function_match, "id", "") or "").strip()
                    if function_match
                    else ""
                )
                if expected_node_id:
                    if function_scoped_match_id == expected_node_id:
                        function_scoped_top1_hits += 1
                    if expected_node_id in function_scoped_candidates:
                        function_scoped_recall_hits += 1

        per_case.append(
            {
                "sample_id": str(row.get("sample_id") or ""),
                "source_kind": str(row.get("source_kind") or ""),
                "source_ref": str(row.get("source_ref") or ""),
                "run_id": row.get("run_id"),
                "task_id": row.get("task_id"),
                "trace_id": row.get("trace_id"),
                "step_index": row.get("step_index"),
                "frame_index": row.get("frame_index"),
                "expected_node_id": expected_node_id or None,
                "expected_function_id": expected_function_id or None,
                "global_match_node_id": global_match_id or None,
                "global_candidate_node_ids": global_candidates,
                "function_scoped_match_node_id": function_scoped_match_id or None,
                "function_scoped_candidate_node_ids": function_scoped_candidates,
                "global_top1_correct": bool(
                    expected_node_id and global_match_id == expected_node_id
                ),
                "global_recall_hit": bool(
                    expected_node_id and expected_node_id in global_candidates
                ),
                "function_scoped_top1_correct": bool(
                    expected_node_id and function_scoped_match_id == expected_node_id
                ),
                "function_scoped_recall_hit": bool(
                    expected_node_id and expected_node_id in function_scoped_candidates
                ),
            }
        )

    summary = {
        "mode": "node_match",
        "case_count": len(rows),
        "positive_case_count": int(positive_cases),
        "top_k": int(max(1, top_k)),
        "global_top1_accuracy": _safe_rate(global_top1_hits, positive_cases),
        "global_recall_at_k": _safe_rate(global_recall_hits, positive_cases),
        "global_no_match_accuracy": _safe_rate(
            global_no_match_hits, max(0, len(rows) - positive_cases)
        ),
        "function_scoped_case_count": int(function_scoped_cases),
        "function_scoped_top1_accuracy": _safe_rate(
            function_scoped_top1_hits, function_scoped_cases
        ),
        "function_scoped_recall_at_k": _safe_rate(
            function_scoped_recall_hits, function_scoped_cases
        ),
    }
    return _write_report(summary, per_case, output_dir=output_dir, mode="node_match")


def score_action_effect_benchmark(
    dataset_path: str | Path,
    *,
    output_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Score the current action-effect detector on one exported dataset.

    Args:
        dataset_path: Bundle directory or direct `action_effect.jsonl` file path.
        output_dir: Optional explicit report directory.

    Returns:
        Summary payload written alongside a `per_case.jsonl` report.
    """

    rows = _load_jsonl(_resolve_dataset_file(dataset_path, kind="action_effect"))
    per_case: list[dict[str, Any]] = []
    positives = 0
    negatives = 0
    true_positive = 0
    true_negative = 0
    false_positive = 0
    false_negative = 0
    by_action_type: dict[str, dict[str, int]] = {}

    for row in rows:
        before = dict(row.get("before_observation") or {})
        after = dict(row.get("after_observation") or {})
        action_type = str(row.get("action_type") or "").strip() or "unknown"
        predicted = _observations_differ_payload(before, after)
        if not isinstance(row.get("expected_effect"), bool):
            continue
        expected = bool(row.get("expected_effect"))
        counters = by_action_type.setdefault(
            action_type,
            {"count": 0, "tp": 0, "tn": 0, "fp": 0, "fn": 0},
        )
        counters["count"] += 1
        if expected:
            positives += 1
            if predicted:
                true_positive += 1
                counters["tp"] += 1
            else:
                false_negative += 1
                counters["fn"] += 1
        else:
            negatives += 1
            if predicted:
                false_positive += 1
                counters["fp"] += 1
            else:
                true_negative += 1
                counters["tn"] += 1
        per_case.append(
            {
                "sample_id": str(row.get("sample_id") or ""),
                "source_kind": str(row.get("source_kind") or ""),
                "source_ref": str(row.get("source_ref") or ""),
                "run_id": row.get("run_id"),
                "task_id": row.get("task_id"),
                "trace_id": row.get("trace_id"),
                "step_index": row.get("step_index"),
                "frame_index": row.get("frame_index"),
                "action_type": action_type,
                "expected_effect": expected,
                "predicted_effect": bool(predicted),
                "match": bool(predicted == expected),
                "metadata": dict(row.get("metadata") or {}),
            }
        )

    summary = {
        "mode": "action_effect",
        "case_count": len(rows),
        "positive_case_count": int(positives),
        "negative_case_count": int(negatives),
        "accuracy": _safe_rate(true_positive + true_negative, len(rows)),
        "effect_precision": _safe_rate(true_positive, true_positive + false_positive),
        "effect_recall": _safe_rate(true_positive, positives),
        "no_effect_precision": _safe_rate(
            true_negative, true_negative + false_negative
        ),
        "false_positive_rate": _safe_rate(false_positive, negatives),
        "false_negative_rate": _safe_rate(false_negative, positives),
        "by_action_type": by_action_type,
    }
    return _write_report(
        summary,
        per_case,
        output_dir=output_dir,
        mode="action_effect",
    )


def _extract_source_records(
    source_path: Path,
    *,
    benchmark_kind: str,
    run_id: str | None,
) -> dict[str, Any]:
    """Extract benchmark rows from one source path with minimal format branching.

    Args:
        source_path: Existing source file or directory.
        benchmark_kind: `node_match`, `action_effect`, or `both`.
        run_id: Optional run id filter for canonical run-log JSONL sources.

    Returns:
        Dict containing `source_kind`, `node_match_rows`, and
        `action_effect_rows`.
    """

    node_match_rows: list[dict[str, Any]] = []
    action_effect_rows: list[dict[str, Any]] = []
    if source_path.is_dir():
        case_file = source_path / "case.json"
        if case_file.exists():
            node_rows, effect_rows = _extract_offline_replay_case_rows(
                source_path,
                benchmark_kind=benchmark_kind,
            )
            return {
                "source_kind": "offline_replay_case",
                "node_match_rows": node_rows,
                "action_effect_rows": effect_rows,
            }
        cases = discover_offline_replay_cases(source_path)
        if not cases:
            raise ValueError(f"Unsupported observation source directory: {source_path}")
        for case in cases:
            node_rows, effect_rows = _extract_offline_replay_case_rows(
                case.case_dir,
                benchmark_kind=benchmark_kind,
            )
            node_match_rows.extend(node_rows)
            action_effect_rows.extend(effect_rows)
        return {
            "source_kind": "offline_replay_root",
            "node_match_rows": node_match_rows,
            "action_effect_rows": action_effect_rows,
        }

    run_logs = _load_run_logs_from_file(source_path, run_id=run_id)
    if not run_logs:
        raise ValueError(f"No run logs found in observation source: {source_path}")
    for run_log in run_logs:
        node_rows, effect_rows = _extract_run_log_rows(
            run_log,
            source_ref=str(source_path),
            benchmark_kind=benchmark_kind,
        )
        node_match_rows.extend(node_rows)
        action_effect_rows.extend(effect_rows)
    return {
        "source_kind": "run_log",
        "node_match_rows": node_match_rows,
        "action_effect_rows": action_effect_rows,
    }


def _load_run_logs_from_file(
    source_path: Path,
    *,
    run_id: str | None,
) -> list[dict[str, Any]]:
    """Load one or more canonical run logs from JSON or JSONL files.

    Args:
        source_path: Source file path containing one run log or many JSONL rows.
        run_id: Optional run id filter applied to JSONL rows.

    Returns:
        Canonical run-log payload list.
    """

    if source_path.suffix.lower() == ".jsonl":
        rows = _load_jsonl(source_path)
        filtered_rows: list[dict[str, Any]] = []
        run_id_text = str(run_id or "").strip()
        for row in rows:
            if not _looks_like_run_log(row):
                continue
            if run_id_text and str(row.get("run_id") or "").strip() != run_id_text:
                continue
            filtered_rows.append(row)
        return filtered_rows
    payload = json.loads(source_path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        if _looks_like_run_log(payload):
            return [payload]
        nested = payload.get("run_log")
        if isinstance(nested, dict) and _looks_like_run_log(nested):
            return [nested]
    if isinstance(payload, list):
        return [dict(item) for item in payload if _looks_like_run_log(item)]
    return []


def _extract_run_log_rows(
    run_log: dict[str, Any],
    *,
    source_ref: str,
    benchmark_kind: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Extract node-match and action-effect rows from one canonical run log.

    Args:
        run_log: Canonical `run(goal)` payload.
        source_ref: Human-readable source path for traceability.
        benchmark_kind: `node_match`, `action_effect`, or `both`.

    Returns:
        Tuple of exported node-match rows and action-effect rows.
    """

    run_id = str(run_log.get("run_id") or "").strip() or None
    raw_steps = [
        dict(item)
        for item in list(run_log.get("steps") or [])
        if isinstance(item, dict)
    ]
    node_rows: list[dict[str, Any]] = []
    effect_rows: list[dict[str, Any]] = []
    all_frames = build_main_action_frames_from_run_log(run_log)
    frames_by_step: dict[int, list[dict[str, Any]]] = {}
    for frame in all_frames:
        step_index = int(frame.get("step_index", 0) or 0)
        frames_by_step.setdefault(step_index, []).append(dict(frame))

    for raw_step in raw_steps:
        step_index = int(raw_step.get("step_index", 0) or 0)
        step_frames = list(frames_by_step.get(step_index) or [])
        if not step_frames:
            continue
        final_observation = _step_final_observation(raw_step)
        for frame_offset, frame in enumerate(step_frames):
            if benchmark_kind in {"node_match", "both"}:
                row = _node_match_row_from_frame(
                    frame,
                    source_kind="run_log",
                    source_ref=source_ref,
                    run_id=run_id,
                )
                if row is not None:
                    node_rows.append(row)
            if benchmark_kind in {"action_effect", "both"}:
                raw_action_records = [
                    dict(item)
                    for item in list(
                        (
                            raw_step.get("provider_detail", {})
                            if isinstance(raw_step.get("provider_detail"), dict)
                            else {}
                        ).get("executed_actions")
                        or []
                    )
                    if isinstance(item, dict)
                ]
                after_observation = (
                    dict(step_frames[frame_offset + 1].get("before_observation") or {})
                    if frame_offset + 1 < len(step_frames)
                    else dict(final_observation or {})
                )
                row = _action_effect_row_from_frame(
                    frame,
                    after_observation=after_observation,
                    source_kind="run_log",
                    source_ref=source_ref,
                    run_id=run_id,
                    action_record=raw_action_records[frame_offset]
                    if frame_offset < len(raw_action_records)
                    else None,
                    step=raw_step,
                    step_frame_count=len(step_frames),
                )
                if row is not None:
                    effect_rows.append(row)
    return node_rows, effect_rows


def _extract_offline_replay_case_rows(
    case_dir: str | Path,
    *,
    benchmark_kind: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Extract benchmark rows from one offline replay case directory.

    Args:
        case_dir: Replay case directory containing `case.json` and replay assets.
        benchmark_kind: `node_match`, `action_effect`, or `both`.

    Returns:
        Tuple of node-match rows and action-effect rows.
    """

    case = load_offline_replay_case(case_dir)
    node_rows: list[dict[str, Any]] = []
    effect_rows: list[dict[str, Any]] = []
    if (
        benchmark_kind in {"node_match", "both"}
        and case.main_action_frames_path.exists()
    ):
        frames = json.loads(case.main_action_frames_path.read_text(encoding="utf-8"))
        if isinstance(frames, list):
            for frame in frames:
                if not isinstance(frame, dict):
                    continue
                row = _node_match_row_from_frame(
                    frame,
                    source_kind="offline_replay",
                    source_ref=str(case.case_dir),
                    run_id=None,
                    task_id=case.task_id,
                    trace_id=case.trace_id,
                )
                if row is not None:
                    node_rows.append(row)
    if benchmark_kind in {"action_effect", "both"} and case.port_trace_path.exists():
        events = _load_jsonl(case.port_trace_path)
        previous_observation: dict[str, Any] | None = None
        pending_action: dict[str, Any] | None = None
        pending_index = 0
        for event in events:
            event_type = str(event.get("event") or "").strip()
            if event_type == "observe":
                result = dict(event.get("result") or {})
                if pending_action is not None and previous_observation is not None:
                    action_payload = _normalize_action_payload(
                        pending_action.get("action")
                    )
                    row = _action_effect_row(
                        sample_id=(
                            f"offline_replay::{case.task_id}::{case.trace_id}"
                            f"::action_effect::{pending_index}"
                        ),
                        source_kind="offline_replay",
                        source_ref=str(case.case_dir),
                        run_id=None,
                        task_id=case.task_id,
                        trace_id=case.trace_id,
                        step_index=None,
                        frame_index=pending_index,
                        action=action_payload,
                        before_observation=previous_observation,
                        after_observation=result,
                        expected_effect=_resolve_expected_effect_label(
                            action_record=pending_action,
                            step=None,
                            step_frame_count=1,
                        ),
                        metadata={"frame_source": "port_trace"},
                    )
                    if row is not None:
                        effect_rows.append(row)
                    pending_action = None
                    pending_index += 1
                previous_observation = result
                continue
            if event_type == "act":
                pending_action = dict(event)
        # Cases ending without a trailing observe are skipped by design.
    return node_rows, effect_rows


def _node_match_row_from_frame(
    frame: dict[str, Any],
    *,
    source_kind: str,
    source_ref: str,
    run_id: str | None,
    task_id: str | None = None,
    trace_id: str | None = None,
) -> dict[str, Any] | None:
    """Build one node-match dataset row from one lightweight main-action frame.

    Args:
        frame: Lightweight main-action frame with `before_observation` and
            optional `node_id/function_id`.
        source_kind: Source label such as `run_log` or `offline_replay`.
        source_ref: Human-readable artifact path used for traceability.
        run_id: Optional canonical run id.
        task_id: Optional offline replay task id.
        trace_id: Optional offline replay trace id.

    Returns:
        Dataset row or `None` when required fields are missing.
    """

    before_observation = dict(frame.get("before_observation") or {})
    xml = str(before_observation.get("xml") or "").strip()
    expected_node_id = str(frame.get("node_id") or "").strip()
    if not xml or not expected_node_id:
        return None
    step_index = frame.get("step_index")
    frame_index = frame.get("frame_index")
    sample_id = (
        f"{source_kind}::{str(run_id or task_id or source_ref)}::"
        f"{str(trace_id or 'na')}::node_match::"
        f"{step_index if step_index is not None else 'na'}::"
        f"{frame_index if frame_index is not None else 'na'}"
    )
    return {
        "sample_id": sample_id,
        "source_kind": source_kind,
        "source_ref": source_ref,
        "run_id": run_id,
        "task_id": task_id,
        "trace_id": trace_id,
        "step_index": step_index,
        "frame_index": frame_index,
        "xml": xml,
        "package_name": str(before_observation.get("package_name") or "").strip(),
        "activity_name": str(before_observation.get("activity_name") or "").strip(),
        "expected_node_id": expected_node_id,
        "expected_function_id": str(frame.get("function_id") or "").strip() or None,
        "metadata": dict(frame.get("meta") or {}),
    }


def _action_effect_row_from_frame(
    frame: dict[str, Any],
    *,
    after_observation: dict[str, Any],
    source_kind: str,
    source_ref: str,
    run_id: str | None,
    action_record: dict[str, Any] | None = None,
    step: dict[str, Any] | None = None,
    step_frame_count: int = 1,
) -> dict[str, Any] | None:
    """Build one action-effect dataset row from one lightweight main-action frame.

    Args:
        frame: Lightweight main-action frame with `before_observation`.
        after_observation: Next observed page after the frame action completes.
        source_kind: Source label such as `run_log`.
        source_ref: Human-readable artifact path used for traceability.
        run_id: Optional canonical run id.
        action_record: Optional provider action record carrying host/runtime labels.
        step: Optional canonical step used for one-step fallback labels.
        step_frame_count: Number of exported action frames within the current step.

    Returns:
        Dataset row or `None` when required fields are missing.
    """

    step_index = frame.get("step_index")
    frame_index = frame.get("frame_index")
    sample_id = (
        f"{source_kind}::{str(run_id or source_ref)}::action_effect::"
        f"{step_index if step_index is not None else 'na'}::"
        f"{frame_index if frame_index is not None else 'na'}"
    )
    return _action_effect_row(
        sample_id=sample_id,
        source_kind=source_kind,
        source_ref=source_ref,
        run_id=run_id,
        task_id=None,
        trace_id=None,
        step_index=step_index,
        frame_index=frame_index,
        action=_normalize_action_payload(frame.get("expected_action")),
        before_observation=dict(frame.get("before_observation") or {}),
        after_observation=after_observation,
        expected_effect=_resolve_expected_effect_label(
            action_record=action_record,
            step=step,
            step_frame_count=step_frame_count,
        ),
        metadata={
            "frame_source": str(
                dict(frame.get("meta") or {}).get("frame_source") or ""
            ),
            "function_id": str(frame.get("function_id") or "").strip() or None,
            "node_id": str(frame.get("node_id") or "").strip() or None,
            "sequence_id": str(frame.get("sequence_id") or "").strip() or None,
        },
    )


def _action_effect_row(
    *,
    sample_id: str,
    source_kind: str,
    source_ref: str,
    run_id: str | None,
    task_id: str | None,
    trace_id: str | None,
    step_index: Any,
    frame_index: Any,
    action: dict[str, Any],
    before_observation: dict[str, Any],
    after_observation: dict[str, Any],
    expected_effect: bool | None,
    metadata: dict[str, Any],
) -> dict[str, Any] | None:
    """Build one normalized action-effect dataset row.

    Args:
        sample_id: Stable dedupe id for this sample.
        source_kind: Source label such as `run_log` or `offline_replay`.
        source_ref: Human-readable artifact path used for traceability.
        run_id: Optional canonical run id.
        task_id: Optional offline replay task id.
        trace_id: Optional offline replay trace id.
        step_index: Optional high-level step index.
        frame_index: Optional per-step or per-trace action index.
        action: Normalized action payload containing `type/params`.
        before_observation: Observation snapshot before the action.
        after_observation: Observation snapshot after the action.
        expected_effect: External effect label when available.
        metadata: Extra export-only metadata.

    Returns:
        Dataset row or `None` when required fields are missing.
    """

    if not isinstance(action, dict) or not str(action.get("type") or "").strip():
        return None
    before_xml = str(before_observation.get("xml") or "").strip()
    after_xml = str(after_observation.get("xml") or "").strip()
    before_package = str(before_observation.get("package_name") or "").strip()
    after_package = str(after_observation.get("package_name") or "").strip()
    before_activity = str(before_observation.get("activity_name") or "").strip()
    after_activity = str(after_observation.get("activity_name") or "").strip()
    if not (
        before_xml
        or after_xml
        or before_package
        or after_package
        or before_activity
        or after_activity
    ):
        return None
    if not isinstance(expected_effect, bool):
        return None
    return {
        "sample_id": sample_id,
        "source_kind": source_kind,
        "source_ref": source_ref,
        "run_id": run_id,
        "task_id": task_id,
        "trace_id": trace_id,
        "step_index": step_index,
        "frame_index": frame_index,
        "action_type": str(action.get("type") or "").strip(),
        "action": action,
        "before_observation": before_observation,
        "after_observation": after_observation,
        "expected_effect": expected_effect,
        "metadata": metadata,
    }


def _resolve_expected_effect_label(
    *,
    action_record: dict[str, Any] | None,
    step: dict[str, Any] | None,
    step_frame_count: int,
) -> bool | None:
    """Resolve one external action-effect label from host/runtime outcome fields.

    Args:
        action_record: Optional per-action record from provider_detail or port trace.
        step: Optional canonical step payload used for one-frame fallback labels.
        step_frame_count: Number of action frames exported from the current step.

    Returns:
        `True` or `False` only when the source provides an external effect label.
        Ambiguous cases return `None` and are skipped from the benchmark.
    """

    containers: list[dict[str, Any]] = []
    if isinstance(action_record, dict):
        containers.append(action_record)
        if isinstance(action_record.get("result"), dict):
            containers.append(dict(action_record.get("result") or {}))
    if isinstance(step, dict):
        act_result = step.get("act_result")
        if isinstance(act_result, dict):
            containers.append(dict(act_result or {}))
        provider_detail = step.get("provider_detail")
        if isinstance(provider_detail, dict):
            containers.append(dict(provider_detail or {}))
    for container in containers:
        explicit = container.get("expected_effect")
        if isinstance(explicit, bool):
            return explicit
        reason = str(container.get("reason") or "").strip().lower()
        if reason == "effect_verified":
            return True
        if reason == "no_effect":
            return False
        error_code = str(container.get("error_code") or "").strip()
        if error_code == EXEC_ACTION_NO_EFFECT:
            return False
    if step_frame_count == 1 and isinstance(step, dict):
        act_result = step.get("act_result")
        if isinstance(act_result, dict) and isinstance(act_result.get("success"), bool):
            return bool(act_result.get("success"))
    return None


def _step_final_observation(step: dict[str, Any]) -> dict[str, Any]:
    """Resolve the best available post-step observation from a canonical step log.

    Args:
        step: Canonical step record inside one `run_log.steps[*]`.

    Returns:
        Final observation payload, or `{}` when none is available.
    """

    provider_detail = (
        dict(step.get("provider_detail") or {})
        if isinstance(step.get("provider_detail"), dict)
        else {}
    )
    final_observation = provider_detail.get("final_observation")
    if isinstance(final_observation, dict) and final_observation:
        return dict(final_observation)
    final_state = provider_detail.get("final_state")
    if isinstance(final_state, dict) and final_state:
        return dict(final_state)
    step_final = step.get("final_observation")
    if isinstance(step_final, dict) and step_final:
        return dict(step_final)
    return {}


def _resolve_dataset_file(dataset_path: str | Path, *, kind: str) -> Path:
    """Resolve bundle dirs or direct files into one concrete dataset file path.

    Args:
        dataset_path: Bundle directory or direct dataset file path.
        kind: `node_match` or `action_effect`.

    Returns:
        Concrete JSONL file path for the requested benchmark kind.
    """

    path = Path(dataset_path).expanduser().resolve()
    if path.is_dir():
        filename = (
            _NODE_MATCH_FILENAME if kind == "node_match" else _ACTION_EFFECT_FILENAME
        )
        path = path / filename
    return path


def _snapshot_match_debug(runtime: Any) -> dict[str, Any]:
    """Capture the latest matcher debug payload after one `runtime.match_node(...)`.

    Args:
        runtime: Runtime exposing an internal `_matcher.last_match_debug` field.

    Returns:
        Debug payload dictionary, or `{}` when unavailable.
    """

    matcher = getattr(runtime, "_matcher", None)
    debug_info = getattr(matcher, "last_match_debug", None)
    return dict(debug_info or {}) if isinstance(debug_info, dict) else {}


def _topk_node_ids(debug_info: dict[str, Any], *, top_k: int) -> list[str]:
    """Extract deduped top-k candidate node ids from matcher debug payload.

    Args:
        debug_info: `UTGMatchEngine.last_match_debug` snapshot.
        top_k: Maximum number of candidate ids to keep.

    Returns:
        Ordered candidate node id list.
    """

    out: list[str] = []
    seen: set[str] = set()
    for key in ("candidate_scores", "search_topk"):
        for item in list(debug_info.get(key) or []):
            if not isinstance(item, dict):
                continue
            node_id = str(item.get("node_id") or "").strip()
            if not node_id or node_id in seen:
                continue
            seen.add(node_id)
            out.append(node_id)
            if len(out) >= max(1, int(top_k)):
                return out
    return out


def _observations_differ_payload(
    first: dict[str, Any] | None,
    second: dict[str, Any] | None,
) -> bool:
    """判断两个观测是否不同（用于动作效果检测）。

    Args:
        first: 动作前的观测 payload。
        second: 动作后的观测 payload。

    Returns:
        `True` 如果 XML 或 app identity 有变化，否则 `False`。
    """
    first_payload = dict(first or {})
    second_payload = dict(second or {})
    first_obs = DeviceObservation(
        xml=first_payload.get("xml"),
        package_name=first_payload.get("package_name"),
        activity_name=first_payload.get("activity_name"),
    )
    second_obs = DeviceObservation(
        xml=second_payload.get("xml"),
        package_name=second_payload.get("package_name"),
        activity_name=second_payload.get("activity_name"),
    )
    return not observations_equal(first_obs, second_obs)


def _normalize_action_payload(action: Any) -> dict[str, Any]:
    """Normalize action-like payloads into stable `type/params` dicts.

    Args:
        action: Action dict/object derived from run logs or replay artifacts.

    Returns:
        Minimal JSON-safe action payload.
    """

    payload = dict(canonical_action_payload(action) or {})
    return {
        "type": str(payload.get("type") or "").strip(),
        "params": to_serializable(payload.get("params") or {}),
    }


def _load_jsonl(path: str | Path) -> list[dict[str, Any]]:
    """Load one JSONL file into a list of dict rows.

    Args:
        path: JSONL file path. Missing files return an empty list.

    Returns:
        JSON object rows in file order.
    """

    path_obj = Path(path).expanduser().resolve()
    if not path_obj.exists():
        return []
    rows: list[dict[str, Any]] = []
    for raw_line in path_obj.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        item = json.loads(line)
        if isinstance(item, dict):
            rows.append(item)
    return rows


def _write_jsonl(path: str | Path, rows: Iterable[dict[str, Any]]) -> None:
    """Write dict rows into one UTF-8 JSONL file.

    Args:
        path: Target JSONL file path.
        rows: Dataset rows already normalized as dictionaries.
    """

    path_obj = Path(path).expanduser().resolve()
    path_obj.parent.mkdir(parents=True, exist_ok=True)
    with path_obj.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(dict(row or {}), ensure_ascii=False))
            handle.write("\n")


def _looks_like_run_log(payload: Any) -> bool:
    """Return whether one decoded JSON object follows canonical run-log shape.

    Args:
        payload: Decoded JSON value from files or JSONL rows.

    Returns:
        `True` only when the object has a list-like `steps` field.
    """

    return isinstance(payload, dict) and isinstance(payload.get("steps"), list)


def _write_report(
    summary: dict[str, Any],
    per_case: Sequence[dict[str, Any]],
    *,
    output_dir: str | Path | None,
    mode: str,
) -> dict[str, Any]:
    """Persist one observation benchmark summary and per-case JSONL report.

    Args:
        summary: Aggregate metrics for the benchmark run.
        per_case: Per-sample evaluation rows.
        output_dir: Optional explicit output directory.
        mode: Short benchmark label such as `node_match`.

    Returns:
        Summary dict with resolved output paths attached.
    """

    resolved_dir = (
        Path(output_dir).expanduser().resolve()
        if output_dir is not None
        else get_runtime_dir(
            "evals",
            "observation",
            mode,
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f"),
        )
    )
    resolved_dir.mkdir(parents=True, exist_ok=True)
    summary_path = resolved_dir / "summary.json"
    per_case_path = resolved_dir / "per_case.jsonl"
    payload = dict(summary)
    payload["summary_path"] = str(summary_path.resolve())
    payload["per_case_path"] = str(per_case_path.resolve())
    summary_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    _write_jsonl(per_case_path, per_case)
    return payload


def _safe_rate(numerator: int | float, denominator: int | float) -> float:
    """Return `numerator / denominator` with zero-safe semantics.

    Args:
        numerator: Count-like value in the numerator.
        denominator: Count-like value in the denominator.

    Returns:
        Zero when the denominator is empty, else the division result.
    """

    if not denominator:
        return 0.0
    return float(numerator) / float(denominator)


__all__ = [
    "export_observation_benchmark_bundle",
    "score_action_effect_benchmark",
    "score_node_match_benchmark",
]
