"""
Simple keyword-based function retrieval.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Set

from src.utg.core.models import Function
from src.utg.retrieval.tokenizer import tokenize


@dataclass
class RetrievalResult:
    """Result of function retrieval."""

    function_id: str
    score: float
    function: Function


class FunctionRetriever:
    """
    Simple keyword-based function retriever using inverted index.

    Builds an inverted index from function descriptions and recall phrases,
    then retrieves functions by token overlap scoring.
    """

    def __init__(self, functions: List[Function]) -> None:
        self._functions: Dict[str, Function] = {f.name: f for f in functions if f.name}
        self._index: Dict[str, Set[str]] = {}
        self._function_tokens: Dict[str, Set[str]] = {}
        self._build_index()

    def _build_index(self) -> None:
        """Build keyword → function_ids inverted index."""
        for func_id, func in self._functions.items():
            tokens = self._extract_tokens(func)
            self._function_tokens[func_id] = tokens
            for token in tokens:
                if token not in self._index:
                    self._index[token] = set()
                self._index[token].add(func_id)

    def _extract_tokens(self, func: Function) -> Set[str]:
        """Extract tokens from function description and recall phrases."""
        tokens: Set[str] = set()

        # From description
        if func.description:
            tokens.update(tokenize(func.description))

        # From expanded phrases / recall phrases (stored in metadata)
        expanded_phrases = func.metadata.get("expandedPhrases", [])
        for phrase in expanded_phrases or []:
            tokens.update(tokenize(phrase))

        # From action verbs in metadata
        action_verbs = func.metadata.get("action_verbs") if func.metadata else None
        if isinstance(action_verbs, list):
            for verb in action_verbs:
                tokens.update(tokenize(str(verb)))

        return tokens

    def retrieve(
        self,
        query: str,
        *,
        current_node_id: Optional[str] = None,
        top_k: int = 5,
    ) -> List[RetrievalResult]:
        """
        Retrieve functions matching the query.

        Args:
            query: User query text.
            current_node_id: Optional current node for position filtering.
            top_k: Maximum number of results to return.

        Returns:
            List of RetrievalResult sorted by score descending.
        """
        if not query:
            return []

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        # Collect candidate functions from inverted index
        candidate_ids: Set[str] = set()
        for token in query_tokens:
            if token in self._index:
                candidate_ids.update(self._index[token])

        if not candidate_ids:
            return []

        # Score candidates by token overlap
        results: List[RetrievalResult] = []
        for func_id in candidate_ids:
            func = self._functions.get(func_id)
            if not func:
                continue

            # Position filter: if current_node_id specified, prefer functions starting there
            position_boost = 0.0
            if current_node_id and func.start_node_id == current_node_id:
                position_boost = 0.5

            # Token overlap score (Jaccard-like)
            func_tokens = self._function_tokens.get(func_id, set())
            if not func_tokens:
                continue

            intersection = len(query_tokens & func_tokens)
            union = len(query_tokens | func_tokens)
            overlap_score = intersection / union if union > 0 else 0.0

            # Final score
            score = overlap_score + position_boost

            results.append(
                RetrievalResult(function_id=func_id, score=score, function=func)
            )

        # Sort by score descending
        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    def update(self, functions: List[Function]) -> None:
        """
        Update the index with new functions.

        Args:
            functions: New or updated functions to index.
        """
        for func in functions:
            if not func.name:
                continue
            self._functions[func.name] = func
            tokens = self._extract_tokens(func)
            self._function_tokens[func.name] = tokens
            for token in tokens:
                if token not in self._index:
                    self._index[token] = set()
                self._index[token].add(func.name)

    def remove(self, function_id: str) -> None:
        """
        Remove a function from the index.

        Args:
            function_id: ID (name) of function to remove.
        """
        if function_id not in self._functions:
            return

        tokens = self._function_tokens.get(function_id, set())
        for token in tokens:
            if token in self._index:
                self._index[token].discard(function_id)
                if not self._index[token]:
                    del self._index[token]

        self._functions.pop(function_id, None)
        self._function_tokens.pop(function_id, None)
