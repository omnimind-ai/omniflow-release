"""
Simple tokenizer for Chinese and English text.
"""

from __future__ import annotations

import re
from typing import Set

_CJK_CHAR = re.compile(r"[\u4e00-\u9fff]")
_ENGLISH_WORD = re.compile(r"[a-zA-Z]+")
_NUMBER = re.compile(r"[0-9]+")


def tokenize(text: str) -> Set[str]:
    """
    Simple tokenization supporting Chinese and English.

    - Chinese: character-level tokens
    - English: word-level tokens (lowercased)
    - Numbers: kept as whole tokens

    Args:
        text: Input text to tokenize.

    Returns:
        Set of unique tokens.
    """
    if not text:
        return set()

    text = str(text)
    tokens: Set[str] = set()

    # Extract Chinese characters (char-level)
    for char in text:
        if _CJK_CHAR.match(char):
            tokens.add(char)

    # Extract English words (word-level, lowercased)
    for match in _ENGLISH_WORD.finditer(text):
        tokens.add(match.group().lower())

    # Extract numbers
    for match in _NUMBER.finditer(text):
        tokens.add(match.group())

    return tokens
