"""
UTG-specific prompt builders and parsers.

Re-exports common LLM functions from foundation.ai for convenience.
"""

# Re-export common LLM functions from foundation.ai
from src.foundation.ai import (
    MODEL_KIND_LLM,
    acomplete,
    acomplete_json,
    complete,
    complete_json,
    default_llm_model,
    extract_json,
    get_api_config,
    get_model_name,
    llm_complete_with_timeout,
    llm_complete_with_timeout_async,
    resolve_llm_provider,
    resolve_provider,
)

# UTG-specific prompt builders and parsers
from src.utg.prompts.param_fill import (
    build_param_fill_prompt,
    parse_param_value,
)
from src.utg.prompts.semantic import (
    build_action_parameter_plan_prompt,
    build_semantic_analysis_prompt,
    normalize_action_parameter_plan_parameters,
    parse_action_parameter_plan,
    parse_semantic_analysis,
)

__all__ = [
    # Re-exported from foundation.ai
    "MODEL_KIND_LLM",
    "complete",
    "acomplete",
    "complete_json",
    "acomplete_json",
    "extract_json",
    "resolve_provider",
    "resolve_llm_provider",
    "default_llm_model",
    "get_model_name",
    "get_api_config",
    "llm_complete_with_timeout",
    "llm_complete_with_timeout_async",
    # UTG-specific: Parameter fill
    "build_param_fill_prompt",
    "parse_param_value",
    # UTG-specific: Semantic analysis
    "build_semantic_analysis_prompt",
    "parse_semantic_analysis",
    "build_action_parameter_plan_prompt",
    "parse_action_parameter_plan",
    "normalize_action_parameter_plan_parameters",
]
