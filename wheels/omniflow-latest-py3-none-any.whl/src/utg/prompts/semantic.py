"""
LLM semantic analysis utilities.

Provides prompt builders and parsers for semantic analysis and action parameter planning.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List


def build_semantic_analysis_prompt(
    *,
    goal: str,
    function_description: str,
    actions: List[Any],
    start_xml: str,
    end_xml: str,
) -> str:
    """Build JSON prompt for offline run-log semantic enrichment.

    Args:
        goal: Original user goal or prompt text.
        function_description: Current function description snapshot if already present.
        actions: Raw actions extracted from the run log.
        start_xml: XML before the first action.
        end_xml: XML after the last action.

    Returns:
        Compact prompt for LLM semantic analysis.
    """
    action_rows = _build_action_rows(actions, include_click_prompt=True)
    payload = {
        "task": "offline_run_log_semantic_enrichment",
        "goal": goal or None,
        "function_description": function_description or None,
        "actions": action_rows,
        "start_xml": start_xml or None,
        "end_xml": end_xml or None,
        "output_schema": {
            "action_parameter_plan": {
                "function_description": "templated function description using ${parameter}",
                "function_parameters": {"parameter_name": "text"},
                "action_bindings": [
                    {"action_index": 0, "parameter_name": "parameter_name"}
                ],
            },
            "arguments": {"parameter_name": "value copied from the goal"},
            "semantic_functions": [
                {
                    "name": "short_function_name",
                    "summary": "human readable summary",
                    "raw_step_indices": [0],
                }
            ],
            "node_semantics": {
                "start_node_description": "short page description",
                "end_node_description": "short page description",
            },
        },
        "rules": [
            "Return valid JSON only.",
            "Do not invent actions or indices.",
            "Use action indices from the provided action list.",
            "Keep node descriptions short and page-level.",
            "If a field is unknown, omit it instead of guessing.",
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def parse_semantic_analysis(
    raw: str,
    *,
    actions: List[Any],
) -> Dict[str, Any]:
    """Parse semantic-analysis JSON payload returned by the LLM.

    Args:
        raw: Raw completion text.
        actions: Current action list used for index validation.

    Returns:
        Normalized semantic payload or `{}` when the output is malformed.
    """
    payload = _extract_json_payload(raw)
    if not payload:
        return {}

    out: Dict[str, Any] = {}

    # Parse action_parameter_plan
    action_parameter_plan = payload.get("action_parameter_plan")
    if isinstance(action_parameter_plan, dict):
        normalized_plan = parse_action_parameter_plan(
            json.dumps(action_parameter_plan, ensure_ascii=False),
            actions=actions,
        )
        if normalized_plan:
            out["action_parameter_plan"] = normalized_plan

    # Parse arguments
    raw_arguments = payload.get("arguments")
    if isinstance(raw_arguments, dict):
        normalized_arguments = {
            str(name or "").strip(): str(value or "").strip()
            for name, value in raw_arguments.items()
            if str(name or "").strip() and str(value or "").strip()
        }
        if normalized_arguments:
            out["arguments"] = normalized_arguments

    # Parse semantic_functions
    raw_functions = payload.get("semantic_functions")
    if isinstance(raw_functions, list):
        normalized_functions = _parse_semantic_functions(raw_functions, len(actions))
        if normalized_functions:
            out["semantic_functions"] = normalized_functions

    # Parse node_semantics
    raw_node_semantics = payload.get("node_semantics")
    if isinstance(raw_node_semantics, dict):
        normalized_node_semantics = {
            key: str(raw_node_semantics.get(key) or "").strip()
            for key in ("start_node_description", "end_node_description")
            if str(raw_node_semantics.get(key) or "").strip()
        }
        if normalized_node_semantics:
            out["node_semantics"] = normalized_node_semantics

    return out


def build_action_parameter_plan_prompt(
    *,
    sentence: str,
    function_description: str,
    actions: List[Any],
) -> str:
    """Build compact JSON prompt for action-parameter extraction.

    Args:
        sentence: Original user goal or prompt text.
        function_description: Current function description snapshot.
        actions: Raw actions that the model may bind to derived parameters.

    Returns:
        Plain-text prompt asking the model to emit a strict JSON plan.
    """
    action_rows = _build_action_rows(actions, include_click_prompt=False)
    payload = {
        "task": "offline_action_parameter_extraction",
        "sentence": sentence,
        "function_description": function_description or None,
        "actions": action_rows,
        "output_schema": {
            "function_description": "templated function description using ${parameter}",
            "function_parameters": {"parameter_name": "text"},
            "action_bindings": [
                {
                    "action_index": 0,
                    "parameter_name": "parameter used by this type action text field",
                }
            ],
        },
        "rules": [
            "Bind parameters at the action level.",
            "Only bind existing actions. Do not invent actions or indices.",
            "Only variable user-provided text should become a parameter.",
            "Different input actions should usually map to different parameters in action order, such as input_1, input_2, input_3.",
            "Do not infer extra semantics like first_name or last_name unless they are explicit.",
            "If the parameter meaning is unclear, use input_N naming.",
            "Return valid JSON only.",
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def parse_action_parameter_plan(
    raw: str,
    *,
    actions: List[Any],
) -> Dict[str, Any]:
    """Parse and validate LLM action-parameter plan payload.

    Args:
        raw: Raw text response from the LLM.
        actions: Action list used to validate `action_index` targets.

    Returns:
        Validated plan dict or `{}` on malformed output.
    """
    payload = _extract_json_payload(raw)
    if not payload:
        return {}

    plan: Dict[str, Any] = {}

    # Extract function_description
    function_description = str(payload.get("function_description") or "").strip()
    if function_description:
        plan["function_description"] = function_description

    # Extract function_parameters
    function_parameters = payload.get("function_parameters")
    if isinstance(function_parameters, dict):
        normalized_parameters = {
            str(name or "").strip(): str(parameter_type or "").strip() or "text"
            for name, parameter_type in function_parameters.items()
            if str(name or "").strip()
        }
        if normalized_parameters:
            plan["function_parameters"] = normalized_parameters

    # Extract action_bindings
    normalized_bindings: List[Dict[str, Any]] = []
    for binding in list(payload.get("action_bindings") or []):
        if not isinstance(binding, dict):
            continue
        try:
            action_index = int(binding.get("action_index"))
        except (TypeError, ValueError):
            continue
        if action_index < 0 or action_index >= len(actions):
            continue
        parameter_name = str(binding.get("parameter_name") or "").strip()
        if not parameter_name:
            continue
        normalized_bindings.append(
            {"action_index": action_index, "parameter_name": parameter_name}
        )
    if normalized_bindings:
        plan["action_bindings"] = normalized_bindings

    return plan


def normalize_action_parameter_plan_parameters(plan: Dict[str, Any]) -> Dict[str, str]:
    """Normalize parameter definitions from an action-parameter plan.

    Args:
        plan: Parsed plan payload from semantic extraction or live LLM.

    Returns:
        Parameter-name to parameter-type map. Missing types default to `text`.
    """
    normalized: Dict[str, str] = {}

    # From function_parameters
    raw_parameters = plan.get("function_parameters")
    if isinstance(raw_parameters, dict):
        for raw_name, raw_type in raw_parameters.items():
            parameter_name = str(raw_name or "").strip()
            parameter_type = str(raw_type or "").strip() or "text"
            if parameter_name:
                normalized[parameter_name] = parameter_type

    # From function_description template
    function_description = str(plan.get("function_description") or "").strip()
    for parameter_name in re.findall(r"\$\{(\w+)\}", function_description):
        key = str(parameter_name or "").strip()
        if key and key not in normalized:
            normalized[key] = "text"

    # From action_bindings
    for binding in list(plan.get("action_bindings") or []):
        if not isinstance(binding, dict):
            continue
        parameter_name = str(binding.get("parameter_name") or "").strip()
        if parameter_name and parameter_name not in normalized:
            normalized[parameter_name] = "text"

    return normalized


# =============================================================================
# Internal helpers
# =============================================================================


def _build_action_rows(
    actions: List[Any],
    *,
    include_click_prompt: bool = False,
) -> List[Dict[str, Any]]:
    """Build action row list for prompts."""
    rows: List[Dict[str, Any]] = []
    for index, action in enumerate(actions):
        action_type = str(
            action.get("type", "")
            if isinstance(action, dict)
            else getattr(action, "type", "")
        ).strip()
        params = (
            action.get("params")
            if isinstance(action, dict)
            else getattr(action, "params", None)
        )
        row: Dict[str, Any] = {"action_index": index, "type": action_type}
        if isinstance(params, dict):
            text_value = str(params.get("text") or "").strip()
            if text_value:
                row["text"] = text_value
            if include_click_prompt:
                click_prompt = str(
                    params.get("clickPrompt") or params.get("click_prompt") or ""
                ).strip()
                if click_prompt:
                    row["click_prompt"] = click_prompt
        rows.append(row)
    return rows


def _extract_json_payload(raw: str) -> Dict[str, Any]:
    """Extract JSON payload from raw LLM response."""
    text = str(raw or "").strip()
    if not text:
        return {}
    try:
        payload = json.loads(text)
    except Exception:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if not match:
            return {}
        try:
            payload = json.loads(match.group(0))
        except Exception:
            return {}
    if not isinstance(payload, dict):
        return {}
    return payload


def _normalize_step_indices(raw_indices: Any, action_count: int) -> List[int]:
    """Normalize step indices for semantic functions."""
    if not isinstance(raw_indices, list) or action_count <= 0:
        return []
    normalized: List[int] = []
    seen: set[int] = set()
    for item in raw_indices:
        try:
            index = int(item)
        except (TypeError, ValueError):
            continue
        if index < 0 or index >= action_count or index in seen:
            continue
        normalized.append(index)
        seen.add(index)
    normalized.sort()
    return normalized


def _parse_semantic_functions(
    raw_functions: List[Any],
    action_count: int,
) -> List[Dict[str, Any]]:
    """Parse semantic functions from LLM response."""
    normalized_functions: List[Dict[str, Any]] = []
    for index, item in enumerate(raw_functions):
        if not isinstance(item, dict):
            continue
        step_indices = _normalize_step_indices(
            item.get("raw_step_indices"), action_count
        )
        if not step_indices:
            continue
        normalized_item: Dict[str, Any] = {
            "name": str(
                item.get("name")
                or item.get("function_id")
                or f"semantic_function_{index}"
            ).strip()
            or f"semantic_function_{index}",
            "raw_step_indices": step_indices,
        }
        summary = str(item.get("summary") or item.get("description") or "").strip()
        if summary:
            normalized_item["summary"] = summary
        normalized_functions.append(normalized_item)
    return normalized_functions
