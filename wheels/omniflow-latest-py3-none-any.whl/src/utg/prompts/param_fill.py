"""
LLM parameter filling utilities.
"""


def build_param_fill_prompt(
    *,
    sentence: str,
    path_template: str,
    parameter_name: str,
) -> str:
    """Build prompt for parameter value extraction.

    Args:
        sentence: Source sentence containing the value.
        path_template: Path template with `${parameter}` placeholders.
        parameter_name: Name of the parameter to fill.

    Returns:
        Compact prompt for LLM parameter filling.
    """
    return (
        "fill(sentence,path,parameter)\n"
        "Return ONLY parameter value text. No JSON, no explanation.\n"
        "If missing, return NONE.\n"
        f"sentence={sentence}\n"
        f"path={path_template}\n"
        f"parameter={parameter_name}"
    )


def parse_param_value(raw: str) -> str:
    """Parse parameter value from LLM response.

    Args:
        raw: Raw LLM completion text.

    Returns:
        Extracted parameter value or empty string.
    """
    text = str(raw or "").strip()
    if not text:
        return ""

    first_line = text.splitlines()[0].strip()

    # Skip JSON/code block responses
    if first_line.startswith(("```", "{", "[")):
        return ""

    # Strip quotes
    if first_line.startswith('"') and first_line.endswith('"') and len(first_line) >= 2:
        first_line = first_line[1:-1].strip()
    if first_line.startswith("'") and first_line.endswith("'") and len(first_line) >= 2:
        first_line = first_line[1:-1].strip()

    # Check for "not found" markers
    lowered = first_line.lower()
    if lowered in {"none", "null", "n/a", "na", "unknown", "not_found"}:
        return ""

    return first_line
