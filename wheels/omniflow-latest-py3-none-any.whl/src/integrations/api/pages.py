from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import (
    HTMLResponse,
    PlainTextResponse,
    RedirectResponse,
    Response,
)

from .contracts import resolve_api_language

_INTEGRATIONS_DIR = Path(__file__).resolve().parents[1]
_WEB_ASSETS_DIR = _INTEGRATIONS_DIR / "web"

_UTG_DETAIL_HTML_PATH = _WEB_ASSETS_DIR / "utg_detail.html"
_UTG_EDITOR_HTML_PATH = _WEB_ASSETS_DIR / "utg_editor.html"
_GRAPH_VIEWER_HTML_PATH = _WEB_ASSETS_DIR / "graph_viewer.html"
_XML_COMPARE_HTML_PATH = _WEB_ASSETS_DIR / "xml_compare.html"
_COMPILE_TEST_HTML_PATH = _WEB_ASSETS_DIR / "compile_test.html"
_DASHBOARD_HTML_PATH = _WEB_ASSETS_DIR / "dashboard.html"
_DEMO_HTML_PATH = _WEB_ASSETS_DIR / "demo.html"
_BROWSE_BROWSER_HTML_PATH = _WEB_ASSETS_DIR / "functions_browser.html"
_DATA_OPS_HTML_PATH = _WEB_ASSETS_DIR / "rag_export.html"
_RUNLOG_TIMELINE_HTML_PATH = _WEB_ASSETS_DIR / "runlog_timeline.html"
_VIS_NETWORK_JS_PATH = _WEB_ASSETS_DIR / "vis-network.min.js"
_PROVIDER_TOPBAR_JS_PATH = _WEB_ASSETS_DIR / "provider_topbar.js"


def _read_text(path: Path) -> str:
    """Load one provider-owned page or JS asset from the unified web folder."""

    return path.read_text(encoding="utf-8")


def load_editor_html() -> str:
    """Load the desktop UTG editor shell."""

    return _read_text(_UTG_EDITOR_HTML_PATH)


def load_detail_html() -> str:
    """Load the shared node/function detail shell."""

    return _read_text(_UTG_DETAIL_HTML_PATH)


def load_graph_viewer_html() -> str:
    """Load the graph viewer shell."""

    return _read_text(_GRAPH_VIEWER_HTML_PATH)


def load_xml_compare_html() -> str:
    """Load the XML compare shell."""

    return _read_text(_XML_COMPARE_HTML_PATH)


def load_compile_test_html() -> str:
    """Load the compile test shell."""

    return _read_text(_COMPILE_TEST_HTML_PATH)


def load_dashboard_html() -> str:
    """Load the provider stats dashboard shell."""

    return _read_text(_DASHBOARD_HTML_PATH)


def load_demo_html() -> str:
    """Load the provider-side demo storyboard shell."""

    return _read_text(_DEMO_HTML_PATH)


def _load_browse_browser_html(mode: str, *, lang: str = "zh") -> str:
    """Load the shared browse shell with per-route labels injected."""

    template = _read_text(_BROWSE_BROWSER_HTML_PATH)
    replacements = {
        "zh": {
            "nodes": {
                "__PAGE_TITLE__": "Nodes Browser",
                "__PAGE_COPY__": (
                    "这里按页面节点浏览 UTG。切换 provider 地址后仍停留在同一 browse 页面，"
                    "继续查 node、包名和 XML 样本。"
                ),
                "__CAPABILITY_PRIMARY__": "Node Catalog",
                "__CAPABILITY_SECONDARY__": "Package Filter",
                "__CAPABILITY_TERTIARY__": "XML Sample Lookup",
                "__COUNT_LABEL__": "Nodes",
                "__SEARCH_PLACEHOLDER__": "搜索 Node ID、包名、描述...",
                "__NODES_ACTIVE_CLASS__": "active",
                "__FUNCTIONS_ACTIVE_CLASS__": "",
                "__NODES_CLICK_ATTR__": "",
                "__FUNCTIONS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/functions')\"",
                "__BROWSE_CONFIG__": json.dumps(
                    {
                        "mode": "nodes",
                        "fetchPath": "/nodes",
                        "itemsKey": "nodes",
                        "emptyText": "没有找到匹配的 Node",
                        "filterOptions": [{"value": "", "label": "全部包名"}],
                    },
                    ensure_ascii=False,
                ),
            },
            "functions": {
                "__PAGE_TITLE__": "Functions Browser",
                "__PAGE_COPY__": (
                    "按 function 资产查看 compile 可复用能力。切换 provider 地址后仍停留在同一 browse 页面，"
                    "便于直接横向比对不同 provider。"
                ),
                "__CAPABILITY_PRIMARY__": "Function Catalog",
                "__CAPABILITY_SECONDARY__": "Type Filter",
                "__CAPABILITY_TERTIARY__": "Compile Asset Browse",
                "__COUNT_LABEL__": "Functions",
                "__SEARCH_PLACEHOLDER__": "搜索 Function 名称、描述...",
                "__NODES_ACTIVE_CLASS__": "",
                "__FUNCTIONS_ACTIVE_CLASS__": "active",
                "__NODES_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/nodes')\"",
                "__FUNCTIONS_CLICK_ATTR__": "",
                "__BROWSE_CONFIG__": json.dumps(
                    {
                        "mode": "functions",
                        "fetchPath": "/functions",
                        "itemsKey": "functions",
                        "emptyText": "没有找到匹配的 Function",
                        "filterOptions": [
                            {"value": "", "label": "全部类型"},
                            {"value": "composite", "label": "复合函数"},
                            {"value": "node", "label": "节点函数"},
                        ],
                    },
                    ensure_ascii=False,
                ),
            },
        },
        "en": {
            "nodes": {
                "__PAGE_TITLE__": "Nodes Browser",
                "__PAGE_COPY__": (
                    "Browse UTG nodes by page. When you switch provider origin, this page stays"
                    " on the same browse view so you can keep comparing node ids, packages, and"
                    " XML samples."
                ),
                "__CAPABILITY_PRIMARY__": "Node Catalog",
                "__CAPABILITY_SECONDARY__": "Package Filter",
                "__CAPABILITY_TERTIARY__": "XML Sample Lookup",
                "__COUNT_LABEL__": "Nodes",
                "__SEARCH_PLACEHOLDER__": "Search node id, package, or description...",
                "__NODES_ACTIVE_CLASS__": "active",
                "__FUNCTIONS_ACTIVE_CLASS__": "",
                "__NODES_CLICK_ATTR__": "",
                "__FUNCTIONS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/functions')\"",
                "__BROWSE_CONFIG__": json.dumps(
                    {
                        "mode": "nodes",
                        "fetchPath": "/nodes",
                        "itemsKey": "nodes",
                        "emptyText": "No matching node found",
                        "filterOptions": [{"value": "", "label": "All packages"}],
                    },
                    ensure_ascii=False,
                ),
            },
            "functions": {
                "__PAGE_TITLE__": "Functions Browser",
                "__PAGE_COPY__": (
                    "Browse reusable compile assets by function. When you switch provider origin,"
                    " this page stays on the same browse view so you can compare providers side by side."
                ),
                "__CAPABILITY_PRIMARY__": "Function Catalog",
                "__CAPABILITY_SECONDARY__": "Type Filter",
                "__CAPABILITY_TERTIARY__": "Compile Asset Browse",
                "__COUNT_LABEL__": "Functions",
                "__SEARCH_PLACEHOLDER__": "Search function name or description...",
                "__NODES_ACTIVE_CLASS__": "",
                "__FUNCTIONS_ACTIVE_CLASS__": "active",
                "__NODES_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/nodes')\"",
                "__FUNCTIONS_CLICK_ATTR__": "",
                "__BROWSE_CONFIG__": json.dumps(
                    {
                        "mode": "functions",
                        "fetchPath": "/functions",
                        "itemsKey": "functions",
                        "emptyText": "No matching function found",
                        "filterOptions": [
                            {"value": "", "label": "All types"},
                            {"value": "composite", "label": "Composite"},
                            {"value": "node", "label": "Node"},
                        ],
                    },
                    ensure_ascii=False,
                ),
            },
        },
    }
    rendered = template
    for placeholder, value in replacements[lang][mode].items():
        rendered = rendered.replace(placeholder, value)
    rendered = rendered.replace(
        '<html lang="zh-CN">',
        f'<html lang="{"zh-CN" if lang == "zh" else "en"}">',
        1,
    )
    return rendered


def load_nodes_browser_html(*, lang: str = "zh") -> str:
    """Load the nodes browser shell."""

    return _load_browse_browser_html("nodes", lang=lang)


def load_functions_browser_html(*, lang: str = "zh") -> str:
    """Load the functions browser shell."""

    return _load_browse_browser_html("functions", lang=lang)


def _load_run_logs_browser_html(*, lang: str = "zh") -> str:
    """Load the run logs browser shell using the shared functions_browser template."""

    template = _read_text(_BROWSE_BROWSER_HTML_PATH)
    replacements = {
        "zh": {
            "__PAGE_TITLE__": "Run Logs Browser",
            "__PAGE_COPY__": (
                "这里保留 provider 最近执行的 canonical run。点击任意条目查看详细 timeline。"
                "切换 provider 地址后继续停留在当前日志页。"
            ),
            "__CAPABILITY_PRIMARY__": "Run Catalog",
            "__CAPABILITY_SECONDARY__": "Success Filter",
            "__CAPABILITY_TERTIARY__": "Timeline View",
            "__COUNT_LABEL__": "Runs",
            "__SEARCH_PLACEHOLDER__": "搜索 Goal、Run ID、来源...",
            "__NODES_ACTIVE_CLASS__": "",
            "__FUNCTIONS_ACTIVE_CLASS__": "",
            "__NODES_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/nodes')\"",
            "__FUNCTIONS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/functions')\"",
            "__BROWSE_CONFIG__": json.dumps(
                {
                    "mode": "run_logs",
                    "fetchPath": "/run_logs?limit=200",
                    "itemsKey": "runs",
                    "emptyText": "没有找到匹配的 Run Log",
                    "filterOptions": [
                        {"value": "", "label": "全部状态"},
                        {"value": "success", "label": "成功"},
                        {"value": "failed", "label": "失败"},
                        {"value": "hit", "label": "Compile Hit"},
                        {"value": "miss", "label": "Compile Miss"},
                    ],
                },
                ensure_ascii=False,
            ),
        },
        "en": {
            "__PAGE_TITLE__": "Run Logs Browser",
            "__PAGE_COPY__": (
                "Browse the provider's recent canonical runs. Open any entry to inspect the"
                " detailed timeline, and stay on the same page when you switch provider origin."
            ),
            "__CAPABILITY_PRIMARY__": "Run Catalog",
            "__CAPABILITY_SECONDARY__": "Success Filter",
            "__CAPABILITY_TERTIARY__": "Timeline View",
            "__COUNT_LABEL__": "Runs",
            "__SEARCH_PLACEHOLDER__": "Search goal, run id, or source...",
            "__NODES_ACTIVE_CLASS__": "",
            "__FUNCTIONS_ACTIVE_CLASS__": "",
            "__NODES_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/nodes')\"",
            "__FUNCTIONS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/functions')\"",
            "__BROWSE_CONFIG__": json.dumps(
                {
                    "mode": "run_logs",
                    "fetchPath": "/run_logs?limit=200",
                    "itemsKey": "runs",
                    "emptyText": "No matching run log found",
                    "filterOptions": [
                        {"value": "", "label": "All statuses"},
                        {"value": "success", "label": "Success"},
                        {"value": "failed", "label": "Failed"},
                        {"value": "hit", "label": "Compile Hit"},
                        {"value": "miss", "label": "Compile Miss"},
                    ],
                },
                ensure_ascii=False,
            ),
        },
    }
    rendered = template
    for placeholder, value in replacements[lang].items():
        rendered = rendered.replace(placeholder, value)
    rendered = rendered.replace(
        '<html lang="zh-CN">',
        f'<html lang="{"zh-CN" if lang == "zh" else "en"}">',
        1,
    )
    return rendered


def _load_data_ops_html(mode: str, *, lang: str = "zh") -> str:
    """Load the shared data-ops shell with per-route labels injected."""

    template = _read_text(_DATA_OPS_HTML_PATH)
    replacements = {
        "zh": {
            "rag_export": {
                "__PAGE_TITLE__": "RAG Export",
                "__PAGE_COPY__": (
                    "这里导出面向检索和记忆沉淀的文档。切换 provider 地址后仍保留在导出页，"
                    "便于横向查看不同 provider 的导出规模和内容。"
                ),
                "__CAPABILITY_PRIMARY__": "RAG Export",
                "__CAPABILITY_SECONDARY__": "Memory Bundle Export",
                "__CAPABILITY_TERTIARY__": "Document Preview",
                "__CONTROL_TITLE__": "导出设置",
                "__CONTROL_COPY__": "配置导出格式、LLM 增强和内容范围，直接预览 memory bundle 或导出完整检索文档。",
                "__RESULT_TITLE__": "导出结果",
                "__RUNLOGS_ACTIVE_CLASS__": "",
                "__RAG_ACTIVE_CLASS__": "active",
                "__RUNLOGS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/run_logs')\"",
                "__RAG_CLICK_ATTR__": "",
                "__DATA_OPS_CONFIG__": json.dumps(
                    {
                        "mode": "rag_export",
                    },
                    ensure_ascii=False,
                ),
            },
        },
        "en": {
            "rag_export": {
                "__PAGE_TITLE__": "RAG Export",
                "__PAGE_COPY__": (
                    "Export retrieval and memory documents here. When you switch provider"
                    " origin, this page stays on the export view so you can compare output"
                    " scale and content across providers."
                ),
                "__CAPABILITY_PRIMARY__": "RAG Export",
                "__CAPABILITY_SECONDARY__": "Memory Bundle Export",
                "__CAPABILITY_TERTIARY__": "Document Preview",
                "__CONTROL_TITLE__": "Export Settings",
                "__CONTROL_COPY__": "Configure output format, LLM enrichment, and content scope, then preview the memory bundle or export full retrieval documents.",
                "__RESULT_TITLE__": "Export Result",
                "__RUNLOGS_ACTIVE_CLASS__": "",
                "__RAG_ACTIVE_CLASS__": "active",
                "__RUNLOGS_CLICK_ATTR__": "onclick=\"navigateToProvider('/browse/run_logs')\"",
                "__RAG_CLICK_ATTR__": "",
                "__DATA_OPS_CONFIG__": json.dumps(
                    {
                        "mode": "rag_export",
                    },
                    ensure_ascii=False,
                ),
            },
        },
    }
    rendered = template
    for placeholder, value in replacements[lang][mode].items():
        rendered = rendered.replace(placeholder, value)
    rendered = rendered.replace(
        '<html lang="zh-CN">',
        f'<html lang="{"zh-CN" if lang == "zh" else "en"}">',
        1,
    )
    return rendered


def load_run_logs_browser_html(*, lang: str = "zh") -> str:
    """Load the run logs browser shell."""

    return _load_run_logs_browser_html(lang=lang)


def load_runlog_timeline_html(*, lang: str = "zh") -> str:
    """Load the provider-owned runlog timeline figure shell."""

    return _read_text(_RUNLOG_TIMELINE_HTML_PATH).replace(
        '<html lang="zh-CN">',
        f'<html lang="{"zh-CN" if lang == "zh" else "en"}">',
        1,
    )


def load_rag_export_html(*, lang: str = "zh") -> str:
    """Load the RAG export shell."""

    return _load_data_ops_html("rag_export", lang=lang)


def register_page_routes(app: FastAPI) -> None:
    """Register provider-owned HTML shells and static JS assets."""

    @app.get("/favicon.ico")
    async def favicon_route() -> Response:
        return Response(status_code=204)

    @app.get("/")
    async def dashboard_root_route() -> RedirectResponse:
        return RedirectResponse(url="/compile_test", status_code=307)

    @app.get("/dashboard", response_class=HTMLResponse)
    async def dashboard_route() -> HTMLResponse:
        return HTMLResponse(load_dashboard_html())

    @app.get("/demo", response_class=HTMLResponse)
    async def demo_route() -> HTMLResponse:
        return HTMLResponse(load_demo_html())

    @app.get("/details", response_class=HTMLResponse)
    async def detail_route() -> HTMLResponse:
        return HTMLResponse(load_detail_html())

    @app.get("/editor", response_class=HTMLResponse)
    async def editor_route() -> HTMLResponse:
        return HTMLResponse(load_editor_html())

    @app.get("/graph_viewer", response_class=HTMLResponse)
    async def graph_viewer_route() -> HTMLResponse:
        return HTMLResponse(load_graph_viewer_html())

    @app.get("/static/vis-network.min.js")
    async def vis_network_js_route() -> PlainTextResponse:
        if _VIS_NETWORK_JS_PATH.exists():
            return PlainTextResponse(
                _read_text(_VIS_NETWORK_JS_PATH),
                media_type="application/javascript",
            )
        return PlainTextResponse("// vis-network not found", status_code=404)

    @app.get("/static/provider_topbar.js")
    async def provider_topbar_js_route() -> PlainTextResponse:
        if _PROVIDER_TOPBAR_JS_PATH.exists():
            return PlainTextResponse(
                _read_text(_PROVIDER_TOPBAR_JS_PATH),
                media_type="application/javascript",
            )
        return PlainTextResponse("// provider_topbar not found", status_code=404)

    @app.get("/xml_compare", response_class=HTMLResponse)
    async def xml_compare_route() -> HTMLResponse:
        return HTMLResponse(load_xml_compare_html())

    @app.get("/compile_test", response_class=HTMLResponse)
    async def compile_test_route() -> HTMLResponse:
        return HTMLResponse(load_compile_test_html())

    @app.get("/browse/nodes", response_class=HTMLResponse)
    async def nodes_browser_route(
        http_request: Request,
        lang: str | None = None,
    ) -> HTMLResponse:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return HTMLResponse(load_nodes_browser_html(lang=resolved_lang))

    @app.get("/browse/functions", response_class=HTMLResponse)
    async def functions_browser_route(
        http_request: Request,
        lang: str | None = None,
    ) -> HTMLResponse:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return HTMLResponse(load_functions_browser_html(lang=resolved_lang))

    @app.get("/browse/run_logs", response_class=HTMLResponse)
    async def run_logs_browser_route(
        http_request: Request,
        lang: str | None = None,
    ) -> HTMLResponse:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return HTMLResponse(load_run_logs_browser_html(lang=resolved_lang))

    @app.get("/browse/run_logs/{run_id}/timeline", response_class=HTMLResponse)
    async def run_log_timeline_route(
        run_id: str,
        http_request: Request,
        lang: str | None = None,
    ) -> HTMLResponse:
        del run_id
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return HTMLResponse(load_runlog_timeline_html(lang=resolved_lang))

    @app.get("/browse/rag_export", response_class=HTMLResponse)
    async def rag_export_route(
        http_request: Request,
        lang: str | None = None,
    ) -> HTMLResponse:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return HTMLResponse(load_rag_export_html(lang=resolved_lang))
