"""
Pydantic input models for utg_api.py validation.

Replaces defensive parsing patterns with declarative validation.
"""

from __future__ import annotations

from typing import Any, Dict, List

from pydantic import BaseModel, Field, field_validator

# =============================================================================
# Base validators - reusable coercion functions
# =============================================================================


def _coerce_str(v: Any) -> str:
    """Coerce value to stripped string."""
    return str(v or "").strip()


def _coerce_dict(v: Any) -> Dict[str, Any]:
    """Coerce value to dict."""
    return dict(v) if isinstance(v, dict) else {}


# =============================================================================
# Run Log Models (for _collect_path_run_usage)
# =============================================================================


class ActResultModel(BaseModel):
    """Validated act_result from a step."""

    success: bool = False
    error_code: str = ""
    error_message: str = ""
    source: str = ""

    @field_validator("success", mode="before")
    @classmethod
    def coerce_bool(cls, v: Any) -> bool:
        return bool(v) if v is not None else False

    @field_validator("error_code", "error_message", "source", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return _coerce_str(v)


class PlanModel(BaseModel):
    """Validated plan from a step."""

    tool_name: str = ""
    tool_args: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("tool_name", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return _coerce_str(v)

    @field_validator("tool_args", mode="before")
    @classmethod
    def coerce_dict(cls, v: Any) -> Dict[str, Any]:
        return _coerce_dict(v)

    @property
    def function_id(self) -> str:
        # 如果 tool_name 看起来像 function_id（包含-或_，或特定前缀）
        # 则将其视为 function_id
        tool_name = self.tool_name
        if tool_name and (
            "-" in tool_name
            or "_" in tool_name
            or tool_name.startswith("fn_")
            or tool_name.startswith("global-")
        ):
            return tool_name
        return ""


class CompileResultModel(BaseModel):
    """Validated compile_result from a step."""

    function_id: str = ""
    success: bool = False

    @field_validator("function_id", mode="before")
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return _coerce_str(v)

    @field_validator("success", mode="before")
    @classmethod
    def coerce_bool(cls, v: Any) -> bool:
        return bool(v) if v is not None else False


class RunStepModel(BaseModel):
    """Validated step from a run log."""

    plan: PlanModel = Field(default_factory=PlanModel)
    compile_result: CompileResultModel = Field(default_factory=CompileResultModel)
    act_result: ActResultModel = Field(default_factory=ActResultModel)

    @field_validator("plan", mode="before")
    @classmethod
    def coerce_plan(cls, v: Any) -> Dict[str, Any]:
        return _coerce_dict(v)

    @field_validator("compile_result", mode="before")
    @classmethod
    def coerce_compile_result(cls, v: Any) -> Dict[str, Any]:
        return _coerce_dict(v)

    @field_validator("act_result", mode="before")
    @classmethod
    def coerce_act_result(cls, v: Any) -> Dict[str, Any]:
        return _coerce_dict(v)

    @property
    def effective_function_id(self) -> str:
        """Get function_id from plan or compile_result."""
        return self.plan.function_id or self.compile_result.function_id


class RunLogModel(BaseModel):
    """Validated run log for path usage collection."""

    run_id: str = ""
    goal: str = ""
    started_at: str = ""
    finished_at: str = ""
    done_reason: str = ""
    success: bool = False
    source: str = ""
    steps: List[RunStepModel] = Field(default_factory=list)

    @field_validator(
        "run_id",
        "goal",
        "started_at",
        "finished_at",
        "done_reason",
        "source",
        mode="before",
    )
    @classmethod
    def coerce_str(cls, v: Any) -> str:
        return _coerce_str(v)

    @field_validator("success", mode="before")
    @classmethod
    def coerce_bool(cls, v: Any) -> bool:
        return bool(v) if v is not None else False

    @field_validator("steps", mode="before")
    @classmethod
    def coerce_steps(cls, v: Any) -> List[Dict[str, Any]]:
        if not isinstance(v, list):
            return []
        return [_coerce_dict(s) for s in v]


# =============================================================================
# Parser functions
# =============================================================================


def parse_run_log(raw: Any) -> RunLogModel:
    """Parse raw run log dict into validated model."""
    if isinstance(raw, RunLogModel):
        return raw
    return RunLogModel.model_validate(_coerce_dict(raw))


__all__ = [
    # Run log models
    "ActResultModel",
    "PlanModel",
    "CompileResultModel",
    "RunStepModel",
    "RunLogModel",
    # Parser functions
    "parse_run_log",
]
