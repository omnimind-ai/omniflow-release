"""
WebArena VLM Planner - 使用 DashScope (通义千问) 作为 fallback

当 function cache miss 时，使用 VLM 生成 action
"""

from __future__ import annotations

import logging
from typing import List

from src.foundation.ai.litellm_client import acomplete_with_tools
from src.omniflow import Action, Observation
from src.utg.core.actions import build_tool_schemas

logger = logging.getLogger(__name__)


class DashScopeVLMPlanner:
    """
    DashScope VLM Planner (通义千问)

    使用 DashScope API 的 tool calling 功能生成 action
    """

    def __init__(
        self,
        *,
        model: str = "qwen-max",
        provider: str = "dashscope",
        timeout: float = 30.0,
    ):
        """
        Args:
            model: DashScope 模型名称 (qwen-turbo, qwen-plus, qwen-max)
            provider: Provider 名称
            timeout: API 超时时间（秒）
        """
        self.model = model
        self.provider = provider
        self.timeout = timeout

    async def plan(self, goal: str, observation: Observation) -> Action | List[Action]:
        """
        根据 goal 和 observation 决策下一步 action

        Args:
            goal: 任务目标描述
            observation: 当前页面观测

        Returns:
            单个 Action 或 Action 列表

        Note:
            遵循 OmniFlow Planner 协议，返回单个 Action（推荐）
        """
        # 构建 prompt
        prompt = self._build_prompt(goal, observation)

        # 获取工具定义（OmniFlow 基础 actions）
        tools = build_tool_schemas()

        logger.info(
            f"VLM planning with {self.provider}/{self.model}, "
            f"goal='{goal}', tools={len(tools)}"
        )

        try:
            # 调用 DashScope API
            result = await acomplete_with_tools(
                prompt=prompt,
                tools=tools,
                provider=self.provider,
                model=self.model,
                timeout=self.timeout,
                tool_choice="required",  # 强制使用工具
            )

            if not result:
                logger.warning("VLM returned empty result")
                return Action(type="none", params={})

            # 转换为 Action
            action = Action(
                type=result["name"],
                params=result["arguments"],
            )

            logger.info(f"VLM planned action: {action.type} {action.params}")
            return action

        except Exception as e:
            logger.error(f"VLM planning failed: {e}", exc_info=True)
            # 返回 none action
            return Action(type="none", params={})

    def _build_prompt(self, goal: str, observation: Observation) -> str:
        """
        构建 VLM prompt

        Args:
            goal: 任务目标
            observation: 页面观测

        Returns:
            Prompt 字符串
        """
        # 简化版 prompt（可以后续优化）
        prompt = f"""You are a web automation assistant.

Goal: {goal}

Current Page:
- URL: {getattr(observation, "url", "N/A")}
- Package: {getattr(observation, "package_name", "N/A")}

Page Structure (XML):
{observation.xml[:2000] if len(observation.xml) > 2000 else observation.xml}

Based on the goal and current page, decide the NEXT SINGLE ACTION to take.
Use the provided tools to perform the action.

Important:
- Return ONLY ONE action (single-step execution)
- Choose the most appropriate tool
- Provide accurate parameters (coordinates, text, etc.)
"""
        return prompt


class OpenAIVLMPlanner:
    """
    OpenAI VLM Planner (GPT-4o)

    使用 OpenAI API 的 tool calling 功能生成 action
    """

    def __init__(
        self,
        *,
        model: str = "gpt-4o",
        provider: str = "openai",
        timeout: float = 30.0,
    ):
        """
        Args:
            model: OpenAI 模型名称 (gpt-4o, gpt-4o-mini)
            provider: Provider 名称
            timeout: API 超时时间（秒）
        """
        self.model = model
        self.provider = provider
        self.timeout = timeout

    async def plan(self, goal: str, observation: Observation) -> Action | List[Action]:
        """
        根据 goal 和 observation 决策下一步 action

        Args:
            goal: 任务目标描述
            observation: 当前页面观测

        Returns:
            单个 Action 或 Action 列表
        """
        # 构建 prompt
        prompt = self._build_prompt(goal, observation)

        # 获取工具定义
        tools = build_tool_schemas()

        logger.info(
            f"VLM planning with {self.provider}/{self.model}, "
            f"goal='{goal}', tools={len(tools)}"
        )

        try:
            # 调用 OpenAI API
            result = await acomplete_with_tools(
                prompt=prompt,
                tools=tools,
                provider=self.provider,
                model=self.model,
                timeout=self.timeout,
                tool_choice="required",
            )

            if not result:
                logger.warning("VLM returned empty result")
                return Action(type="none", params={})

            # 转换为 Action
            action = Action(
                type=result["name"],
                params=result["arguments"],
            )

            logger.info(f"VLM planned action: {action.type} {action.params}")
            return action

        except Exception as e:
            logger.error(f"VLM planning failed: {e}", exc_info=True)
            return Action(type="none", params={})

    def _build_prompt(self, goal: str, observation: Observation) -> str:
        """构建 VLM prompt"""
        prompt = f"""You are a web automation assistant.

Goal: {goal}

Current Page:
- URL: {getattr(observation, "url", "N/A")}
- Package: {getattr(observation, "package_name", "N/A")}

Page Structure (XML):
{observation.xml[:2000] if len(observation.xml) > 2000 else observation.xml}

Based on the goal and current page, decide the NEXT SINGLE ACTION to take.
Use the provided tools to perform the action.

Important:
- Return ONLY ONE action (single-step execution)
- Choose the most appropriate tool
- Provide accurate parameters (coordinates, text, etc.)
"""
        return prompt


__all__ = ["DashScopeVLMPlanner", "OpenAIVLMPlanner"]
