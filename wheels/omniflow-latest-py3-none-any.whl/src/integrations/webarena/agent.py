"""
WebArena Agent - OmniFlow 集成

使用 AsyncWebHost + OmniFlow compile-first 执行 WebArena 任务
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from src.integrations.utg_api import _canonical_run_log_path
from src.omniflow import Observation, OmniFlow
from src.omniflow.hosts.web_host import AsyncWebHost

logger = logging.getLogger(__name__)

MODE_UTG_ONLY = "utg_only"

# 默认值
DEFAULT_MAX_STEPS = 10


class WebArenaAgent:
    """
    WebArena 任务执行 Agent

    架构:
    - AsyncWebHost: 负责 Web 页面交互 (observe/act)
    - OmniFlow: 负责 compile-first function execution
    """

    def __init__(
        self,
        page: Any,  # Playwright Page 实例
        *,
        utg_store_path: Optional[str] = None,
        omniflow: Optional[OmniFlow] = None,
        max_steps: int = DEFAULT_MAX_STEPS,
        wait_after_action: int = 1000,  # ms
    ):
        """
        Args:
            page: Playwright Page 实例
            utg_store_path: UTG store 路径
            omniflow: 预初始化的 OmniFlow 实例 (可选)
            max_steps: 最大步数
            wait_after_action: 动作后等待时间（毫秒）
        """
        # Web Host
        self.host = AsyncWebHost(
            page=page,
            wait_after_action=wait_after_action,
        )

        # OmniFlow function cache（启用 runlog）
        if omniflow is not None:
            self.omniflow = omniflow
        elif utg_store_path:
            self.omniflow = OmniFlow(
                utg_store_path,
                host=self.host,
                enable_runlog=True,
                runlog_path=_canonical_run_log_path(),
            )
        else:
            raise ValueError("Must provide either omniflow or utg_store_path")

        self.max_steps = max_steps
        self._step_count = 0

    async def step(self, goal: str, *, observe_first: bool = True) -> Dict[str, Any]:
        """
        执行单步任务

        Args:
            goal: 任务目标描述
            observe_first: 是否先 observe 当前页面

        Returns:
            Dict: {
                "success": bool,
                "route": "cache" | "vlm" | "error",
                "compile_hit": bool,
                "error": Optional[str],
            }
        """
        self._step_count += 1

        if self._step_count > self.max_steps:
            return {
                "success": False,
                "route": "error",
                "compile_hit": False,
                "error": f"Exceeded max steps ({self.max_steps})",
            }

        try:
            # 1. Observe 当前页面
            if observe_first:
                obs = await self.host.aobserve(xml=True, screenshot=False)
                logger.info(
                    f"[Step {self._step_count}] Observed page: {obs.package_name}"
                )
            else:
                obs = None

            # 2. Compile: 查找已缓存 function
            compile_result = await self._compile(goal, obs)
            step_result = await self.omniflow.astep(
                goal,
                step_index=max(self._step_count - 1, 0),
                observation=obs,
            )
            execution_ok = (not bool(step_result.fallback)) and not bool(
                step_result.error
            )

            if compile_result.get("hit"):
                # 3a. Cache Hit: 执行已有 function
                logger.info(
                    f"[Step {self._step_count}] Cache HIT: {compile_result.get('function_id')}"
                )

                return {
                    "success": execution_ok,
                    "route": "cache",
                    "compile_hit": True,
                    "function_id": compile_result.get("function_id"),
                    "steps_executed": step_result.actions_executed,
                    "error": step_result.error,
                }

            if step_result.source == "agent":
                logger.info(f"[Step {self._step_count}] VLM fallback executed")
                return {
                    "success": execution_ok,
                    "route": "vlm",
                    "compile_hit": False,
                    "steps_executed": step_result.actions_executed,
                    "error": step_result.error,
                }

            # 完全 miss (无 cache 也无 planner)
            logger.warning(f"[Step {self._step_count}] Cache MISS (no fallback)")
            return {
                "success": False,
                "route": "error",
                "compile_hit": False,
                "error": step_result.error
                or compile_result.get("error")
                or "No cached function and no planner fallback available",
            }

        except Exception as e:
            logger.error(f"[Step {self._step_count}] Error: {e}", exc_info=True)
            return {
                "success": False,
                "route": "error",
                "compile_hit": False,
                "error": str(e),
            }

    async def _compile(self, goal: str, obs: Optional[Observation]) -> Dict[str, Any]:
        """
        调用 OmniFlow runtime.compile(...) 获取 compile 命中结果

        Returns:
            Dict: {"hit": bool, "function_id": Optional[str], "decision": str, ...}
        """
        try:
            from src.utg.execution.compile import CompileContext

            result = self.omniflow.runtime.compile(
                goal,
                context=CompileContext(
                    current_node_id=str(
                        getattr(obs, "extra", {}).get("current_node_id", "") or ""
                    ).strip()
                    or None,
                    current_package=getattr(obs, "package_name", None),
                ),
            )
            if hasattr(result, "to_dict"):
                result = result.to_dict()
            if not isinstance(result, dict):
                result = dict(getattr(result, "__dict__", {}) or {})
            decision = str(result.get("decision") or "miss").strip() or "miss"

            return {
                "hit": decision == "hit",
                "function_id": str(result.get("function_id") or "").strip() or None,
                "decision": decision,
                "reason": str(result.get("reason") or "").strip() or None,
            }
        except Exception as e:
            logger.warning(f"Compile failed: {e}")
            return {"hit": False, "error": str(e)}

    def reset(self) -> None:
        """重置 agent 状态"""
        self._step_count = 0
        logger.info("Agent reset")


def build_web_agent(
    *,
    page: Any,
    utg_store_path: Optional[str] = None,
    omniflow: Optional[OmniFlow] = None,
    planner: Optional[Any] = None,
    use_vlm_fallback: bool = True,
    vlm_provider: str = "dashscope",
    vlm_model: str = "qwen-max",
    max_steps: int = DEFAULT_MAX_STEPS,
    wait_after_action: int = 1000,  # ms
) -> WebArenaAgent:
    """
    构建 WebArena Agent

    Args:
        page: Playwright Page 实例
        utg_store_path: UTG store 路径
        omniflow: 预初始化的 OmniFlow 实例 (可选)
        planner: VLM planner 实例 (可选，默认使用 DashScope)
        use_vlm_fallback: 是否启用 VLM fallback (cache miss 时)
        vlm_provider: VLM provider (dashscope, openai)
        vlm_model: VLM 模型名称
        max_steps: 最大步数
        wait_after_action: 动作后等待时间（毫秒）

    Returns:
        WebArenaAgent 实例

    Example:
        >>> from playwright.async_api import async_playwright
        >>> async with async_playwright() as p:
        ...     browser = await p.chromium.launch()
        ...     page = await browser.new_page()
        ...     await page.goto("https://example.com")
        ...
        ...     # 默认使用 DashScope VLM fallback
        ...     agent = build_web_agent(
        ...         page=page,
        ...         utg_store_path="data/utg_webarena.json"
        ...     )
        ...
        ...     # 禁用 VLM fallback (cache miss 时报错)
        ...     agent = build_web_agent(
        ...         page=page,
        ...         utg_store_path="data/utg_webarena.json",
        ...         use_vlm_fallback=False
        ...     )
        ...
        ...     # 使用 OpenAI VLM
        ...     agent = build_web_agent(
        ...         page=page,
        ...         utg_store_path="data/utg_webarena.json",
        ...         vlm_provider="openai",
        ...         vlm_model="gpt-4o"
        ...     )
        ...
        ...     result = await agent.step("Find products under $50")
    """
    # 如果没有提供 omniflow，自动创建并配置 planner
    if omniflow is None:
        # 导入 planner（延迟导入避免循环依赖）
        if planner is None and use_vlm_fallback:
            from src.integrations.webarena.vlm_planner import (
                DashScopeVLMPlanner,
                OpenAIVLMPlanner,
            )

            if vlm_provider == "dashscope":
                planner = DashScopeVLMPlanner(model=vlm_model)
                logger.info(f"Using DashScope VLM fallback: {vlm_model}")
            elif vlm_provider == "openai":
                planner = OpenAIVLMPlanner(model=vlm_model)
                logger.info(f"Using OpenAI VLM fallback: {vlm_model}")
            else:
                raise ValueError(f"Unknown VLM provider: {vlm_provider}")

        # 创建 host
        host = AsyncWebHost(page=page, wait_after_action=wait_after_action)

        # 创建 OmniFlow with planner（启用 runlog）
        omniflow = OmniFlow(
            utg_store_path,
            host=host,
            planner=planner,
            max_steps=max_steps,
            enable_runlog=True,
            runlog_path=_canonical_run_log_path(),
        )

    return WebArenaAgent(
        page=page,
        omniflow=omniflow,
        max_steps=max_steps,
        wait_after_action=wait_after_action,
    )
