from __future__ import annotations

__all__ = [
    "OpenOmniBotBridgeClient",
    "UTGRuntime",
    "build_app",
    "compile_goal",
    "health",
    "execute_function",
]


def __getattr__(name: str):
    if name in set(__all__):
        from . import utg_api

        return getattr(utg_api, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
