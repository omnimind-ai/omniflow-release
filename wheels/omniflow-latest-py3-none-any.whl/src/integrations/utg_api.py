from __future__ import annotations

import argparse
import asyncio
import base64
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
from time import perf_counter
from typing import Any
import xml.etree.ElementTree as ET

import aiohttp
from fastapi import FastAPI
import numpy as np
import uvicorn

from src.foundation.ai import (
    default_llm_model,
    resolve_llm_provider,
)
from src.foundation.paths import get_runtime_dir, get_runtime_file
from src.foundation.source_tools import find_node_center_by_id, to_serializable
from src.integrations.api.contracts import (
    CompileRequest,
    DownloadCloudFunctionRequest,
    ExecuteFunctionRequest,
    ImportFunctionBundleRequest,
    ImportRunLogRequest,
    ManualCaptureRequest,
    ReplayRunLogRequest,
    RunLogIngestRequest,
    SharedPageImportRequest,
    SharedPageMapCoordinatesRequest,
    SharedPageSearchRequest,
    UploadCloudFunctionRequest,
    resolve_api_language,
)
from src.integrations.api.ops import (
    capture_manual_page as _capture_manual_page_impl,
)
from src.integrations.api.ops import (
    check_oob_workbench_environment as _check_oob_workbench_environment_impl,
)
from src.integrations.api.ops import (
    health as _health_impl,
)
from src.integrations.api.ops import (
    register_ops_routes,
)
from src.integrations.api.ops import (
    run_workbench_command as _run_workbench_command,
)
from src.integrations.api.pages import register_page_routes
from src.integrations.api.services import register_service_routes
from src.integrations.utg_api_models import (
    parse_run_log,
)
from src.utg.core.actions import (
    CallFunctionAction,
    CallFunctionParams,
    DeviceKey,
    action_key_value,
    action_params_of,
    canonical_action_payload,
    canonical_action_type,
    make_press_key_action,
    parse_action_payload,
)
from src.utg.core.graph_ops import find_shortest_path_edges
from src.utg.core.models import Function, NodeRepr, UTGGraph, UTGNode
from src.utg.execution.compile import CompileContext
from src.utg.execution.control.error_codes import EXEC_ACTION_NO_EFFECT
from src.utg.execution.protocol import DeviceObservation
from src.utg.log.run_logger import UTGRunLogger
from src.utg.runtime import UTGRuntime
from src.utg.testing.observation_eval import (
    export_observation_benchmark_bundle,
    score_action_effect_benchmark,
    score_node_match_benchmark,
)

SUPPORTED_BRIDGE_ACTIONS = [
    "click",
    "long_press",
    "input_text",
    "swipe",
    "open_app",
    "press_key",
    "wait",
    "finished",
]
PROVIDER_ID = "omniflow_utg"
HOST_CALLBACKS = ["observe", "act", "confirm"]
PROVIDER_API_METHODS = [
    "health",
    "reset_provider",
    "capture_manual",
    "workbench_oob_check",
    "workbench_oob_one_click",
    "graph_shortest_path",
    "graph_export_dot",
    "graph_export_mermaid",
    "graph_apps",
    "app_graph",
    "app_graph_node",
    "nodes",
    "functions",
    "get_function",
    "delete_function",
    "enrich_function",
    "split_function",
    "merge_functions_preview",
    "merge_functions_save",
    "function_bundle",
    "import_function_bundle",
    "pull_function",
    "push_function",
    "run_logs",
    "run_logs_global_index",
    "ingest_run_log",
    "import_run_log",
    "replay_run_log",
    "get_run_log",
    "run_log_timeline_payload",
    "shared_pages",
    "get_shared_page",
    "import_shared_page",
    "search_shared_pages",
    "map_shared_coordinates",
    "enrich_node",
    "export_node_memory",
    "export_memory_bundle",
    "export_memory_to_dir",
    "export_rag_memory",
    "compile",
    "decompose_goal",
    "vlm_pre_hook",
    "execute_function",
    "xml_search",
    "xml_compare",
    "xml_map_coordinates",
    "xml_node_screenshot",
    "merge_stats",
]
SMOKE_TEST_UTG_PATH = (
    Path(__file__).resolve().parents[2] / "tests" / "fixtures" / "utg_smoke_test.json"
).resolve()
_IMPORT_RUN_LOG_CACHE: dict[str, dict[str, Any]] = {}
RAW_REPLAY_FUNCTION_KIND = "raw_replay"
FUNCTION_ASSET_KIND = "function_asset"
TEMPORARY_ASSET_STATE = "temporary"
READY_ASSET_STATE = "ready"
_REPO_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_PROVIDER_PORT = int(os.getenv("OMNIFLOW_UTG_API_PORT", "19070"))
_DEFAULT_BRIDGE_PORT = int(os.getenv("OOB_UTG_BRIDGE_PORT", "8899"))
_DEFAULT_OOB_PACKAGE = "cn.com.omnimind.bot.debug"
logger = logging.getLogger(__name__)

# =============================================================================
# Background Task System
# =============================================================================
_BACKGROUND_TASKS: dict[str, dict[str, Any]] = {}


def _create_background_task(
    task_type: str,
    ref_id: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Create a background task and return its ID."""
    task_id = (
        f"task_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')}_{ref_id[:8]}"
    )
    _BACKGROUND_TASKS[task_id] = {
        "task_id": task_id,
        "task_type": task_type,
        "ref_id": ref_id,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "started_at": None,
        "finished_at": None,
        "result": None,
        "error": None,
        "metadata": metadata or {},
    }
    return task_id


def _update_background_task(
    task_id: str,
    *,
    status: str | None = None,
    result: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    """Update a background task status."""
    if task_id not in _BACKGROUND_TASKS:
        return
    task = _BACKGROUND_TASKS[task_id]
    now = datetime.now(timezone.utc).isoformat()
    if status:
        task["status"] = status
        if status == "running" and task["started_at"] is None:
            task["started_at"] = now
        if status in ("completed", "failed"):
            task["finished_at"] = now
    if result is not None:
        task["result"] = result
    if error is not None:
        task["error"] = error


def get_background_task(task_id: str) -> dict[str, Any] | None:
    """Get background task status by ID."""
    return _BACKGROUND_TASKS.get(task_id)


def list_background_tasks(
    *,
    task_type: str | None = None,
    status: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """List recent background tasks."""
    tasks = list(_BACKGROUND_TASKS.values())
    if task_type:
        tasks = [t for t in tasks if t.get("task_type") == task_type]
    if status:
        tasks = [t for t in tasks if t.get("status") == status]
    # Sort by created_at desc
    tasks.sort(key=lambda t: t.get("created_at", ""), reverse=True)
    return tasks[:limit]


_API_L10N = {
    "zh": {
        "reuse_function_with_id": "复用 Function · {function_id}",
        "reuse_function": "复用 Function",
        "vlm_execution": "VLM 执行",
        "no_tool": "无 Tool",
        "omniflow_executed_goal": "OmniFlow 已执行：{goal}",
        "omniflow_executed_done": "OmniFlow 已执行完成",
        "omniflow_failed_reason": "OmniFlow 执行失败：{done_reason}",
        "omniflow_failed_generic": "OmniFlow 执行失败",
        "no_displayable_steps": (
            "OmniFlow 没有记录可展示的步骤。常见原因：compile 前失败、首个观察前中断，"
            "或仅保留了外层执行壳。"
        ),
        "compile_request_failed_use_planner": "UTG compile 请求失败，缓存层不可用，请使用 planner",
        "compile_request_failed_blocked": "UTG compile 请求失败，任务中止",
        "compile_hit_summary": "UTG compile 命中：{function_id}；使用缓存 Function",
        "cache_miss_use_planner": "缓存层无匹配，请使用 planner",
        "cache_miss_blocked": "缓存层无匹配，且已禁用 planner fallback",
        "compile_short_hit": "UTG compile 命中：{function_id}",
        "compile_short_miss_candidates": "UTG compile 未命中：{candidate_ids}",
        "compile_short_miss_reason": "UTG compile 未命中：{reason}",
        "compile_short_miss_goal": "UTG compile 未命中：{goal}",
        "planner_guidance_intro": "UTG compile 未命中。在走通用屏幕推理前，先检查这些已编译 Function 是否能直接完成目标。",
        "planner_guidance_goal": "目标：{goal}",
        "planner_guidance_call": "如果已有 Function 适合，请直接调用这些 function_id 中的一个：",
        "planner_guidance_fallback": "只有当这些候选 Function 都不适合当前目标时，才回退到普通 VLM 屏幕动作。",
        "utg_completed_goal": "已通过 UTG 执行完成：{goal}",
        "utg_executed_goal": "已通过 UTG 执行：{goal}",
        "utg_failed_code": "UTG 执行失败：{error_code}",
        "utg_failed_generic": "UTG 执行失败",
        "function_execute_success": "执行 function {function_id} 成功",
        "function_execute_failed": "执行 function {function_id} 失败",
    },
    "en": {
        "reuse_function_with_id": "Reuse Function · {function_id}",
        "reuse_function": "Reuse Function",
        "vlm_execution": "VLM Execution",
        "no_tool": "No Tool",
        "omniflow_executed_goal": "OmniFlow executed: {goal}",
        "omniflow_executed_done": "OmniFlow execution completed",
        "omniflow_failed_reason": "OmniFlow execution failed: {done_reason}",
        "omniflow_failed_generic": "OmniFlow execution failed",
        "no_displayable_steps": (
            "OmniFlow did not record any displayable steps. Common reasons: failure before compile,"
            " interruption before the first observation, or only the outer execution shell was preserved."
        ),
        "compile_request_failed_use_planner": "UTG compile request failed; cache layer unavailable. Use planner.",
        "compile_request_failed_blocked": "UTG compile request failed; task blocked.",
        "compile_hit_summary": "UTG compile hit: {function_id}; using cached Function.",
        "cache_miss_use_planner": "No cache match; use planner.",
        "cache_miss_blocked": "No cache match and planner fallback is disabled.",
        "compile_short_hit": "UTG compile hit: {function_id}",
        "compile_short_miss_candidates": "UTG compile miss: {candidate_ids}",
        "compile_short_miss_reason": "UTG compile miss: {reason}",
        "compile_short_miss_goal": "UTG compile miss: {goal}",
        "planner_guidance_intro": "UTG compile missed. Before using generic screen reasoning, first check whether one of these compiled Functions can finish the goal directly.",
        "planner_guidance_goal": "Goal: {goal}",
        "planner_guidance_call": "If an existing Function fits, call one of these function_ids directly:",
        "planner_guidance_fallback": "Only fall back to normal VLM screen actions when none of these candidate Functions fits the current goal.",
        "utg_completed_goal": "Completed via UTG: {goal}",
        "utg_executed_goal": "Executed via UTG: {goal}",
        "utg_failed_code": "UTG execution failed: {error_code}",
        "utg_failed_generic": "UTG execution failed",
        "function_execute_success": "Function {function_id} executed successfully",
        "function_execute_failed": "Function {function_id} execution failed",
    },
}


def _api_text(lang: str | None, key: str, **kwargs: Any) -> str:
    """Render one provider-owned user-visible string in the requested language.

    Args:
        lang: Optional provider language code. Unsupported values fall back to
            the provider default language.
        key: Stable translation key inside `_API_L10N`.
        **kwargs: Format arguments used by the selected copy template.

    Returns:
        One formatted provider-owned string for API/page rendering.
    """

    resolved_lang = resolve_api_language(lang=lang)
    template = _API_L10N[resolved_lang][key]
    return template.format(**kwargs)


def _read_node_id(node: Any) -> str:
    """Return one normalized node id from either UTGNode or dict payload.

    Args:
        node: One in-memory UTG node object or dict-like node payload.

    Returns:
        The stable node id string, or `""` when the node payload does not carry
        a valid id.
    """

    if isinstance(node, dict):
        return str(node.get("id") or "").strip()
    return str(getattr(node, "id", "") or "").strip()


def _canonical_run_log_path() -> str:
    """Return the unified persisted event-stream path for integration readers."""

    return str(get_runtime_file("logs", "run_logs.jsonl"))


def _multi_user_registry_path() -> str:
    """Return the anonymized multi-user global registry path.

    Returns:
        One runtime-backed JSON file that stores only hashed user/session tags
        plus aggregate counts for provider-side global management.
    """

    return str(get_runtime_file("logs", "multi_user_registry.json"))


async def _check_oob_workbench_environment(
    runtime: UTGRuntime,
    *,
    adb_serial: str,
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    """Collect one desktop workbench snapshot for the current OOB bridge chain."""

    return await _check_oob_workbench_environment_impl(
        runtime,
        adb_serial=adb_serial,
        timeout_seconds=timeout_seconds,
        provider_id=PROVIDER_ID,
        provider_api_methods=PROVIDER_API_METHODS,
        host_callbacks=HOST_CALLBACKS,
        supported_bridge_actions=SUPPORTED_BRIDGE_ACTIONS,
        canonical_run_log_path=_canonical_run_log_path(),
    )


def _utc_now_compact() -> str:
    """Return one filesystem-safe UTC timestamp used by one-shot capture assets."""

    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _shared_vector_store_dir() -> Path:
    """Return the provider-side shared vector store directory.

    Returns:
        One runtime-backed directory used to persist privacy-safe shared pages.
    """

    return get_runtime_dir("shared_backend", "pages")


def _normalize_shared_page_id(page_id: str) -> str:
    """Normalize one shared page id for filesystem-safe persistence.

    Args:
        page_id: Caller-provided page id or derived id candidate.

    Returns:
        One sanitized identifier containing only alnum / `_-.` characters.
    """

    raw = str(page_id or "").strip()
    if not raw:
        return ""
    normalized = "".join(
        ch if (ch.isalnum() or ch in ("_", "-", ".")) else "_" for ch in raw
    ).strip("._")
    while "__" in normalized:
        normalized = normalized.replace("__", "_")
    return normalized[:120]


def _shared_page_file(page_id: str) -> Path:
    """Return the persisted JSON file path for one shared page id.

    Args:
        page_id: Stable shared page identifier.

    Returns:
        Absolute runtime file path under the shared vector store.
    """

    normalized_page_id = _normalize_shared_page_id(page_id)
    return _shared_vector_store_dir() / f"{normalized_page_id}.json"


def _sanitize_xml_for_upload(xml_text: str) -> str:
    """Redact user-visible XML text before provider-to-provider upload.

    Args:
        xml_text: Raw UI hierarchy XML captured locally and stored in the UTG.

    Returns:
        One XML string that preserves structure, bounds, package, and developer
        identifiers, while replacing user-visible text-like attributes with
        stable hash tokens. Parse failures fall back to the original string.
    """

    normalized_xml = str(xml_text or "").strip()
    if not normalized_xml:
        return ""
    try:
        root = ET.fromstring(normalized_xml)
    except Exception:
        return normalized_xml
    for element in root.iter():
        for attr_name in (
            "text",
            "content-desc",
            "hint-text",
            "hint_text",
            "tooltip",
        ):
            raw_value = str(element.attrib.get(attr_name) or "").strip()
            if not raw_value:
                continue
            hashed_value = hashlib.sha256(
                raw_value.lower().encode("utf-8")
            ).hexdigest()[:12]
            element.set(attr_name, f"hash:{hashed_value}")
    return ET.tostring(root, encoding="unicode")


def _sanitize_bundle_graph_for_upload(graph: dict[str, Any]) -> dict[str, Any]:
    """Build an upload-safe function bundle without leaking local raw XML.

    Args:
        graph: Function bundle payload produced by `export_function_bundle(...)`.

    Returns:
        A deep-copied graph payload whose node XMLs are text-redacted, whose
        screenshots are removed, and whose `xml_ref` / `xmlRef` fields are
        remapped to the redacted XML snapshots.
    """

    sanitized_graph = copy.deepcopy(dict(graph or {}))
    ref_map: dict[str, str] = {}
    for node in list(sanitized_graph.get("nodes") or []):
        if not isinstance(node, dict):
            continue
        node_repr = node.get("repr")
        if not isinstance(node_repr, dict):
            continue
        sanitized_xmls: list[str] = []
        sanitized_refs: list[str] = []
        original_xmls = list(node_repr.get("xmls") or [])
        original_refs = list(node_repr.get("xmlRefs") or [])
        for index, xml_text in enumerate(original_xmls):
            original_xml = str(xml_text or "")
            original_ref = (
                str(original_refs[index] or "").strip()
                if index < len(original_refs)
                else ""
            )
            if not original_ref:
                original_ref = NodeRepr.build_xml_ref(original_xml)
            sanitized_xml = _sanitize_xml_for_upload(original_xml)
            sanitized_ref = NodeRepr.build_xml_ref(sanitized_xml)
            sanitized_xmls.append(sanitized_xml)
            sanitized_refs.append(sanitized_ref)
            if original_ref:
                ref_map[original_ref] = sanitized_ref
        node_repr["xmls"] = sanitized_xmls
        node_repr["xmlRefs"] = sanitized_refs
        node_repr["images"] = []
        node_repr["imageRefs"] = []
        node_metadata = (
            dict(node.get("metadata") or {})
            if isinstance(node.get("metadata"), dict)
            else {}
        )
        node_metadata["upload_privacy_mode"] = "sanitized_xml_bundle"
        node["metadata"] = node_metadata

    def _rewrite_refs(payload: Any) -> Any:
        if isinstance(payload, list):
            return [_rewrite_refs(item) for item in payload]
        if not isinstance(payload, dict):
            return payload
        rewritten: dict[str, Any] = {}
        for key, value in payload.items():
            if key in ("xml_ref", "xmlRef"):
                mapped = ref_map.get(str(value or "").strip())
                rewritten[key] = mapped if mapped else value
                continue
            rewritten[key] = _rewrite_refs(value)
        return rewritten

    sanitized_graph = _rewrite_refs(sanitized_graph)
    for function_payload in list(dict(sanitized_graph.get("functions") or {}).values()):
        if not isinstance(function_payload, dict):
            continue
        metadata = (
            dict(function_payload.get("metadata") or {})
            if isinstance(function_payload.get("metadata"), dict)
            else {}
        )
        metadata["upload_privacy_mode"] = "sanitized_xml_bundle"
        function_payload["metadata"] = metadata
    return sanitized_graph


def _normalize_page_vector(vector: Any) -> np.ndarray | None:
    """Normalize one page vector for cosine search.

    Args:
        vector: Any array-like page vector payload.

    Returns:
        One L2-normalized float32 vector, or `None` when unavailable.
    """

    if vector is None:
        return None
    arr = np.asarray(vector, dtype=np.float32).reshape(-1)
    if arr.size == 0:
        return None
    norm = float(np.linalg.norm(arr))
    if norm <= 1e-6:
        return None
    return (arr / norm).astype(np.float32)


def _ensure_shared_page_vector(page) -> np.ndarray | None:
    """Ensure one `PageVectorSet` carries a page-level vector.

    Args:
        page: One `PageVectorSet` object that may only contain node vectors.

    Returns:
        The normalized page vector used for store search, or `None`.
    """

    current = _normalize_page_vector(getattr(page, "page_vector", None))
    if current is not None:
        page.page_vector = current
        return current
    node_vectors = [
        np.asarray(getattr(node, "vector", None), dtype=np.float32).reshape(-1)
        for node in list(getattr(page, "nodes", []) or [])
        if getattr(node, "vector", None) is not None
    ]
    if not node_vectors:
        return None
    try:
        page_vector = np.mean(np.stack(node_vectors, axis=0), axis=0)
    except Exception:
        return None
    normalized = _normalize_page_vector(page_vector)
    if normalized is not None:
        page.page_vector = normalized
    return normalized


def _page_vector_cosine(left: np.ndarray | None, right: np.ndarray | None) -> float:
    """Return one bounded cosine similarity between two normalized vectors.

    Args:
        left: Normalized left vector.
        right: Normalized right vector.

    Returns:
        Cosine similarity in `[0.0, 1.0]`.
    """

    if left is None or right is None:
        return 0.0
    if left.shape != right.shape:
        return 0.0
    score = float(np.dot(left, right))
    return max(0.0, min(1.0, score))


def _shared_page_summary(page, *, score: float | None = None) -> dict[str, Any]:
    """Build one response summary for a stored shared page.

    Args:
        page: One `PageVectorSet` object already loaded from storage.
        score: Optional search score attached to the current response item.

    Returns:
        One JSON-safe page summary used by list/search routes.
    """

    payload = {
        "page_id": str(getattr(page, "page_id", "") or ""),
        "package_name": str(getattr(page, "package_name", "") or ""),
        "node_count": len(list(getattr(page, "nodes", []) or [])),
        "fingerprint": str(getattr(page, "fingerprint", "") or ""),
        "source_device": str(getattr(page, "source_device", "") or ""),
        "created_at": str(getattr(page, "created_at", "") or ""),
        "has_page_vector": _ensure_shared_page_vector(page) is not None,
        "storage_path": str(_shared_page_file(str(getattr(page, "page_id", "") or ""))),
    }
    if score is not None:
        payload["score"] = float(score)
    return payload


def _derive_shared_page_id(page, explicit_page_id: str = "") -> str:
    """Derive one stable shared page id from payload metadata.

    Args:
        page: One `PageVectorSet` object whose metadata may already include ids.
        explicit_page_id: Optional API-level override from the caller.

    Returns:
        One filesystem-safe shared page id.
    """

    explicit = _normalize_shared_page_id(explicit_page_id)
    if explicit:
        return explicit
    existing = _normalize_shared_page_id(str(getattr(page, "page_id", "") or ""))
    if existing:
        return existing
    package_name = (
        _normalize_shared_page_id(str(getattr(page, "package_name", "") or ""))
        or "shared_page"
    )
    fingerprint = _normalize_shared_page_id(str(getattr(page, "fingerprint", "") or ""))
    if fingerprint:
        return f"{package_name}_{fingerprint}"
    return f"{package_name}_{_utc_now_compact().lower()}"


def _load_shared_page(page_id: str):
    """Load one shared page from provider-side runtime storage.

    Args:
        page_id: Stable shared page identifier.

    Returns:
        One `PageVectorSet` object, or `None` when the page does not exist.
    """

    from src.utg.assets.embedding import PageVectorSet

    file_path = _shared_page_file(page_id)
    if not file_path.exists():
        return None
    try:
        page = PageVectorSet.from_json(file_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    page.page_id = _derive_shared_page_id(page, explicit_page_id=page_id)
    _ensure_shared_page_vector(page)
    return page


def _iter_shared_pages(package_name: str = "") -> list[Any]:
    """Load stored shared pages, optionally filtered by package.

    Args:
        package_name: Optional package name filter.

    Returns:
        Loaded `PageVectorSet` objects sorted by page id.
    """

    normalized_package = str(package_name or "").strip()
    pages = []
    for file_path in sorted(_shared_vector_store_dir().glob("*.json")):
        page = _load_shared_page(file_path.stem)
        if page is None:
            continue
        if (
            normalized_package
            and str(getattr(page, "package_name", "") or "") != normalized_package
        ):
            continue
        pages.append(page)
    return pages


def _resolve_shared_page_input(
    *,
    page_id: str = "",
    vector_set: dict[str, Any] | None = None,
    xml: str = "",
    package_name: str = "",
    source_device: str = "",
    created_at: str = "",
):
    """Resolve one shared page from id, vector payload, or XML.

    Args:
        page_id: Optional stored shared page id.
        vector_set: Optional serialized `PageVectorSet`.
        xml: Optional raw XML input.
        package_name: Optional package name used for XML import.
        source_device: Optional source device tag used for XML import.
        created_at: Optional timestamp override used for XML import.

    Returns:
        One `PageVectorSet` object, or `None` when no valid source was supplied.
    """

    from src.utg.assets.embedding import (
        PageVectorSet,
        encode_xml_page,
        xml_to_vector_set,
    )

    normalized_page_id = str(page_id or "").strip()
    if normalized_page_id:
        return _load_shared_page(normalized_page_id)
    if isinstance(vector_set, dict):
        try:
            page = PageVectorSet.from_dict(vector_set)
        except Exception:
            return None
        page.page_id = _derive_shared_page_id(page)
        _ensure_shared_page_vector(page)
        return page
    normalized_xml = str(xml or "").strip()
    if not normalized_xml:
        return None
    derived_page_id = f"query_{_utc_now_compact().lower()}"
    page = xml_to_vector_set(
        normalized_xml,
        derived_page_id,
        package_name=str(package_name or "").strip(),
        source_device=str(source_device or "").strip(),
        created_at=str(created_at or "").strip(),
    )
    try:
        page.page_vector = _normalize_page_vector(encode_xml_page(normalized_xml))
    except Exception:
        _ensure_shared_page_vector(page)
    return page


def _decode_image_base64_payload(image_base64: str) -> bytes:
    """Decode one screenshot payload returned by `observe(...)`.

    Args:
        image_base64: Raw base64 string or data URL returned by one host bridge.

    Returns:
        Decoded PNG/JPEG bytes. Invalid payloads return empty bytes.
    """

    raw = str(image_base64 or "").strip()
    if not raw:
        return b""
    if raw.startswith("data:image/") and "," in raw:
        raw = raw.split(",", 1)[1]
    try:
        return base64.b64decode(raw, validate=False)
    except Exception:
        return b""


def _write_capture_screenshot(image_base64: str | None, *, capture_id: str) -> str:
    """Persist one observed screenshot under `runtime/captures/`.

    Args:
        image_base64: Optional screenshot payload returned by the live host.
        capture_id: Stable capture identifier used to derive the output filename.

    Returns:
        Absolute screenshot path when bytes were written successfully, else `""`.
    """

    screenshot_bytes = _decode_image_base64_payload(str(image_base64 or ""))
    if not screenshot_bytes:
        return ""
    target = get_runtime_file("captures", f"{str(capture_id or 'capture')}.png")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(screenshot_bytes)
    return str(target.resolve())


class OpenOmniBotBridgeClient:
    """Thin bridge client that lets UTGRuntime drive one OpenOmniBot host.

    Args:
        bridge_base_url: Base URL for the OpenOmniBot bridge endpoints. The
            `/observe`, `/act`, and `/confirm` suffixes are appended internally.
        bridge_token: Bearer token generated by OpenOmniBot's Ktor host.
        timeout_seconds: End-to-end HTTP timeout for one bridge request.

    Returns:
        A host bridge exposing `observe`, `act`, and `require_user_confirmation`
        so UTGRuntime can reuse the shared execute/control chain unchanged.
    """

    def __init__(
        self,
        *,
        bridge_base_url: str,
        bridge_token: str,
        timeout_seconds: float = 120.0,
    ) -> None:
        self.bridge_base_url = str(bridge_base_url or "").rstrip("/")
        self.bridge_token = str(bridge_token or "").strip()
        self.timeout_seconds = max(1.0, float(timeout_seconds))
        self._omniflow_local_stabilize = True

    async def observe(
        self,
        *,
        xml: bool = False,
        screenshot: bool = False,
        app_info: bool = False,
        **kwargs: Any,
    ) -> DeviceObservation:
        """Fetch one live observation snapshot from OpenOmniBot.

        Args:
            xml: Whether current page XML should be captured.
            screenshot: Whether screenshot content should be captured.
            app_info: Whether foreground package/activity info is needed.
            **kwargs: Extra observe fields ignored by the current bridge.

        Returns:
            One normalized `DeviceObservation` payload.
        """

        del kwargs
        payload = await self._post_json(
            "/observe",
            {
                "xml": bool(xml),
                "screenshot": bool(screenshot),
                "app_info": bool(app_info),
            },
        )
        return DeviceObservation(
            xml=payload.get("xml"),
            image_base64=payload.get("image_base64"),
            package_name=payload.get("package_name"),
            activity_name=payload.get("activity_name"),
        )

    async def act(
        self,
        action: Any,
        *,
        observation: DeviceObservation | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute one UTG action on OpenOmniBot after lowering to host tools.

        Args:
            action: Canonical UTG action emitted by the runtime/executor.
            observation: Optional latest observation already available upstream.
            **kwargs: Extra execution kwargs ignored by the bridge.

        Returns:
            One JSON response returned by the OpenOmniBot bridge.
        """

        del kwargs
        lowered = await self._lower_action(action, observation=observation)
        return await self._post_json("/act", {"action": lowered})

    async def require_user_confirmation(self, prompt: str) -> bool:
        """Request a blocking human confirmation from the OpenOmniBot host.

        Args:
            prompt: Human-readable question shown by the host UI.

        Returns:
            Whether the user explicitly confirmed execution should continue.
        """

        payload = await self._post_json("/confirm", {"prompt": str(prompt or "")})
        if bool(payload.get("confirmed")):
            return True
        if bool(payload.get("confirm")):
            return True
        return False

    def click_node(self, node_id: str) -> str:
        """Expose click-node capability to the ActionAdapter feature probe.

        Args:
            node_id: Target XML element id requested by the runtime adapter.

        Returns:
            The input node id unchanged. The bridge lowers `click_node` later
            inside `act(...)`, so this method is only a capability marker.
        """

        return str(node_id or "")

    async def _lower_action(
        self,
        action: Any,
        *,
        observation: DeviceObservation | None = None,
    ) -> dict[str, Any]:
        """Lower one canonical UTG action into the OpenOmniBot bridge protocol.

        Args:
            action: Canonical UTG action emitted by the runtime/executor.
            observation: Optional latest observation whose XML can be reused when
                lowering `click_node`.

        Returns:
            A minimal action envelope accepted by OpenOmniBot `/utg/act`.
        """

        if isinstance(action, dict):
            try:
                action = parse_action_payload(action)
            except Exception:
                pass
        action_type = canonical_action_type(action)
        params = dict(action_params_of(action) or {})
        if action_type == "click":
            return {
                "type": "click",
                "params": {
                    "x": params.get("x"),
                    "y": params.get("y"),
                },
            }
        if action_type == "click_node":
            node_id = str(params.get("node_id") or "").strip()
            xml_text = str(getattr(observation, "xml", "") or "").strip()
            if not xml_text:
                observed = await self.observe(
                    xml=True,
                    screenshot=False,
                    app_info=False,
                )
                xml_text = str(observed.xml or "").strip()
            center = find_node_center_by_id(xml_text, node_id)
            if center is None:
                return {
                    "type": "click",
                    "params": {"x": None, "y": None, "node_id": node_id},
                }
            return {
                "type": "click",
                "params": {"x": center[0], "y": center[1], "node_id": node_id},
            }
        if action_type == "long_press":
            return {
                "type": "long_press",
                "params": {
                    "x": params.get("x"),
                    "y": params.get("y"),
                    "duration_ms": params.get("duration_ms"),
                },
            }
        if action_type == "input_text":
            return {
                "type": "input_text",
                "params": {"text": params.get("text")},
            }
        if action_type == "swipe":
            return {
                "type": "swipe",
                "params": {
                    "x": params.get("x"),
                    "y": params.get("y"),
                    "direction": params.get("direction"),
                    "distance": params.get("distance"),
                },
            }
        if action_type == "open_app":
            return {
                "type": "open_app",
                "params": {"package_name": params.get("package_name")},
            }
        if action_type == "press_key":
            return {
                "type": "press_key",
                "params": {"key": action_key_value(action)},
            }
        if action_type == "wait":
            return {
                "type": "wait",
                "params": {"time_s": params.get("time_s")},
            }
        if action_type == "finished":
            return {"type": "finished", "params": {}}
        return {
            "type": str(getattr(action, "type", "") or action_type or "unknown"),
            "params": to_serializable(params),
        }

    async def _post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Post one JSON request to OpenOmniBot and decode the JSON response.

        Args:
            path: Endpoint suffix such as `/observe`.
            payload: JSON-serializable request body.

        Returns:
            Decoded JSON dictionary. Non-dict responses are wrapped under `data`.
        """

        url = f"{self.bridge_base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.bridge_token}",
            "Content-Type": "application/json",
        }
        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, json=payload, headers=headers) as response:
                response.raise_for_status()
                data = await response.json()
        if isinstance(data, dict):
            return dict(data)
        return {"data": data}


def health(runtime: UTGRuntime | None = None) -> dict[str, Any]:
    """Return the provider health payload via the ops module implementation."""

    payload = _health_impl(
        runtime,
        provider_id=PROVIDER_ID,
        provider_api_methods=PROVIDER_API_METHODS,
        host_callbacks=HOST_CALLBACKS,
        supported_bridge_actions=SUPPORTED_BRIDGE_ACTIONS,
        canonical_run_log_path=_canonical_run_log_path(),
    )
    payload["shared_vector_store_path"] = str(_shared_vector_store_dir())
    payload["multi_user_registry_path"] = _multi_user_registry_path()
    payload["multi_user_privacy_mode"] = "hashed_client_tags"
    return payload


def list_shared_pages(runtime: UTGRuntime, *, package_name: str = "") -> dict[str, Any]:
    """List shared privacy-safe pages persisted by the provider.

    Args:
        runtime: Runtime instance. It is unused here but kept for provider
            callback signature consistency.
        package_name: Optional package name filter for stored pages.

    Returns:
        One response payload containing stored shared-page summaries.
    """

    del runtime
    pages = _iter_shared_pages(package_name=package_name)
    return {
        "success": True,
        "count": len(pages),
        "pages": [_shared_page_summary(page) for page in pages],
        "provider": PROVIDER_ID,
        "shared_vector_store_path": str(_shared_vector_store_dir()),
    }


def get_shared_page(runtime: UTGRuntime, *, page_id: str) -> dict[str, Any]:
    """Return one persisted shared page payload and summary.

    Args:
        runtime: Runtime instance. It is unused here but kept for signature parity.
        page_id: Stable shared page identifier.

    Returns:
        One response payload with the full serialized `PageVectorSet`.
    """

    del runtime
    normalized_page_id = _normalize_shared_page_id(page_id)
    if not normalized_page_id:
        return {
            "success": False,
            "error_code": "INVALID_SHARED_PAGE_ID",
            "error_message": "page_id is required.",
            "page_id": str(page_id or "").strip(),
            "provider": PROVIDER_ID,
        }
    page = _load_shared_page(normalized_page_id)
    if page is None:
        return {
            "success": False,
            "error_code": "SHARED_PAGE_NOT_FOUND",
            "error_message": f"Shared page not found: {normalized_page_id}",
            "page_id": normalized_page_id,
            "provider": PROVIDER_ID,
        }
    return {
        "success": True,
        "page_id": normalized_page_id,
        "page": to_serializable(page.to_dict()),
        "summary": _shared_page_summary(page),
        "provider": PROVIDER_ID,
    }


def import_shared_page(
    runtime: UTGRuntime,
    *,
    page_id: str | None = None,
    vector_set: dict[str, Any] | None = None,
    xml: str = "",
    package_name: str = "",
    source_device: str = "",
    created_at: str = "",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Persist one shared page in vector-only form.

    Args:
        runtime: Runtime instance. It is unused here but kept for provider
            callback signature consistency.
        page_id: Optional page id override.
        vector_set: Optional serialized `PageVectorSet` payload.
        xml: Optional raw XML that will be converted before persistence.
        package_name: Optional package override used for XML imports.
        source_device: Optional source-device tag used for XML imports.
        created_at: Optional timestamp override used for XML imports.
        overwrite: Whether an existing page may be replaced.

    Returns:
        One response payload describing the persisted shared page.
    """

    del runtime
    page = _resolve_shared_page_input(
        page_id="",
        vector_set=vector_set,
        xml=xml,
        package_name=package_name,
        source_device=source_device,
        created_at=created_at,
    )
    if page is None:
        return {
            "success": False,
            "error_code": "INVALID_SHARED_PAGE_PAYLOAD",
            "error_message": "Provide either vector_set or xml when importing a shared page.",
            "provider": PROVIDER_ID,
        }
    normalized_page_id = _derive_shared_page_id(
        page, explicit_page_id=str(page_id or "")
    )
    if not normalized_page_id:
        return {
            "success": False,
            "error_code": "INVALID_SHARED_PAGE_ID",
            "error_message": "Unable to derive a valid shared page id.",
            "provider": PROVIDER_ID,
        }
    file_path = _shared_page_file(normalized_page_id)
    if file_path.exists() and not bool(overwrite):
        return {
            "success": False,
            "error_code": "SHARED_PAGE_ALREADY_EXISTS",
            "error_message": f"Shared page already exists: {normalized_page_id}",
            "page_id": normalized_page_id,
            "provider": PROVIDER_ID,
        }
    page.page_id = normalized_page_id
    if not str(getattr(page, "created_at", "") or "").strip():
        page.created_at = str(created_at or _utc_now_compact())
    if package_name and not str(getattr(page, "package_name", "") or "").strip():
        page.package_name = str(package_name or "").strip()
    if source_device and not str(getattr(page, "source_device", "") or "").strip():
        page.source_device = str(source_device or "").strip()
    _ensure_shared_page_vector(page)
    file_path.write_text(
        json.dumps(to_serializable(page.to_dict()), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return {
        "success": True,
        "page_id": normalized_page_id,
        "summary": _shared_page_summary(page),
        "provider": PROVIDER_ID,
        "stored": True,
        "overwrite": bool(overwrite),
    }


def search_shared_pages(
    runtime: UTGRuntime,
    *,
    page_id: str = "",
    vector_set: dict[str, Any] | None = None,
    xml: str = "",
    package_name: str = "",
    top_k: int = 5,
    threshold: float | None = None,
) -> dict[str, Any]:
    """Search stored shared pages using one vectorized query page.

    Args:
        runtime: Runtime instance. It is unused here but kept for signature parity.
        page_id: Optional stored page id used as query.
        vector_set: Optional ad-hoc query `PageVectorSet`.
        xml: Optional ad-hoc query XML.
        package_name: Optional package filter for stored candidates.
        top_k: Maximum number of results to return.
        threshold: Optional minimum cosine similarity threshold.

    Returns:
        Ranked shared-page summaries with cosine scores.
    """

    del runtime
    query_page = _resolve_shared_page_input(
        page_id=page_id,
        vector_set=vector_set,
        xml=xml,
        package_name=package_name,
    )
    if query_page is None:
        return {
            "success": False,
            "error_code": "INVALID_SHARED_PAGE_QUERY",
            "error_message": "Provide one of page_id, vector_set, or xml for search.",
            "provider": PROVIDER_ID,
        }
    query_vector = _ensure_shared_page_vector(query_page)
    if query_vector is None:
        return {
            "success": False,
            "error_code": "MISSING_QUERY_VECTOR",
            "error_message": "Query page does not contain a usable page vector.",
            "provider": PROVIDER_ID,
        }
    normalized_threshold = (
        None if threshold is None else max(0.0, min(1.0, float(threshold)))
    )
    ranked_results: list[dict[str, Any]] = []
    query_page_id = str(getattr(query_page, "page_id", "") or "").strip()
    for candidate in _iter_shared_pages(package_name=package_name):
        candidate_vector = _ensure_shared_page_vector(candidate)
        score = _page_vector_cosine(query_vector, candidate_vector)
        if normalized_threshold is not None and score < normalized_threshold:
            continue
        ranked_results.append(_shared_page_summary(candidate, score=score))
    ranked_results.sort(key=lambda item: float(item.get("score", 0.0)), reverse=True)
    limited_results = ranked_results[: max(1, int(top_k or 1))]
    return {
        "success": True,
        "query_page_id": query_page_id,
        "count": len(limited_results),
        "results": limited_results,
        "provider": PROVIDER_ID,
    }


def map_shared_coordinates(
    runtime: UTGRuntime,
    *,
    source_page_id: str = "",
    source_vector_set: dict[str, Any] | None = None,
    source_xml: str = "",
    target_page_id: str = "",
    target_vector_set: dict[str, Any] | None = None,
    target_xml: str = "",
    x: float,
    y: float,
) -> dict[str, Any]:
    """Project one source coordinate into a target shared page.

    Args:
        runtime: Runtime instance. It is unused here but kept for signature parity.
        source_page_id: Optional stored shared source page id.
        source_vector_set: Optional ad-hoc source `PageVectorSet`.
        source_xml: Optional source XML.
        target_page_id: Optional stored shared target page id.
        target_vector_set: Optional ad-hoc target `PageVectorSet`.
        target_xml: Optional target XML.
        x: Source x coordinate in pixels.
        y: Source y coordinate in pixels.

    Returns:
        One mapping payload built from `match_coordinates(...)`.
    """

    del runtime
    from src.utg.assets.embedding import match_coordinates

    source_page = _resolve_shared_page_input(
        page_id=source_page_id,
        vector_set=source_vector_set,
        xml=source_xml,
    )
    target_page = _resolve_shared_page_input(
        page_id=target_page_id,
        vector_set=target_vector_set,
        xml=target_xml,
    )
    if source_page is None or target_page is None:
        return {
            "success": False,
            "error_code": "INVALID_SHARED_PAGE_MAPPING_INPUT",
            "error_message": (
                "Both source and target must be provided via page_id, vector_set, or xml."
            ),
            "provider": PROVIDER_ID,
        }
    result = match_coordinates(
        source_page,
        target_page,
        x=float(x),
        y=float(y),
    )
    return {
        "success": True,
        "source_page_id": str(getattr(source_page, "page_id", "") or ""),
        "target_page_id": str(getattr(target_page, "page_id", "") or ""),
        "mapping": to_serializable(result),
        "provider": PROVIDER_ID,
    }


def list_graph_apps(runtime: UTGRuntime) -> dict[str, Any]:
    """Return app-level graph groups derived from the current UTG graph.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.

    Returns:
        Compact app summaries used by the desktop graph selector.
    """

    apps: dict[str, dict[str, Any]] = {}
    composite_functions = list(
        getattr(getattr(runtime, "_utg", None), "functions", {}).values() or []
    )
    for node in list(getattr(getattr(runtime, "_utg", None), "nodes", []) or []):
        package_name = str(
            getattr(getattr(node, "repr", None), "packageName", "") or ""
        ).strip()
        node_id = str(getattr(node, "id", "") or "").strip()
        if not package_name or not node_id:
            continue
        app_entry = apps.setdefault(
            package_name,
            {
                "package_name": package_name,
                "app_name": "",
                "node_ids": set(),
                "function_ids": set(),
            },
        )
        app_entry["node_ids"].add(node_id)
        app_info = getattr(
            getattr(runtime, "_utg", None),
            "find_app_info_by_package_name",
            lambda _pkg: None,
        )(package_name)
        if not app_entry["app_name"] and app_info is not None:
            app_entry["app_name"] = str(getattr(app_info, "appName", "") or "").strip()
    for function in composite_functions:
        function_id = str(getattr(function, "id", "") or "").strip()
        if not function_id:
            continue
        package_names: set[str] = set()
        for node_id in list(dict(getattr(function, "steps", {}) or {}).keys()):
            node = runtime.get_node_by_id(str(node_id or "").strip())
            package_name = str(
                getattr(getattr(node, "repr", None), "packageName", "") or ""
            ).strip()
            if package_name:
                package_names.add(package_name)
        for package_name in package_names:
            app_entry = apps.setdefault(
                package_name,
                {
                    "package_name": package_name,
                    "app_name": "",
                    "node_ids": set(),
                    "function_ids": set(),
                },
            )
            app_entry["function_ids"].add(function_id)
    items = []
    for app in apps.values():
        items.append(
            {
                "package_name": app["package_name"],
                "app_name": app["app_name"] or app["package_name"],
                "node_count": len(app["node_ids"]),
                "function_count": len(app["function_ids"]),
            }
        )
    items.sort(
        key=lambda item: (
            str(item.get("app_name") or ""),
            str(item.get("package_name") or ""),
        )
    )
    return {
        "success": True,
        "count": len(items),
        "apps": items,
        "provider": PROVIDER_ID,
    }


def get_app_graph(runtime: UTGRuntime, *, package_name: str) -> dict[str, Any]:
    """Project one app-scoped node/edge graph out of the current UTG graph.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.
        package_name: App package used to filter nodes and projected edges.

    Returns:
        JSON-safe app graph payload for the desktop editor.
    """

    normalized_package_name = str(package_name or "").strip()
    if not normalized_package_name:
        return {
            "success": False,
            "error_code": "INVALID_PACKAGE_NAME",
            "error_message": "package_name is required.",
        }
    utg = getattr(runtime, "_utg", None)
    nodes = list(getattr(utg, "nodes", []) or [])
    composite_functions = list(getattr(utg, "functions", {}).values() or [])
    app_info = getattr(utg, "find_app_info_by_package_name", lambda _pkg: None)(
        normalized_package_name
    )
    graph_nodes: list[dict[str, Any]] = []
    node_ids_in_app: set[str] = set()
    function_ids_by_node: dict[str, set[str]] = {}
    for function in composite_functions:
        function_id = str(getattr(function, "id", "") or "").strip()
        if not function_id:
            continue
        for node_id in list(dict(getattr(function, "steps", {}) or {}).keys()):
            normalized_node_id = str(node_id or "").strip()
            if not normalized_node_id:
                continue
            source_node = runtime.get_node_by_id(normalized_node_id)
            source_package = str(
                getattr(getattr(source_node, "repr", None), "packageName", "") or ""
            ).strip()
            if source_package == normalized_package_name:
                function_ids_by_node.setdefault(normalized_node_id, set()).add(
                    function_id
                )
    for node in nodes:
        node_id = str(getattr(node, "id", "") or "").strip()
        node_package_name = str(
            getattr(getattr(node, "repr", None), "packageName", "") or ""
        ).strip()
        if not node_id or node_package_name != normalized_package_name:
            continue
        node_ids_in_app.add(node_id)
        node_metadata = dict(getattr(node, "metadata", {}) or {})
        functions = dict(getattr(node, "functions", {}) or {})
        capabilities = []
        for function_name, function_obj in functions.items():
            normalized_function_name = str(function_name or "").strip()
            if not normalized_function_name:
                continue
            capabilities.append(
                {
                    "function_name": normalized_function_name,
                    "title": normalized_function_name,
                    "description": str(
                        getattr(function_obj, "description", "") or ""
                    ).strip()
                    or None,
                    "parameter_names": list(
                        getattr(function_obj, "get_parameter_names", lambda: [])() or []
                    ),
                    "function_schema": (
                        function_obj.to_function_schema()
                        if hasattr(function_obj, "to_function_schema")
                        else None
                    ),
                }
            )
        capabilities.sort(key=lambda item: str(item.get("function_name") or ""))
        graph_nodes.append(
            {
                "id": node_id,
                "label": str(
                    getattr(getattr(node, "repr", None), "description", "") or ""
                ).strip()
                or node_id,
                "description": str(
                    getattr(getattr(node, "repr", None), "description", "") or ""
                ).strip()
                or None,
                "package_name": node_package_name,
                "xml_ref": str(
                    getattr(
                        getattr(node, "repr", None), "primary_xml_ref", lambda: ""
                    )()
                    or ""
                ).strip()
                or None,
                "screenshot_path": str(
                    node_metadata.get("screenshot_path") or ""
                ).strip()
                or None,
                "function_count": len(capabilities),
                "function_ids": sorted(function_ids_by_node.get(node_id, set())),
                "page_capabilities": capabilities,
            }
        )
    edge_buckets: dict[tuple[str, str], dict[str, Any]] = {}
    for function in composite_functions:
        function_id = str(getattr(function, "id", "") or "").strip()
        if not function_id:
            continue
        function_metadata = dict(getattr(function, "metadata", {}) or {})
        ordered_steps = sorted(
            list(dict(getattr(function, "steps", {}) or {}).items()),
            key=lambda item: int(getattr(item[1], "index", 0) or 0),
        )
        for index in range(len(ordered_steps) - 1):
            from_node_id, from_step = ordered_steps[index]
            to_node_id, _ = ordered_steps[index + 1]
            from_id = str(from_node_id or "").strip()
            to_id = str(to_node_id or "").strip()
            if from_id not in node_ids_in_app:
                continue
            to_node = runtime.get_node_by_id(to_id)
            to_package_name = str(
                getattr(getattr(to_node, "repr", None), "packageName", "") or ""
            ).strip()
            if to_package_name != normalized_package_name:
                continue
            source_node = runtime.get_node_by_id(from_id)
            source_functions = (
                dict(getattr(source_node, "functions", {}) or {})
                if source_node is not None
                else {}
            )
            function_names = [
                str(name or "").strip()
                for name in list(getattr(from_step, "functions", []) or [])
                if str(name or "").strip()
            ]
            bucket = edge_buckets.setdefault(
                (from_id, to_id),
                {
                    "id": f"{from_id}->{to_id}",
                    "source": from_id,
                    "target": to_id,
                    "function_ids": [],
                    "functions": [],
                    "function_names": [],
                    "function_descriptions": [],
                    "composite_functions": [],
                },
            )
            if function_id not in bucket["function_ids"]:
                bucket["function_ids"].append(function_id)
            for function_name in function_names:
                function_obj = source_functions.get(function_name)
                normalized_function_name = str(function_name or "").strip()
                if not normalized_function_name:
                    continue
                if normalized_function_name not in bucket["function_names"]:
                    bucket["function_names"].append(normalized_function_name)
                normalized_description = (
                    str(getattr(function_obj, "description", "") or "").strip() or None
                )
                if (
                    normalized_description
                    and normalized_description not in bucket["function_descriptions"]
                ):
                    bucket["function_descriptions"].append(normalized_description)
                if not any(
                    str(item.get("function_name") or "").strip()
                    == normalized_function_name
                    for item in bucket["functions"]
                ):
                    bucket["functions"].append(
                        {
                            "function_name": normalized_function_name,
                            "description": normalized_description,
                            "parameter_names": list(
                                getattr(
                                    function_obj, "get_parameter_names", lambda: []
                                )()
                                or []
                            ),
                            "function_schema": (
                                function_obj.to_function_schema()
                                if hasattr(function_obj, "to_function_schema")
                                else None
                            ),
                        }
                    )
            bucket["composite_functions"].append(
                {
                    "function_id": function_id,
                    "description": str(
                        getattr(function, "description", "") or ""
                    ).strip()
                    or None,
                    "function_kind": _function_kind_from_metadata(function_metadata),
                    "asset_state": _asset_state_from_metadata(function_metadata),
                    "shared_function_ids": list(
                        function_metadata.get("shared_function_ids") or []
                    ),
                    "parameter_names": list(
                        getattr(function, "get_parameter_names", lambda: [])() or []
                    ),
                    "step_index": int(getattr(from_step, "index", 0) or 0),
                    "functions": function_names,
                }
            )
    graph_edges = []
    for edge in edge_buckets.values():
        label = " / ".join(list(edge["function_names"])[:2]) or "transition"
        graph_edges.append(
            {
                **edge,
                "label": label,
                "function_asset_count": len(edge["function_ids"]),
            }
        )
    graph_nodes.sort(key=lambda item: str(item.get("label") or item.get("id") or ""))
    graph_edges.sort(
        key=lambda item: (
            str(item.get("source") or ""),
            str(item.get("target") or ""),
            str(item.get("label") or ""),
        )
    )
    return {
        "success": True,
        "package_name": normalized_package_name,
        "app_name": str(getattr(app_info, "appName", "") or "").strip()
        or normalized_package_name,
        "node_count": len(graph_nodes),
        "edge_count": len(graph_edges),
        "nodes": graph_nodes,
        "edges": graph_edges,
        "provider": PROVIDER_ID,
    }


def _collect_function_run_usage() -> dict[str, dict[str, Any]]:
    """Scan canonical agent run logs and derive per-function recent execution stats.

    Refactored to use Pydantic RunLogModel for cleaner validation.
    Now also tracks duration_ms and token usage for averages.
    """
    run_log_path = Path(_canonical_run_log_path())
    if not run_log_path.exists():
        return {}

    logger = UTGRunLogger(enabled=True, path=str(run_log_path))
    usage_by_function: dict[str, dict[str, Any]] = {}

    for raw in logger.load_materialized_runs():
        log = parse_run_log(raw)
        if not log.steps:
            continue

        # Extract run-level stats
        raw_dict = dict(raw) if isinstance(raw, dict) else {}
        run_duration_ms = float(raw_dict.get("duration_ms") or 0.0)
        run_llm_usage = dict(raw_dict.get("llm_usage") or {})
        run_input_tokens = int(run_llm_usage.get("input_tokens") or 0)
        run_output_tokens = int(run_llm_usage.get("output_tokens") or 0)

        for step in log.steps:
            function_id = step.effective_function_id
            if not function_id:
                continue

            usage = usage_by_function.setdefault(
                function_id,
                {
                    "run_count": 0,
                    "success_count": 0,
                    "fail_count": 0,
                    "last_run": None,
                    "total_duration_ms": 0.0,
                    "total_input_tokens": 0,
                    "total_output_tokens": 0,
                },
            )
            usage["run_count"] += 1

            # Accumulate duration and tokens
            # Note: If multiple functions in same run, each gets the full run's stats
            # This is a simplification; ideally we'd attribute proportionally
            usage["total_duration_ms"] += run_duration_ms
            usage["total_input_tokens"] += run_input_tokens
            usage["total_output_tokens"] += run_output_tokens

            # Determine step success
            step_success = log.success
            if step.act_result.success is False:
                step_success = False

            if step_success:
                usage["success_count"] += 1
            else:
                usage["fail_count"] += 1

            # Update last_run if this is more recent
            last_key = log.finished_at or log.started_at
            prev_key = ""
            last_run = usage.get("last_run")
            if isinstance(last_run, dict):
                prev_key = (
                    last_run.get("finished_at") or last_run.get("started_at") or ""
                )

            if not isinstance(last_run, dict) or last_key >= prev_key:
                usage["last_run"] = {
                    "run_id": log.run_id or None,
                    "goal": log.goal or None,
                    "success": step_success,
                    "started_at": log.started_at or None,
                    "finished_at": log.finished_at or None,
                    "done_reason": log.done_reason or None,
                    "error_code": step.act_result.error_code or None,
                    "error_message": step.act_result.error_message or None,
                    "source": step.act_result.source or log.source or None,
                    "duration_ms": run_duration_ms,
                    "input_tokens": run_input_tokens,
                    "output_tokens": run_output_tokens,
                }

    return usage_by_function


def _merge_run_stats(
    func_stats: dict[str, Any],
    usage: dict[str, Any] | None,
) -> dict[str, Any]:
    """Merge run_stats from function object and usage data.

    Now includes average duration and token usage.
    """
    # Prefer function object stats (realtime) over usage stats (historical)
    call_count = int(func_stats.get("call_count") or 0)
    success_count = int(func_stats.get("success_count") or 0)

    # Duration and token stats from usage
    total_duration_ms = 0.0
    total_input_tokens = 0
    total_output_tokens = 0

    # Fallback to usage if function stats are empty
    if call_count == 0 and usage:
        call_count = int(usage.get("run_count") or 0)
        success_count = int(usage.get("success_count") or 0)

    if usage:
        total_duration_ms = float(usage.get("total_duration_ms") or 0.0)
        total_input_tokens = int(usage.get("total_input_tokens") or 0)
        total_output_tokens = int(usage.get("total_output_tokens") or 0)

    # Calculate averages
    avg_duration_ms = total_duration_ms / call_count if call_count > 0 else 0.0
    avg_input_tokens = total_input_tokens / call_count if call_count > 0 else 0.0
    avg_output_tokens = total_output_tokens / call_count if call_count > 0 else 0.0

    return {
        "call_count": call_count,
        "run_count": call_count,
        "success_count": success_count,
        "fail_count": call_count - success_count if call_count > success_count else 0,
        "last_run_id": str(func_stats.get("last_run_id") or "").strip() or None,
        "last_run_at": str(func_stats.get("last_run_at") or "").strip() or None,
        "last_success": func_stats.get("last_success"),
        # Average execution stats
        "avg_duration_ms": round(avg_duration_ms, 2),
        "avg_input_tokens": round(avg_input_tokens, 1),
        "avg_output_tokens": round(avg_output_tokens, 1),
        "avg_total_tokens": round(avg_input_tokens + avg_output_tokens, 1),
        # Totals (for reference)
        "total_duration_ms": round(total_duration_ms, 2),
        "total_input_tokens": total_input_tokens,
        "total_output_tokens": total_output_tokens,
    }


def _extract_last_run(
    func_stats: dict[str, Any],
    usage: dict[str, Any] | None,
) -> dict[str, Any]:
    """Extract last run info from function stats or usage."""
    # Prefer function object stats
    if func_stats.get("last_run_id"):
        return {
            "run_id": str(func_stats.get("last_run_id") or "").strip() or None,
            "run_at": str(func_stats.get("last_run_at") or "").strip() or None,
            "success": func_stats.get("last_success"),
        }
    # Fallback to usage
    return dict((usage or {}).get("last_run") or {})


def _extract_asset_refs(
    func: Any,
    func_id: str,
    runtime: UTGRuntime,
) -> dict[str, Any]:
    """Extract asset references (xml_refs, screenshot_refs) from function."""
    # Check function object's asset_refs field
    func_asset_refs = dict(getattr(func, "asset_refs", {}) or {})
    if func_asset_refs:
        return func_asset_refs

    # Check metadata
    metadata = dict(getattr(func, "metadata", {}) or {})
    if metadata.get("asset_refs"):
        return dict(metadata.get("asset_refs") or {})

    # Try to find stored function directory
    xml_refs: list[str] = []
    screenshot_refs: list[str] = []
    function_dir: str | None = None

    # Check FunctionStore
    store_path = (
        Path(runtime._filepath).parent / "functions"
        if runtime._filepath
        else Path("runtime/functions")
    )
    func_dir = store_path / func_id
    if func_dir.exists() and func_dir.is_dir():
        function_dir = str(func_dir)
        # Scan for XML files
        for xml_file in sorted(func_dir.glob("step_*_xml.xml")):
            xml_refs.append(xml_file.name)
        # Scan for screenshot files
        for img_file in sorted(func_dir.glob("step_*_screenshot.png")):
            screenshot_refs.append(img_file.name)

    return {
        "xml_refs": xml_refs,
        "screenshot_refs": screenshot_refs,
        "function_dir": function_dir,
    }


def _count_actions_recursive(
    runtime: UTGRuntime,
    func: Any,
    visited: set[str] | None = None,
) -> int:
    """Recursively count all actions including expanding call_function.

    Args:
        runtime: Runtime instance for function lookup
        func: Function object to count actions for
        visited: Set of visited function IDs to prevent infinite recursion

    Returns:
        Total action count (atomic actions + expanded call_function actions)
    """
    if visited is None:
        visited = set()

    func_id = str(getattr(func, "name", "") or "").strip()
    if func_id in visited:
        return 0  # Prevent infinite recursion
    visited.add(func_id)

    actions = list(getattr(func, "actions", []) or [])
    total_count = 0

    for action in actions:
        action_type = None
        action_params = {}

        # Handle different action formats
        if hasattr(action, "type"):
            action_type = getattr(action, "type", None)
            action_params = dict(getattr(action, "params", {}) or {})
        elif isinstance(action, dict):
            action_type = action.get("type")
            action_params = dict(action.get("params") or {})

        if action_type == "call_function":
            # Expand call_function by looking up the referenced function
            ref_func_id = str(
                action_params.get("function_id")
                or action_params.get("function_name")
                or ""
            ).strip()
            if ref_func_id:
                ref_func = runtime.get_function_by_id(ref_func_id)
                if ref_func is not None:
                    # Recursively count actions in referenced function
                    total_count += _count_actions_recursive(runtime, ref_func, visited)
                else:
                    # Referenced function not found, count as 1
                    total_count += 1
            else:
                total_count += 1
        else:
            # Atomic action
            total_count += 1

    return total_count


def _summarize_function(
    runtime: UTGRuntime,
    func: Any,
    *,
    usage: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build one dashboard-grade summary for one function object."""

    func_id = str(getattr(func, "name", "") or "").strip()
    start_node_id = str(getattr(func, "start_node_id", "") or "").strip() or None
    end_node_id = str(getattr(func, "end_node_id", "") or "").strip() or None
    start_node = runtime.get_node_by_id(start_node_id) if start_node_id else None
    end_node = runtime.get_node_by_id(end_node_id) if end_node_id else None
    actions = list(getattr(func, "actions", []) or [])
    metadata = dict(getattr(func, "metadata", {}) or {})
    # Fallback: if actions is empty but metadata has step_count, use it
    step_count_from_metadata = metadata.get("step_count")
    effective_step_count = (
        len(actions)
        if actions
        else (
            int(step_count_from_metadata) if step_count_from_metadata is not None else 0
        )
    )
    package_name = (
        str(getattr(getattr(start_node, "repr", None), "packageName", "") or "").strip()
        or str(
            getattr(getattr(end_node, "repr", None), "packageName", "") or ""
        ).strip()
    )
    app_name = ""
    if package_name:
        app_info = runtime._utg.find_app_info_by_package_name(package_name)
        app_name = str(getattr(app_info, "appName", "") or "").strip()
    parameter_examples = metadata.get("parameter_examples")
    if not isinstance(parameter_examples, dict):
        parameter_examples = {}
    sync_status = str(metadata.get("sync_status") or "").strip() or "local_only"
    function_kind = _function_kind_from_metadata(metadata)
    asset_state = _asset_state_from_metadata(metadata)

    # Extract action summaries from call_function actions
    action_summaries: list[dict[str, Any]] = []
    for idx, action in enumerate(actions):
        action_type = getattr(action, "type", None)
        if action_type == "call_function":
            params = getattr(action, "params", None)
            if params:
                node_id = str(getattr(params, "node_id", "") or "").strip()
                function_name = str(getattr(params, "function_name", "") or "").strip()
                source_node = runtime.get_node_by_id(node_id) if node_id else None
                node_functions = (
                    dict(getattr(source_node, "functions", {}) or {})
                    if source_node is not None
                    else {}
                )
                function_obj = node_functions.get(function_name)
                if function_obj is None:
                    global_func = runtime.get_function_by_id(function_name)
                    global_start = (
                        str(getattr(global_func, "start_node_id", "") or "").strip()
                        if global_func is not None
                        else ""
                    )
                    if global_func is not None and (
                        not global_start or not node_id or global_start == node_id
                    ):
                        function_obj = global_func
                action_summaries.append(
                    {
                        "node_id": node_id or None,
                        "step_index": idx,
                        "function_name": function_name or None,
                        "description": str(
                            getattr(function_obj, "description", "") or ""
                        ).strip()
                        or None,
                        "parameter_names": list(
                            getattr(function_obj, "get_parameter_names", lambda: [])()
                            or []
                        ),
                        "function_schema": (
                            function_obj.to_function_schema()
                            if hasattr(function_obj, "to_function_schema")
                            else None
                        ),
                    }
                )

    # Calculate recursive action count (expanding call_function)
    action_count = _count_actions_recursive(runtime, func)

    return {
        "function_id": func_id,
        "description": str(getattr(func, "description", "") or "").strip() or None,
        "action_count": action_count,  # Recursive total
        "step_count": effective_step_count,  # Direct steps only
        "parameter_names": list(
            getattr(func, "get_parameter_names", lambda: [])() or []
        ),
        "parameter_examples": {
            str(key): str(value)
            for key, value in dict(parameter_examples).items()
            if str(key).strip() and str(value).strip()
        },
        "start_node_id": start_node_id,
        "end_node_id": end_node_id,
        "start_node_description": str(
            getattr(getattr(start_node, "repr", None), "description", "") or ""
        ).strip()
        or None,
        "end_node_description": str(
            getattr(getattr(end_node, "repr", None), "description", "") or ""
        ).strip()
        or None,
        "package_name": package_name or None,
        "app_name": app_name or None,
        "group_name": app_name or package_name or "unknown_app",
        "source": str(metadata.get("source") or "").strip() or None,
        "created_at": str(metadata.get("created_at") or "").strip() or None,
        "updated_at": str(metadata.get("updated_at") or "").strip() or None,
        "sync_status": sync_status,
        "sync_origin": str(metadata.get("sync_origin") or "").strip() or None,
        "cloud_base_url": str(metadata.get("cloud_base_url") or "").strip() or None,
        "last_synced_at": str(metadata.get("last_synced_at") or "").strip() or None,
        "function_kind": function_kind,
        "asset_state": asset_state,
        "functions": action_summaries,
        "derived_from_raw_function_id": str(
            metadata.get("derived_from_raw_function_id") or ""
        ).strip()
        or None,
        "run_stats": _merge_run_stats(
            dict(getattr(func, "run_stats", {}) or {}),
            usage,
        ),
        "last_run": _extract_last_run(
            dict(getattr(func, "run_stats", {}) or {}),
            usage,
        ),
        # 语义去重相关字段
        "source_run_ids": list(metadata.get("source_run_ids") or []),
        "source_run_count": len(list(metadata.get("source_run_ids") or [])),
        "enriched_goal": str(metadata.get("enriched_goal") or "").strip() or None,
        "original_goal": str(metadata.get("original_goal") or "").strip() or None,
        "is_from_import": metadata.get("source") == "run_log_import",
        # 资产引用
        "asset_refs": _extract_asset_refs(func, func_id, runtime),
    }


# Legacy alias
def list_functions(runtime: UTGRuntime) -> dict[str, Any]:
    """Return a compact dashboard-friendly summary of all known UTG functions.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.

    Returns:
        A JSON-safe payload containing all known functions sorted by id. Each item
        keeps only display-grade metadata so mobile dashboards can render the
        current asset set without pulling the whole UTG store.
    """

    items: list[dict[str, Any]] = []
    usage_by_func = _collect_function_run_usage()
    functions = dict(getattr(getattr(runtime, "_utg", None), "functions", {}) or {})
    for func_id, func in functions.items():
        func_id = str(func_id or "").strip()
        if not func_id:
            continue
        items.append(
            _summarize_function(runtime, func, usage=usage_by_func.get(func_id))
        )
    items.sort(key=lambda item: str(item.get("function_id") or ""))
    return {
        "success": True,
        "count": len(items),
        "functions": items,
        "provider": PROVIDER_ID,
    }


def list_nodes(runtime: UTGRuntime) -> dict[str, Any]:
    """Return a compact dashboard-friendly summary of all UTG nodes.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.

    Returns:
        A JSON-safe payload containing all nodes sorted by id. Each item
        contains node metadata suitable for browser display.
    """
    utg = getattr(runtime, "_utg", None)
    nodes_list = list(getattr(utg, "nodes", []) or [])
    items: list[dict[str, Any]] = []

    for node in nodes_list:
        node_id = str(getattr(node, "id", "") or "").strip()
        if not node_id:
            continue

        repr_obj = getattr(node, "repr", None)
        package_name = str(getattr(repr_obj, "packageName", "") or "").strip()
        activity_name = str(getattr(repr_obj, "activityName", "") or "").strip()
        description = str(getattr(repr_obj, "description", "") or "").strip()
        signatures = list(getattr(repr_obj, "signatures", []) or [])
        xml_refs = list(getattr(repr_obj, "xmlRefs", []) or [])

        # Get available functions for this node
        available_functions: list[str] = []
        utg_functions = dict(getattr(utg, "functions", {}) or {})
        for func_id, func in utg_functions.items():
            pre = getattr(func, "precondition", None)
            if pre and str(getattr(pre, "node_id", "") or "").strip() == node_id:
                available_functions.append(str(func_id or ""))

        # Get reachable nodes (can_reach)
        can_reach: list[str] = []
        edges = list(getattr(utg, "edges", []) or [])
        for edge in edges:
            from_id = str(getattr(edge, "from_node_id", "") or "").strip()
            to_id = str(getattr(edge, "to_node_id", "") or "").strip()
            if from_id == node_id and to_id:
                can_reach.append(to_id)

        # Get a sample XML (first ref if available)
        xml_sample = ""
        if xml_refs:
            xml_ref = xml_refs[0]
            try:
                xml_sample = runtime.resolve_xml_ref(xml_ref) or ""
            except Exception:
                pass

        items.append(
            {
                "id": node_id,
                "package": package_name,
                "activity": activity_name,
                "description": description,
                "signatures": signatures[:20],  # Limit for display
                "available_functions": available_functions,
                "can_reach": list(set(can_reach))[:10],  # Limit for display
                "xml_refs_count": len(xml_refs),
                "xml_sample": xml_sample[:2000] if xml_sample else "",
            }
        )

    items.sort(key=lambda item: str(item.get("id") or ""))
    return {
        "success": True,
        "count": len(items),
        "nodes": items,
        "provider": PROVIDER_ID,
    }


def list_run_logs(
    *,
    limit: int = 20,
    user_tag: str = "",
    session_tag: str = "",
) -> dict[str, Any]:
    """Return recent canonical `run(goal)` logs for dashboard display.

    Args:
        limit: Maximum number of recent run entries returned, newest first.
        user_tag: Optional hashed user tag filter.
        session_tag: Optional hashed session tag filter.

    Returns:
        Stable JSON payload containing compact summaries of recent canonical runs.
    """

    normalized_limit = max(1, int(limit))
    normalized_user_tag = str(user_tag or "").strip()
    normalized_session_tag = str(session_tag or "").strip()
    run_log_path = Path(_canonical_run_log_path())
    if not run_log_path.exists():
        return {
            "success": True,
            "count": 0,
            "runs": [],
            "run_log_path": str(run_log_path),
            "multi_user_registry_path": _multi_user_registry_path(),
            "provider": PROVIDER_ID,
        }
    logger = UTGRunLogger(enabled=True, path=str(run_log_path))
    runs: list[dict[str, Any]] = []
    for normalized_run in reversed(logger.load_materialized_runs()):
        ingest_scope = _extract_ingest_scope(normalized_run)
        current_user_tag = ingest_scope.get("user_tag", "")
        current_session_tag = ingest_scope.get("session_tag", "")
        if normalized_user_tag and current_user_tag != normalized_user_tag:
            continue
        if normalized_session_tag and current_session_tag != normalized_session_tag:
            continue
        steps = list(normalized_run.get("steps") or [])
        first_step = steps[0] if steps and isinstance(steps[0], dict) else {}
        plan = (
            dict(first_step.get("plan") or {}) if isinstance(first_step, dict) else {}
        )
        tool_call = (
            dict(first_step.get("tool_call") or {})
            if isinstance(first_step.get("tool_call"), dict)
            else {}
        )
        tool_args = (
            dict(plan.get("tool_args") or {})
            if isinstance(plan.get("tool_args"), dict)
            else {}
        )
        compile_result = (
            dict(first_step.get("compile_result") or {})
            if isinstance(first_step, dict)
            else {}
        )
        extra = (
            dict(normalized_run.get("extra") or {})
            if isinstance(normalized_run.get("extra"), dict)
            else {}
        )
        tool_call_names: list[str] = []
        function_ids: list[str] = []
        for step_obj in steps:
            if not isinstance(step_obj, dict):
                continue
            step_plan = (
                dict(step_obj.get("plan") or {})
                if isinstance(step_obj.get("plan"), dict)
                else {}
            )
            step_tool_call = (
                dict(step_obj.get("tool_call") or {})
                if isinstance(step_obj.get("tool_call"), dict)
                else {}
            )
            step_tool_args = (
                dict(step_plan.get("tool_args") or {})
                if isinstance(step_plan.get("tool_args"), dict)
                else {}
            )
            step_compile = (
                dict(step_obj.get("compile_result") or {})
                if isinstance(step_obj.get("compile_result"), dict)
                else {}
            )
            step_tool_name = str(step_tool_call.get("name") or "").strip()
            if step_tool_name and step_tool_name not in tool_call_names:
                tool_call_names.append(step_tool_name)
            step_function_id = str(
                step_tool_call.get("function_id")
                or step_tool_args.get("function_id")
                or step_plan.get("function_id")
                or step_compile.get("function_id")
                or ""
            ).strip()
            if (
                not step_function_id
                and step_tool_name
                and (
                    "-" in step_tool_name
                    or "_" in step_tool_name
                    or step_tool_name.startswith("fn")
                    or step_tool_name.startswith("global")
                )
            ):
                step_function_id = step_tool_name
            if step_function_id and step_function_id not in function_ids:
                function_ids.append(step_function_id)
        error_message = str(extra.get("error_message") or "").strip()
        if not error_message:
            for step_obj in reversed(steps):
                if not isinstance(step_obj, dict):
                    continue
                act_result = (
                    dict(step_obj.get("act_result") or {})
                    if isinstance(step_obj.get("act_result"), dict)
                    else {}
                )
                error_message = str(act_result.get("error_message") or "").strip()
                if error_message:
                    break
        final_observation = (
            dict(normalized_run.get("final_observation") or {})
            if isinstance(normalized_run.get("final_observation"), dict)
            else {}
        )
        runs.append(
            {
                "run_id": str(normalized_run.get("run_id") or "").strip(),
                "goal": str(normalized_run.get("goal") or "").strip(),
                "success": bool(normalized_run.get("success")),
                "done_reason": str(normalized_run.get("done_reason") or "").strip()
                or None,
                "step_count": int(normalized_run.get("step_count") or 0),
                "started_at": str(normalized_run.get("started_at") or "").strip()
                or None,
                "finished_at": str(normalized_run.get("finished_at") or "").strip()
                or None,
                "duration_ms": normalized_run.get("duration_ms"),
                "tool_name": str(tool_call.get("name") or "").strip() or None,
                "tool_call_count": len(tool_call_names),
                "tool_call_names": tool_call_names,
                "function_call_count": len(function_ids),
                "function_ids": function_ids,
                "operation_description": str(
                    first_step.get("operation_description")
                    or plan.get("description")
                    or ""
                ).strip()
                or None,
                "selector_source": str(first_step.get("selector_source") or "").strip()
                or None,
                "selector_label": str(first_step.get("selector_label") or "").strip()
                or None,
                "selector_reason": str(first_step.get("selector_reason") or "").strip()
                or None,
                "compile_status": "hit"
                if compile_result.get("success") is True
                else "miss",
                "compile_function_id": str(
                    compile_result.get("function_id") or ""
                ).strip()
                or None,
                "compile_decision": str(compile_result.get("decision") or "").strip()
                or None,
                "act_function_id": str(tool_args.get("function_id") or "").strip()
                or None,
                "source": str(normalized_run.get("source") or "").strip() or None,
                "compile_summary": str(extra.get("compile_summary") or "").strip()
                or None,
                "error_message": error_message or None,
                "final_package_name": str(
                    final_observation.get("package_name") or ""
                ).strip()
                or None,
                "privacy_mode": ingest_scope.get("privacy_mode") or None,
                "user_tag": current_user_tag or None,
                "session_tag": current_session_tag or None,
            }
        )
        if len(runs) >= normalized_limit:
            break
    return {
        "success": True,
        "count": len(runs),
        "runs": runs,
        "run_log_path": str(run_log_path),
        "multi_user_registry_path": _multi_user_registry_path(),
        "filters": {
            "user_tag": normalized_user_tag or None,
            "session_tag": normalized_session_tag or None,
        },
        "provider": PROVIDER_ID,
    }


def get_run_log(*, run_id: str, lang: str | None = None) -> dict[str, Any]:
    """Return one canonical `run(goal)` log by id for dashboard detail view.

    Args:
        run_id: Stable canonical run identifier stored in `run_logs.jsonl`.

    Returns:
        Stable JSON payload containing the full canonical run log when found.
        Missing ids return `success=False` with a stable error payload.
    """

    normalized_run_id = str(run_id or "").strip()
    run_log_path = Path(_canonical_run_log_path())
    if not normalized_run_id:
        return {
            "success": False,
            "error_code": "run_id_required",
            "error_message": "run_id is required",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }
    if not run_log_path.exists():
        return {
            "success": False,
            "error_code": "run_log_not_found",
            "error_message": f"run_log {normalized_run_id} not found",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }
    logger = UTGRunLogger(enabled=True, path=str(run_log_path))
    normalized_run = logger.load_materialized_run(run_id=normalized_run_id)
    if normalized_run is not None:
        return {
            "success": True,
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
            "run_log": normalized_run,
            "view": _build_run_log_view(normalized_run, lang=lang),
        }
    return {
        "success": False,
        "error_code": "run_log_not_found",
        "error_message": f"run_log {normalized_run_id} not found",
        "run_id": normalized_run_id,
        "run_log_path": str(run_log_path),
        "provider": PROVIDER_ID,
    }


def delete_run_log(*, run_id: str) -> dict[str, Any]:
    """Delete one run_log and all its events from the canonical event stream.

    Args:
        run_id: Stable canonical run identifier to delete.

    Returns:
        Success payload with deleted event count, or error if not found.
    """
    import tempfile

    normalized_run_id = str(run_id or "").strip()
    run_log_path = Path(_canonical_run_log_path())

    if not normalized_run_id:
        return {
            "success": False,
            "error_code": "run_id_required",
            "error_message": "run_id is required",
            "run_id": normalized_run_id,
            "provider": PROVIDER_ID,
        }

    if not run_log_path.exists():
        return {
            "success": False,
            "error_code": "run_log_file_not_found",
            "error_message": "run_log file does not exist",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }

    # Read all events, filter out the target run_id
    kept_lines: list[str] = []
    deleted_count = 0

    with run_log_path.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            raw_line_stripped = raw_line.strip()
            if not raw_line_stripped:
                continue
            try:
                payload = json.loads(raw_line_stripped)
            except Exception:
                # Keep malformed lines to avoid data loss
                kept_lines.append(raw_line_stripped)
                continue

            event_run_id = str(payload.get("run_id") or "").strip()
            if event_run_id == normalized_run_id:
                deleted_count += 1
            else:
                kept_lines.append(raw_line_stripped)

    if deleted_count == 0:
        return {
            "success": False,
            "error_code": "run_log_not_found",
            "error_message": f"run_log {normalized_run_id} not found",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }

    # Write back atomically using temp file
    temp_fd, temp_path = tempfile.mkstemp(dir=run_log_path.parent, suffix=".jsonl.tmp")
    try:
        with os.fdopen(temp_fd, "w", encoding="utf-8") as temp_handle:
            for line in kept_lines:
                temp_handle.write(line + "\n")
        # Atomic replace
        Path(temp_path).replace(run_log_path)
    except Exception as e:
        # Cleanup temp file on error
        try:
            os.unlink(temp_path)
        except Exception:
            pass
        return {
            "success": False,
            "error_code": "write_error",
            "error_message": f"Failed to write run_log file: {e}",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }

    return {
        "success": True,
        "run_id": normalized_run_id,
        "deleted_event_count": deleted_count,
        "run_log_path": str(run_log_path),
        "provider": PROVIDER_ID,
    }


def get_run_log_timeline_payload(
    *, run_id: str, lang: str | None = None
) -> dict[str, Any]:
    """Return one paper-style runlog timeline payload for one canonical run.

    Args:
        run_id: Stable canonical run identifier stored in `run_logs.jsonl`.

    Returns:
        Stable JSON payload containing the rendered timeline figure data used by
        the provider-owned `/browse/run_logs/{run_id}/timeline` page.
    """

    run_detail = get_run_log(run_id=run_id, lang=lang)
    if not bool(run_detail.get("success")):
        return run_detail

    from scripts.runlog_timeline_figure import build_runlog_timeline_payload

    normalized_run_id = str(run_id or "").strip()
    run_log_path = Path(_canonical_run_log_path())
    stream_events: list[dict[str, Any]] = []
    if run_log_path.exists():
        with run_log_path.open("r", encoding="utf-8") as handle:
            for raw_line in handle:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if str(payload.get("run_id") or "").strip() != normalized_run_id:
                    continue
                if isinstance(payload, dict):
                    stream_events.append(dict(payload))

    timeline_payload = build_runlog_timeline_payload(
        dict(run_detail.get("run_log") or {}),
        events=stream_events,
        lang=resolve_api_language(lang=lang),
    )
    return {
        "success": True,
        "run_id": normalized_run_id,
        "run_log_path": str(run_log_path),
        "provider": PROVIDER_ID,
        "timeline_payload": timeline_payload,
    }


def _build_run_log_view(
    run_log: dict[str, Any], *, lang: str | None = None
) -> dict[str, Any]:
    """Build one provider-owned display view from a canonical run log.

    Args:
        run_log: Materialized canonical run log returned by `UTGRunLogger`.

    Returns:
        One JSON-safe view payload for thin clients such as OOB. This view keeps
        rendering decisions on the provider side so the phone UI does not need
        to infer compile status or step labels from partial local task reports.
    """

    normalized_run = dict(run_log or {})
    goal = str(normalized_run.get("goal") or "").strip()
    success = normalized_run.get("success") is True
    done_reason = str(normalized_run.get("done_reason") or "").strip()
    source = str(normalized_run.get("source") or "").strip()
    extra = (
        dict(normalized_run.get("extra") or {})
        if isinstance(normalized_run.get("extra"), dict)
        else {}
    )
    final_observation = (
        dict(normalized_run.get("final_observation") or {})
        if isinstance(normalized_run.get("final_observation"), dict)
        else {}
    )
    raw_steps = [
        dict(item)
        for item in list(normalized_run.get("steps") or [])
        if isinstance(item, dict)
    ]
    first_step = raw_steps[0] if raw_steps else {}
    first_plan = (
        dict(first_step.get("plan") or {})
        if isinstance(first_step.get("plan"), dict)
        else {}
    )
    first_tool_call = (
        dict(first_step.get("tool_call") or {})
        if isinstance(first_step.get("tool_call"), dict)
        else {}
    )
    first_compile = (
        dict(first_step.get("compile_result") or {})
        if isinstance(first_step.get("compile_result"), dict)
        else {}
    )

    compile_function_id = str(
        first_compile.get("function_id")
        or extra.get("function_id")
        or normalized_run.get("function_id")
        or ""
    ).strip()
    compile_kind = "unknown"
    if first_compile.get("success") is True:
        compile_kind = "hit"
    elif first_compile.get("success") is False:
        compile_kind = "miss"
    elif str(first_step.get("selector_source") or "").strip() == "omniflow":
        compile_kind = "hit"
    elif source in {"oob_run_log_ingest", "oob_canonical_steps"}:
        compile_kind = "miss"

    # User-friendly compile label
    compile_label = ""
    if compile_kind == "hit":
        compile_label = (
            _api_text(
                lang,
                "reuse_function_with_id",
                function_id=compile_function_id,
            )
            if compile_function_id
            else _api_text(lang, "reuse_function")
        )
    elif compile_kind == "miss":
        compile_label = _api_text(lang, "vlm_execution")

    tool_label = _api_text(lang, "no_tool")
    for candidate in (
        first_step.get("operation_description"),
        first_tool_call.get("name"),
        first_plan.get("description"),
    ):
        candidate_text = str(candidate or "").strip()
        if candidate_text:
            tool_label = candidate_text
            break
    summary = (
        str(extra.get("compile_summary") or "").strip()
        or str(extra.get("error_message") or "").strip()
    )
    if not summary:
        if success:
            if goal:
                summary = _api_text(lang, "omniflow_executed_goal", goal=goal)
            else:
                summary = _api_text(lang, "omniflow_executed_done")
        else:
            if done_reason:
                summary = _api_text(
                    lang,
                    "omniflow_failed_reason",
                    done_reason=done_reason,
                )
            else:
                summary = _api_text(lang, "omniflow_failed_generic")

    final_package = (
        str(final_observation.get("package_name") or "").strip() or "unknown"
    )
    if not raw_steps:
        empty_message = _api_text(lang, "no_displayable_steps")
    else:
        empty_message = ""

    rendered_steps: list[dict[str, Any]] = []
    for index, step in enumerate(raw_steps, start=1):
        from src.utg.log.run_logger import (
            _build_action_description,
            _step_execution_request,
        )

        plan = (
            dict(step.get("plan") or {}) if isinstance(step.get("plan"), dict) else {}
        )
        step_tool_call = (
            dict(step.get("tool_call") or {})
            if isinstance(step.get("tool_call"), dict)
            else {}
        )
        act_result = (
            dict(step.get("act_result") or {})
            if isinstance(step.get("act_result"), dict)
            else {}
        )
        result_summary = (
            dict(act_result.get("result_summary") or {})
            if isinstance(act_result.get("result_summary"), dict)
            else {}
        )
        execution_request = _step_execution_request(step)
        rendered_action = ""
        if isinstance(execution_request.get("action"), dict):
            rendered_action = _build_action_description(
                dict(execution_request.get("action") or {})
            ).strip()
        if not rendered_action:
            rendered_action = str(plan.get("action_description") or "").strip()
        if not rendered_action:
            rendered_action = str(step.get("operation_description") or "").strip()
        if not rendered_action:
            rendered_action = str(step_tool_call.get("name") or "").strip()
        executed_actions = [rendered_action] if rendered_action else []
        title_description = str(step.get("operation_description") or "").strip()
        title = (
            title_description
            or str(plan.get("description") or "").strip()
            or rendered_action
            or f"Step {index}"
        )
        rendered_steps.append(
            {
                "index": index,
                "title": title,
                "success": act_result.get("success") is not False,
                "selected_by": str(step.get("selector_label") or "").strip(),
                "why": str(step.get("selector_reason") or "").strip(),
                "actions": executed_actions,
                "result": str(result_summary.get("message") or "").strip(),
                "thought": str(result_summary.get("thought") or "").strip(),
                "summary": str(result_summary.get("summary") or "").strip(),
                "tool_call": step_tool_call or None,
            }
        )

    # Extract duration and token usage
    duration_ms = float(normalized_run.get("duration_ms") or 0.0)
    llm_usage = dict(normalized_run.get("llm_usage") or {})
    input_tokens = int(llm_usage.get("input_tokens") or 0)
    output_tokens = int(llm_usage.get("output_tokens") or 0)

    return {
        "success": success,
        "status_label": "success" if success else "failed",
        "goal": goal,
        "summary": summary,
        "compile_kind": compile_kind,
        "compile_label": compile_label,
        "tool_label": tool_label,
        "step_count": len(raw_steps),
        "final_package": final_package,
        "empty_message": empty_message,
        "steps": rendered_steps,
        # Execution stats
        "duration_ms": round(duration_ms, 2),
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
    }


def get_multi_user_global_registry() -> dict[str, Any]:
    """Return the provider-side anonymized global multi-user registry.

    Returns:
        One JSON payload containing only hashed user/session tags plus aggregate
        counts and recent-run summaries. Raw identifiers are never exposed.
    """

    registry = _load_multi_user_registry()
    users = sorted(
        [
            {
                "user_tag": str(item.get("user_tag") or "").strip(),
                "privacy_mode": str(item.get("privacy_mode") or "").strip() or None,
                "run_count": int(item.get("run_count") or 0),
                "session_tags": list(item.get("session_tags") or []),
                "last_run_id": str(item.get("last_run_id") or "").strip() or None,
                "last_goal": str(item.get("last_goal") or "").strip() or None,
                "last_seen_at": str(item.get("last_seen_at") or "").strip() or None,
            }
            for item in list(dict(registry.get("users") or {}).values())
            if str(item.get("user_tag") or "").strip()
        ],
        key=lambda item: item["user_tag"],
    )
    sessions = sorted(
        [
            {
                "session_tag": str(item.get("session_tag") or "").strip(),
                "privacy_mode": str(item.get("privacy_mode") or "").strip() or None,
                "user_tag": str(item.get("user_tag") or "").strip() or None,
                "run_count": int(item.get("run_count") or 0),
                "last_run_id": str(item.get("last_run_id") or "").strip() or None,
                "last_goal": str(item.get("last_goal") or "").strip() or None,
                "last_seen_at": str(item.get("last_seen_at") or "").strip() or None,
            }
            for item in list(dict(registry.get("sessions") or {}).values())
            if str(item.get("session_tag") or "").strip()
        ],
        key=lambda item: item["session_tag"],
    )
    return {
        "success": True,
        "privacy_mode": str(registry.get("privacy_mode") or "hashed_client_tags"),
        "user_count": len(users),
        "session_count": len(sessions),
        "users": users,
        "sessions": sessions,
        "recent_runs": list(registry.get("recent_runs") or []),
        "updated_at": registry.get("updated_at"),
        "multi_user_registry_path": _multi_user_registry_path(),
        "provider": PROVIDER_ID,
    }


# =============================================================================
# Control Plane Management
# =============================================================================


def get_control_plane_rules(runtime: UTGRuntime) -> dict[str, Any]:
    """Return all control plane rules including controllers and trigger pool.

    Returns:
        JSON payload with controllers, trigger pool rules, and error codes.
    """
    from src.utg.execution.control.engine import ControlEngine
    from src.utg.execution.control.error_codes import list_error_codes

    control_engine = getattr(runtime, "_control_engine", None)
    if control_engine is None or not isinstance(control_engine, ControlEngine):
        # Create a temporary engine to get static rules
        control_engine = ControlEngine()

    controllers = control_engine.list_controllers()
    trigger_rules = control_engine.list_trigger_pool_rules()
    trigger_status = control_engine.get_trigger_pool_status()
    error_codes = list_error_codes()

    # Group controllers by phase
    controllers_by_phase: dict[str, list[dict[str, Any]]] = {}
    for ctrl in controllers:
        phase = ctrl.get("phase", "unknown")
        if phase not in controllers_by_phase:
            controllers_by_phase[phase] = []
        controllers_by_phase[phase].append(ctrl)

    return {
        "success": True,
        "controllers": controllers,
        "controllers_by_phase": controllers_by_phase,
        "trigger_pool": {
            "status": trigger_status,
            "rules": trigger_rules,
        },
        "error_codes": error_codes,
        "phases": ["before_step", "before_action", "execute_action", "after_action"],
        "provider": PROVIDER_ID,
    }


def get_control_plane_trace(*, run_id: str) -> dict[str, Any]:
    """Return control plane trace for one execution run.

    Args:
        run_id: Canonical run identifier.

    Returns:
        JSON payload with control trace events from the run.
    """
    normalized_run_id = str(run_id or "").strip()
    if not normalized_run_id:
        return {
            "success": False,
            "error_code": "run_id_required",
            "error_message": "run_id is required",
            "provider": PROVIDER_ID,
        }

    run_log, run_log_path = _load_canonical_run_log(run_id=normalized_run_id)
    if run_log is None:
        return {
            "success": False,
            "error_code": "run_log_not_found",
            "error_message": f"run_log {normalized_run_id} not found",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "provider": PROVIDER_ID,
        }

    # Extract control trace from run_log
    control_trace = run_log.get("__utg_control_trace__", {})
    steps = list(run_log.get("steps") or [])

    # Build per-step control summary
    step_summaries = []
    for idx, step in enumerate(steps):
        step_controls = control_trace.get(str(idx), control_trace.get(idx, []))
        triggered = [c for c in step_controls if c.get("status") == "triggered"]
        blocked = [c for c in step_controls if c.get("status") == "blocked"]
        step_summaries.append(
            {
                "step_index": idx,
                "goal": step.get("goal") or step.get("request", {}).get("goal"),
                "control_count": len(step_controls),
                "triggered_count": len(triggered),
                "blocked_count": len(blocked),
                "controls": step_controls,
            }
        )

    return {
        "success": True,
        "run_id": normalized_run_id,
        "goal": run_log.get("goal"),
        "step_count": len(steps),
        "control_trace": control_trace,
        "step_summaries": step_summaries,
        "provider": PROVIDER_ID,
    }


def _load_canonical_run_log(*, run_id: str) -> tuple[dict[str, Any] | None, Path]:
    """Load one canonical run record from `run_logs.jsonl`.

    Args:
        run_id: Stable canonical run identifier emitted by the provider.

    Returns:
        A `(run_log, run_log_path)` tuple. Missing ids return `(None, path)`.
    """

    normalized_run_id = str(run_id or "").strip()
    run_log_path = Path(_canonical_run_log_path())
    if not normalized_run_id or not run_log_path.exists():
        return None, run_log_path
    logger = UTGRunLogger(enabled=True, path=str(run_log_path))
    return logger.load_materialized_run(run_id=normalized_run_id), run_log_path


def _function_kind_from_metadata(metadata: dict[str, Any]) -> str:
    """Resolve the public function-kind label from one function metadata dict."""

    value = str((metadata or {}).get("function_kind") or "").strip()
    return value or FUNCTION_ASSET_KIND


def _asset_state_from_metadata(metadata: dict[str, Any]) -> str:
    """Resolve the public asset-state label from one path metadata dict."""

    value = str((metadata or {}).get("asset_state") or "").strip()
    return value or READY_ASSET_STATE


def _iter_call_function_records(func: Function) -> list[dict[str, Any]]:
    """Return stable call-function records extracted from one function action list."""

    records: list[dict[str, Any]] = []
    for action_index, action in enumerate(list(getattr(func, "actions", []) or [])):
        payload = canonical_action_payload(action)
        if str(payload.get("type") or "").strip() != "call_function":
            continue
        params = dict(payload.get("params") or {})
        records.append(
            {
                "action_index": action_index,
                "node_id": str(params.get("node_id") or "").strip(),
                "function_name": str(params.get("function_name") or "").strip(),
                "arguments": (
                    dict(params.get("arguments") or {})
                    if isinstance(params.get("arguments"), dict)
                    else {}
                ),
            }
        )
    return records


def _declared_child_function_ids(
    functions_by_id: dict[str, Function],
    func: Function,
) -> list[str]:
    """Resolve global child-function ids for one function.

    Preference order:
    1. Explicit `metadata.child_function_ids`
    2. Inferred `call_function.function_name` entries that point to known global
       functions with a matching `start_node_id`
    """

    metadata = dict(getattr(func, "metadata", {}) or {})
    explicit_child_ids = [
        str(item or "").strip()
        for item in list(metadata.get("child_function_ids") or [])
        if str(item or "").strip()
    ]
    if explicit_child_ids:
        return list(dict.fromkeys(explicit_child_ids))

    inferred_child_ids: list[str] = []
    for record in _iter_call_function_records(func):
        child_id = str(record.get("function_name") or "").strip()
        if not child_id:
            continue
        child_func = functions_by_id.get(child_id)
        if child_func is None:
            continue
        expected_start = str(getattr(child_func, "start_node_id", "") or "").strip()
        target_node_id = str(record.get("node_id") or "").strip()
        if expected_start and target_node_id and expected_start != target_node_id:
            continue
        if child_id not in inferred_child_ids:
            inferred_child_ids.append(child_id)
    return inferred_child_ids


def _resolve_bundle_root_function_id(
    functions_by_id: dict[str, Function],
) -> tuple[str | None, str | None]:
    """Infer one root function id from a bundle graph."""

    if not functions_by_id:
        return None, "Bundle graph must contain at least one function."
    if len(functions_by_id) == 1:
        return next(iter(functions_by_id.keys())), None

    referenced_ids: set[str] = set()
    entry_point_ids: list[str] = []
    for function_id, func in functions_by_id.items():
        metadata = dict(getattr(func, "metadata", {}) or {})
        if bool(metadata.get("entry_point")):
            entry_point_ids.append(function_id)
        for child_id in _declared_child_function_ids(functions_by_id, func):
            if child_id in functions_by_id and child_id != function_id:
                referenced_ids.add(child_id)

    root_ids = [fid for fid in functions_by_id if fid not in referenced_ids]
    if len(root_ids) == 1:
        return root_ids[0], None

    entry_roots = [fid for fid in root_ids if fid in entry_point_ids]
    if len(entry_roots) == 1:
        return entry_roots[0], None

    if len(entry_point_ids) == 1:
        return entry_point_ids[0], None

    if not root_ids:
        return None, "Bundle graph root is ambiguous: no unique unreferenced function."
    return (
        None,
        "Bundle graph root is ambiguous: multiple candidate root functions "
        f"({', '.join(sorted(root_ids))}).",
    )


def _validate_function_topology(
    functions_by_id: dict[str, Function],
    *,
    root_function_id: str,
) -> dict[str, Any] | None:
    """Validate one global function dependency bundle before save/export/import."""

    errors: list[str] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def _validate_one(function_id: str) -> None:
        if function_id in visited:
            return
        if function_id in visiting:
            errors.append(f"Function topology cycle detected at '{function_id}'.")
            return
        func = functions_by_id.get(function_id)
        if func is None:
            errors.append(
                f"Function topology references missing function '{function_id}'."
            )
            return
        visiting.add(function_id)
        metadata = dict(getattr(func, "metadata", {}) or {})
        call_records = _iter_call_function_records(func)
        explicit_child_ids = [
            str(item or "").strip()
            for item in list(metadata.get("child_function_ids") or [])
            if str(item or "").strip()
        ]
        resolved_child_ids = _declared_child_function_ids(functions_by_id, func)

        if (
            str(metadata.get("merge_mode") or "").strip() == "compose"
            or explicit_child_ids
        ):
            if len(call_records) != len(list(getattr(func, "actions", []) or [])):
                errors.append(
                    f"Composite function '{function_id}' must encode its child chain "
                    "only through call_function actions."
                )
            action_child_ids = [
                str(record.get("function_name") or "").strip()
                for record in call_records
            ]
            if explicit_child_ids and action_child_ids != explicit_child_ids:
                errors.append(
                    f"Composite function '{function_id}' has mismatched child_function_ids "
                    "metadata and call_function order."
                )

        previous_child: Function | None = None
        for record in call_records:
            child_id = str(record.get("function_name") or "").strip()
            if not child_id or child_id not in functions_by_id:
                continue
            child_func = functions_by_id[child_id]
            target_node_id = str(record.get("node_id") or "").strip()
            child_start = str(getattr(child_func, "start_node_id", "") or "").strip()
            if child_start and target_node_id and child_start != target_node_id:
                errors.append(
                    f"Composite function '{function_id}' targets child '{child_id}' at "
                    f"node '{target_node_id}', but the child starts at '{child_start}'."
                )
            if previous_child is not None:
                previous_end = str(
                    getattr(previous_child, "end_node_id", "") or ""
                ).strip()
                if previous_end and child_start and previous_end != child_start:
                    errors.append(
                        f"Composite function '{function_id}' is not node-contiguous: "
                        f"'{previous_child.name}' ends at '{previous_end}' but "
                        f"'{child_id}' starts at '{child_start}'."
                    )
            previous_child = child_func

        if resolved_child_ids:
            first_child = functions_by_id.get(resolved_child_ids[0])
            last_child = functions_by_id.get(resolved_child_ids[-1])
            function_start = str(getattr(func, "start_node_id", "") or "").strip()
            function_end = str(getattr(func, "end_node_id", "") or "").strip()
            if first_child is not None:
                first_start = str(
                    getattr(first_child, "start_node_id", "") or ""
                ).strip()
                if function_start and first_start and function_start != first_start:
                    errors.append(
                        f"Composite function '{function_id}' start_node_id '{function_start}' "
                        f"does not match first child start '{first_start}'."
                    )
            if last_child is not None:
                last_end = str(getattr(last_child, "end_node_id", "") or "").strip()
                if function_end and last_end and function_end != last_end:
                    errors.append(
                        f"Composite function '{function_id}' end_node_id '{function_end}' "
                        f"does not match last child end '{last_end}'."
                    )

        for child_id in resolved_child_ids:
            if child_id not in functions_by_id:
                errors.append(
                    f"Composite function '{function_id}' is missing bundled child '{child_id}'."
                )
                continue
            _validate_one(child_id)

        visiting.remove(function_id)
        visited.add(function_id)

    _validate_one(root_function_id)
    if errors:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_TOPOLOGY",
            "error_message": errors[0],
            "topology_errors": errors,
            "function_id": root_function_id,
        }
    return None


def _collect_bundle_functions(
    runtime: UTGRuntime,
    func: Function,
) -> dict[str, Function]:
    """Collect one root function plus all global child-function dependencies."""

    all_runtime_functions = dict(
        getattr(getattr(runtime, "_utg", None), "functions", {}) or {}
    )
    all_runtime_functions[str(func.name or "").strip()] = func
    bundle_functions: dict[str, Function] = {}
    queue: list[str] = [str(func.name or "").strip()]

    while queue:
        function_id = queue.pop(0)
        if not function_id or function_id in bundle_functions:
            continue
        current_func = all_runtime_functions.get(function_id)
        if current_func is None:
            raise ValueError(
                f"Function bundle references missing global child function: {function_id}"
            )
        bundle_functions[function_id] = current_func
        for child_id in _declared_child_function_ids(
            all_runtime_functions, current_func
        ):
            if child_id not in all_runtime_functions:
                raise ValueError(
                    f"Function '{function_id}' references missing global child '{child_id}'."
                )
            if child_id not in bundle_functions:
                queue.append(child_id)

    validation_error = _validate_function_topology(
        bundle_functions,
        root_function_id=str(func.name or "").strip(),
    )
    if validation_error is not None:
        raise ValueError(
            str(validation_error.get("error_message") or "invalid topology")
        )
    return bundle_functions


def _raw_replay_prefix(run_id: str) -> str:
    """Build one stable short identifier used by raw replay assets."""

    compact = "".join(char.lower() for char in str(run_id or "") if char.isalnum())
    compact = compact[:8]
    return compact or "rawrun"


def _extract_ingest_scope(run_log: dict[str, Any]) -> dict[str, str]:
    """Extract one privacy-safe ingest scope from a normalized run log.

    Args:
        run_log: Normalized canonical run payload.

    Returns:
        A compact dict containing only `privacy_mode`, `user_tag`, and
        `session_tag` when present. Raw identifiers are never returned.
    """

    extra = dict(run_log.get("extra") or {}) if isinstance(run_log, dict) else {}
    ingest_client = (
        dict(extra.get("ingest_client") or {})
        if isinstance(extra.get("ingest_client"), dict)
        else {}
    )
    scope: dict[str, str] = {}
    privacy_mode = str(ingest_client.get("privacy_mode") or "").strip()
    user_tag = str(ingest_client.get("user_tag") or "").strip()
    session_tag = str(ingest_client.get("session_tag") or "").strip()
    if privacy_mode:
        scope["privacy_mode"] = privacy_mode
    if user_tag:
        scope["user_tag"] = user_tag
    if session_tag:
        scope["session_tag"] = session_tag
    return scope


def _load_multi_user_registry() -> dict[str, Any]:
    """Load the anonymized multi-user registry from disk.

    Returns:
        One JSON-safe registry payload. Missing or invalid files fall back to a
        fresh empty registry.
    """

    registry_path = Path(_multi_user_registry_path())
    if not registry_path.exists():
        return {
            "privacy_mode": "hashed_client_tags",
            "users": {},
            "sessions": {},
            "recent_runs": [],
            "updated_at": None,
        }
    try:
        raw = json.loads(registry_path.read_text(encoding="utf-8"))
    except Exception:
        return {
            "privacy_mode": "hashed_client_tags",
            "users": {},
            "sessions": {},
            "recent_runs": [],
            "updated_at": None,
        }
    if not isinstance(raw, dict):
        return {
            "privacy_mode": "hashed_client_tags",
            "users": {},
            "sessions": {},
            "recent_runs": [],
            "updated_at": None,
        }
    return {
        "privacy_mode": str(raw.get("privacy_mode") or "hashed_client_tags"),
        "users": dict(raw.get("users") or {}),
        "sessions": dict(raw.get("sessions") or {}),
        "recent_runs": list(raw.get("recent_runs") or []),
        "updated_at": raw.get("updated_at"),
    }


def _save_multi_user_registry(registry: dict[str, Any]) -> None:
    """Persist the anonymized multi-user registry to disk.

    Args:
        registry: JSON-safe registry payload containing only hashed tags and
            aggregate counters.
    """

    registry_path = Path(_multi_user_registry_path())
    registry_path.write_text(
        json.dumps(to_serializable(registry), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _update_multi_user_registry(run_log: dict[str, Any]) -> dict[str, Any]:
    """Update provider-wide anonymized user/session aggregates for one run.

    Args:
        run_log: Normalized canonical run payload already stripped of raw IDs.

    Returns:
        The updated anonymized registry snapshot.
    """

    scope = _extract_ingest_scope(run_log)
    if not scope:
        return _load_multi_user_registry()
    registry = _load_multi_user_registry()
    now_iso = datetime.now(timezone.utc).isoformat()
    run_id = str(run_log.get("run_id") or "").strip()
    goal = str(run_log.get("goal") or "").strip()
    started_at = str(run_log.get("started_at") or "").strip() or None
    user_tag = scope.get("user_tag", "")
    session_tag = scope.get("session_tag", "")
    privacy_mode = scope.get("privacy_mode", "") or "hashed_client_tags"
    registry["privacy_mode"] = privacy_mode
    registry["updated_at"] = now_iso

    if user_tag:
        user_entry = dict(registry["users"].get(user_tag) or {})
        user_entry["user_tag"] = user_tag
        user_entry["privacy_mode"] = privacy_mode
        user_entry["run_count"] = int(user_entry.get("run_count") or 0) + 1
        user_entry["last_run_id"] = run_id or user_entry.get("last_run_id")
        user_entry["last_goal"] = goal or user_entry.get("last_goal")
        user_entry["last_seen_at"] = started_at or now_iso
        existing_sessions = {
            str(item or "").strip()
            for item in list(user_entry.get("session_tags") or [])
            if str(item or "").strip()
        }
        if session_tag:
            existing_sessions.add(session_tag)
        user_entry["session_tags"] = sorted(existing_sessions)
        registry["users"][user_tag] = user_entry

    if session_tag:
        session_entry = dict(registry["sessions"].get(session_tag) or {})
        session_entry["session_tag"] = session_tag
        session_entry["privacy_mode"] = privacy_mode
        session_entry["user_tag"] = user_tag or session_entry.get("user_tag")
        session_entry["run_count"] = int(session_entry.get("run_count") or 0) + 1
        session_entry["last_run_id"] = run_id or session_entry.get("last_run_id")
        session_entry["last_goal"] = goal or session_entry.get("last_goal")
        session_entry["last_seen_at"] = started_at or now_iso
        registry["sessions"][session_tag] = session_entry

    recent_runs = [
        item
        for item in list(registry.get("recent_runs") or [])
        if str(item.get("run_id") or "").strip() != run_id
    ]
    recent_runs.insert(
        0,
        {
            "run_id": run_id,
            "goal": goal,
            "user_tag": user_tag or None,
            "session_tag": session_tag or None,
            "started_at": started_at,
            "privacy_mode": privacy_mode,
        },
    )
    registry["recent_runs"] = recent_runs[:200]
    _save_multi_user_registry(registry)
    return registry


def _extract_action_from_step(step: dict[str, Any]) -> dict[str, Any] | None:
    """从 step 提取动作对应的最小 tool call。

    Args:
        step: 单步数据，可能来自不同来源（OOB、AndroidWorld等）。

    Returns:
        规范化后的 action 字典，供 run-log 写回流程转成 tool_call。
    """
    if not isinstance(step, dict):
        return None
    # 优先级1: 最小 canonical tool_call
    tool_call = step.get("tool_call") or {}
    if isinstance(tool_call, dict):
        tool_name = str(tool_call.get("name") or "").strip()
        if tool_name:
            return {
                "type": tool_name,
                "params": dict(tool_call.get("params") or {}),
            }
    # 优先级2: 直接的 action
    if step.get("action") and isinstance(step["action"], dict):
        return step["action"]
    # 优先级3: plan.tool_args.action
    plan = step.get("plan") or {}
    if isinstance(plan, dict):
        tool_args = plan.get("tool_args") or {}
        if isinstance(tool_args, dict) and tool_args.get("action"):
            return tool_args["action"]
    return None


def _extract_target_element_from_action(
    xml: str | None, action: dict[str, Any]
) -> dict[str, Any] | None:
    """从坐标匹配目标元素"""
    if not xml:
        return None

    action_type = str(action.get("type") or "").lower()
    params = action.get("params") or {}

    # 获取坐标
    if action_type in ("click", "long_press"):
        x, y = params.get("x"), params.get("y")
    elif action_type == "swipe":
        x, y = params.get("x"), params.get("y")
    else:
        return None

    if x is None or y is None:
        return None

    try:
        from src.utg.assets.embedding.element_embedding import UITree

        tree = UITree(xml, is_file=False)
        element = tree.get_element_at_coords(float(x), float(y))
        if not element:
            return None
        return {
            "resource_id": element.get("resource-id"),
            "text": element.get("text"),
            "content_desc": element.get("content-desc"),
            "class_name": element.get("class"),
            "bounds": element.get("bound_list"),
            "match_method": "coordinate_lookup",
        }
    except Exception:
        return None


def _extract_intent_from_action(
    action: dict[str, Any], tool_call: dict[str, Any]
) -> str | None:
    """从 action 和 tool_call 中提取 intent

    优先级：
    1. action.description
    2. params.targetDescription / target_description
    3. params.clickPrompt
    4. tool_call.reason
    """
    # 1. action 自带的 description
    intent = str(action.get("description") or "").strip()
    if intent:
        return intent

    params = action.get("params") or {}

    # 2. targetDescription
    intent = str(
        params.get("targetDescription") or params.get("target_description") or ""
    ).strip()
    if intent:
        return intent

    # 3. clickPrompt
    intent = str(params.get("clickPrompt") or params.get("click_prompt") or "").strip()
    if intent:
        return intent

    # 4. tool_call.reason
    intent = str(tool_call.get("reason") or "").strip()
    if intent and intent != "oob_run_log_ingest":
        return intent

    return None


def _build_ingest_client_metadata(
    *, client_user_id: str | None = None, client_session_id: str | None = None
) -> dict[str, Any]:
    """Build privacy-safe ingest client metadata without persisting raw IDs.

    Args:
        client_user_id: Optional caller-side user identifier such as email, uid,
            or account handle. The provider hashes it into a stable `user_tag`
            and drops the raw value before any run_log persistence.
        client_session_id: Optional caller-side session identifier. The provider
            hashes it into a stable `session_tag` and never stores the raw value.

    Returns:
        A JSON-safe metadata dict suitable for `run_log.extra.ingest_client`.
        Returns `{}` when the caller does not supply any client identifiers.
    """

    normalized_user = str(client_user_id or "").strip()
    normalized_session = str(client_session_id or "").strip()
    if not normalized_user and not normalized_session:
        return {}
    salt = (
        str(os.getenv("OMNIFLOW_INGEST_PRIVACY_SALT") or "").strip()
        or "omniflow_ingest_v1"
    )
    metadata: dict[str, Any] = {"privacy_mode": "hashed_client_tags"}
    if normalized_user:
        user_digest = hashlib.sha256(
            f"{salt}:user:{normalized_user}".encode("utf-8")
        ).hexdigest()[:12]
        metadata["user_tag"] = f"user_{user_digest}"
    if normalized_session:
        session_digest = hashlib.sha256(
            f"{salt}:session:{normalized_session}".encode("utf-8")
        ).hexdigest()[:12]
        metadata["session_tag"] = f"session_{session_digest}"
    return metadata


async def ingest_run_log(
    runtime: UTGRuntime,
    *,
    run_log: dict[str, Any],
    auto_import: bool = False,
    client_user_id: str | None = None,
    client_session_id: str | None = None,
) -> dict[str, Any]:
    """导入 OOB / host 上报的 canonical run 到统一事件流。

    Args:
        runtime: UTGRuntime 实例
        run_log: 当前唯一正式 ingest 输入。调用方必须直接上传 canonical /
            materialized run payload，provider 不再接受顶层旧 `goal/steps`
            兼容字段。
        auto_import: 是否自动导入为本地 function asset
        client_user_id: Optional caller user identifier. The provider hashes it
            into `run_log.extra.ingest_client.user_tag` and drops the raw value.
        client_session_id: Optional caller session identifier. The provider
            hashes it into `run_log.extra.ingest_client.session_tag` and never
            persists the raw input.

    Returns:
        导入结果
    """
    ingest_client = _build_ingest_client_metadata(
        client_user_id=client_user_id,
        client_session_id=client_session_id,
    )

    # 使用 UTGRunLogger 写入事件流（统一格式）
    logger = UTGRunLogger(enabled=True, path=_canonical_run_log_path())
    normalized_run = (
        dict(to_serializable(run_log) or {}) if isinstance(run_log, dict) else {}
    )
    if not normalized_run:
        return {
            "success": False,
            "error_code": "INVALID_RUN_LOG",
            "error_message": "run_log must be one non-empty canonical payload.",
        }

    normalized_goal = str(normalized_run.get("goal") or "").strip()
    started_at_value = str(normalized_run.get("started_at") or "").strip()
    if not started_at_value:
        started_at_value = datetime.now(timezone.utc).isoformat()
        normalized_run["started_at"] = started_at_value
    finished_at_value = str(normalized_run.get("finished_at") or "").strip()
    if not finished_at_value:
        finished_at_value = datetime.now(timezone.utc).isoformat()
        normalized_run["finished_at"] = finished_at_value
    normalized_run_id = (
        str(normalized_run.get("run_id") or "").strip() or logger.new_run_id()
    )
    normalized_run["run_id"] = normalized_run_id
    extra = (
        dict(normalized_run.get("extra") or {})
        if isinstance(normalized_run.get("extra"), dict)
        else {}
    )
    if not str(extra.get("source") or "").strip():
        extra["source"] = "oob_canonical_steps"
    if ingest_client:
        extra["ingest_client"] = dict(ingest_client)
    normalized_run["extra"] = extra
    if not isinstance(normalized_run.get("steps"), list):
        normalized_run["steps"] = []
    for raw_step in list(normalized_run.get("steps") or []):
        if not isinstance(raw_step, dict):
            continue
        started_text = str(raw_step.get("started_at") or "").strip()
        finished_text = str(raw_step.get("finished_at") or "").strip()
        if not finished_text:
            continue
        try:
            finished_dt = datetime.fromisoformat(finished_text.replace("Z", "+00:00"))
        except ValueError:
            continue
        started_dt = None
        if started_text:
            try:
                started_dt = datetime.fromisoformat(started_text.replace("Z", "+00:00"))
            except ValueError:
                started_dt = None
        if started_dt is not None and started_dt <= finished_dt:
            continue
        duration_ms = raw_step.get("duration_ms")
        if duration_ms is not None:
            try:
                duration_ms = float(duration_ms)
            except (TypeError, ValueError):
                duration_ms = None
        if duration_ms is not None and duration_ms > 0:
            raw_step["started_at"] = (
                finished_dt - timedelta(milliseconds=duration_ms)
            ).isoformat()
        else:
            raw_step["started_at"] = finished_dt.isoformat()

    for event in logger.decompose_materialized_run(normalized_run):
        logger.write_event(event)
    if ingest_client:
        _update_multi_user_registry(normalized_run)

    result = {
        "success": True,
        "run_id": normalized_run_id,
        "run_log_path": _canonical_run_log_path(),
        "goal": normalized_goal,
        "step_count": len(list(normalized_run.get("steps") or [])),
    }
    if ingest_client:
        result["ingest_client"] = dict(ingest_client)

    # 自动导入：导入快（同步），LLM 升级慢（后台）
    if auto_import:
        # Step 1: 同步导入（不做 LLM enrich，快）
        import_result = await import_run_log(
            runtime, run_id=normalized_run_id, auto_enrich=False
        )
        result["auto_import"] = import_result
        created_func_id = str(import_result.get("created_function_id") or "").strip()

        # Step 2: 后台 LLM 升级（慢）
        if created_func_id and import_result.get("success"):
            task_id = _create_background_task(
                task_type="enrich_function",
                ref_id=created_func_id,
                metadata={"goal": normalized_goal, "run_id": normalized_run_id},
            )
            result["enrich_task_id"] = task_id
            result["enrich_task_status"] = "pending"

            async def _run_enrich_in_background():
                try:
                    _update_background_task(task_id, status="running")
                    enrich_result = await enrich_function(
                        runtime, function_id=created_func_id
                    )
                    _update_background_task(
                        task_id, status="completed", result=enrich_result
                    )
                except Exception as e:
                    logger.exception(f"Background enrich failed: {e}")
                    _update_background_task(task_id, status="failed", error=str(e))

            asyncio.create_task(_run_enrich_in_background())

    return result


# =============================================================================
# Goal Embedding & Semantic Deduplication Helpers
# =============================================================================

# 缓存 sentence-transformers 模型实例，避免重复加载
_EMBEDDING_MODEL_CACHE: dict = {}


def _get_embedding_model(model_name: str):
    """获取或创建 sentence-transformers 模型实例（带缓存）。

    Args:
        model_name: 模型名称

    Returns:
        SentenceTransformer 实例，或 None（如果不可用）
    """
    global _EMBEDDING_MODEL_CACHE

    if model_name in _EMBEDDING_MODEL_CACHE:
        return _EMBEDDING_MODEL_CACHE[model_name]

    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(model_name)
        _EMBEDDING_MODEL_CACHE[model_name] = model
        logger.info(f"Loaded embedding model: {model_name}")
        return model
    except ImportError:
        logger.warning("sentence-transformers not installed")
        return None
    except Exception as e:
        logger.warning(f"Failed to load embedding model {model_name}: {e}")
        return None


def _get_goal_embedding(goal: str) -> np.ndarray:
    """使用 sentence-transformers 生成 goal 的 embedding。

    与 compile 模块使用相同的模型，保证语义一致性。
    模型实例会被缓存，避免重复加载。

    Args:
        goal: 任务目标文本

    Returns:
        归一化后的 embedding 向量
    """
    from src.foundation.settings import settings

    model_name = settings.compile.model_name
    model = _get_embedding_model(model_name)

    if model is None:
        return np.zeros(384, dtype=np.float32)

    try:
        embedding = model.encode([goal], normalize_embeddings=True)
        return embedding[0]
    except Exception as e:
        logger.warning(f"Failed to encode goal: {e}, using zero embedding")
        return np.zeros(384, dtype=np.float32)


def _cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """计算两个向量的余弦相似度。

    假设向量已经归一化，直接计算点积。
    """
    if vec1.shape != vec2.shape:
        return 0.0
    return float(np.dot(vec1, vec2))


async def _find_matching_function_by_goal(
    runtime: UTGRuntime,
    goal_embedding: np.ndarray,
    *,
    threshold: float = 0.95,
) -> tuple[str | None, float]:
    """通过 embedding 相似度查找语义匹配的 function。

    遍历现有 functions，计算 goal embedding 相似度，找出最佳匹配。

    Args:
        runtime: Runtime instance
        goal_embedding: 待匹配的 goal embedding
        threshold: 相似度阈值，超过此值认为是同一个 function

    Returns:
        (function_id, similarity) 或 (None, 0.0)
    """
    best_match_id: str | None = None
    best_similarity: float = 0.0

    utg_graph = getattr(runtime, "_utg", None)
    if utg_graph is None:
        return None, 0.0

    functions = getattr(utg_graph, "functions", {}) or {}

    for func_id, func in functions.items():
        # 从 metadata 获取已缓存的 goal embedding
        metadata = getattr(func, "metadata", {}) or {}
        if not isinstance(metadata, dict):
            metadata = {}

        cached_embedding = metadata.get("goal_embedding")

        if cached_embedding is not None:
            # 转换为 numpy 数组
            if isinstance(cached_embedding, list):
                cached_embedding = np.array(cached_embedding, dtype=np.float32)
            elif not isinstance(cached_embedding, np.ndarray):
                cached_embedding = None

        if cached_embedding is None:
            # 如果没有缓存，使用 description 计算（但不更新缓存，避免副作用）
            func_description = getattr(func, "description", "") or func_id
            if func_description:
                cached_embedding = _get_goal_embedding(func_description)
            else:
                continue

        sim = _cosine_similarity(goal_embedding, cached_embedding)
        if sim > best_similarity:
            best_similarity = sim
            best_match_id = func_id

    if best_similarity >= threshold:
        return best_match_id, best_similarity
    return None, best_similarity


async def _enrich_goal(goal: str, run_log: dict[str, Any]) -> tuple[str, np.ndarray]:
    """自动 enrich：生成规范化的 goal 和 embedding。

    使用 LLM 将原始 goal 规范化为简洁的 function 名称，
    然后生成 embedding 用于语义去重。

    Args:
        goal: 原始任务目标
        run_log: run_log 数据（用于提取 action 上下文）

    Returns:
        (enriched_goal, goal_embedding)
    """
    from src.foundation.ai import acomplete

    # 构建上下文：goal + 执行的 actions 摘要
    actions_summary = []
    steps = run_log.get("steps") or []
    for step in steps[:5]:  # 最多取前 5 步
        if not isinstance(step, dict):
            continue
        tool_call = step.get("tool_call") or {}
        if isinstance(tool_call, dict):
            action_name = tool_call.get("name", "unknown")
            actions_summary.append(str(action_name))

    prompt = f"""规范化以下任务目标为简洁的 function 名称。

原始目标: {goal}
执行动作: {", ".join(actions_summary) if actions_summary else "无"}

要求:
1. 保留核心意图
2. 去除冗余描述
3. 使用动词开头（如"打开XX"、"发送XX"）
4. 不超过20字

直接输出规范化后的 function 名称，不要解释。"""

    try:
        enriched_goal = await acomplete(prompt, provider="openai", timeout=10.0)
        enriched_goal = enriched_goal.strip()
        if not enriched_goal:
            enriched_goal = goal
    except Exception as e:
        logger.warning(f"Failed to enrich goal: {e}, using original")
        enriched_goal = goal

    # 生成 embedding
    goal_embedding = _get_goal_embedding(enriched_goal)

    return enriched_goal, goal_embedding


async def import_run_log(
    runtime: UTGRuntime,
    *,
    run_id: str,
    persist: bool = True,
    auto_enrich: bool = True,
    dedup_threshold: float = 0.95,
) -> dict[str, Any]:
    """导入 run_log 为 function（支持语义去重）

    核心设计:
    一个 run_log 可能包含多种 step：
    - Compile Hit step: 执行已有 function，只更新关联的 source_run_ids
    - Miss step: 原子动作 (click, swipe 等)，从中创建/更新 function

    返回字段:
    - hit_function_ids: 关联的已有 function IDs（compile hit）
    - created_function_id: 从 miss actions 创建的 function ID（如果有）
    - miss_action_count: 提取的原子动作数量

    同时保存到:
    1. FunctionStore（文件系统）- 详细的 step 数据
    2. runtime._utg.functions - 执行用的精简数据

    Args:
        runtime: Runtime instance (用于获取存储路径)
        run_id: run_log ID
        persist: 是否持久化保存。False 时只在内存中创建临时 function（用于 replay）
        auto_enrich: 是否自动 enrich goal（LLM 规范化）
        dedup_threshold: 语义去重阈值（默认 0.95）

    Returns:
        导入结果，正式字段为 hit_function_ids / created_function_id
    """
    from src.utg.assets.function_store import Function as StoredFunction
    from src.utg.assets.function_store import (
        FunctionStore,
        extract_step_action,
        extract_step_function_id,
    )
    from src.utg.core.actions import serialize_action_for_storage
    from src.utg.core.models import Function as UTGFunction

    normalized_run_id = str(run_id or "").strip()
    if not normalized_run_id:
        return {
            "success": False,
            "error_code": "INVALID_RUN_ID",
            "error_message": "Run id is required.",
        }

    # 加载 run_log
    selected_run, run_log_path = _load_canonical_run_log(run_id=normalized_run_id)
    if selected_run is None:
        return {
            "success": False,
            "error_code": "RUN_LOG_NOT_FOUND",
            "error_message": f"Run log not found: {normalized_run_id}",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
        }

    goal = str(selected_run.get("goal", "") or "").strip()
    ingest_scope = _extract_ingest_scope(selected_run)
    steps_data = selected_run.get("steps") or []

    # =================================================================
    # Step 1: 区分 Compile Hit 和 Miss Actions
    # =================================================================
    hit_function_ids: list[str] = []  # 关联的已有 function
    miss_actions: list[dict[str, Any]] = []  # 提取的原子动作
    candidate_function_ids: list[str] = []  # 候选 function IDs (可能不存在)

    for step in steps_data:
        if not isinstance(step, dict):
            continue

        # 检查是否有 compile hit (使用 mutation 模块的函数)
        # 注意：即使是 compile hit，也要保留 call_function 作为 step
        function_id = extract_step_function_id(step, runtime.get_function_by_id)
        if function_id:
            if function_id not in hit_function_ids:
                hit_function_ids.append(function_id)
            # 不再 continue，继续提取 action（包括 call_function）

        # 收集 compile_result 中的 function_id（即使 function 不存在）
        compile_result = step.get("compile_result")
        if isinstance(compile_result, dict):
            for cid in [
                str(compile_result.get("function_id") or "").strip(),
                *[
                    str(item or "").strip()
                    for item in list(compile_result.get("candidate_function_ids") or [])
                ],
            ]:
                if cid and cid not in candidate_function_ids:
                    candidate_function_ids.append(cid)

        # 提取动作 (包括 call_function)
        action = extract_step_action(step)
        if action:
            miss_actions.append(action)

    # =================================================================
    # Step 1.5: 从 hit function 或 candidate function 复制 actions
    # =================================================================
    # 当没有 miss_actions 时，从已有 function 复制 actions 以创建新 function
    source_function_id: str | None = None
    if not miss_actions:
        from src.utg.core.actions import serialize_action_for_storage

        # 合并所有候选 function IDs
        all_candidates = hit_function_ids + [
            cid for cid in candidate_function_ids if cid not in hit_function_ids
        ]

        for cid in all_candidates:
            current_id = cid
            visited: set[str] = set()
            while current_id and current_id not in visited:
                visited.add(current_id)
                ref_func = runtime.get_function_by_id(current_id)
                if ref_func is None:
                    break
                ref_actions = list(getattr(ref_func, "actions", []) or [])
                if ref_actions:
                    source_function_id = current_id
                    miss_actions = [
                        serialize_action_for_storage(a) for a in ref_actions
                    ]
                    # 同时加入 hit_function_ids
                    if current_id not in hit_function_ids:
                        hit_function_ids.append(current_id)
                    break
                # 检查是否有 import_source_function_id
                ref_meta = getattr(ref_func, "metadata", {}) or {}
                if isinstance(ref_meta, dict):
                    current_id = str(
                        ref_meta.get("import_source_function_id") or ""
                    ).strip()
                else:
                    break
            if miss_actions:
                break

    # =================================================================
    # Step 2: 更新 hit function 的执行统计
    # =================================================================
    if persist:
        for func_id in hit_function_ids:
            func = runtime.get_function_by_id(func_id)
            if func:
                # UTGFunction 使用 metadata.source_run_ids
                metadata = getattr(func, "metadata", {}) or {}
                if not isinstance(metadata, dict):
                    metadata = {}
                source_run_ids_list = list(metadata.get("source_run_ids") or [])
                if normalized_run_id not in source_run_ids_list:
                    source_run_ids_list.append(normalized_run_id)
                    metadata["source_run_ids"] = source_run_ids_list
                    func.metadata = metadata

    # =================================================================
    # Step 3: 如果有 miss actions，创建/更新 function
    # =================================================================
    created_function_id: str | None = None
    enriched_goal = goal
    goal_embedding: np.ndarray | None = None
    is_update = False
    match_similarity: float = 0.0
    matched_func_id: str | None = None
    source_run_ids: list[str] = []

    if miss_actions:
        # Goal Enrichment & Embedding
        if auto_enrich and goal and persist:
            try:
                enriched_goal, goal_embedding = await _enrich_goal(goal, selected_run)
                logger.info(f"Enriched goal: '{goal}' → '{enriched_goal}'")
            except Exception as e:
                logger.warning(f"Goal enrichment failed: {e}, using original goal")
                enriched_goal = goal
                goal_embedding = _get_goal_embedding(goal)
        elif goal:
            goal_embedding = _get_goal_embedding(goal)

        # Semantic Deduplication
        if persist and goal_embedding is not None:
            matched_func_id, match_similarity = await _find_matching_function_by_goal(
                runtime, goal_embedding, threshold=dedup_threshold
            )

            if matched_func_id:
                is_update = True
                existing_func = runtime.get_function_by_id(matched_func_id)
                if existing_func:
                    existing_metadata = getattr(existing_func, "metadata", {}) or {}
                    if isinstance(existing_metadata, dict):
                        source_run_ids = list(
                            existing_metadata.get("source_run_ids") or []
                        )
                if normalized_run_id not in source_run_ids:
                    source_run_ids.append(normalized_run_id)
                logger.info(
                    f"Found matching function: {matched_func_id} "
                    f"(similarity: {match_similarity:.3f})"
                )

        # Generate Stable Function ID
        if is_update and matched_func_id:
            stable_func_id = matched_func_id
        else:
            goal_hash = hashlib.md5(enriched_goal.encode()).hexdigest()[:8]
            stable_func_id = f"func_{goal_hash}"
            source_run_ids = [normalized_run_id]

        created_function_id = stable_func_id

        # 构建 StoredFunction
        store_path = (
            Path(runtime._filepath).parent / "functions"
            if runtime._filepath
            else Path("runtime/functions")
        )
        store = FunctionStore(store_path)

        stored_func = StoredFunction.from_run_log(selected_run)
        stored_func.id = stable_func_id
        stored_func.enriched_goal = enriched_goal
        stored_func.source_run_ids = source_run_ids

        # 构建 UTG Function
        utg_metadata = {
            "source": "run_log_import",
            "run_id": normalized_run_id,
            "run_log_path": str(run_log_path),
            "original_goal": goal,
            "enriched_goal": enriched_goal,
            "goal": enriched_goal,
            "step_count": len(miss_actions),  # 只计算实际保存的 actions
            "success": stored_func.success,
            "created_at": stored_func.created_at,
            "ingest_scope": dict(ingest_scope),
            "import_source_function_id": source_function_id,
            "persisted": persist,
            "source_run_ids": source_run_ids,
            "is_update": is_update,
        }

        if goal_embedding is not None:
            utg_metadata["goal_embedding"] = goal_embedding.tolist()

        utg_func = UTGFunction(
            name=stable_func_id,
            description=enriched_goal
            or goal
            or f"Imported from run_log: {normalized_run_id}",
            parameters={
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
            actions=miss_actions,
            metadata=utg_metadata,
        )

        runtime._utg.functions[stable_func_id] = utg_func
        runtime._rebuild_function_lookup()

        if persist:
            store.save(stored_func)
            # Update asset_refs after storing
            func_dir = store_path / stable_func_id
            if func_dir.exists():
                xml_refs = sorted([f.name for f in func_dir.glob("step_*_xml.xml")])
                screenshot_refs = sorted(
                    [f.name for f in func_dir.glob("step_*_screenshot.png")]
                )
                utg_func.asset_refs = {
                    "xml_refs": xml_refs,
                    "screenshot_refs": screenshot_refs,
                    "function_dir": str(func_dir),
                }

    # =================================================================
    # Step 4: 持久化
    # =================================================================
    if persist and (hit_function_ids or created_function_id):
        await runtime.save()

    # 如果只有 hit_function_ids 但没有 miss_actions，尝试从 hit function 获取 actions
    # 用于支持 replay 场景
    if not created_function_id and hit_function_ids and not persist:
        # persist=False 表示 replay 模式，需要从 hit function 复制 actions
        from src.utg.core.actions import serialize_action_for_storage

        for func_id in hit_function_ids:
            hit_func = runtime.get_function_by_id(func_id)
            if hit_func:
                hit_actions = list(getattr(hit_func, "actions", []) or [])
                if hit_actions:
                    # 为 replay 创建临时 function
                    goal_hash = hashlib.md5(goal.encode()).hexdigest()[:8]
                    temp_func_id = f"func_{goal_hash}_replay"
                    utg_func = UTGFunction(
                        name=temp_func_id,
                        description=goal or f"Replay from {func_id}",
                        parameters={
                            "type": "object",
                            "properties": {},
                            "required": [],
                            "additionalProperties": False,
                        },
                        actions=[
                            serialize_action_for_storage(action)
                            for action in hit_actions
                        ],
                        metadata={
                            "source": "run_log_import_replay",
                            "run_id": normalized_run_id,
                            "import_source_function_id": func_id,
                        },
                    )
                    runtime._utg.functions[temp_func_id] = utg_func
                    runtime._rebuild_function_lookup()
                    created_function_id = temp_func_id
                    break

    # 如果既没有 hit 也没有 created，返回错误
    if not hit_function_ids and not created_function_id:
        # 收集不支持的 tool_call 用于错误消息
        unsupported_tool_calls: list[str] = []
        for step in steps_data:
            if not isinstance(step, dict):
                continue
            tool_call = step.get("tool_call")
            if isinstance(tool_call, dict):
                tool_name = str(tool_call.get("name") or "").strip()
                if tool_name:
                    step_idx = max(0, int(step.get("step_index") or 0))
                    unsupported_tool_calls.append(f"step {step_idx}: {tool_name}")

        if unsupported_tool_calls:
            return {
                "success": False,
                "error_code": "RUN_LOG_REPLAY_ACTIONS_MISSING",
                "error_message": (
                    "Run log contains non-replayable step.tool_call values: "
                    + ", ".join(unsupported_tool_calls[:5])
                ),
                "run_id": normalized_run_id,
                "run_log_path": str(run_log_path),
            }
        else:
            return {
                "success": False,
                "error_code": "RUN_LOG_REPLAY_ACTIONS_MISSING",
                "error_message": (
                    "Run log import requires canonical step.tool_call entries or a "
                    "compile_result.function_id that points to an existing function."
                ),
                "run_id": normalized_run_id,
                "run_log_path": str(run_log_path),
            }

    result: dict[str, Any] = {
        "success": True,
        "run_id": normalized_run_id,
        "goal": goal,
        "run_log_path": str(run_log_path),
        "ingest_scope": dict(ingest_scope),
        "provider": PROVIDER_ID,
        "hit_function_ids": hit_function_ids,
        "created_function_id": created_function_id,
        "miss_action_count": len(miss_actions),
        "import_source_function_id": source_function_id,
        "source_run_ids": source_run_ids if created_function_id else [],
        "is_update": is_update,
    }

    if created_function_id:
        result["enriched_goal"] = enriched_goal
        result["step_count"] = len(miss_actions)
        if is_update:
            result["similarity"] = match_similarity
            result["matched_function_id"] = matched_func_id

    return result


async def is_same_page(
    xml1: str,
    xml2: str,
    *,
    threshold: float = 0.92,
    uncertain_range: tuple[float, float] = (0.85, 0.92),
    use_llm_fallback: bool = False,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> tuple[bool, float, str]:
    """判断两个 XML 是否代表状态机上的同一个节点。

    注意：这里的"同一页面"是状态机意义上的同一个点，需要严格判断。
    即使是同一功能页面，如果状态不同（如列表滚动位置、输入内容），
    也可能需要作为不同节点处理。

    策略:
    1. Hash 精确匹配（内部优化，快速跳过完全相同的）
    2. Vector 相似度判断（主要方法，阈值设置较高 0.92）
    3. LLM fallback（可选，当 vector 分数在不确定区间 0.85-0.92 时）

    Args:
        xml1: 第一个 XML
        xml2: 第二个 XML
        threshold: 相似度阈值 (默认 0.92，严格)
        uncertain_range: 不确定区间 (默认 0.85-0.92)
        use_llm_fallback: 是否启用 LLM fallback
        llm_provider: LLM 提供商
        llm_model: LLM 模型

    Returns:
        (is_same, score, method_used)
    """
    from src.utg.assets.embedding import xml_similarity
    from src.utg.core.models import NodeRepr

    xml1 = str(xml1 or "").strip()
    xml2 = str(xml2 or "").strip()

    if not xml1 or not xml2:
        return False, 0.0, "empty"

    # 1. Hash 精确匹配（内部优化）
    ref1 = NodeRepr.build_xml_ref(xml1)
    ref2 = NodeRepr.build_xml_ref(xml2)
    if ref1 == ref2:
        return True, 1.0, "hash"

    # 2. Vector 相似度
    try:
        score = xml_similarity(xml1, xml2)
    except Exception:
        return False, 0.0, "vector_error"

    # 高于阈值 → 相同
    if score >= threshold:
        return True, score, "vector"

    # 低于不确定区间下限 → 不同
    if score < uncertain_range[0]:
        return False, score, "vector"

    # 在不确定区间内，且启用 LLM fallback
    if use_llm_fallback and uncertain_range[0] <= score < uncertain_range[1]:
        from src.foundation.ai import acomplete_json

        prompt = f"""判断这两个 Android UI 页面是否代表同一个功能页面。

页面 1 (前 1500 字符):
{xml1[:1500]}

页面 2 (前 1500 字符):
{xml2[:1500]}

判断标准:
- 相同功能页面（如都是"登录页"）→ 同一页面
- 内容略有不同（列表项、时间）但功能相同 → 同一页面
- 不同功能（如"登录页"vs"注册页"）→ 不同页面

返回 JSON: {{"is_same": true/false, "confidence": 0.0-1.0, "reason": "简短原因"}}
"""
        try:
            provider = llm_provider or "openai"
            model = llm_model or "gpt-4o-mini"
            result = await acomplete_json(prompt, provider=provider, model=model)
            is_same = bool(result.get("is_same", False))
            confidence = float(result.get("confidence", 0.5))
            return is_same, confidence, "llm"
        except Exception:
            # LLM 失败，用 vector 结果
            return False, score, "vector_llm_failed"

    # 不确定区间内但未启用 LLM → 不同
    return False, score, "vector"


def _load_xml_from_observation(observation: dict[str, Any]) -> str | None:
    """Load XML content from observation, supporting both inline and path-based storage.

    This supports the asset separation architecture where XML can be:
    1. Inline in observation["xml"] (legacy)
    2. Referenced by path in observation["xml_path"] (new)

    Args:
        observation: Step observation dict

    Returns:
        XML content string, or None if not available
    """
    # Priority 1: Inline XML (legacy or already loaded)
    xml = str(observation.get("xml") or "").strip()
    if xml:
        return xml

    # Priority 2: Load from xml_path (new asset separation)
    xml_path = str(observation.get("xml_path") or "").strip()
    if xml_path:
        try:
            from src.foundation.paths import get_runtime_root

            full_path = get_runtime_root() / xml_path
            if full_path.exists():
                return full_path.read_text(encoding="utf-8").strip()
        except Exception:
            pass

    return None


async def enrich_function(
    runtime: UTGRuntime,
    *,
    function_id: str,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    """LLM 补齐 function 的语义信息。

    补齐内容:
    - description: 任务描述
    - slots: 可参数化的变量
    - preconditions: 前置条件
    - postconditions: 后置条件

    Args:
        runtime: Runtime instance that owns the local UTG store.
        function_id: Function id to enrich.
        llm_provider: Optional LLM provider override.
        llm_model: Optional LLM model override.

    Returns:
        Stable JSON payload with enriched function info.
    """
    from src.utg.assets.function_store import FunctionStore
    from src.utg.assets.function_store import enrich_function as _enrich

    normalized_id = str(function_id or "").strip()
    if not normalized_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }

    # 创建 store
    store_path = (
        Path(runtime._filepath).parent / "functions"
        if runtime._filepath
        else Path("runtime/functions")
    )
    store = FunctionStore(store_path)

    if store.load(normalized_id) is None:
        return {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Function not found: {normalized_id}",
            "function_id": normalized_id,
        }

    # 解析 LLM 配置
    resolved_provider = resolve_llm_provider(llm_provider)
    resolved_model = llm_model or (
        default_llm_model(resolved_provider) if resolved_provider else "gpt-4o"
    )

    try:
        func = await _enrich(
            normalized_id,
            store,
            llm_provider=resolved_provider or "openai",
            llm_model=resolved_model,
        )
        return {
            "success": True,
            "function_id": func.id,
            "goal": func.goal,
            "description": func.description,
            "slots": [s.to_dict() for s in func.slots],
            "preconditions": func.preconditions,
            "postconditions": func.postconditions,
            "provider": PROVIDER_ID,
        }
    except Exception as e:
        return {
            "success": False,
            "error_code": "ENRICH_FAILED",
            "error_message": str(e),
            "function_id": normalized_id,
        }


async def split_function(
    runtime: UTGRuntime,
    *,
    function_id: str,
    hint: str | None = None,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    """LLM 语义切分 function。

    将一个长 function 拆分成多个短 function（语义独立单元）。

    Args:
        runtime: Runtime instance that owns the local UTG store.
        function_id: Function id to split.
        hint: Optional hint for splitting strategy.
        llm_provider: Optional LLM provider override.
        llm_model: Optional LLM model override.

    Returns:
        Stable JSON payload with split function info.
    """
    from src.utg.assets.function_store import FunctionStore
    from src.utg.assets.function_store import split_function as _split

    normalized_id = str(function_id or "").strip()
    if not normalized_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }

    # 创建 store
    store_path = (
        Path(runtime._filepath).parent / "functions"
        if runtime._filepath
        else Path("runtime/functions")
    )
    store = FunctionStore(store_path)

    if store.load(normalized_id) is None:
        return {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Function not found: {normalized_id}",
            "function_id": normalized_id,
        }

    # 解析 LLM 配置
    resolved_provider = resolve_llm_provider(llm_provider)
    resolved_model = llm_model or (
        default_llm_model(resolved_provider) if resolved_provider else "gpt-4o"
    )

    try:
        new_functions = await _split(
            normalized_id,
            store,
            hint=hint,
            llm_provider=resolved_provider or "openai",
            llm_model=resolved_model,
        )
        return {
            "success": True,
            "original_function_id": normalized_id,
            "split_count": len(new_functions),
            "new_functions": [
                {
                    "id": f.id,
                    "goal": f.goal,
                    "step_count": len(f.steps),
                }
                for f in new_functions
            ],
            "provider": PROVIDER_ID,
        }
    except Exception as e:
        return {
            "success": False,
            "error_code": "SPLIT_FAILED",
            "error_message": str(e),
            "function_id": normalized_id,
        }


async def decompose_goal_to_key_functions(
    runtime: UTGRuntime,
    *,
    goal: str,
    llm_provider: str | None = None,
    llm_model: str | None = None,
    max_key_functions: int = 5,
) -> dict[str, Any]:
    """Use one LLM call to split a goal into an ordered key-function list.

    Args:
        runtime: Runtime instance that owns the current UTG function pool.
        goal: Natural-language goal from the compile page.
        llm_provider: Optional LLM provider override for decomposition.
        llm_model: Optional model override for decomposition.
        max_key_functions: Upper bound for returned key functions. This is a UI
            control, not a persistence limit.

    Returns:
        Stable JSON payload with one ordered `key_functions` list that can be
        previewed on the compile page before any merge/save step happens.
    """

    from src.foundation.ai import acomplete_json

    normalized_goal = str(goal or "").strip()
    if not normalized_goal:
        return {
            "success": False,
            "error_code": "INVALID_GOAL",
            "error_message": "Goal is required.",
            "provider": PROVIDER_ID,
        }

    normalized_max_key_functions = max(2, min(int(max_key_functions or 5), 8))
    resolved_provider = resolve_llm_provider(llm_provider) or "openai"
    resolved_model = llm_model or default_llm_model(resolved_provider)

    function_examples = []
    try:
        listed_functions = list(list_functions(runtime).get("functions") or [])
        for item in listed_functions[:8]:
            if not isinstance(item, dict):
                continue
            function_id = str(item.get("function_id") or "").strip()
            description = str(item.get("description") or "").strip()
            if function_id:
                function_examples.append(
                    {
                        "function_id": function_id,
                        "description": description,
                    }
                )
    except Exception:
        function_examples = []

    prompt = f"""你是 OmniFlow compile 页的 goal decomposer。

请把一个 Android UI 自动化 goal 拆成按执行顺序排列的 key functions。

要求：
- 只输出最关键、可复用的 function，不要拆得过细。
- 每个 function 都要是一个短而稳定的能力单元。
- 总数不超过 {normalized_max_key_functions} 个。
- function_id 用 snake_case，偏动作语义，例如 open_alipay / open_yuebao。
- title 用简短中文。
- description 写清这个 function 完成什么，不要写实现细节。
- goal 字段写该子目标的自然语言版本。
- 若原目标本身只需要 1-2 个 function，就不要强行凑数。
- 只返回 JSON，不要返回 markdown。

当前目标：
{normalized_goal}

当前 provider 里已有的一些 function 样例（仅供命名风格参考，不要求必须复用）：
{json.dumps(function_examples, ensure_ascii=False)}

返回 JSON:
{{
  "key_functions": [
    {{
      "function_id": "open_alipay",
      "title": "打开支付宝",
      "description": "从当前环境进入支付宝首页",
      "goal": "打开支付宝应用"
    }}
  ]
}}
"""

    try:
        result = await acomplete_json(
            prompt,
            provider=resolved_provider,
            model=resolved_model,
        )
    except Exception as exc:
        return {
            "success": False,
            "error_code": "DECOMPOSE_FAILED",
            "error_message": str(exc),
            "goal": normalized_goal,
            "llm_provider": resolved_provider,
            "llm_model": resolved_model,
            "provider": PROVIDER_ID,
        }

    raw_items = list(result.get("key_functions") or result.get("functions") or [])
    key_functions: list[dict[str, Any]] = []
    for index, item in enumerate(raw_items[:normalized_max_key_functions], start=1):
        if not isinstance(item, dict):
            continue
        raw_function_id = str(item.get("function_id") or "").strip().lower()
        normalized_function_id = "".join(
            ch if (ch.isalnum() or ch == "_") else "_"
            for ch in raw_function_id.replace("-", "_").replace(" ", "_")
        ).strip("_")
        while "__" in normalized_function_id:
            normalized_function_id = normalized_function_id.replace("__", "_")
        if not normalized_function_id:
            normalized_function_id = f"key_function_{index:02d}"
        title = str(item.get("title") or item.get("name") or "").strip()
        description = str(item.get("description") or "").strip()
        child_goal = str(item.get("goal") or title or description or "").strip()
        key_functions.append(
            {
                "index": index,
                "function_id": normalized_function_id,
                "title": title or f"Key Function {index}",
                "description": description or child_goal or normalized_function_id,
                "goal": child_goal or title or normalized_function_id,
            }
        )

    if not key_functions:
        return {
            "success": False,
            "error_code": "DECOMPOSE_EMPTY",
            "error_message": "LLM did not return any key functions.",
            "goal": normalized_goal,
            "raw_response": result,
            "llm_provider": resolved_provider,
            "llm_model": resolved_model,
            "provider": PROVIDER_ID,
        }

    return {
        "success": True,
        "goal": normalized_goal,
        "key_functions": key_functions,
        "count": len(key_functions),
        "llm_provider": resolved_provider,
        "llm_model": resolved_model,
        "provider": PROVIDER_ID,
    }


# =============================================================================
# Memory / RAG API
# =============================================================================


async def enrich_node(
    runtime: UTGRuntime,
    *,
    node_id: str,
    screenshot_base64: str | None = None,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    """LLM/VLM 增强单个 Node 的语义信息。

    增强内容:
    - description: 页面描述
    - visual_elements: 页面关键元素
    - visual_summary: 视觉摘要

    Args:
        runtime: Runtime instance that owns the local UTG store.
        node_id: Node id to enrich.
        screenshot_base64: Optional screenshot for VLM analysis.
        llm_provider: Optional LLM provider override.
        llm_model: Optional LLM model override.

    Returns:
        Stable JSON payload with enriched node info.
    """
    from src.utg.assets.memory_enricher import enrich_node_async
    from src.utg.assets.memory_export import export_utg_memory

    normalized_id = str(node_id or "").strip()
    if not normalized_id:
        return {
            "success": False,
            "error_code": "INVALID_NODE_ID",
            "error_message": "Node id is required.",
        }

    # 检查 node 是否存在
    node = runtime.get_node_by_id(normalized_id)
    if node is None:
        return {
            "success": False,
            "error_code": "NODE_NOT_FOUND",
            "error_message": f"Node not found: {normalized_id}",
            "node_id": normalized_id,
        }

    # 导出为 NodeMemory 格式
    bundle = export_utg_memory(runtime._utg, include_xml=True)
    node_memory = next((n for n in bundle.nodes if n.id == normalized_id), None)

    if node_memory is None:
        return {
            "success": False,
            "error_code": "NODE_EXPORT_FAILED",
            "error_message": f"Failed to export node: {normalized_id}",
            "node_id": normalized_id,
        }

    # 解析 LLM 配置
    resolved_provider = resolve_llm_provider(llm_provider) or "openai"
    resolved_model = llm_model or default_llm_model(resolved_provider)

    try:
        enriched = await enrich_node_async(
            node_memory,
            screenshot_base64=screenshot_base64,
            llm_provider=resolved_provider,
            llm_model=resolved_model,
        )
        return {
            "success": True,
            "node_id": enriched.id,
            "package": enriched.package,
            "activity": enriched.activity,
            "description": enriched.description,
            "visual_summary": enriched.visual_summary,
            "visual_elements": enriched.visual_elements,
            "available_functions": list(enriched.available_functions),
            "can_reach": enriched.can_reach,
            "signatures": enriched.signatures,
            "provider": PROVIDER_ID,
            "llm_provider": resolved_provider,
            "llm_model": resolved_model,
            "used_vision": bool(screenshot_base64),
        }
    except Exception as e:
        return {
            "success": False,
            "error_code": "ENRICH_FAILED",
            "error_message": str(e),
            "node_id": normalized_id,
        }


def export_node_memory(
    runtime: UTGRuntime,
    *,
    node_id: str,
) -> dict[str, Any]:
    """导出单个 Node 的 RAG Memory 上下文。

    返回 node 的完整上下文，包括:
    - node 信息（description, visual_elements 等）
    - 可用的 functions
    - 图位置（can_reach, reachable_from）

    Args:
        runtime: Runtime instance that owns the local UTG store.
        node_id: Node id to export.

    Returns:
        Stable JSON payload with node memory context.
    """
    from src.utg.assets.memory_export import export_node_context

    normalized_id = str(node_id or "").strip()
    if not normalized_id:
        return {
            "success": False,
            "error_code": "INVALID_NODE_ID",
            "error_message": "Node id is required.",
        }

    # 检查 node 是否存在
    node = runtime.get_node_by_id(normalized_id)
    if node is None:
        return {
            "success": False,
            "error_code": "NODE_NOT_FOUND",
            "error_message": f"Node not found: {normalized_id}",
            "node_id": normalized_id,
        }

    context = export_node_context(runtime._utg, normalized_id)
    if context is None:
        return {
            "success": False,
            "error_code": "NODE_EXPORT_FAILED",
            "error_message": f"Failed to export node context: {normalized_id}",
            "node_id": normalized_id,
        }

    return {
        "success": True,
        "node_id": normalized_id,
        **context,
        "provider": PROVIDER_ID,
    }


async def export_memory_bundle(
    runtime: UTGRuntime,
    *,
    include_xml: bool = True,
    enrich: bool = False,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    """导出完整的 UTG Memory Bundle。

    可选择是否使用 LLM 增强。

    Args:
        runtime: Runtime instance that owns the local UTG store.
        include_xml: 是否包含 XML 样本.
        enrich: 是否使用 LLM 增强.
        llm_provider: Optional LLM provider override.
        llm_model: Optional LLM model override.

    Returns:
        Stable JSON payload with memory bundle.
    """
    from src.utg.assets.memory_enricher import (
        enrich_bundle_async,
        enrich_bundle_without_llm,
    )
    from src.utg.assets.memory_export import export_utg_memory

    try:
        bundle = export_utg_memory(runtime._utg, include_xml=include_xml)

        if enrich:
            resolved_provider = resolve_llm_provider(llm_provider) or "openai"
            resolved_model = llm_model or default_llm_model(resolved_provider)

            bundle = await enrich_bundle_async(
                bundle,
                llm_provider=resolved_provider,
                llm_model=resolved_model,
            )
        else:
            # 无 LLM 的规则增强
            bundle = enrich_bundle_without_llm(bundle)

        return {
            "success": True,
            "version": bundle.version,
            "node_count": len(bundle.nodes),
            "function_count": len(bundle.functions),
            "nodes": [n.model_dump() for n in bundle.nodes],
            "functions": [func.model_dump() for func in bundle.functions],
            "graph": bundle.graph.model_dump(),
            "metadata": bundle.metadata,
            "provider": PROVIDER_ID,
        }
    except Exception as e:
        return {
            "success": False,
            "error_code": "EXPORT_FAILED",
            "error_message": str(e),
        }


async def export_memory_to_dir(
    runtime: UTGRuntime,
    *,
    output_dir: str | None = None,
    include_xml: bool = True,
    enrich: bool = False,
    llm_provider: str | None = None,
    llm_model: str | None = None,
) -> dict[str, Any]:
    """导出 Memory Bundle 到目录。

    目录结构:
    ```
    output_dir/
    ├── memory.json        # 完整 bundle
    ├── nodes/
    │   ├── node_1.json
    │   └── node_2.json
    ├── functions/
    │   ├── function_1.json
    │   └── function_2.json
    └── graph.json         # 图结构
    ```

    Args:
        runtime: Runtime instance that owns the local UTG store.
        output_dir: 输出目录，默认为 runtime/memory/<utg_name>
        include_xml: 是否包含 XML 样本.
        enrich: 是否使用 LLM 增强.
        llm_provider: Optional LLM provider override.
        llm_model: Optional LLM model override.

    Returns:
        Stable JSON payload with export paths.
    """
    from src.utg.assets.memory_enricher import (
        enrich_bundle_async,
        enrich_bundle_without_llm,
    )
    from src.utg.assets.memory_export import export_utg_memory

    try:
        # 确定输出目录
        if output_dir:
            out_path = Path(output_dir).expanduser().resolve()
        else:
            utg_name = Path(runtime._filepath).stem if runtime._filepath else "utg"
            out_path = Path(get_runtime_file("memory", utg_name))

        out_path.mkdir(parents=True, exist_ok=True)

        # 导出 bundle
        bundle = export_utg_memory(runtime._utg, include_xml=include_xml)

        if enrich:
            resolved_provider = resolve_llm_provider(llm_provider) or "openai"
            resolved_model = llm_model or default_llm_model(resolved_provider)
            bundle = await enrich_bundle_async(
                bundle,
                llm_provider=resolved_provider,
                llm_model=resolved_model,
            )
        else:
            bundle = enrich_bundle_without_llm(bundle)

        # 写入主文件
        memory_path = out_path / "memory.json"
        memory_path.write_text(bundle.model_dump_json(indent=2), encoding="utf-8")

        # 写入 nodes
        nodes_dir = out_path / "nodes"
        nodes_dir.mkdir(exist_ok=True)
        for node in bundle.nodes:
            safe_id = node.id.replace("/", "_").replace(":", "_")
            (nodes_dir / f"{safe_id}.json").write_text(
                node.model_dump_json(indent=2), encoding="utf-8"
            )

        # 写入 functions
        functions_dir = out_path / "functions"
        functions_dir.mkdir(exist_ok=True)
        for function in bundle.functions:
            safe_id = function.id.replace("/", "_").replace(":", "_")
            (functions_dir / f"{safe_id}.json").write_text(
                function.model_dump_json(indent=2), encoding="utf-8"
            )

        # 写入 graph
        graph_path = out_path / "graph.json"
        graph_path.write_text(bundle.graph.model_dump_json(indent=2), encoding="utf-8")

        return {
            "success": True,
            "output_dir": str(out_path),
            "memory_path": str(memory_path),
            "nodes_dir": str(nodes_dir),
            "functions_dir": str(functions_dir),
            "graph_path": str(graph_path),
            "node_count": len(bundle.nodes),
            "function_count": len(bundle.functions),
            "enriched": enrich,
            "provider": PROVIDER_ID,
        }
    except Exception as e:
        return {
            "success": False,
            "error_code": "EXPORT_TO_DIR_FAILED",
            "error_message": str(e),
        }


async def export_rag_memory(
    runtime: UTGRuntime,
    *,
    output_dir: str | None = None,
    output_format: str = "all",
    enrich: bool = True,
    llm_provider: str | None = None,
    llm_model: str | None = None,
    create_embeddings: bool = False,
    embedding_provider: str | None = None,
    include_nodes: bool = True,
    include_functions: bool = True,
    include_apps: bool = True,
    include_graph: bool = True,
) -> dict[str, Any]:
    """一键导出 UTG 为 Agent 可用的 RAG Memory。

    完整流程：
    1. 导出 UTG 为 Memory Bundle
    2. 使用 LLM 增强语义描述（可选）
    3. 转换为自然语言文档（RAG 友好）
    4. 生成向量嵌入（可选）

    输出格式:
    - json: 结构化 JSON（nodes.json, functions.json, apps.json）
    - markdown: Markdown 文档（便于人阅读）
    - documents: RAG 文档格式（id, type, content, metadata）
    - all: 全部格式

    Args:
        runtime: UTGRuntime 实例
        output_dir: 输出目录，默认为 runtime/rag_memory/<utg_name>
        output_format: 输出格式
        enrich: 是否使用 LLM 增强描述
        llm_provider: LLM 提供商
        llm_model: LLM 模型
        create_embeddings: 是否生成向量嵌入
        embedding_provider: 嵌入模型提供商
        include_nodes: 包含 Node 文档
        include_functions: 包含 Function 文档
        include_apps: 包含 App 文档
        include_graph: 包含 Graph 结构

    Returns:
        {
            "success": True,
            "output_dir": "/path/to/output",
            "documents": [...],  # RAG 文档列表
            "stats": {
                "app_count": 3,
                "node_count": 15,
                "function_count": 42,
                "document_count": 60,
            },
            "embeddings_path": "/path/to/embeddings.json",  # 如果生成了嵌入
        }
    """
    import json as json_lib

    from src.utg.assets.memory_enricher import (
        enrich_bundle_async,
        enrich_bundle_without_llm,
    )
    from src.utg.assets.memory_export import (
        app_to_natural_language,
        export_memory_as_documents,
        export_utg_memory,
        function_to_natural_language,
        node_to_natural_language,
    )

    try:
        # 1. 确定输出目录
        if output_dir:
            out_path = Path(output_dir).expanduser().resolve()
        else:
            utg_name = Path(runtime._filepath).stem if runtime._filepath else "utg"
            out_path = Path(get_runtime_file("rag_memory", utg_name))

        out_path.mkdir(parents=True, exist_ok=True)

        # 2. 导出 Memory Bundle
        bundle = export_utg_memory(runtime._utg, include_xml=True)

        # 3. LLM 增强（可选）
        if enrich:
            resolved_provider = resolve_llm_provider(llm_provider) or "openai"
            resolved_model = llm_model or default_llm_model(resolved_provider)
            bundle = await enrich_bundle_async(
                bundle,
                llm_provider=resolved_provider,
                llm_model=resolved_model,
            )
        else:
            bundle = enrich_bundle_without_llm(bundle)

        # 4. 转换为 RAG 文档
        all_documents = export_memory_as_documents(runtime._utg)

        # 过滤文档
        documents = []
        for doc in all_documents:
            if doc["type"] == "app" and include_apps:
                documents.append(doc)
            elif doc["type"] == "node" and include_nodes:
                documents.append(doc)
            elif doc["type"] == "function" and include_functions:
                documents.append(doc)

        # 5. 输出不同格式
        output_files = {}

        if output_format in ("json", "all"):
            # 结构化 JSON
            json_dir = out_path / "json"
            json_dir.mkdir(exist_ok=True)

            if include_apps:
                apps_json = [app.model_dump() for app in bundle.apps]
                (json_dir / "apps.json").write_text(
                    json_lib.dumps(apps_json, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                output_files["apps_json"] = str(json_dir / "apps.json")

            if include_nodes:
                nodes_json = [node.model_dump() for node in bundle.nodes]
                (json_dir / "nodes.json").write_text(
                    json_lib.dumps(nodes_json, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                output_files["nodes_json"] = str(json_dir / "nodes.json")

            if include_functions:
                functions_json = [func.model_dump() for func in bundle.functions]
                (json_dir / "functions.json").write_text(
                    json_lib.dumps(functions_json, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                output_files["functions_json"] = str(json_dir / "functions.json")

            if include_graph:
                (json_dir / "graph.json").write_text(
                    bundle.graph.model_dump_json(indent=2),
                    encoding="utf-8",
                )
                output_files["graph_json"] = str(json_dir / "graph.json")

        if output_format in ("markdown", "all"):
            # Markdown 文档
            md_dir = out_path / "markdown"
            md_dir.mkdir(exist_ok=True)

            if include_apps:
                apps_md_dir = md_dir / "apps"
                apps_md_dir.mkdir(exist_ok=True)
                for app in bundle.apps:
                    safe_pkg = app.package.replace(".", "_")
                    content = app_to_natural_language(app)
                    (apps_md_dir / f"{safe_pkg}.md").write_text(
                        content, encoding="utf-8"
                    )
                output_files["apps_markdown"] = str(apps_md_dir)

            if include_nodes:
                nodes_md_dir = md_dir / "nodes"
                nodes_md_dir.mkdir(exist_ok=True)
                for node in bundle.nodes:
                    safe_id = node.id.replace("/", "_").replace(":", "_")
                    content = node_to_natural_language(node)
                    (nodes_md_dir / f"{safe_id}.md").write_text(
                        content, encoding="utf-8"
                    )
                output_files["nodes_markdown"] = str(nodes_md_dir)

            if include_functions:
                functions_md_dir = md_dir / "functions"
                functions_md_dir.mkdir(exist_ok=True)
                pkg_to_name = {app.package: app.name for app in bundle.apps}
                for func in bundle.functions:
                    safe_id = func.id.replace("/", "_").replace(":", "_")
                    source_node = next(
                        (n for n in bundle.nodes if n.id == func.source_node_id), None
                    )
                    app_name = (
                        pkg_to_name.get(source_node.package, "") if source_node else ""
                    )
                    content = function_to_natural_language(func, app_name)
                    (functions_md_dir / f"{safe_id}.md").write_text(
                        content, encoding="utf-8"
                    )
                output_files["functions_markdown"] = str(functions_md_dir)

        if output_format in ("documents", "all"):
            # RAG 文档格式（用于向量化）
            docs_path = out_path / "documents.json"
            (docs_path).write_text(
                json_lib.dumps(documents, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            output_files["documents"] = str(docs_path)

        # 6. 生成向量嵌入（可选）
        embeddings_path = None
        if create_embeddings and documents:
            embeddings_path = out_path / "embeddings.json"
            embeddings = []

            # TODO: 实现实际的嵌入生成
            # resolved_emb_provider = embedding_provider or resolve_llm_provider(llm_provider) or "openai"
            # 这里只生成元数据，实际嵌入需要调用嵌入 API
            for doc in documents:
                embeddings.append(
                    {
                        "id": doc["id"],
                        "type": doc["type"],
                        "content_length": len(doc["content"]),
                        "metadata": doc["metadata"],
                        # "embedding": [...]  # 实际嵌入向量
                    }
                )

            (embeddings_path).write_text(
                json_lib.dumps(embeddings, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            output_files["embeddings"] = str(embeddings_path)

        # 7. 写入元信息
        meta_info = {
            "version": "1.0.0",
            "utg_name": Path(runtime._filepath).stem
            if runtime._filepath
            else "unknown",
            "enriched": enrich,
            "llm_provider": llm_provider,
            "llm_model": llm_model,
            "stats": {
                "app_count": len(bundle.apps),
                "node_count": len(bundle.nodes),
                "function_count": len(bundle.functions),
                "document_count": len(documents),
            },
            "output_files": output_files,
        }
        (out_path / "meta.json").write_text(
            json_lib.dumps(meta_info, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        return {
            "success": True,
            "output_dir": str(out_path),
            "documents": documents,
            "stats": meta_info["stats"],
            "embeddings_path": str(embeddings_path) if embeddings_path else None,
            "output_files": output_files,
            "provider": PROVIDER_ID,
        }

    except Exception as e:
        import traceback

        traceback.print_exc()
        return {
            "success": False,
            "error_code": "EXPORT_RAG_MEMORY_FAILED",
            "error_message": str(e),
        }


async def delete_function(runtime: UTGRuntime, function_id: str) -> dict[str, Any]:
    """Delete one global function from the current UTG store and persist the change.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.
        function_id: Function identifier to remove from the local store.

    Returns:
        Stable JSON payload describing whether the function was deleted.
    """

    normalized_func_id = str(function_id or "").strip()
    if not normalized_func_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }
    if runtime.get_function_by_id(normalized_func_id) is None:
        return {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Function not found: {normalized_func_id}",
            "function_id": normalized_func_id,
        }
    # Delete from functions dict
    if normalized_func_id in runtime._utg.functions:
        del runtime._utg.functions[normalized_func_id]
    await runtime.save()
    runtime.refresh_after_mutation()
    return {
        "success": True,
        "deleted": True,
        "function_id": normalized_func_id,
        "count": len(runtime._utg.functions),
        "provider": PROVIDER_ID,
    }


async def update_function(
    runtime: UTGRuntime,
    function_id: str,
    *,
    description: str | None = None,
    goal: str | None = None,
    preconditions: list[str] | None = None,
    postconditions: list[str] | None = None,
    enriched_goal: str | None = None,
) -> dict[str, Any]:
    """Update one global function's metadata in the current UTG store.

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.
        function_id: Function identifier to update.
        description: New description for the function.
        goal: New goal for the function.
        preconditions: New preconditions list.
        postconditions: New postconditions list.
        enriched_goal: New enriched goal (LLM normalized).

    Returns:
        Stable JSON payload with updated function details.
    """

    normalized_func_id = str(function_id or "").strip()
    if not normalized_func_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }
    func = runtime.get_function_by_id(normalized_func_id)
    if func is None:
        return {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Function not found: {normalized_func_id}",
            "function_id": normalized_func_id,
        }

    updated_fields: list[str] = []

    def _set_field(field_name: str, value: Any) -> None:
        """Helper to set field on func (object or dict)."""
        if hasattr(func, field_name):
            setattr(func, field_name, value)
            updated_fields.append(field_name)
        elif isinstance(func, dict):
            func[field_name] = value
            updated_fields.append(field_name)

    # Update fields if provided
    if description is not None:
        _set_field("description", str(description).strip())

    if goal is not None:
        _set_field("goal", str(goal).strip())

    if preconditions is not None:
        _set_field("preconditions", [str(p).strip() for p in preconditions])

    if postconditions is not None:
        _set_field("postconditions", [str(p).strip() for p in postconditions])

    if enriched_goal is not None:
        _set_field("enriched_goal", str(enriched_goal).strip())

    if not updated_fields:
        return {
            "success": False,
            "error_code": "NO_FIELDS_TO_UPDATE",
            "error_message": "No valid fields provided for update.",
            "function_id": normalized_func_id,
        }

    await runtime.save()
    runtime.refresh_after_mutation()

    # Build function summary for response
    func_summary = _summarize_function(runtime, func)

    return {
        "success": True,
        "function_id": normalized_func_id,
        "function": func_summary,
        "updated_fields": updated_fields,
        "provider": PROVIDER_ID,
    }


async def reset_all_data(runtime: UTGRuntime) -> dict[str, Any]:
    """清空所有数据：run_logs + functions + shared_pages。

    Args:
        runtime: Runtime instance that owns the in-memory UTG graph.

    Returns:
        Stable JSON payload describing what was cleared.
    """
    import shutil

    deleted_counts = {
        "functions": 0,
        "nodes": 0,
        "run_logs": 0,
        "shared_pages": 0,
    }

    # 1. Clear functions
    deleted_counts["functions"] = len(runtime._utg.functions)
    runtime._utg.functions.clear()

    # 2. Clear nodes
    deleted_counts["nodes"] = len(runtime._utg.nodes)
    runtime._utg.nodes.clear()

    # 3. Clear run_logs file
    run_log_path = Path(_canonical_run_log_path())
    if run_log_path.exists():
        # Count lines before clearing
        with run_log_path.open("r", encoding="utf-8") as f:
            deleted_counts["run_logs"] = sum(1 for _ in f)
        run_log_path.write_text("", encoding="utf-8")

    # 4. Clear function store directory
    store_path = (
        Path(runtime._filepath).parent / "functions"
        if runtime._filepath
        else Path("runtime/functions")
    )
    if store_path.exists() and store_path.is_dir():
        shutil.rmtree(store_path)
        store_path.mkdir(parents=True, exist_ok=True)

    # 5. Clear shared pages
    shared_pages_path = _shared_vector_store_dir()
    if shared_pages_path.exists() and shared_pages_path.is_dir():
        deleted_counts["shared_pages"] = len(list(shared_pages_path.glob("*.json")))
        shutil.rmtree(shared_pages_path)
        shared_pages_path.mkdir(parents=True, exist_ok=True)

    # Save and refresh
    await runtime.save()
    runtime.refresh_after_mutation()

    return {
        "success": True,
        "deleted": deleted_counts,
        "provider": PROVIDER_ID,
    }


def _normalize_merge_mode(raw_mode: str) -> str:
    """Normalize one desktop merge mode into the supported canonical values."""

    normalized_mode = str(raw_mode or "").strip().lower()
    return normalized_mode if normalized_mode in {"compose", "aggregate"} else ""


def _normalize_function_candidate_id(raw_id: str) -> str:
    """Normalize one output function id for preview/save requests."""

    return _normalize_shared_page_id(raw_id).replace(".", "_")


def _load_selected_functions(
    runtime: UTGRuntime,
    *,
    function_ids: list[str],
    function_order: list[str] | None = None,
) -> tuple[list[Function], dict[str, Any] | None]:
    """Load selected UTG functions in explicit editor order.

    Args:
        runtime: Runtime that owns the in-memory UTG graph.
        function_ids: Selected function ids from the desktop editor.
        function_order: Optional explicit order for compose preview/save.

    Returns:
        `(functions, error_payload)` where `error_payload` is `None` on success.
    """

    normalized_ids = [
        str(item or "").strip()
        for item in list(function_ids or [])
        if str(item or "").strip()
    ]
    if len(normalized_ids) < 2:
        return [], {
            "success": False,
            "error_code": "FUNCTION_SELECTION_TOO_SMALL",
            "error_message": "Select at least two functions for merge.",
            "function_ids": normalized_ids,
        }
    dedup_ids = list(dict.fromkeys(normalized_ids))
    functions_by_id: dict[str, Function] = {}
    missing_ids: list[str] = []
    for function_id in dedup_ids:
        func = runtime.get_function_by_id(function_id)
        if isinstance(func, Function):
            functions_by_id[function_id] = func
        else:
            missing_ids.append(function_id)
    if missing_ids:
        return [], {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Functions not found: {', '.join(missing_ids)}",
            "function_ids": dedup_ids,
            "missing_function_ids": missing_ids,
        }
    explicit_order = [
        str(item or "").strip()
        for item in list(function_order or [])
        if str(item or "").strip() in functions_by_id
    ]
    ordered_ids = explicit_order + [
        function_id for function_id in dedup_ids if function_id not in explicit_order
    ]
    return [functions_by_id[function_id] for function_id in ordered_ids], None


def _collect_bundle_nodes_for_function(
    runtime: UTGRuntime, func: Function
) -> list[UTGNode]:
    """Collect node objects needed to serialize one function bundle."""

    bundle_functions = _collect_bundle_functions(runtime, func)
    node_ids: set[str] = set()
    for current_func in bundle_functions.values():
        if str(current_func.start_node_id or "").strip():
            node_ids.add(str(current_func.start_node_id))
        if str(current_func.end_node_id or "").strip():
            node_ids.add(str(current_func.end_node_id))
        for action in list(getattr(current_func, "actions", []) or []):
            payload = canonical_action_payload(action)
            if str(payload.get("type") or "").strip() != "call_function":
                continue
            params = dict(payload.get("params") or {})
            node_id = str(params.get("node_id") or "").strip()
            if node_id:
                node_ids.add(node_id)
    return [
        node
        for node in list(getattr(runtime._utg, "nodes", []) or [])
        if str(getattr(node, "id", "") or "").strip() in node_ids
    ]


def _build_function_bundle_graph(runtime: UTGRuntime, func: Function) -> UTGGraph:
    """Build one root-function bundle graph plus its global child dependencies."""

    bundle_functions = _collect_bundle_functions(runtime, func)
    nodes = _collect_bundle_nodes_for_function(runtime, func)
    package_names = {
        str(getattr(getattr(node, "repr", None), "packageName", "") or "").strip()
        for node in nodes
        if str(getattr(getattr(node, "repr", None), "packageName", "") or "").strip()
    }
    app_info = [
        app
        for app in list(getattr(runtime._utg, "appInfo", []) or [])
        if str(getattr(app, "packageName", "") or "").strip() in package_names
    ]
    return UTGGraph(
        version=str(getattr(runtime._utg, "version", "1.0.0") or "1.0.0"),
        actionSchemaVersion=str(
            getattr(runtime._utg, "actionSchemaVersion", "1.0.0") or "1.0.0"
        ),
        appInfo=app_info,
        nodes=nodes,
        functions=bundle_functions,
        triggers=[],
    )


def _infer_json_schema_type(values: list[Any]) -> str:
    """Infer a compact JSON Schema type from promoted aggregate slot values."""

    filtered = [item for item in values if item is not None]
    if filtered and all(isinstance(item, bool) for item in filtered):
        return "boolean"
    if filtered and all(
        isinstance(item, int) and not isinstance(item, bool) for item in filtered
    ):
        return "integer"
    if filtered and all(
        isinstance(item, (int, float)) and not isinstance(item, bool)
        for item in filtered
    ):
        return "number"
    return "string"


def _build_compose_merged_function(
    runtime: UTGRuntime,
    *,
    functions: list[Function],
    output_function_id: str,
    description: str | None = None,
) -> tuple[Function, list[dict[str, Any]]]:
    """Compose selected functions and shortest-path bridge gaps between them.

    Args:
        runtime: Runtime used to resolve node-to-node shortest bridge paths.
        functions: User-selected key functions in desired execution order.
        output_function_id: Identifier for the synthesized merged function.
        description: Optional human override for the new function description.

    Returns:
        Tuple of `(merged_function, bridge_segments)`. `bridge_segments`
        records every inserted shortest-path bridge between two selected
        functions so the editor can inspect how the final sequence was built.
    """

    properties: dict[str, Any] = {}
    required: list[str] = []
    composed_actions: list[Any] = []
    selected_function_ids = [func.name for func in functions]
    bridge_function_ids: list[str] = []
    bridge_segments: list[dict[str, Any]] = []
    ordered_functions: list[Function] = []

    for index, func in enumerate(functions):
        if index > 0:
            previous = functions[index - 1]
            previous_end = str(previous.end_node_id or "").strip()
            current_start = str(func.start_node_id or "").strip()
            if previous_end and current_start and previous_end != current_start:
                route_payload = shortest_path_between_nodes(
                    runtime,
                    start_node_id=previous_end,
                    end_node_id=current_start,
                )
                if route_payload.get("success") is not True:
                    raise ValueError(
                        "Compose merge could not bridge "
                        f"{previous.name} ({previous_end}) -> {func.name} ({current_start}) "
                        "with current shortest-path graph."
                    )
                route_edges = list(route_payload.get("edges") or [])
                route_function_ids = [
                    str(edge.get("function_id") or "").strip()
                    for edge in route_edges
                    if str(edge.get("function_id") or "").strip()
                ]
                if not route_function_ids:
                    raise ValueError(
                        "Compose merge found an empty bridge route for "
                        f"{previous.name} -> {func.name}."
                    )
                resolved_bridge_functions: list[Function] = []
                for route_function_id in route_function_ids:
                    bridge_func = runtime.get_function_by_id(route_function_id)
                    if bridge_func is None:
                        raise ValueError(
                            f"Compose merge bridge function not found locally: {route_function_id}"
                        )
                    resolved_bridge_functions.append(bridge_func)
                    bridge_function_ids.append(route_function_id)
                ordered_functions.extend(resolved_bridge_functions)
                bridge_segments.append(
                    {
                        "from_function_id": previous.name,
                        "to_function_id": func.name,
                        "from_node_id": previous_end,
                        "to_node_id": current_start,
                        "shortest_hops": int(route_payload.get("shortest_hops") or 0),
                        "bridge_function_ids": route_function_ids,
                        "node_path": list(route_payload.get("node_path") or []),
                    }
                )
            elif previous_end != current_start:
                raise ValueError(
                    "Compose merge requires both end/start nodes to bridge gaps; "
                    f"got {previous.name} ({previous_end or 'missing'}) -> "
                    f"{func.name} ({current_start or 'missing'})."
                )
        ordered_functions.append(func)

    child_function_ids = [func.name for func in ordered_functions]
    for func in ordered_functions:
        child_start_node_id = str(func.start_node_id or "").strip()
        if not child_start_node_id:
            raise ValueError(
                f"Compose merge requires child function '{func.name}' to declare start_node_id."
            )
        for parameter_name in list(func.get_parameter_names() or []):
            if parameter_name not in properties:
                properties[parameter_name] = dict(
                    (func.parameters.get("properties") or {}).get(parameter_name)
                    or {"type": "string"}
                )
            if (
                parameter_name in list(func.parameters.get("required") or [])
                and parameter_name not in required
            ):
                required.append(parameter_name)
        composed_actions.append(
            CallFunctionAction(
                type="call_function",
                params=CallFunctionParams(
                    node_id=child_start_node_id,
                    function_name=func.name,
                    arguments={
                        parameter_name: f"${{{parameter_name}}}"
                        for parameter_name in list(func.get_parameter_names() or [])
                        if parameter_name in properties
                    },
                ),
                description=str(func.description or "").strip() or None,
            )
        )
    description_text = str(description or "").strip() or " then ".join(
        str(func.description or func.name or "").strip() or func.name
        for func in functions
    )
    return (
        Function(
            name=output_function_id,
            description=description_text,
            parameters={
                "type": "object",
                "properties": properties,
                "required": required,
                "additionalProperties": False,
            },
            actions=composed_actions,
            start_node_id=str(functions[0].start_node_id or "").strip() or None,
            end_node_id=str(functions[-1].end_node_id or "").strip() or None,
            metadata={
                "function_type": "composite",
                "entry_point": True,
                "merge_mode": "compose",
                "selected_function_ids": selected_function_ids,
                "child_function_ids": child_function_ids,
                "bridge_function_ids": bridge_function_ids,
                "bridge_segments": bridge_segments,
                "aggregated_from": selected_function_ids,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
        ),
        bridge_segments,
    )


def _build_aggregate_merged_function(
    *,
    functions: list[Function],
    output_function_id: str,
    description: str | None = None,
) -> Function:
    """Aggregate same-skeleton functions into one parameterized function."""

    first = functions[0]
    if any(
        str(func.start_node_id or "").strip() != str(first.start_node_id or "").strip()
        for func in functions
    ):
        raise ValueError(
            "Aggregate merge requires the same start_node_id across selected functions."
        )
    if any(
        str(func.end_node_id or "").strip() != str(first.end_node_id or "").strip()
        for func in functions
    ):
        raise ValueError(
            "Aggregate merge requires the same end_node_id across selected functions."
        )
    payload_matrix = [
        [
            canonical_action_payload(action)
            for action in list(getattr(func, "actions", []) or [])
        ]
        for func in functions
    ]
    action_count = len(payload_matrix[0])
    if any(len(row) != action_count for row in payload_matrix):
        raise ValueError(
            "Aggregate merge requires the same action count across selected functions."
        )

    properties: dict[str, Any] = {}
    required: list[str] = []
    merged_actions: list[Any] = []
    promoted_slots: list[str] = []
    for action_index in range(action_count):
        action_payloads = [row[action_index] for row in payload_matrix]
        action_type = str(action_payloads[0].get("type") or "").strip()
        if any(
            str(item.get("type") or "").strip() != action_type
            for item in action_payloads
        ):
            raise ValueError("Aggregate merge requires the same action type skeleton.")
        param_key_set = tuple(
            sorted(dict(action_payloads[0].get("params") or {}).keys())
        )
        if any(
            tuple(sorted(dict(item.get("params") or {}).keys())) != param_key_set
            for item in action_payloads
        ):
            raise ValueError(
                "Aggregate merge requires identical action parameter keys."
            )
        merged_payload = {
            "type": action_type,
            "params": {},
        }
        if str(action_payloads[0].get("description") or "").strip():
            merged_payload["description"] = str(
                action_payloads[0].get("description") or ""
            ).strip()
        for param_key in param_key_set:
            values = [
                dict(item.get("params") or {}).get(param_key)
                for item in action_payloads
            ]
            first_value = values[0]
            if all(value == first_value for value in values):
                merged_payload["params"][param_key] = first_value
                continue
            if any(isinstance(value, (dict, list, tuple)) for value in values):
                raise ValueError(
                    f"Aggregate merge only supports scalar parameter promotion; unsupported param '{param_key}' at action {action_index}."
                )
            slot_name = f"{param_key}_{action_index + 1}"
            while slot_name in properties:
                slot_name = f"{slot_name}_v"
            merged_payload["params"][param_key] = f"${{{slot_name}}}"
            properties[slot_name] = {
                "type": _infer_json_schema_type(values),
                "description": f"Promoted from action {action_index + 1} parameter '{param_key}'.",
            }
            required.append(slot_name)
            promoted_slots.append(slot_name)
        merged_actions.append(parse_action_payload(merged_payload))
    description_text = str(description or "").strip() or (
        str(first.description or "").strip()
        or f"aggregate {' + '.join(func.name for func in functions)}"
    )
    return Function(
        name=output_function_id,
        description=description_text,
        parameters={
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False,
        },
        actions=merged_actions,
        start_node_id=str(first.start_node_id or "").strip() or None,
        end_node_id=str(first.end_node_id or "").strip() or None,
        metadata={
            **dict(getattr(first, "metadata", {}) or {}),
            "merge_mode": "aggregate",
            "aggregated_from": [func.name for func in functions],
            "merged_slot_names": promoted_slots,
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def merge_functions_preview(
    runtime: UTGRuntime,
    *,
    function_ids: list[str],
    merge_mode: str,
    output_function_id: str | None = None,
    description: str | None = None,
    function_order: list[str] | None = None,
) -> dict[str, Any]:
    """Preview one merged function built from selected existing UTG functions."""

    normalized_mode = _normalize_merge_mode(merge_mode)
    if not normalized_mode:
        return {
            "success": False,
            "error_code": "INVALID_MERGE_MODE",
            "error_message": "merge_mode must be 'compose' or 'aggregate'.",
            "merge_mode": str(merge_mode or ""),
        }
    selected_functions, error_payload = _load_selected_functions(
        runtime,
        function_ids=function_ids,
        function_order=function_order,
    )
    if error_payload is not None:
        return error_payload
    explicit_output_id = _normalize_function_candidate_id(str(output_function_id or ""))
    if (
        explicit_output_id
        and runtime.get_function_by_id(explicit_output_id) is not None
    ):
        return {
            "success": False,
            "error_code": "FUNCTION_ALREADY_EXISTS",
            "error_message": f"Function already exists locally: {explicit_output_id}",
            "function_id": explicit_output_id,
        }
    output_id = explicit_output_id or _normalize_function_candidate_id(
        f"{normalized_mode}_{'_'.join(func.name for func in selected_functions[:3])}"
    )
    if not output_id:
        output_id = (
            f"{normalized_mode}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        )
    bridge_segments: list[dict[str, Any]] = []
    try:
        if normalized_mode == "compose":
            merged_function, bridge_segments = _build_compose_merged_function(
                runtime,
                functions=selected_functions,
                output_function_id=output_id,
                description=description,
            )
        else:
            merged_function = _build_aggregate_merged_function(
                functions=selected_functions,
                output_function_id=output_id,
                description=description,
            )
    except ValueError as exc:
        return {
            "success": False,
            "error_code": "MERGE_PREVIEW_REJECTED",
            "error_message": str(exc),
            "merge_mode": normalized_mode,
            "function_ids": [func.name for func in selected_functions],
        }
    try:
        bundle_graph = _build_function_bundle_graph(runtime, merged_function)
    except ValueError as exc:
        return {
            "success": False,
            "error_code": "MERGE_PREVIEW_REJECTED",
            "error_message": str(exc),
            "merge_mode": normalized_mode,
            "function_ids": [func.name for func in selected_functions],
        }
    return {
        "success": True,
        "merge_mode": normalized_mode,
        "function_ids": [func.name for func in selected_functions],
        "function_id": merged_function.name,
        "function": _summarize_function(runtime, merged_function),
        "bridge_segments": bridge_segments,
        "graph": bundle_graph.model_dump(exclude_none=True, by_alias=True),
        "provider": PROVIDER_ID,
    }


async def merge_functions_save(
    runtime: UTGRuntime,
    *,
    function_ids: list[str],
    merge_mode: str,
    output_function_id: str | None = None,
    description: str | None = None,
    function_order: list[str] | None = None,
) -> dict[str, Any]:
    """Persist one merged function assembled from selected existing functions."""

    preview = merge_functions_preview(
        runtime,
        function_ids=function_ids,
        merge_mode=merge_mode,
        output_function_id=output_function_id,
        description=description,
        function_order=function_order,
    )
    if preview.get("success") is not True:
        return preview
    payload = await import_function_bundle(
        runtime, graph=dict(preview.get("graph") or {})
    )
    return {
        **payload,
        "merge_mode": str(preview.get("merge_mode") or ""),
        "source_function_ids": list(preview.get("function_ids") or []),
        "preview_function_id": str(preview.get("function_id") or ""),
    }


def export_function_bundle(runtime: UTGRuntime, function_id: str) -> dict[str, Any]:
    """Export one function as a self-contained UTG fragment for provider transfer.

    Args:
        runtime: Runtime instance that owns the current UTG graph.
        function_id: Function identifier to export.

    Returns:
        Stable JSON payload containing the root function, any global child
        functions it depends on, and the nodes referenced by that bundle.
    """

    normalized_func_id = str(function_id or "").strip()
    if not normalized_func_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }
    func = runtime.get_function_by_id(normalized_func_id)
    if func is None:
        return {
            "success": False,
            "error_code": "FUNCTION_NOT_FOUND",
            "error_message": f"Function not found: {normalized_func_id}",
            "function_id": normalized_func_id,
        }
    try:
        bundle_graph = _build_function_bundle_graph(runtime, func)
    except ValueError as exc:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_TOPOLOGY",
            "error_message": str(exc),
            "function_id": normalized_func_id,
        }
    return {
        "success": True,
        "provider": PROVIDER_ID,
        "function_id": normalized_func_id,
        "node_count": len(list(bundle_graph.nodes or [])),
        "graph": bundle_graph.model_dump(exclude_none=True, by_alias=True),
    }


async def import_function_bundle(
    runtime: UTGRuntime,
    *,
    graph: dict[str, Any],
    cloud_base_url: str | None = None,
) -> dict[str, Any]:
    """Import one exported function bundle into the current local provider store.

    Args:
        runtime: Runtime instance that owns the current local UTG graph.
        graph: Minimal UTG graph payload produced by `export_function_bundle(...)`.
        cloud_base_url: Optional remote provider root when this bundle comes
            from a cloud provider download.

    Returns:
        Stable JSON payload describing whether the posted bundle was imported.
    """

    if not isinstance(graph, dict) or not graph:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BUNDLE",
            "error_message": "Bundle graph payload is required.",
        }
    try:
        imported_graph = UTGGraph.model_validate(graph)
    except Exception as exc:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BUNDLE",
            "error_message": str(exc),
        }
    imported_functions = dict(getattr(imported_graph, "functions", {}) or {})
    if not imported_functions:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BUNDLE",
            "error_message": "Bundle graph must contain at least one function.",
        }
    imported_func_id, root_error = _resolve_bundle_root_function_id(imported_functions)
    if root_error:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BUNDLE",
            "error_message": root_error,
        }
    imported_func_id = str(imported_func_id or "").strip()
    if not imported_func_id:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BUNDLE",
            "error_message": "Bundle function id is required.",
        }
    topology_error = _validate_function_topology(
        imported_functions,
        root_function_id=imported_func_id,
    )
    if topology_error is not None:
        return topology_error
    if runtime.get_function_by_id(imported_func_id) is not None:
        return {
            "success": False,
            "error_code": "FUNCTION_ALREADY_EXISTS",
            "error_message": f"Function already exists locally: {imported_func_id}",
            "function_id": imported_func_id,
        }
    skipped_existing_function_ids: list[str] = []
    for function_id in imported_functions:
        normalized_function_id = str(function_id or "").strip()
        if not normalized_function_id or normalized_function_id == imported_func_id:
            continue
        if runtime.get_function_by_id(normalized_function_id) is not None:
            skipped_existing_function_ids.append(normalized_function_id)
    sync_origin = "cloud" if str(cloud_base_url or "").strip() else "bundle"
    sync_status = (
        "downloaded_from_cloud"
        if str(cloud_base_url or "").strip()
        else "imported_bundle"
    )
    synced_at = (
        datetime.now(timezone.utc).isoformat()
        if str(cloud_base_url or "").strip()
        else ""
    )
    for imported_func in imported_functions.values():
        imported_metadata = dict(getattr(imported_func, "metadata", {}) or {})
        imported_metadata["sync_status"] = sync_status
        imported_metadata["sync_origin"] = sync_origin
        imported_metadata["updated_at"] = (
            str(imported_metadata.get("updated_at") or "").strip()
            or datetime.now(timezone.utc).isoformat()
        )
        if str(cloud_base_url or "").strip():
            imported_metadata["cloud_base_url"] = str(cloud_base_url or "").strip()
            imported_metadata["last_synced_at"] = synced_at
        imported_func.metadata = imported_metadata
    runtime._utg = runtime._utg.merge(imported_graph)
    await runtime.save()
    runtime.refresh_after_mutation()
    imported_func = runtime.get_function_by_id(imported_func_id)
    summary = next(
        (
            item
            for item in list_functions(runtime).get("functions", [])
            if str(item.get("function_id") or "") == imported_func_id
        ),
        None,
    )
    return {
        "success": imported_func is not None,
        "imported": imported_func is not None,
        "function_id": imported_func_id,
        "count": len(runtime._utg.functions),
        "function": summary,
        "imported_function_ids": sorted(imported_functions.keys()),
        "skipped_existing_function_ids": sorted(skipped_existing_function_ids),
        "provider": PROVIDER_ID,
    }


async def download_cloud_function(
    runtime: UTGRuntime,
    *,
    cloud_base_url: str,
    function_id: str,
    timeout_seconds: float = 20.0,
) -> dict[str, Any]:
    """Download one or all remote function bundles into the local UTG store.

    Args:
        runtime: Runtime instance that owns the current local UTG graph.
        cloud_base_url: Remote provider root exposing `/functions` and
            `/functions/{function_id}/bundle`.
        function_id: Optional function identifier to fetch from the remote provider.
            Leave empty to pull every remote function.
        timeout_seconds: HTTP timeout for the remote request.

    Returns:
        Stable JSON payload describing whether the remote functions were imported.
    """

    normalized_base_url = str(cloud_base_url or "").strip().rstrip("/")
    normalized_function_id = str(function_id or "").strip()
    if not normalized_base_url:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BASE_URL",
            "error_message": "Cloud base URL is required.",
        }
    try:
        timeout = aiohttp.ClientTimeout(total=max(1.0, float(timeout_seconds)))
        async with aiohttp.ClientSession(timeout=timeout) as session:
            if normalized_function_id:
                remote_function_ids = [normalized_function_id]
            else:
                async with session.get(f"{normalized_base_url}/functions") as response:
                    if response.status < 200 or response.status >= 300:
                        return {
                            "success": False,
                            "error_code": "CLOUD_HTTP_ERROR",
                            "error_message": f"Cloud function list request failed: HTTP {response.status}",
                            "function_id": "",
                            "cloud_base_url": normalized_base_url,
                        }
                    list_payload = await response.json()
                if not isinstance(list_payload, dict):
                    return {
                        "success": False,
                        "error_code": "INVALID_CLOUD_RESPONSE",
                        "error_message": "Cloud function list response must be a JSON object.",
                        "function_id": "",
                        "cloud_base_url": normalized_base_url,
                    }
                remote_function_ids = []
                for item in list(list_payload.get("functions") or []):
                    if not isinstance(item, dict):
                        continue
                    candidate_function_id = str(item.get("function_id") or "").strip()
                    if candidate_function_id:
                        remote_function_ids.append(candidate_function_id)
                remote_function_ids = sorted(set(remote_function_ids))
    except Exception as exc:
        return {
            "success": False,
            "error_code": "CLOUD_REQUEST_FAILED",
            "error_message": str(exc),
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
        }

    if not remote_function_ids:
        return {
            "success": True,
            "imported": False,
            "count": 0,
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
            "imported_function_ids": [],
            "skipped_existing_function_ids": [],
            "failed_function_ids": [],
        }

    imported_function_ids: list[str] = []
    skipped_existing_function_ids: list[str] = []
    failed_function_ids: list[str] = []
    last_imported_payload: dict[str, Any] | None = None

    try:
        timeout = aiohttp.ClientTimeout(total=max(1.0, float(timeout_seconds)))
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for remote_function_id in remote_function_ids:
                if runtime.get_function_by_id(remote_function_id) is not None:
                    skipped_existing_function_ids.append(remote_function_id)
                    continue
                request_url = (
                    f"{normalized_base_url}/functions/{remote_function_id}/bundle"
                )
                try:
                    async with session.get(request_url) as response:
                        if response.status < 200 or response.status >= 300:
                            failed_function_ids.append(remote_function_id)
                            continue
                        payload = await response.json()
                except Exception:
                    failed_function_ids.append(remote_function_id)
                    continue
                if not isinstance(payload, dict) or payload.get("success") is False:
                    failed_function_ids.append(remote_function_id)
                    continue
                imported = await import_function_bundle(
                    runtime,
                    graph=payload.get("graph"),
                    cloud_base_url=normalized_base_url,
                )
                if imported.get("success") is True:
                    imported_function_ids.append(remote_function_id)
                    last_imported_payload = imported
                else:
                    failed_function_ids.append(remote_function_id)
    except Exception as exc:
        return {
            "success": False,
            "error_code": "CLOUD_REQUEST_FAILED",
            "error_message": str(exc),
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
        }

    success = not failed_function_ids
    result = dict(last_imported_payload or {})
    result.update(
        {
            "success": success,
            "imported": bool(imported_function_ids),
            "count": len(imported_function_ids),
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
            "imported_function_ids": imported_function_ids,
            "skipped_existing_function_ids": skipped_existing_function_ids,
            "failed_function_ids": failed_function_ids,
        }
    )
    if failed_function_ids and not result.get("error_message"):
        result["error_code"] = "PARTIAL_CLOUD_DOWNLOAD_FAILED"
        result["error_message"] = (
            f"Failed to download {len(failed_function_ids)} remote functions."
        )
    return result


async def upload_cloud_function(
    runtime: UTGRuntime,
    *,
    cloud_base_url: str,
    function_id: str,
    timeout_seconds: float = 20.0,
) -> dict[str, Any]:
    """Upload one local function bundle to another provider.

    Args:
        runtime: Runtime instance that owns the current local UTG graph.
        cloud_base_url: Remote provider root exposing
            `/functions/import_bundle`.
        function_id: Local function identifier that should be pushed to the remote store.
        timeout_seconds: HTTP timeout for the remote request.

    Returns:
        Stable JSON payload describing whether the local function was uploaded.
    """

    normalized_base_url = str(cloud_base_url or "").strip().rstrip("/")
    normalized_function_id = str(function_id or "").strip()
    if not normalized_base_url:
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_BASE_URL",
            "error_message": "Cloud base URL is required.",
        }
    if not normalized_function_id:
        return {
            "success": False,
            "error_code": "INVALID_FUNCTION_ID",
            "error_message": "Function id is required.",
        }
    bundle_payload = export_function_bundle(runtime, normalized_function_id)
    if bundle_payload.get("success") is False:
        bundle_payload["cloud_base_url"] = normalized_base_url
        return bundle_payload
    upload_graph = _sanitize_bundle_graph_for_upload(bundle_payload.get("graph") or {})
    request_url = f"{normalized_base_url}/functions/import_bundle"
    try:
        timeout = aiohttp.ClientTimeout(total=max(1.0, float(timeout_seconds)))
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                request_url,
                json={"graph": upload_graph},
            ) as response:
                if response.status < 200 or response.status >= 300:
                    return {
                        "success": False,
                        "error_code": "CLOUD_HTTP_ERROR",
                        "error_message": f"Cloud function upload failed: HTTP {response.status}",
                        "function_id": normalized_function_id,
                        "cloud_base_url": normalized_base_url,
                    }
                payload = await response.json()
    except Exception as exc:
        return {
            "success": False,
            "error_code": "CLOUD_REQUEST_FAILED",
            "error_message": str(exc),
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
        }
    if not isinstance(payload, dict):
        return {
            "success": False,
            "error_code": "INVALID_CLOUD_RESPONSE",
            "error_message": "Cloud response must be a JSON object.",
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
        }
    if payload.get("success") is False:
        return {
            "success": False,
            "error_code": str(payload.get("error_code") or "CLOUD_IMPORT_FAILED"),
            "error_message": str(
                payload.get("error_message") or "Cloud import failed."
            ),
            "function_id": normalized_function_id,
            "cloud_base_url": normalized_base_url,
        }
    payload = dict(payload)
    payload["uploaded"] = True
    payload["upload_privacy_mode"] = "sanitized_xml_bundle"
    payload["function_id"] = str(payload.get("function_id") or normalized_function_id)
    payload["cloud_base_url"] = normalized_base_url
    payload["provider"] = str(payload.get("provider") or PROVIDER_ID)
    local_path = runtime.get_function_by_id(normalized_function_id)
    if local_path is not None:
        metadata = dict(getattr(local_path, "metadata", {}) or {})
        metadata["sync_status"] = "uploaded_to_cloud"
        metadata["sync_origin"] = (
            str(metadata.get("sync_origin") or "").strip() or "local"
        )
        metadata["cloud_base_url"] = normalized_base_url
        metadata["last_synced_at"] = datetime.now(timezone.utc).isoformat()
        metadata["updated_at"] = (
            str(metadata.get("updated_at") or "").strip() or metadata["last_synced_at"]
        )
        local_path.metadata = metadata
        await runtime.save()
        runtime.refresh_after_mutation()
    return payload


def shortest_path_between_nodes(
    runtime: UTGRuntime,
    *,
    start_node_id: str,
    end_node_id: str,
) -> dict[str, Any]:
    """Return one BFS shortest route between two UTG nodes.

    Args:
        runtime: Runtime instance that owns the current in-memory UTG graph.
        start_node_id: Source node id already present in the UTG file.
        end_node_id: Destination node id already present in the UTG file.

    Returns:
        Stable JSON payload for CLI testing. The route is derived from current
        UTG function edges; each hop also exposes the source-step function list
        so callers can inspect the reusable execution blocks carried by the path.
    """

    start_id = str(start_node_id or "").strip()
    end_id = str(end_node_id or "").strip()
    payload: dict[str, Any] = {
        "success": False,
        "reachable": False,
        "start_node_id": start_id,
        "end_node_id": end_id,
        "shortest_hops": None,
        "node_path": [],
        "edges": [],
        "reason": "",
        "utg_store_path": str(getattr(runtime, "_filepath", "") or ""),
    }
    if not start_id or not end_id:
        payload["reason"] = "missing_node_id"
        return payload
    start_node = runtime.get_node_by_id(start_id)
    if start_node is None:
        payload["reason"] = "start_node_not_found"
        return payload
    end_node = runtime.get_node_by_id(end_id)
    if end_node is None:
        payload["reason"] = "end_node_not_found"
        return payload
    payload["start_node_description"] = str(
        getattr(getattr(start_node, "repr", None), "description", "") or ""
    )
    payload["end_node_description"] = str(
        getattr(getattr(end_node, "repr", None), "description", "") or ""
    )
    if start_id == end_id:
        payload["success"] = True
        payload["reachable"] = True
        payload["shortest_hops"] = 0
        payload["node_path"] = [start_id]
        payload["reason"] = "same_node"
        return payload

    route_edges = find_shortest_path_edges(getattr(runtime, "_utg"), start_id, end_id)
    if not route_edges:
        payload["reason"] = "path_unreachable"
        return payload

    node_path = [start_id]
    enriched_edges: list[dict[str, Any]] = []
    for edge in route_edges:
        from_node = str(edge.get("from_node") or "").strip()
        to_node = str(edge.get("to_node") or "").strip()
        function_id = str(edge.get("function_id") or "").strip()
        function = runtime.get_function_by_id(function_id)
        step = (
            getattr(function, "steps", {}).get(from_node)
            if function is not None
            and isinstance(getattr(function, "steps", None), dict)
            else None
        )
        function_names = list(getattr(step, "functions", []) or [])
        function_descriptions: list[str] = []
        function_schemas: list[dict[str, Any] | None] = []
        if function_names:
            source_node = runtime.get_node_by_id(from_node)
            for function_name in function_names:
                function_obj = (
                    getattr(source_node, "functions", {}).get(function_name)
                    if source_node is not None
                    and isinstance(getattr(source_node, "functions", None), dict)
                    else None
                )
                function_descriptions.append(
                    str(getattr(function_obj, "description", "") or "")
                )
                function_schemas.append(
                    function_obj.to_function_schema()
                    if function_obj is not None
                    and hasattr(function_obj, "to_function_schema")
                    else None
                )
        elif function is not None:
            function_names = [function_id]
            function_descriptions = [str(getattr(function, "description", "") or "")]
            function_schemas = [
                function.to_function_schema()
                if hasattr(function, "to_function_schema")
                else None
            ]
        enriched_edges.append(
            {
                "function_id": function_id,
                "from_node": from_node,
                "to_node": to_node,
                "functions": function_names,
                "function_descriptions": function_descriptions,
                "function_schemas": function_schemas,
            }
        )
        if to_node:
            node_path.append(to_node)

    payload["success"] = True
    payload["reachable"] = True
    payload["shortest_hops"] = len(enriched_edges)
    payload["node_path"] = node_path
    payload["edges"] = enriched_edges
    payload["reason"] = "shortest_path_found"
    return payload


async def capture_enter_node(
    runtime: UTGRuntime,
    *,
    bridge_base_url: str,
    bridge_token: str,
    capture_mode: str,
) -> dict[str, Any]:
    """Execute one Enter keypress and capture the resulting page against UTG.

    Args:
        runtime: Runtime instance that owns the current UTG store.
        bridge_base_url: Host bridge root exposing `/observe` and `/act`.
        bridge_token: Bearer token accepted by the host bridge.
        capture_mode: One-shot capture mode. `init_build` requires no existing
            node match and writes one new node; `match_test` requires a match.

    Returns:
        Stable JSON-safe capture result used by the CLI side-command.
    """

    mode = str(capture_mode or "").strip().lower()
    if mode not in {"init_build", "match_test"}:
        return {
            "success": False,
            "capture_mode": mode,
            "matched_node_id": "",
            "created_node_id": "",
            "utg_store_path": str(getattr(runtime, "_filepath", "") or ""),
            "screenshot_path": "",
            "package_name": "",
            "reason": "unsupported_capture_mode",
        }

    bridge = OpenOmniBotBridgeClient(
        bridge_base_url=bridge_base_url,
        bridge_token=bridge_token,
    )
    await bridge.act(make_press_key_action(DeviceKey.ENTER))
    observed = await bridge.observe(
        xml=True,
        screenshot=True,
        app_info=True,
    )
    xml_text = str(getattr(observed, "xml", "") or "").strip()
    package_name = str(getattr(observed, "package_name", "") or "").strip()
    capture_id = f"capture_enter_{_utc_now_compact()}"
    screenshot_path = _write_capture_screenshot(
        getattr(observed, "image_base64", None),
        capture_id=capture_id,
    )
    payload: dict[str, Any] = {
        "success": False,
        "capture_mode": mode,
        "matched_node_id": "",
        "created_node_id": "",
        "utg_store_path": str(getattr(runtime, "_filepath", "") or ""),
        "screenshot_path": screenshot_path,
        "package_name": package_name,
        "reason": "",
    }
    if not xml_text:
        payload["reason"] = "missing_observation_xml"
        return payload

    matched_node = runtime.match_node(xml_text, package_name=package_name)
    if matched_node is not None:
        payload["matched_node_id"] = str(getattr(matched_node, "id", "") or "")
        payload["matched_node_description"] = str(
            getattr(getattr(matched_node, "repr", None), "description", "") or ""
        )

    if mode == "init_build":
        if matched_node is not None:
            payload["reason"] = "unexpected_existing_match"
            return payload
        new_node_id = capture_id
        new_node = UTGNode(
            id=new_node_id,
            repr=NodeRepr(
                xmls=[xml_text],
                packageName=package_name or "com.example.app",
                description="",
            ),
            functions={},
            metadata={
                "capture_mode": "init_build",
                "source_action": "press_key_enter",
                "screenshot_path": screenshot_path,
            },
            triggers=[],
        )
        # Directly append node to UTG (save_node_to_utg was removed)
        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is not None:
            utg_graph.nodes.append(new_node)
        payload["success"] = True
        payload["created_node_id"] = new_node_id
        payload["reason"] = "node_created"
        return payload

    if matched_node is None:
        payload["reason"] = "required_match_missing"
        return payload
    payload["success"] = True
    payload["reason"] = "matched_existing_node"
    return payload


async def capture_manual_page(
    runtime: UTGRuntime,
    *,
    bridge_base_url: str,
    bridge_token: str,
    adb_serial: str = "",
    skip_screenshot: bool = False,
) -> dict[str, Any]:
    """Capture one current page screenshot/XML snapshot via the ops module."""

    return await _capture_manual_page_impl(
        runtime,
        bridge_base_url=bridge_base_url,
        bridge_token=bridge_token,
        adb_serial=adb_serial,
        skip_screenshot=skip_screenshot,
        provider_id=PROVIDER_ID,
    )


def compile_goal(
    runtime: UTGRuntime,
    goal: str,
    *,
    context: CompileContext | dict[str, Any] | None = None,
    match_scope: str | list[str] | None = None,
) -> dict[str, Any]:
    """Run the public compile gate and normalize the response for export.

    Args:
        runtime: Runtime instance that owns the UTG store and compile index.
        goal: Natural-language goal text that should be compiled to one UTG function.
        context: Optional minimal compile context passed through to the runtime.
        match_scope: Optional function id or function id list that restricts compile.

    Returns:
        A stable dict payload for provider export. This is the public compile
        contract and should be preferred over returning compile result objects directly.

        On compile miss, includes `candidate_functions` list with full function details
        for dynamic tool set construction.
    """
    from src.utg.core.actions import extract_function_parameters

    result = runtime.compile(
        goal,
        context=context,
    )
    # Convert CompileResult dataclass to dict
    if hasattr(result, "to_dict"):
        data = result.to_dict()
    elif hasattr(result, "__dataclass_fields__"):
        from dataclasses import asdict

        data = asdict(result)
        # Convert decision enum to string
        if "decision" in data and hasattr(data["decision"], "value"):
            data["decision"] = data["decision"].value
    else:
        return {"error": "unknown_result_type", "result": str(result)}

    normalized_function_id = str(data.get("function_id") or "").strip()
    if normalized_function_id:
        data["function_id"] = normalized_function_id
    decision_text = str(data.get("decision") or "").strip().lower()
    data.setdefault("success", bool(normalized_function_id))
    candidate_function_ids = [
        str(item or "").strip()
        for item in list(data.get("candidate_function_ids") or [])
        if str(item or "").strip()
    ]
    if not candidate_function_ids:
        for item in list(data.get("candidate_scores") or []):
            if isinstance(item, (list, tuple)) and item:
                candidate_id = str(item[0] or "").strip()
            elif isinstance(item, dict):
                candidate_id = str(
                    item.get("function_id") or item.get("id") or ""
                ).strip()
            else:
                candidate_id = ""
            if candidate_id and candidate_id not in candidate_function_ids:
                candidate_function_ids.append(candidate_id)
    if decision_text == "hit" and normalized_function_id:
        data["success"] = True
    else:
        # miss 或 ambiguous 都不算成功命中
        data["success"] = False
        if decision_text == "miss":
            candidate_function_ids = [
                item
                for item in candidate_function_ids
                if item != normalized_function_id
            ]
    data["candidate_function_ids"] = candidate_function_ids

    # Enrich with candidate_functions for dynamic tool set construction
    if candidate_function_ids:
        candidate_functions = []
        for func_id in candidate_function_ids:
            func = runtime.get_function_by_id(func_id)
            if func:
                try:
                    params = extract_function_parameters(func)
                    candidate_functions.append(
                        {
                            "function_id": str(func_id),
                            "name": str(getattr(func, "name", func_id) or func_id),
                            "description": str(getattr(func, "description", "") or ""),
                            "parameters": params,
                        }
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to extract parameters for function %s: %s", func_id, exc
                    )
        data["candidate_functions"] = candidate_functions

    return data


def _compile_miss_summary(
    goal: str,
    compile_result: dict[str, Any],
    *,
    lang: str | None = None,
) -> str:
    """Build the stable pre-hook summary string for one compile miss."""

    function_id = str(compile_result.get("function_id") or "").strip()
    if function_id:
        return _api_text(lang, "compile_short_hit", function_id=function_id)
    candidate_ids = [
        str(item or "").strip()
        for item in list(compile_result.get("candidate_function_ids") or [])
        if str(item or "").strip()
    ]
    if candidate_ids:
        return _api_text(
            lang,
            "compile_short_miss_candidates",
            candidate_ids=", ".join(candidate_ids),
        )
    reason_text = str(compile_result.get("reason") or "").strip()
    if reason_text:
        return _api_text(lang, "compile_short_miss_reason", reason=reason_text)
    return _api_text(lang, "compile_short_miss_goal", goal=str(goal or "").strip())


def _compile_miss_planner_guidance(
    goal: str,
    compile_result: dict[str, Any],
    *,
    lang: str | None = None,
) -> str:
    """Build the stable planner guidance text for one compile miss."""

    candidate_ids = [
        str(item or "").strip()
        for item in list(compile_result.get("candidate_function_ids") or [])
        if str(item or "").strip()
    ]
    if not candidate_ids:
        return ""
    lines = [
        _api_text(lang, "planner_guidance_intro"),
        _api_text(lang, "planner_guidance_goal", goal=str(goal or "").strip()),
        _api_text(lang, "planner_guidance_call"),
    ]
    lines.extend(
        f"{index}. {function_id}"
        for index, function_id in enumerate(candidate_ids, start=1)
    )
    lines.append(_api_text(lang, "planner_guidance_fallback"))
    return "\n".join(lines)


def convert_function_dict_to_tool(func_dict: dict[str, Any]) -> dict[str, Any]:
    """Convert a function dictionary to OpenAI tool schema.

    Args:
        func_dict: Function dict with function_id, name, description, parameters

    Returns:
        OpenAI tool schema
    """
    return {
        "type": "function",
        "function": {
            "name": func_dict.get("function_id", ""),
            "description": func_dict.get("description", "")
            or f"Execute {func_dict.get('name', '')}",
            "parameters": {
                "type": "object",
                "properties": func_dict.get("parameters", {}).get("properties", {}),
                "required": func_dict.get("parameters", {}).get("required", []),
            },
        },
    }


def build_tools_from_compile_result(
    compile_result: dict[str, Any],
) -> list[dict[str, Any]]:
    """Build dynamic tool set from compile result.

    Args:
        compile_result: Result from compile_goal()

    Returns:
        List of tools (base actions + candidate functions)

    Examples:
        Compile hit - only return the matched function:
        >>> compile_result = {"success": True, "function_id": "login_wechat", "candidate_functions": [...]}
        >>> tools = build_tools_from_compile_result(compile_result)
        >>> len(tools) == 1  # Only the hit function

        Compile miss - return base + candidates:
        >>> compile_result = {"success": False, "candidate_functions": [func1, func2]}
        >>> tools = build_tools_from_compile_result(compile_result)
        >>> len(tools) == 8 + 2  # Base actions + 2 candidates
    """
    from src.utg.core.actions import EXECUTE_TOOL_SCHEMAS

    base_tools = list(EXECUTE_TOOL_SCHEMAS)

    # Compile hit - only return the matched function
    if compile_result.get("success"):
        function_id = str(compile_result.get("function_id") or "").strip()
        if function_id:
            # Find the function in candidate_functions
            for func in compile_result.get("candidate_functions", []):
                if func.get("function_id") == function_id:
                    return [convert_function_dict_to_tool(func)]
        # Fallback: return base tools only
        return base_tools

    # Compile miss - return base + candidate functions
    candidate_functions = compile_result.get("candidate_functions", [])
    if not candidate_functions:
        return base_tools

    function_tools = []
    for func in candidate_functions:
        try:
            tool = convert_function_dict_to_tool(func)
            function_tools.append(tool)
        except Exception as exc:
            logger.warning(
                "Failed to convert function %s to tool: %s",
                func.get("function_id"),
                exc,
            )

    return base_tools + function_tools


def prepare_vlm_task_execution(
    runtime: UTGRuntime,
    goal: str,
    *,
    context: CompileContext | dict[str, Any] | None = None,
    current_package_name: str | None = None,
    fallback_allowed: bool = True,
    lang: str | None = None,
) -> dict[str, Any]:
    """Run the compile gate and tell caller whether to use UTG or fallback to planner.

    OmniFlow Provider is a cache layer - it does not have planning capability.
    This function only performs compile (recall) and tells the caller:
    - hit: use cached UTG function (execution_route="utg")
    - miss: no cache, caller should use their own planner (execution_route="vlm")

    Args:
        runtime: Runtime instance that owns compile behavior.
        goal: Natural-language task goal.
        context: Optional explicit compile context.
        current_package_name: Optional current foreground package from the host.
        fallback_allowed: Whether caller allows fallback to planner on compile miss.

    Returns:
        Payload with execution_route:
        - "utg": compile hit, execute cached function
        - "vlm": compile miss, caller should use planner
        - "blocked": compile failed or fallback_allowed=False
    """
    from src.utg.core.actions import EXECUTE_TOOL_SCHEMAS

    try:
        compile_context = context
        if compile_context is None:
            compile_context = CompileContext(
                current_package=str(current_package_name or "").strip() or None,
            )
        compile_result = compile_goal(
            runtime,
            goal,
            context=compile_context,
        )
    except Exception:
        base_tools = list(EXECUTE_TOOL_SCHEMAS)
        if fallback_allowed:
            return {
                "kind": "disabled_or_fallback",
                "summary": _api_text(lang, "compile_request_failed_use_planner"),
                "function_id": None,
                "tools": base_tools,
                "planner_guidance": "",
                "fallback_allowed": True,
                "execution_route": "vlm",
            }
        return {
            "kind": "hard_fail",
            "summary": _api_text(lang, "compile_request_failed_blocked"),
            "function_id": None,
            "tools": base_tools,
            "planner_guidance": "",
            "fallback_allowed": False,
            "execution_route": "blocked",
        }

    function_id = str(compile_result.get("function_id") or "").strip() or None
    if bool(compile_result.get("success")) and function_id:
        # Compile hit - use cached UTG function
        tools = build_tools_from_compile_result(compile_result)
        return {
            "kind": "hit",
            "summary": _api_text(
                lang,
                "compile_hit_summary",
                function_id=function_id,
            ),
            "function_id": function_id,
            "tools": tools,
            "planner_guidance": "",
            "fallback_allowed": bool(fallback_allowed),
            "execution_route": "utg",
        }

    # Compile miss - no cache, tell caller to use planner
    tools = build_tools_from_compile_result(compile_result)

    if not fallback_allowed:
        return {
            "kind": "hard_fail",
            "summary": (
                f"{_compile_miss_summary(goal, compile_result, lang=lang)}；"
                f"{_api_text(lang, 'cache_miss_blocked')}"
                if resolve_api_language(lang=lang) == "zh"
                else (
                    f"{_compile_miss_summary(goal, compile_result, lang=lang)}; "
                    f"{_api_text(lang, 'cache_miss_blocked')}"
                )
            ),
            "function_id": None,
            "tools": tools,
            "planner_guidance": _compile_miss_planner_guidance(
                goal,
                compile_result,
                lang=lang,
            ),
            "fallback_allowed": False,
            "execution_route": "blocked",
        }

    return {
        "kind": "miss",
        "summary": (
            f"{_compile_miss_summary(goal, compile_result, lang=lang)}；"
            f"{_api_text(lang, 'cache_miss_use_planner')}"
            if resolve_api_language(lang=lang) == "zh"
            else (
                f"{_compile_miss_summary(goal, compile_result, lang=lang)}; "
                f"{_api_text(lang, 'cache_miss_use_planner')}"
            )
        ),
        "function_id": None,
        "tools": tools,
        "planner_guidance": _compile_miss_planner_guidance(
            goal,
            compile_result,
            lang=lang,
        ),
        "fallback_allowed": True,
        "execution_route": "vlm",
    }


async def execute_function(
    runtime: UTGRuntime,
    observe,
    act,
    *,
    function_id: str,
    arguments: dict[str, Any] | None = None,
    goal: str | None = None,
    context: dict[str, Any] | None = None,
    skip_terminal_verify: bool = False,
    lang: str | None = None,
    retry_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute one function through the shared runtime and control plane.

    Args:
        runtime: Runtime instance that owns execution/control behavior.
        observe: Host observe callable. It must follow the shared
            `observe(xml=..., screenshot=..., app_info=...)` contract.
        act: Host act callable. It must execute one normalized UTG action.
        function_id: Function id returned by `compile_goal(...)`.
        arguments: Optional parameter values rendered into the function actions.
        goal: Optional original user goal kept only for response context.
        context: Optional extra runtime context. Public parameter values are
            merged directly into this dict because rendering reads top-level keys.
        skip_terminal_verify: Whether this caller wants "function finished" semantics.
            When true, the runtime-side terminal verifier is also disabled so the
            shared executor will not downgrade an otherwise completed function into a
            terminal mismatch failure.

        Returns:
        A stable execution payload containing success, terminal verify result,
        run log, and final observation. Direct single-action control hooks such
        as `controlled_act` are intentionally not exposed here.
    """

    runtime_context = dict(context or {})
    runtime_context.update(dict(arguments or {}))
    if goal is not None:
        runtime_context["goal"] = goal
    runtime_context.setdefault("__utg_skip_after_action__", False)
    runtime_context.setdefault("__utg_skip_post_action_observation__", False)
    if bool(skip_terminal_verify):
        runtime_context["__utg_terminal_state_verifier__"] = None
        runtime_context["__utg_skip_explicit_terminal_node__"] = True
    source = (
        str(runtime_context.get("source") or "utg_manual_dashboard").strip() or "utg"
    )
    canonical_logger = UTGRunLogger(enabled=True, path=_canonical_run_log_path())

    # Handle retry context - continue from previous run
    is_retry = False
    resume_from_step = 0
    if retry_context is not None and isinstance(retry_context, dict):
        retry_run_id = str(retry_context.get("run_id") or "").strip()
        if retry_run_id:
            canonical_run_id = retry_run_id
            is_retry = True
            resume_from_step = int(retry_context.get("resume_from_step") or 0)
            # Use function_id from retry_context if not provided
            if not function_id and retry_context.get("function_id"):
                function_id = str(retry_context.get("function_id") or "").strip()
            runtime_context["__utg_resume_from_step__"] = resume_from_step
            runtime_context["__utg_is_retry__"] = True

    if not is_retry:
        canonical_run_id = canonical_logger.new_run_id()

    started_at = datetime.now(timezone.utc).isoformat()
    t0 = perf_counter()
    if isinstance(runtime, UTGRuntime):
        runtime_context.update(
            {
                "__utg_run_id__": canonical_run_id,
                "__utg_run_goal__": str(
                    goal or f"manual_utg_function_run:{function_id}"
                ),
                "__utg_run_step_index__": 0,
                "__utg_run_selection_source__": "utg",
                "__utg_run_execution_source__": "utg",
                "__utg_run_session_managed__": True,
            }
        )
    observation_before_act: dict[str, Any] | None = None
    # Write run_started or retry_started event
    event_type = "retry_started" if is_retry else "run_started"
    canonical_logger.write_event(
        canonical_logger.build_stream_event(
            event_type=event_type,
            run_id=canonical_run_id,
            goal=str(goal or f"manual_utg_function_run:{function_id}"),
            payload={
                "started_at": started_at,
                "is_retry": is_retry,
                "resume_from_step": resume_from_step if is_retry else None,
                "extra": {
                    "source": source,
                    "function_id": function_id,
                    "arguments": dict(arguments or {}),
                    "skip_terminal_verify": bool(skip_terminal_verify),
                },
            },
        )
    )
    try:
        observed_before = await observe(
            xml=True,
            screenshot=False,
            app_info=True,
        )
        if isinstance(observed_before, DeviceObservation):
            observation_before_act = {
                "xml": observed_before.xml,
                "package_name": observed_before.package_name,
                "activity_name": observed_before.activity_name,
                "image_base64": None,
            }
        else:
            observation_before_act = to_serializable(observed_before)
    except Exception:
        observation_before_act = None
    if observation_before_act is not None:
        canonical_logger.write_event(
            canonical_logger.build_stream_event(
                event_type="observe_finished",
                run_id=canonical_run_id,
                goal=str(goal or f"manual_utg_function_run:{function_id}"),
                step_index=0,
                selection_source="utg",
                execution_source="utg",
                payload=observation_before_act,
            )
        )
    canonical_logger.write_event(
        canonical_logger.build_stream_event(
            event_type="compile_decided",
            run_id=canonical_run_id,
            goal=str(goal or f"manual_utg_function_run:{function_id}"),
            step_index=0,
            selection_source="utg",
            execution_source="utg",
            payload={
                "success": True,
                "decision": "manual_function_execution",
                "function_id": function_id,
                "candidate_function_ids": [function_id],
                "arguments": dict(arguments or {}),
            },
        )
    )
    canonical_logger.write_event(
        canonical_logger.build_stream_event(
            event_type="plan_selected",
            run_id=canonical_run_id,
            goal=str(goal or f"manual_utg_function_run:{function_id}"),
            step_index=0,
            selection_source="utg",
            execution_source="utg",
            payload={
                "source": "cache",
                "tool_name": function_id,
                "tool_args": dict(arguments or {}),
                "function_id": function_id,
                "decision": "manual_function_execution",
                "planner_used": False,
            },
        )
    )

    function_obj = runtime.get_function_by_id(function_id)
    result = await runtime.run_function(
        observe,
        act,
        function_id,
        context=runtime_context,
    )

    terminal_state: dict[str, Any]
    if bool(skip_terminal_verify):
        terminal_state = {
            "verifiable": False,
            "terminal_page_reached": None,
            "reason": "skipped_for_oob",
        }
    elif function_obj is None:
        terminal_state = {
            "verifiable": False,
            "terminal_page_reached": None,
            "reason": "function_not_found",
        }
    else:
        terminal_state = await runtime.verify_terminal_state(
            observe,
            function_id=function_id,
            arguments=dict(arguments or {}),
            execution_result=result,
            include_app_identity=False,
        )

    matched_steps = int(getattr(result, "matched_steps", 0) or 0)
    skipped_steps = int(getattr(result, "skipped_steps", 0) or 0)
    executed_functions = int(getattr(result, "executed_functions", 0) or 0)
    error_code = getattr(result, "error_code", None)
    error_message = getattr(result, "error_message", None)
    success = bool(getattr(result, "success", False))
    expected_step_count = 0
    if function_obj is not None:
        expected_step_count = len(getattr(function_obj, "steps", {}) or {})
        if expected_step_count <= 0:
            expected_step_count = len(getattr(function_obj, "actions", []) or [])
        if expected_step_count <= 0:
            expected_step_count = 1
    if (
        bool(skip_terminal_verify)
        and not success
        and function_obj is not None
        and expected_step_count > 0
        and matched_steps + skipped_steps >= expected_step_count
        and executed_functions >= expected_step_count
        and str(error_code or "") in {"", EXEC_ACTION_NO_EFFECT}
    ):
        success = True
        error_code = None
        error_message = None

    payload = {
        "success": success,
        "function_id": function_id,
        "goal": goal,
        "arguments": dict(arguments or {}),
        "error_code": error_code,
        "error_message": error_message,
        "tool_call_count": 1 if function_id else 0,
        "completed_tool_call_count": 1 if success and function_id else 0,
        "function_call_count": 1 if function_id else 0,
        "completed_function_call_count": 1 if success and function_id else 0,
        "function_step_count": expected_step_count,
        "terminal_state": to_serializable(terminal_state),
        "final_observation": to_serializable(
            getattr(result, "final_observation", None)
        ),
        "control_trace": to_serializable(getattr(result, "control_trace", None)),
        "device_actions": to_serializable(getattr(result, "device_actions", None)),
        "main_action_frames": to_serializable(
            getattr(result, "main_action_frames", None)
        ),
        "final_state": to_serializable(getattr(result, "final_state", None)),
        "provider_detail_summary": to_serializable(
            getattr(result, "provider_detail_summary", None)
        )
        or {
            "function_id": function_id,
            "success": success,
            "error_code": error_code,
            "error_message": error_message,
            "control_trace": to_serializable(getattr(result, "control_trace", None)),
            "device_actions": to_serializable(getattr(result, "device_actions", None)),
            "main_action_frames": to_serializable(
                getattr(result, "main_action_frames", None)
            ),
            "final_state": to_serializable(getattr(result, "final_state", None)),
        },
        "canonical_run_log_path": _canonical_run_log_path(),
    }
    terminal_reached = payload["terminal_state"].get("terminal_page_reached") is True
    terminal_skipped = payload["terminal_state"].get("reason") == "skipped_for_oob"
    payload["summary"] = (
        _api_text(lang, "utg_completed_goal", goal=goal)
        if success and (terminal_reached or terminal_skipped)
        else (
            _api_text(lang, "utg_executed_goal", goal=goal)
            if success
            else (
                str(error_message or "").strip()
                or (
                    _api_text(lang, "utg_failed_code", error_code=error_code)
                    if str(error_code or "").strip()
                    else _api_text(lang, "utg_failed_generic")
                )
            )
        )
    )
    finished_at = datetime.now(timezone.utc).isoformat()
    duration_ms = (perf_counter() - t0) * 1000
    canonical_logger.write_event(
        canonical_logger.build_stream_event(
            event_type="step_closed",
            run_id=canonical_run_id,
            goal=str(goal or f"manual_utg_function_run:{function_id}"),
            step_index=0,
            selection_source="utg",
            execution_source="utg",
            payload={
                "act_source": "utg",
                "act_result": {
                    "success": bool(payload["success"]),
                    "error_code": payload["error_code"],
                    "error_message": payload["error_message"],
                    "source": source,
                    "result_summary": {
                        "message": (
                            _api_text(
                                lang,
                                "function_execute_success",
                                function_id=function_id,
                            )
                            if payload["success"]
                            else (
                                str(payload["error_message"] or "").strip()
                                or _api_text(
                                    lang,
                                    "function_execute_failed",
                                    function_id=function_id,
                                )
                            )
                        ),
                        "summary": payload["summary"],
                        "function_id": function_id,
                        "tool_call_count": payload["tool_call_count"],
                        "completed_tool_call_count": payload[
                            "completed_tool_call_count"
                        ],
                        "function_call_count": payload["function_call_count"],
                        "completed_function_call_count": payload[
                            "completed_function_call_count"
                        ],
                        "function_step_count": payload["function_step_count"],
                    },
                },
                "terminal_state": to_serializable(terminal_state),
                "final_observation": to_serializable(
                    getattr(result, "final_observation", None)
                ),
                "finished_at": finished_at,
                "duration_ms": duration_ms,
            },
        )
    )
    canonical_logger.write_event(
        canonical_logger.build_stream_event(
            event_type="run_finished",
            run_id=canonical_run_id,
            goal=str(goal or f"manual_utg_function_run:{function_id}"),
            payload={
                "success": bool(payload["success"]),
                "done_reason": "completed" if bool(payload["success"]) else "failed",
                "finished_at": finished_at,
                "duration_ms": duration_ms,
                "final_observation": to_serializable(
                    getattr(result, "final_observation", None)
                ),
            },
        )
    )
    payload["run_log"] = canonical_logger.load_materialized_run(run_id=canonical_run_id)
    payload["run_log_summary"] = {
        "run_id": canonical_run_id,
        "function_id": function_id,
        "success": bool(payload["success"]),
        "duration_ms": duration_ms,
    }

    # Add retry_context for failed executions
    if not success:
        # Determine which step failed
        failed_step = matched_steps + skipped_steps
        payload["retry_context"] = {
            "run_id": canonical_run_id,
            "function_id": function_id,
            "resume_from_step": failed_step,
            "error_code": error_code,
        }

    # Update function run_stats
    if function_obj is not None:
        run_stats = dict(getattr(function_obj, "run_stats", {}) or {})
        run_stats["call_count"] = int(run_stats.get("call_count") or 0) + 1
        if success:
            run_stats["success_count"] = int(run_stats.get("success_count") or 0) + 1
        run_stats["last_run_id"] = canonical_run_id
        run_stats["last_run_at"] = finished_at
        run_stats["last_success"] = success
        function_obj.run_stats = run_stats
        # Async save in background (don't block response)
        try:
            asyncio.create_task(runtime.save())
        except Exception:
            pass  # Best effort, don't fail execution for stats

    return payload


def build_app(runtime: UTGRuntime) -> FastAPI:
    """Build the local OmniFlow provider service for OpenOmniBot integration.

    Args:
        runtime: Runtime instance bound to one UTG store.

    Returns:
        A FastAPI app exposing `health`, `compile`, and `execute_function`.
    """

    app = FastAPI(title="OmniFlow UTG API", version="0.1.0")

    register_page_routes(app)
    register_ops_routes(
        app,
        runtime=runtime,
        provider_id=PROVIDER_ID,
        provider_api_methods=PROVIDER_API_METHODS,
        host_callbacks=HOST_CALLBACKS,
        supported_bridge_actions=SUPPORTED_BRIDGE_ACTIONS,
        canonical_run_log_path=_canonical_run_log_path(),
        health_fn=health,
        capture_manual_page_fn=capture_manual_page,
        run_workbench_command_fn=_run_workbench_command,
        check_oob_workbench_environment_fn=_check_oob_workbench_environment,
        reset_all_data_fn=reset_all_data,
    )
    register_service_routes(
        app,
        runtime=runtime,
        provider_id=PROVIDER_ID,
        bridge_client_cls=OpenOmniBotBridgeClient,
        list_graph_apps_fn=list_graph_apps,
        get_app_graph_fn=get_app_graph,
        list_nodes_fn=list_nodes,
        list_functions_fn=list_functions,
        delete_function_fn=delete_function,
        update_function_fn=update_function,
        merge_functions_preview_fn=merge_functions_preview,
        merge_functions_save_fn=merge_functions_save,
        enrich_function_fn=enrich_function,
        split_function_fn=split_function,
        export_function_bundle_fn=export_function_bundle,
        import_function_bundle_fn=import_function_bundle,
        list_run_logs_fn=list_run_logs,
        ingest_run_log_fn=ingest_run_log,
        import_run_log_fn=import_run_log,
        delete_run_log_fn=delete_run_log,
        get_run_log_fn=get_run_log,
        get_run_log_timeline_payload_fn=get_run_log_timeline_payload,
        get_multi_user_global_registry_fn=get_multi_user_global_registry,
        download_cloud_function_fn=download_cloud_function,
        upload_cloud_function_fn=upload_cloud_function,
        list_shared_pages_fn=list_shared_pages,
        get_shared_page_fn=get_shared_page,
        import_shared_page_fn=import_shared_page,
        search_shared_pages_fn=search_shared_pages,
        map_shared_coordinates_fn=map_shared_coordinates,
        enrich_node_fn=enrich_node,
        export_node_memory_fn=export_node_memory,
        export_memory_bundle_fn=export_memory_bundle,
        export_memory_to_dir_fn=export_memory_to_dir,
        export_rag_memory_fn=export_rag_memory,
        compile_goal_fn=compile_goal,
        decompose_goal_fn=decompose_goal_to_key_functions,
        prepare_vlm_task_execution_fn=prepare_vlm_task_execution,
        execute_function_fn=execute_function,
        get_control_plane_rules_fn=get_control_plane_rules,
        get_control_plane_trace_fn=get_control_plane_trace,
        get_background_task_fn=get_background_task,
        list_background_tasks_fn=list_background_tasks,
    )

    return app


def _build_arg_parser() -> argparse.ArgumentParser:
    """Build the CLI parser for launching the local provider service."""

    parser = argparse.ArgumentParser(
        description="Run the local OmniFlow UTG provider service for OpenOmniBot.",
    )
    parser.add_argument(
        "--host",
        default=os.getenv("OMNIFLOW_UTG_API_HOST", "127.0.0.1"),
        help="Bind host for the local provider service.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.getenv("OMNIFLOW_UTG_API_PORT", "19070")),
        help="Bind port for the local provider service.",
    )
    parser.add_argument(
        "--utg-store-path",
        default=os.getenv("OMNIFLOW_UTG_STORE_PATH"),
        help="Optional UTG store JSON path. Falls back to runtime defaults.",
    )
    parser.add_argument(
        "--asset-utg-path",
        action="append",
        default=[],
        help="Optional extra UTG JSON asset path. Can be passed multiple times.",
    )
    parser.add_argument(
        "--capture-enter-node",
        action="store_true",
        help="Execute one press_key(enter), capture the resulting page, and either create or verify one UTG node.",
    )
    parser.add_argument(
        "--test-compile",
        action="store_true",
        help="Load the UTG file and run one compile(goal) test instead of starting the provider server.",
    )
    parser.add_argument(
        "--shortest-path-test",
        action="store_true",
        help="Load the UTG file and run a node-to-node shortest path query instead of starting the provider server.",
    )
    parser.add_argument(
        "--export-observation-benchmark",
        action="store_true",
        help="Export node-match and/or action-effect benchmark rows from existing run logs or offline replay assets.",
    )
    parser.add_argument(
        "--score-node-match",
        action="store_true",
        help="Run the offline node-match benchmark on one exported observation dataset.",
    )
    parser.add_argument(
        "--score-action-effect",
        action="store_true",
        help="Run the offline action-effect benchmark on one exported observation dataset.",
    )
    parser.add_argument(
        "--capture-mode",
        choices=("init_build", "match_test"),
        default="match_test",
        help="Capture behavior used only with --capture-enter-node.",
    )
    parser.add_argument(
        "--bridge-base-url",
        default="",
        help="Host bridge base URL used only with --capture-enter-node.",
    )
    parser.add_argument(
        "--bridge-token",
        default="",
        help="Host bridge bearer token used only with --capture-enter-node.",
    )
    parser.add_argument(
        "--goal",
        default="",
        help="Goal text used only with --test-compile.",
    )
    parser.add_argument(
        "--current-node-id",
        default="",
        help="Optional current node id used only with --test-compile.",
    )
    parser.add_argument(
        "--start-node-id",
        default="",
        help="Source node id used only with --shortest-path-test.",
    )
    parser.add_argument(
        "--end-node-id",
        default="",
        help="Target node id used only with --shortest-path-test.",
    )
    parser.add_argument(
        "--observation-source-path",
        action="append",
        default=[],
        help="Run-log file or offline replay dir used only with --export-observation-benchmark. Can be passed multiple times.",
    )
    parser.add_argument(
        "--observation-output-dir",
        default=None,
        help="Optional output dir used only with --export-observation-benchmark.",
    )
    parser.add_argument(
        "--observation-dataset-path",
        default="",
        help="Bundle dir or direct dataset file used only with --score-node-match/--score-action-effect.",
    )
    parser.add_argument(
        "--observation-run-id",
        default="",
        help="Optional canonical run id filter used only when exporting from run_logs.jsonl.",
    )
    parser.add_argument(
        "--observation-benchmark-kind",
        choices=("node_match", "action_effect", "both"),
        default="both",
        help="Observation benchmark slice used only with --export-observation-benchmark.",
    )
    parser.add_argument(
        "--node-match-top-k",
        type=int,
        default=3,
        help="Candidate cut used only with --score-node-match.",
    )
    return parser


def main() -> int:
    """Launch the local FastAPI service used by OpenOmniBot integration."""

    args = _build_arg_parser().parse_args()
    if bool(args.capture_enter_node):
        if not str(args.bridge_base_url or "").strip():
            raise SystemExit("--bridge-base-url is required with --capture-enter-node")
        if not str(args.bridge_token or "").strip():
            raise SystemExit("--bridge-token is required with --capture-enter-node")
        runtime = UTGRuntime(filepath=args.utg_store_path)
        payload = asyncio.run(
            capture_enter_node(
                runtime,
                bridge_base_url=str(args.bridge_base_url),
                bridge_token=str(args.bridge_token),
                capture_mode=str(args.capture_mode),
            )
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0 if bool(payload.get("success")) else 1
    if bool(args.test_compile):
        if not str(args.utg_store_path or "").strip():
            raise SystemExit("--utg-store-path is required with --test-compile")
        if not str(args.goal or "").strip():
            raise SystemExit("--goal is required with --test-compile")
        runtime = UTGRuntime(filepath=args.utg_store_path)
        payload = compile_goal(
            runtime,
            str(args.goal),
            context=CompileContext(
                current_node_id=str(args.current_node_id or "").strip() or None
            ),
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0 if bool(payload.get("success")) else 1
    if bool(args.shortest_path_test):
        if not str(args.utg_store_path or "").strip():
            raise SystemExit("--utg-store-path is required with --shortest-path-test")
        if not str(args.start_node_id or "").strip():
            raise SystemExit("--start-node-id is required with --shortest-path-test")
        if not str(args.end_node_id or "").strip():
            raise SystemExit("--end-node-id is required with --shortest-path-test")
        runtime = UTGRuntime(filepath=args.utg_store_path)
        payload = shortest_path_between_nodes(
            runtime,
            start_node_id=str(args.start_node_id),
            end_node_id=str(args.end_node_id),
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0 if bool(payload.get("success")) else 1
    if bool(args.export_observation_benchmark):
        if not list(args.observation_source_path or []):
            raise SystemExit(
                "--observation-source-path is required with --export-observation-benchmark"
            )
        payload = export_observation_benchmark_bundle(
            source_paths=list(args.observation_source_path or []),
            output_dir=args.observation_output_dir,
            benchmark_kind=str(args.observation_benchmark_kind),
            run_id=str(args.observation_run_id or "").strip() or None,
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    if bool(args.score_node_match):
        if not str(args.utg_store_path or "").strip():
            raise SystemExit("--utg-store-path is required with --score-node-match")
        if not str(args.observation_dataset_path or "").strip():
            raise SystemExit(
                "--observation-dataset-path is required with --score-node-match"
            )
        runtime = UTGRuntime(filepath=args.utg_store_path)
        payload = score_node_match_benchmark(
            runtime,
            str(args.observation_dataset_path),
            output_dir=args.observation_output_dir,
            top_k=max(1, int(args.node_match_top_k or 3)),
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    if bool(args.score_action_effect):
        if not str(args.observation_dataset_path or "").strip():
            raise SystemExit(
                "--observation-dataset-path is required with --score-action-effect"
            )
        payload = score_action_effect_benchmark(
            str(args.observation_dataset_path),
            output_dir=args.observation_output_dir,
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    asset_utg_paths = list(args.asset_utg_path or [])
    smoke_test_utg_path = str(SMOKE_TEST_UTG_PATH)
    if SMOKE_TEST_UTG_PATH.exists() and smoke_test_utg_path not in asset_utg_paths:
        asset_utg_paths.append(smoke_test_utg_path)
    runtime = UTGRuntime(
        filepath=args.utg_store_path,
        asset_utg_paths=asset_utg_paths,
    )
    uvicorn.run(
        build_app(runtime),
        host=str(args.host or "127.0.0.1"),
        port=max(1, int(args.port)),
        log_level="info",
    )
    return 0


__all__ = [
    "CompileRequest",
    "ManualCaptureRequest",
    "DownloadCloudFunctionRequest",
    "ImportFunctionBundleRequest",
    "ImportRunLogRequest",
    "RunLogIngestRequest",
    "OpenOmniBotBridgeClient",
    "ReplayRunLogRequest",
    "ExecuteFunctionRequest",
    "SharedPageImportRequest",
    "SharedPageMapCoordinatesRequest",
    "SharedPageSearchRequest",
    "UTGRuntime",
    "UploadCloudFunctionRequest",
    "build_app",
    "capture_enter_node",
    "capture_manual_page",
    "compile_goal",
    "download_cloud_function",
    "export_function_bundle",
    "export_observation_benchmark_bundle",
    "get_run_log",
    "get_app_graph",
    "health",
    "HOST_CALLBACKS",
    "import_function_bundle",
    "import_run_log",
    "ingest_run_log",
    "list_graph_apps",
    "list_functions",
    "list_run_logs",
    "list_shared_pages",
    "main",
    "map_shared_coordinates",
    "PROVIDER_API_METHODS",
    "execute_function",
    "get_shared_page",
    "import_shared_page",
    "search_shared_pages",
    "score_action_effect_benchmark",
    "score_node_match_benchmark",
    "shortest_path_between_nodes",
    "SUPPORTED_BRIDGE_ACTIONS",
    "upload_cloud_function",
]


if __name__ == "__main__":
    raise SystemExit(main())
