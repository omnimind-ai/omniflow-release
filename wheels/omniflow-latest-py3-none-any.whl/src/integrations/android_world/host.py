from __future__ import annotations

import base64
from dataclasses import dataclass
import importlib
import inspect
import io
import logging
import types
from typing import Any, Callable, Dict, Optional, Sequence, Tuple

from src.foundation.source_tools import escape_xml_text, read_attr, safe_int
from src.utg.core.actions import (
    AnyAction,
    ClickAction,
    ClickNodeAction,
    InputTextAction,
    LongPressAction,
    OpenAppAction,
    PressKeyAction,
    SwipeAction,
    UnknownAction,
    WaitAction,
    device_key_value,
    normalize_action,
)

logger = logging.getLogger(__name__)
_UIA2_DEVICE_CACHE: dict[str, Any] = {}


@dataclass
class AndroidWorldPageSnapshot:
    """One AndroidWorld page snapshot cached for observe-time reuse.

    Args:
        state: Original AndroidWorld state object returned by env/agent APIs.
        pixels: Optional screenshot-like pixels attached to the state.
        forest: Optional AndroidWorld accessibility forest from the state.
        ui_elements: JSON-safe UI elements copied from the state.
        activity_name: Foreground activity name reported by the env.
        package_name: Foreground package name derived from the activity.
        stable: Whether this snapshot came from a stabilized state query.
    """

    state: Any
    pixels: Any | None
    forest: Any
    ui_elements: list[Any]
    activity_name: str
    package_name: str
    stable: bool


_RAW_ANDROID_WORLD_ACTION_TYPE = "android_world_raw"
_RAW_ANDROID_WORLD_PAYLOAD_KEY = "payload"

_BOOL_FIELDS = (
    "is_checked",
    "is_checkable",
    "is_clickable",
    "is_editable",
    "is_enabled",
    "is_focused",
    "is_focusable",
    "is_long_clickable",
    "is_scrollable",
    "is_selected",
    "is_visible",
    "is_visible_to_user",
    "is_important_for_accessibility",
    "is_heading",
    "is_multi_line",
    "is_password",
)

_TEXT_FIELDS = (
    "text",
    "content_description",
    "class_name",
    "hint_text",
    "package_name",
    "resource_name",
    "tooltip",
    "resource_id",
)


def ui_bbox_to_jsonable(bbox: Any) -> dict[str, int] | None:
    """Convert one AndroidWorld bbox object into a stable JSON-safe dict."""

    if bbox is None:
        return None
    fields = ("x_min", "x_max", "y_min", "y_max")
    data: dict[str, int] = {}
    for field in fields:
        value = safe_int(read_attr(bbox, field))
        if value is None:
            return None
        data[field] = value
    return data


def ui_element_bounds_text(elem: Any) -> str:
    """Render one UI element bbox into Android XML-style bounds text."""

    bbox = read_attr(elem, "bbox_pixels")
    box = ui_bbox_to_jsonable(bbox)
    if not box:
        return ""
    return f"[{box['x_min']},{box['y_min']}][{box['x_max']},{box['y_max']}]"


def ui_element_center(elem: Any) -> tuple[int, int] | None:
    """Return the integer center point of one UI element bbox."""

    bbox = read_attr(elem, "bbox_pixels")
    box = ui_bbox_to_jsonable(bbox)
    if not box:
        return None
    return ((box["x_min"] + box["x_max"]) // 2, (box["y_min"] + box["y_max"]) // 2)


def _activity_to_package(activity_name: str) -> str:
    raw = str(activity_name or "").strip()
    if not raw:
        return ""
    if "/" in raw:
        return raw.split("/", 1)[0].strip()
    return raw


def page_pixels_to_image_data_url(page: Any) -> Optional[str]:
    """Convert AndroidWorld pixels into a data URL when a screenshot exists."""

    pixels = getattr(page, "pixels", None)
    if pixels is None:
        return None
    if isinstance(pixels, str):
        raw = str(pixels or "").strip()
        if not raw:
            return None
        return raw if raw.startswith("data:image/") else f"data:image/png;base64,{raw}"
    if isinstance(pixels, (bytes, bytearray)):
        raw = base64.b64encode(bytes(pixels)).decode("utf-8")
        return f"data:image/png;base64,{raw}"
    try:
        from PIL import Image

        image = pixels if isinstance(pixels, Image.Image) else Image.fromarray(pixels)
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        raw = base64.b64encode(buffer.getvalue()).decode("utf-8")
        return f"data:image/png;base64,{raw}"
    except Exception:
        return None


def capture_adapter_state(
    *,
    env: Any,
    adb_serial: str = "",
) -> Any | None:
    """Capture one AndroidWorld-compatible state without relying on a11y forest.

    Args:
        env: Live AndroidWorld env exposing `controller.env.step(...)` and
            `foreground_activity_name`.
        adb_serial: Target device serial used to prefer the OmniFlow-local
            `uiautomator2` XML channel over AndroidWorld's `adb_utils` dump.
    Returns:
        One lightweight state-like object carrying `pixels`, `ui_elements`,
        `xml`, `activity_name`, and `package_name`, or `None` when the direct
        adapter is unavailable on the current host.
    """

    raw_controller_env = getattr(getattr(env, "controller", None), "env", None)
    raw_controller_step = getattr(raw_controller_env, "step", None)
    if not callable(raw_controller_step):
        return None
    try:
        adb_utils = importlib.import_module("android_world.env.adb_utils")
        representation_utils = importlib.import_module(
            "android_world.env.representation_utils"
        )
        action_type = importlib.import_module("android_env.components.action_type")
        numpy = importlib.import_module("numpy")
    except Exception:
        return None

    serial = str(adb_serial or "").strip()
    uia2_device = None
    if serial:
        try:
            uiautomator2 = importlib.import_module("uiautomator2")
            uia2_device = _UIA2_DEVICE_CACHE.get(serial)
            if uia2_device is None:
                uia2_device = uiautomator2.connect(serial)
                _UIA2_DEVICE_CACHE[serial] = uia2_device
        except Exception:
            logger.debug("androidworld.observe_hook uiautomator2 connect failed")
            uia2_device = None

    timestep = raw_controller_step(
        {
            "action_type": numpy.array(
                action_type.ActionType.LIFT,
                dtype=numpy.int32,
            ),
            "touch_position": numpy.array((0.0, 0.0)),
        }
    )
    observation = dict(getattr(timestep, "observation", {}) or {})
    xml_text = ""
    if uia2_device is not None:
        try:
            xml_text = str(
                uia2_device.dump_hierarchy(compressed=False, pretty=False) or ""
            ).strip()
        except Exception:
            logger.debug(
                "androidworld.observe_hook uiautomator2 dump failed",
                exc_info=True,
            )
            _UIA2_DEVICE_CACHE.pop(serial, None)
            uia2_device = None
    if not xml_text:
        xml_text = str(adb_utils.uiautomator_dump(raw_controller_env) or "").strip()
    ui_elements = (
        representation_utils.xml_dump_to_ui_elements(xml_text) if xml_text else []
    )
    activity_name = str(getattr(env, "foreground_activity_name", "") or "").strip()
    package_name = activity_name.split("/", 1)[0].strip() if activity_name else ""
    return types.SimpleNamespace(
        pixels=observation.get("pixels"),
        forest=None,
        ui_elements=ui_elements,
        auxiliaries={},
        xml=xml_text,
        activity_name=activity_name,
        package_name=package_name,
    )


def ui_element_to_jsonable(elem: Any) -> dict[str, Any]:
    """Convert one AndroidWorld UI element object into a JSON-safe dict."""

    data: dict[str, Any] = {}
    for field in _TEXT_FIELDS:
        value = read_attr(elem, field)
        if value is not None:
            data[field] = value
    for field in _BOOL_FIELDS:
        value = read_attr(elem, field)
        if value is not None:
            data[field] = bool(value)
    for field in ("bbox", "bbox_pixels"):
        box = ui_bbox_to_jsonable(read_attr(elem, field))
        if box is not None:
            data[field] = box
    metadata = read_attr(elem, "metadata")
    if isinstance(metadata, dict):
        data["metadata"] = dict(metadata)
    return data


def ui_elements_to_jsonable(ui_elements: Sequence[Any]) -> list[dict[str, Any]]:
    """Convert a UI element list into JSON-safe element dicts."""

    return [ui_element_to_jsonable(elem) for elem in ui_elements]


def ui_elements_to_pseudo_xml(
    ui_elements: Sequence[Any],
    *,
    empty_xml: str = "",
) -> str:
    """Render AndroidWorld UI elements into the pseudo-XML used across OmniFlow."""

    if not ui_elements:
        return empty_xml

    bool_attrs: Dict[str, str] = {
        "clickable": "is_clickable",
        "scrollable": "is_scrollable",
        "long-clickable": "is_long_clickable",
        "editable": "is_editable",
        "focused": "is_focused",
        "focusable": "is_focusable",
        "enabled": "is_enabled",
        "visible": "is_visible",
        "selected": "is_selected",
        "checked": "is_checked",
        "checkable": "is_checkable",
        "password": "is_password",
        "multiline": "is_multi_line",
        "heading": "is_heading",
        "visible-to-user": "is_visible_to_user",
        "important-for-accessibility": "is_important_for_accessibility",
    }

    node_lines = []
    root_package = ""
    max_x = 0.0
    max_y = 0.0
    for idx, elem in enumerate(ui_elements):
        bbox = read_attr(elem, "bbox_pixels")
        box = ui_bbox_to_jsonable(bbox)
        if box is not None:
            max_x = max(max_x, float(box["x_max"]))
            max_y = max(max_y, float(box["y_max"]))

        package_name = str(read_attr(elem, "package_name", "") or "").strip()
        if package_name and not root_package:
            root_package = package_name

        attrs = {
            "id": str(idx),
            "class": escape_xml_text(read_attr(elem, "class_name", "")),
            "text": escape_xml_text(read_attr(elem, "text", "")),
            "hint-text": escape_xml_text(read_attr(elem, "hint_text", "")),
            "content-desc": escape_xml_text(read_attr(elem, "content_description", "")),
            "tooltip": escape_xml_text(read_attr(elem, "tooltip", "")),
            "resource-id": escape_xml_text(read_attr(elem, "resource_name", "")),
            "resource-id-raw": escape_xml_text(read_attr(elem, "resource_id", "")),
            "package": escape_xml_text(package_name),
            "bounds": escape_xml_text(ui_element_bounds_text(elem)),
        }
        for xml_key, field_name in bool_attrs.items():
            default_value = (
                True
                if field_name in {"is_enabled", "is_visible", "is_visible_to_user"}
                else False
            )
            attrs[xml_key] = str(
                bool(read_attr(elem, field_name, default_value))
            ).lower()
        attr_text = " ".join(f'{key}="{value}"' for key, value in attrs.items())
        node_lines.append(f"    <node {attr_text} />")

    width = max(1, int(round(max_x)))
    height = max(1, int(round(max_y)))
    root_bounds = f"[0,0][{width},{height}]"

    parts = ["<hierarchy>"]
    parts.append(
        '  <node id="__aw_root__" class="android.view.ViewRootImpl" text="" '
        f'package="{escape_xml_text(root_package)}" bounds="{root_bounds}" '
        'clickable="false" enabled="true" visible="true">'
    )
    parts.extend(node_lines)
    parts.append("  </node>")
    parts.append("</hierarchy>")
    return "\n".join(parts)


def capture_xml(
    *,
    env: Any,
    page: Any,
) -> str | None:
    """Materialize one OmniFlow XML snapshot from an AndroidWorld page/state.

    Args:
        env: AndroidWorld environment object kept only for compat-layer call shape.
        page: Either an `AndroidWorldPageSnapshot` or one raw AndroidWorld
            `State`-like object carrying `ui_elements`.

    Returns:
        Existing XML when the page already exposes it, otherwise pseudo-XML
        rendered from `ui_elements`. Returns `None` when neither exists.
    """

    del env
    xml_text = str(getattr(page, "xml", "") or "").strip()
    if not xml_text and hasattr(page, "state"):
        xml_text = str(getattr(getattr(page, "state", None), "xml", "") or "").strip()
    if xml_text:
        return xml_text

    ui_elements = getattr(page, "ui_elements", None)
    if ui_elements:
        return ui_elements_to_pseudo_xml(list(ui_elements or []))

    fallback_page = getattr(page, "raw_state", None)
    if fallback_page is None and hasattr(page, "state"):
        fallback_page = getattr(page, "state", None)
    if fallback_page is None:
        return None
    ui_elements = getattr(fallback_page, "ui_elements", None)
    if not ui_elements:
        return None
    return ui_elements_to_pseudo_xml(list(ui_elements or []))


def capture_current_page(
    *,
    env: Any,
    adb_serial: str = "",
) -> AndroidWorldPageSnapshot:
    """Capture one real-time AndroidWorld page snapshot.

    Args:
        env: Live AndroidWorld environment object that exposes `get_state(...)`.
        adb_serial: Target device serial used by the direct adapter XML reader.

    Returns:
        One normalized snapshot built from the freshly-read AndroidWorld state.
        This function intentionally does not retain any host-level page cache.
    """

    state = capture_adapter_state(
        env=env,
        adb_serial=adb_serial,
    )
    if state is None:
        state = env.get_state()

    activity_name = str(getattr(env, "foreground_activity_name", "") or "")
    snapshot = AndroidWorldPageSnapshot(
        state=state,
        pixels=getattr(state, "pixels", None),
        forest=getattr(state, "forest", None),
        ui_elements=ui_elements_to_jsonable(
            list(getattr(state, "ui_elements", []) or [])
        ),
        activity_name=activity_name,
        package_name=_activity_to_package(activity_name),
        stable=False,
    )
    raw_activity_name = str(getattr(state, "activity_name", "") or "").strip()
    if raw_activity_name:
        snapshot.activity_name = raw_activity_name
    raw_package_name = str(getattr(state, "package_name", "") or "").strip()
    if raw_package_name:
        snapshot.package_name = raw_package_name
    elif snapshot.activity_name:
        snapshot.package_name = _activity_to_package(snapshot.activity_name)
    return snapshot


def _import_aw_agent_result_cls() -> Optional[Any]:
    candidates = (
        "android_world.agents.base_agent",
        "android_world.agents.env_interacting_agent",
    )
    for module_name in candidates:
        try:
            module = importlib.import_module(module_name)
        except Exception:
            continue
        cls = getattr(module, "AgentInteractionResult", None)
        if cls is not None:
            return cls
    return None


_AW_AGENT_RESULT_CLS: Optional[Any] = None


def _get_aw_agent_result_cls() -> Optional[Any]:
    global _AW_AGENT_RESULT_CLS
    if _AW_AGENT_RESULT_CLS is not None:
        return _AW_AGENT_RESULT_CLS
    cls = _import_aw_agent_result_cls()
    if cls is not None:
        _AW_AGENT_RESULT_CLS = cls
    return cls


def import_json_action_module() -> Optional[Any]:
    """Import AndroidWorld's JSON action module when available."""

    try:
        return importlib.import_module("android_world.env.json_action")
    except Exception:
        return None


def _enum_member(enum_obj: Any, name: str) -> Any:
    if enum_obj is None:
        return name.lower()
    if hasattr(enum_obj, name):
        return getattr(enum_obj, name)
    lowered = name.lower()
    if hasattr(enum_obj, lowered):
        return getattr(enum_obj, lowered)
    return lowered


def _build_json_action(json_action_module: Any, **kwargs: Any) -> Any:
    action_cls = getattr(json_action_module, "JSONAction")
    signature = inspect.signature(action_cls)
    payload = {
        key: value
        for key, value in kwargs.items()
        if key in signature.parameters and value is not None
    }
    return action_cls(**payload)


def _fallback_action_dict(action_type: str, **kwargs: Any) -> Dict[str, Any]:
    payload = {"action_type": action_type}
    payload.update({key: value for key, value in kwargs.items() if value is not None})
    return payload


def make_status_action(
    goal_status: str, *, json_action_module: Optional[Any] = None
) -> Any:
    """Build one AndroidWorld status action compatible with upstream/result mocks."""

    module = json_action_module or import_json_action_module()
    if module is not None:
        try:
            return _build_json_action(
                module,
                action_type=_enum_member(getattr(module, "ActionType", None), "STATUS"),
                goal_status=goal_status,
            )
        except Exception:
            logger.debug("android_world status action build failed", exc_info=True)
    return _fallback_action_dict("status", goal_status=goal_status)


def make_agent_result(done: bool, data: Dict[str, Any]) -> Any:
    """Build the AndroidWorld-compatible result envelope used by the host bridge."""

    result_cls = _get_aw_agent_result_cls()
    if result_cls is not None:
        try:
            return result_cls(done=done, data=data)
        except Exception:
            logger.debug("AgentInteractionResult build failed", exc_info=True)
    return {"done": bool(done), "data": dict(data or {})}


def extract_agent_interaction_result(
    result: Any,
) -> Optional[Tuple[bool, Dict[str, Any]]]:
    """Extract the stable `(done, data)` pair from AndroidWorld-style results."""

    if result is None:
        return None
    if isinstance(result, tuple) and len(result) == 2 and isinstance(result[1], dict):
        return bool(result[0]), dict(result[1] or {})
    if isinstance(result, dict) and isinstance(result.get("data"), dict):
        return bool(result.get("done", False)), dict(result.get("data") or {})
    if (
        hasattr(result, "done")
        and hasattr(result, "data")
        and isinstance(getattr(result, "data", None), dict)
    ):
        return bool(getattr(result, "done", False)), dict(getattr(result, "data") or {})
    return None


def _raw_android_world_action_payload(action: Any) -> dict[str, Any] | None:
    if isinstance(action, UnknownAction):
        payload = action.params.get(_RAW_ANDROID_WORLD_PAYLOAD_KEY)
        return dict(payload) if isinstance(payload, dict) else None
    if isinstance(action, dict):
        payload = action.get("params")
        if str(
            action.get("type") or ""
        ).strip() == _RAW_ANDROID_WORLD_ACTION_TYPE and isinstance(payload, dict):
            raw_payload = payload.get(_RAW_ANDROID_WORLD_PAYLOAD_KEY)
            return dict(raw_payload) if isinstance(raw_payload, dict) else None
        if str(action.get("action_type") or "").strip():
            return dict(action)
    return None


def android_world_action_to_utg_action(
    action: Any,
    *,
    ui_elements: Sequence[Any] | None = None,
) -> dict[str, Any]:
    """Wrap one AndroidWorld backend action as the formal action routed through control.

    Args:
        action: AndroidWorld JSON action object or dict emitted by an upstream
            step-only backend.
        ui_elements: Optional current page UI elements. When AndroidWorld emits
            index-based actions, the bridge resolves the indexed target to a
            replayable center-point action when possible.

    Returns:
        A JSON-safe UTG action payload. When AndroidWorld semantics cannot be
        represented losslessly as a canonical UTG action, the payload is wrapped as
        `type="android_world_raw"` with the original AndroidWorld action preserved.
    """

    raw = (
        dict(action)
        if isinstance(action, dict)
        else {
            key: value
            for key in (
                "action_type",
                "x",
                "y",
                "index",
                "text",
                "direction",
                "app_name",
                "package_name",
                "goal_status",
                "keycode",
                "seconds",
                "time_s",
            )
            if hasattr(action, key)
            for value in [getattr(action, key)]
            if value is not None
        }
    )
    action_type = str(raw.get("action_type") or "").strip().lower()
    action_index = safe_int(raw.get("index"))
    indexed_target = None
    if (
        action_index is not None
        and action_index >= 0
        and isinstance(ui_elements, Sequence)
        and action_index < len(ui_elements)
    ):
        indexed_target = ui_elements[action_index]

    if (
        action_type in {"click", "tap"}
        and raw.get("x") is not None
        and raw.get("y") is not None
    ):
        return {
            "type": "click",
            "params": {"x": raw.get("x"), "y": raw.get("y")},
        }
    if action_type in {"click", "tap"} and indexed_target is not None:
        center = ui_element_center(indexed_target)
        if center is not None:
            return {
                "type": "click",
                "params": {"x": center[0], "y": center[1]},
            }
    if (
        action_type in {"long_press", "longpress"}
        and raw.get("x") is not None
        and raw.get("y") is not None
    ):
        return {
            "type": "long_press",
            "params": {"x": raw.get("x"), "y": raw.get("y")},
        }
    if action_type in {"long_press", "longpress"} and indexed_target is not None:
        center = ui_element_center(indexed_target)
        if center is not None:
            return {
                "type": "long_press",
                "params": {"x": center[0], "y": center[1]},
            }
    if action_type in {"navigate_back", "back", "press_back"}:
        return {"type": "press_back", "params": {}}
    if action_type in {"navigate_home", "home", "press_home"}:
        return {"type": "press_home", "params": {}}
    if action_type in {"wait"} and (
        raw.get("seconds") is not None or raw.get("time_s") is not None
    ):
        wait_seconds = raw.get("seconds", raw.get("time_s"))
        return {"type": "wait", "params": {"time_s": wait_seconds}}
    if (
        action_type in {"scroll", "swipe"}
        and raw.get("x") is not None
        and raw.get("y") is not None
    ):
        return {
            "type": "swipe",
            "params": {
                "x": raw.get("x"),
                "y": raw.get("y"),
                "direction": str(raw.get("direction") or "down"),
                "distance": int(raw.get("distance") or 800),
            },
        }
    if action_type in {"scroll", "swipe"} and indexed_target is not None:
        center = ui_element_center(indexed_target)
        if center is not None:
            return {
                "type": "swipe",
                "params": {
                    "x": center[0],
                    "y": center[1],
                    "direction": str(raw.get("direction") or "down"),
                    "distance": int(raw.get("distance") or 800),
                },
            }
    if action_type == "input_text" and raw.get("text") is not None:
        return {
            "type": "input_text",
            "params": {"text": str(raw.get("text") or "")},
        }
    if action_type == "open_app" and raw.get("package_name") is not None:
        return {
            "type": "open_app",
            "params": {"package_name": str(raw.get("package_name") or "")},
        }
    if action_type == "open_app" and raw.get("app_name") is not None:
        package_name = ""
        try:
            adb_utils = importlib.import_module("android_world.env.adb_utils")
            get_adb_activity = getattr(adb_utils, "get_adb_activity", None)
            if callable(get_adb_activity):
                activity_name = str(
                    get_adb_activity(str(raw.get("app_name") or "").strip()) or ""
                ).strip()
                package_name = activity_name.split("/", 1)[0].strip()
        except Exception:
            logger.debug(
                "android_world open_app app_name resolve failed", exc_info=True
            )
        if package_name:
            return {
                "type": "open_app",
                "params": {"package_name": package_name},
            }
    return {
        "type": _RAW_ANDROID_WORLD_ACTION_TYPE,
        "params": {_RAW_ANDROID_WORLD_PAYLOAD_KEY: raw},
    }


def utg_action_to_android_world_action(
    action: AnyAction,
    *,
    click_node_resolver: Optional[Callable[[str], Tuple[float, float]]] = None,
    json_action_module: Optional[Any] = None,
) -> Optional[Any]:
    """Convert one canonical UTG action into the AndroidWorld execution payload."""

    raw_payload = _raw_android_world_action_payload(action)
    if raw_payload is not None:
        return raw_payload

    action = normalize_action(action)
    module = json_action_module or import_json_action_module()
    action_type_enum = getattr(module, "ActionType", None) if module else None
    scroll_enum = getattr(module, "ScrollDirection", None) if module else None

    if isinstance(action, ClickAction):
        x = float(action.params["x"])
        y = float(action.params["y"])
        if module is not None:
            return _build_json_action(
                module, action_type=_enum_member(action_type_enum, "CLICK"), x=x, y=y
            )
        return _fallback_action_dict("click", x=x, y=y)

    if isinstance(action, ClickNodeAction):
        if click_node_resolver is None:
            raise ValueError(
                "click_node requires click_node_resolver(node_id) -> (x, y)"
            )
        x, y = click_node_resolver(action.params["node_id"])
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "CLICK"),
                x=float(x),
                y=float(y),
            )
        return _fallback_action_dict("click", x=float(x), y=float(y))

    if isinstance(action, LongPressAction):
        x = float(action.params["x"])
        y = float(action.params["y"])
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "LONG_PRESS"),
                x=x,
                y=y,
            )
        return _fallback_action_dict("long_press", x=x, y=y)

    if isinstance(action, InputTextAction):
        text = str(action.params["text"])
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "INPUT_TEXT"),
                text=text,
            )
        return _fallback_action_dict("input_text", text=text)

    if isinstance(action, SwipeAction):
        params = (
            action.params.model_dump()
            if hasattr(action.params, "model_dump")
            else dict(action.params)
        )
        raw_direction = params["direction"]
        direction = str(getattr(raw_direction, "value", raw_direction)).lower()
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "SCROLL"),
                x=float(params["x"]),
                y=float(params["y"]),
                direction=_enum_member(scroll_enum, direction.upper()),
            )
        return _fallback_action_dict(
            "scroll", x=float(params["x"]), y=float(params["y"]), direction=direction
        )

    if isinstance(action, OpenAppAction):
        package_name = str(action.params["package_name"])
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "OPEN_APP"),
                app_name=package_name,
                package_name=package_name,
            )
        return _fallback_action_dict(
            "open_app", app_name=package_name, package_name=package_name
        )

    if isinstance(action, PressKeyAction):
        key = device_key_value(action.params["key"])
        if key == "home":
            if module is not None:
                return _build_json_action(
                    module, action_type=_enum_member(action_type_enum, "NAVIGATE_HOME")
                )
            return _fallback_action_dict("navigate_home")
        if key == "back":
            if module is not None:
                return _build_json_action(
                    module, action_type=_enum_member(action_type_enum, "NAVIGATE_BACK")
                )
            return _fallback_action_dict("navigate_back")
        if key == "enter":
            if module is not None:
                return _build_json_action(
                    module,
                    action_type=_enum_member(action_type_enum, "KEYBOARD_ENTER"),
                )
            return _fallback_action_dict("keyboard_enter")
        raise ValueError(f"unsupported press_key for AndroidWorld host adapter: {key}")

    if isinstance(action, WaitAction):
        seconds = float(action.params.get("time_s", action.params.get("seconds", 1.0)))
        if module is not None:
            return _build_json_action(
                module,
                action_type=_enum_member(action_type_enum, "WAIT"),
                seconds=seconds,
            )
        return _fallback_action_dict("wait", seconds=seconds)

    return None


def coerce_android_world_action_for_execution(
    action: Any, *, json_action_module: Optional[Any] = None
) -> Any:
    """Convert raw AndroidWorld action dicts into JSONAction instances when possible."""

    module = json_action_module or import_json_action_module()
    if module is None or not isinstance(action, dict):
        return action
    action_type = str(action.get("action_type") or "").strip()
    if not action_type:
        return action
    params = dict(action)
    params.pop("action_type", None)
    return _build_json_action(module, action_type=action_type, **params)


__all__ = [
    "AndroidWorldPageSnapshot",
    "android_world_action_to_utg_action",
    "capture_adapter_state",
    "capture_current_page",
    "coerce_android_world_action_for_execution",
    "extract_agent_interaction_result",
    "import_json_action_module",
    "make_agent_result",
    "make_status_action",
    "page_pixels_to_image_data_url",
    "ui_bbox_to_jsonable",
    "ui_element_bounds_text",
    "ui_element_center",
    "ui_element_to_jsonable",
    "ui_elements_to_jsonable",
    "ui_elements_to_pseudo_xml",
    "utg_action_to_android_world_action",
]
