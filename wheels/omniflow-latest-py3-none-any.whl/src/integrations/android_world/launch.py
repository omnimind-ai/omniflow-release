from __future__ import annotations

import argparse
import asyncio
from datetime import datetime, timezone
import importlib
import logging
import os
from pathlib import Path
import pickle
import sys
from time import perf_counter
import types
from typing import Any, Sequence

from src.foundation.paths import get_runtime_file
from src.foundation.source_tools import read_env_text, to_serializable
from src.integrations.android_world.agent import (
    MODE_UTG_ONLY,
    build_agent,
)
from src.integrations.android_world.host import capture_adapter_state
from src.utg.log.run_logger import UTGRunLogger

OMNIFLOW_ROOT = Path(__file__).resolve().parents[3]
logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    """Return one UTC ISO timestamp for JSONL sidecar records."""

    return datetime.now(timezone.utc).isoformat()


def _default_adb_path() -> str:
    candidates = [
        os.path.expanduser("~/Library/Android/sdk/platform-tools/adb"),
        os.path.expanduser("~/Android/Sdk/platform-tools/adb"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return ""


def _add_android_world_path(android_world_root: Path) -> None:
    root = str(android_world_root.resolve())
    if root not in sys.path:
        sys.path.insert(0, root)


def _patch_contacts_draft_success_eval(
    suite: Any,
    *,
    adb_serial: str,
) -> None:
    """Patch Contacts draft success checks when AndroidWorld drops a11y forest.

    Args:
        suite: AndroidWorld suite object returned by `suite_utils.create_suite(...)`.
            The helper mutates matching task instances in-place before evaluation.
        adb_serial: Device serial used when OmniFlow falls back to its direct
            adapter XML/UI capture for the final success check.
    """

    try:
        contacts_module = importlib.import_module(
            "android_world.task_evals.single.contacts"
        )
    except Exception:
        return
    draft_cls = getattr(contacts_module, "ContactsNewContactDraft", None)
    contact_info_is_entered = getattr(contacts_module, "_contact_info_is_entered", None)
    if draft_cls is None or not callable(contact_info_is_entered):
        return

    for task_instances in list(getattr(suite, "values", lambda: [])() or []):
        for task in list(task_instances or []):
            if not isinstance(task, draft_cls):
                continue
            original_is_successful = getattr(task, "is_successful", None)
            if not callable(original_is_successful):
                continue
            if getattr(task, "_omniflow_contacts_draft_patch", False):
                continue

            def _patched_is_successful(self, env, _original=original_is_successful):
                try:
                    return _original(env)
                except AttributeError as exc:
                    if "windows" not in str(exc):
                        raise
                    state = env.get_state()
                    ui_elements = list(getattr(state, "ui_elements", []) or [])
                    if not ui_elements:
                        fallback_state = capture_adapter_state(
                            env=env,
                            adb_serial=adb_serial,
                        )
                        ui_elements = list(
                            getattr(fallback_state, "ui_elements", []) or []
                        )
                    if not ui_elements:
                        raise
                    logging.warning(
                        "ContactsNewContactDraft success check fell back to ui_elements because a11y forest was missing."
                    )
                    return (
                        1.0
                        if contact_info_is_entered(
                            first=str((self.params or {}).get("first") or ""),
                            last=str((self.params or {}).get("last") or ""),
                            phone=str((self.params or {}).get("phone") or ""),
                            phone_label=str(
                                (self.params or {}).get("phone_label") or ""
                            ),
                            ui_elements=ui_elements,
                        )
                        else 0.0
                    )

            task.is_successful = types.MethodType(_patched_is_successful, task)
            task._omniflow_contacts_draft_patch = True


def _maybe_patch_sqlite_backend() -> None:
    backend = (
        str(read_env_text("OMNIFLOW_ANDROIDWORLD_SQLITE_BACKEND") or "auto")
        .strip()
        .lower()
    )
    if backend not in {"auto", "pysqlite3"}:
        return
    try:
        import pysqlite3.dbapi2 as sqlite3_backend
    except Exception as exc:
        if backend == "pysqlite3":
            raise
        print(f"[warn] sqlite backend fallback to stdlib: {exc}", file=sys.stderr)
        return
    sys.modules["sqlite3"] = sqlite3_backend
    print("[info] sqlite_backend=pysqlite3", file=sys.stderr)


def _is_pickleable(value: object) -> bool:
    try:
        pickle.dumps(value)
    except Exception:
        return False
    return True


def _sanitize_for_checkpoint(value: object) -> object:
    if _is_pickleable(value):
        return value
    if isinstance(value, dict):
        return {key: _sanitize_for_checkpoint(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_for_checkpoint(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _sanitize_for_checkpoint(value.model_dump())
        except Exception:
            pass
    if hasattr(value, "to_dict"):
        try:
            return _sanitize_for_checkpoint(value.to_dict())
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        try:
            return {
                key: _sanitize_for_checkpoint(item)
                for key, item in dict(value.__dict__).items()
                if not key.startswith("_")
            }
        except Exception:
            pass
    return repr(value)


class _SanitizingCheckpointer:
    def __init__(self, delegate: object) -> None:
        self._delegate = delegate
        self.directory = getattr(delegate, "directory", "")

    def save_episodes(
        self, task_episodes: list[dict[str, object]], task_name: str
    ) -> None:
        sanitized = [_sanitize_for_checkpoint(episode) for episode in task_episodes]
        self._delegate.save_episodes(sanitized, task_name)

    def load(self, fields: list[str] | None = None):
        return self._delegate.load(fields=fields)


def _build_official_androidworld_agent(
    *,
    env: Any,
    official_agent_name: str,
) -> Any:
    """Build one upstream AndroidWorld agent for eval-only compile-miss fallback.

    Args:
        env: AndroidWorld environment already created by `env_launcher`.
        official_agent_name: Upstream AndroidWorld agent name. Empty value falls
            back to the same default as upstream `run.py`.

    Returns:
        One upstream AndroidWorld agent instance bound to the current env.
    """

    from android_world.agents import human_agent, infer, m3a, random_agent, seeact, t3a

    resolved_name = str(official_agent_name or "").strip() or "m3a_gpt4v"
    if resolved_name == "human_agent":
        agent = human_agent.HumanAgent(env)
    elif resolved_name == "random_agent":
        agent = random_agent.RandomAgent(env)
    elif resolved_name == "m3a_gemini_gcp":
        agent = m3a.M3A(
            env,
            infer.GeminiGcpWrapper(model_name="gemini-1.5-pro-latest"),
        )
    elif resolved_name == "t3a_gemini_gcp":
        agent = t3a.T3A(
            env,
            infer.GeminiGcpWrapper(model_name="gemini-1.5-pro-latest"),
        )
    elif resolved_name == "t3a_gpt4":
        agent = t3a.T3A(env, infer.Gpt4Wrapper("gpt-4-turbo-2024-04-09"))
    elif resolved_name == "m3a_gpt4v":
        agent = m3a.M3A(env, infer.Gpt4Wrapper("gpt-4-turbo-2024-04-09"))
    elif resolved_name == "seeact":
        agent = seeact.SeeAct(env)
    else:
        raise ValueError(f"Unknown AndroidWorld official agent: {resolved_name}")
    agent.name = resolved_name
    return agent


def _enable_official_agent_fallback(
    primary_agent: Any,
    *,
    official_agent: Any,
    official_agent_name: str,
) -> Any:
    """Attach sticky official-agent fallback onto one compile-first benchmark agent.

    Args:
        primary_agent: Compile-first agent returned by `build_agent(...)`.
        official_agent: Upstream AndroidWorld agent used after the first miss.
        official_agent_name: Stable label written into benchmark/debug metadata.

    Returns:
        The same `primary_agent` instance after in-place method patching.
    """

    original_step = getattr(primary_agent, "step", None)
    original_reset = getattr(primary_agent, "reset", None)
    original_set_max_steps = getattr(primary_agent, "set_max_steps", None)
    if not callable(original_step):
        raise TypeError("primary_agent must expose callable step(goal)")
    fallback_state = {"active": False}
    resolved_name = (
        str(official_agent_name or "").strip()
        or str(getattr(official_agent, "name", "") or "official_agent").strip()
    )

    def _annotate_fallback_result(
        fallback_result: Any,
        *,
        primary_step_result: Any | None,
        delegate_source: str,
    ) -> Any:
        step_data = dict(getattr(fallback_result, "data", {}) or {})
        compile_first = {
            "delegate_source": delegate_source,
            "official_agent_name": resolved_name,
        }
        if primary_step_result is not None:
            compile_first.update(
                {
                    "kind": getattr(primary_step_result, "kind", None),
                    "compile_hit": bool(
                        getattr(primary_step_result, "compile_hit", False)
                    ),
                    "execution_route": getattr(
                        primary_step_result, "execution_route", None
                    ),
                    "hook_required": bool(
                        getattr(primary_step_result, "hook_required", False)
                    ),
                    "fallback_allowed": bool(
                        getattr(primary_step_result, "fallback_allowed", False)
                    ),
                    "summary": dict(getattr(primary_step_result, "data", {}) or {}).get(
                        "summary"
                    ),
                }
            )
        step_data["compile_first"] = to_serializable(compile_first)
        step_data["fallback_delegate"] = {
            "agent_name": resolved_name,
            "active": True,
        }
        setattr(fallback_result, "data", step_data)
        return fallback_result

    def _hybrid_step(goal: str) -> Any:
        if fallback_state["active"]:
            return _annotate_fallback_result(
                official_agent.step(goal),
                primary_step_result=None,
                delegate_source="sticky_official_fallback",
            )
        primary_step_result = original_step(goal)
        should_delegate = bool(getattr(primary_step_result, "hook_required", False))
        if not should_delegate:
            execution_route = str(
                getattr(primary_step_result, "execution_route", "") or ""
            ).strip()
            should_delegate = execution_route == "vlm" and bool(
                getattr(primary_step_result, "fallback", False)
            )
        if not should_delegate:
            return primary_step_result
        fallback_state["active"] = True
        return _annotate_fallback_result(
            official_agent.step(goal),
            primary_step_result=primary_step_result,
            delegate_source="compile_miss",
        )

    def _hybrid_reset(go_home: bool = False) -> None:
        fallback_state["active"] = False
        if callable(original_reset):
            original_reset(go_home=bool(go_home))
        fallback_reset = getattr(official_agent, "reset", None)
        if callable(fallback_reset):
            fallback_reset(bool(go_home))

    def _hybrid_set_max_steps(step_budget: int) -> None:
        if callable(original_set_max_steps):
            original_set_max_steps(step_budget)
        fallback_set_max_steps = getattr(official_agent, "set_max_steps", None)
        if callable(fallback_set_max_steps):
            fallback_set_max_steps(step_budget)

    primary_agent.step = _hybrid_step
    primary_agent.reset = _hybrid_reset
    primary_agent.set_max_steps = _hybrid_set_max_steps
    primary_agent.name = f"{str(getattr(primary_agent, 'name', '') or MODE_UTG_ONLY).strip()}+{resolved_name}"
    primary_agent.miss_policy = "official_agent"
    primary_agent.official_agent_name = resolved_name
    return primary_agent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run AndroidWorld from OmniFlow with the minimal compile-first launcher."
    )
    parser.add_argument("--android-world-root", required=True)
    parser.add_argument("--suite-family", default="android_world")
    parser.add_argument("--tasks", default="ContactsAddContact")
    parser.add_argument("--max-steps", type=int, default=20)
    parser.add_argument("--task-random-seed", type=int, default=30)
    parser.add_argument("--n-task-combinations", type=int, default=1)
    parser.add_argument("--console-port", type=int, default=5554)
    parser.add_argument("--adb-path", default=_default_adb_path())
    parser.add_argument("--perform-emulator-setup", action="store_true")
    parser.add_argument("--fixed-task-seed", action="store_true")
    parser.add_argument("--checkpoint-dir", default="")
    parser.add_argument(
        "--miss-policy",
        default="return_handoff",
        choices=("return_handoff", "official_agent"),
        help=(
            "Compile miss policy. `return_handoff` keeps compile-first mainline; "
            "`official_agent` wraps the launcher with one upstream AndroidWorld "
            "agent for benchmark-only fallback."
        ),
    )
    parser.add_argument(
        "--official-agent-name",
        default="",
        help=(
            "Upstream AndroidWorld agent used only when --miss-policy=official_agent. "
            "Examples: m3a_gpt4v, t3a_gpt4, seeact, random_agent, human_agent."
        ),
    )
    parser.add_argument(
        "--output-path",
        default=str(
            (OMNIFLOW_ROOT / "runtime" / "logs" / "androidworld_runs").resolve()
        ),
    )
    parser.add_argument(
        "--utg-store-path",
        default=str((OMNIFLOW_ROOT / "runtime" / "utg" / "utg_store.json").resolve()),
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    resolved_miss_policy = (
        str(args.miss_policy or "return_handoff").strip().lower() or "return_handoff"
    )
    android_world_root = Path(args.android_world_root).expanduser().resolve()
    run_py = android_world_root / "run.py"
    if not run_py.exists():
        raise FileNotFoundError(f"run.py not found under {android_world_root}")

    previous_action_effect_enabled = os.environ.get("UTG_ACTION_EFFECT_ENABLED")
    previous_terminal_verify = os.environ.get("UTG_EXPLICIT_TERMINAL_NODE_VERIFY")
    os.environ.setdefault("UTG_ACTION_EFFECT_ENABLED", "0")
    os.environ.setdefault("UTG_EXPLICIT_TERMINAL_NODE_VERIFY", "0")

    env = None
    original_allocate_step_budget = None
    original_run_task = None
    original_get_controller = None
    try:
        _maybe_patch_sqlite_backend()
        _add_android_world_path(android_world_root)

        from android_world import checkpointer as checkpointer_lib
        from android_world import registry, suite_utils
        from android_world.env import android_world_controller, env_launcher
        from android_world.utils import datetime_utils

        original_get_controller = getattr(
            android_world_controller, "get_controller", None
        )
        if callable(original_get_controller):

            def _get_controller_without_reinstall(
                console_port: int = 5554,
                adb_path: str = android_world_controller.DEFAULT_ADB_PATH,
                grpc_port: int = 8554,
            ):
                """Construct one AndroidWorld controller without re-installing the forwarder app.

                Args:
                    console_port: Emulator console port used by AndroidEnv.
                    adb_path: Absolute or shell-resolved adb binary path.
                    grpc_port: Emulator gRPC port paired with the console port.

                Returns:
                    An `AndroidWorldController` that keeps the upstream a11y
                    forwarder method but skips the re-install step, which can
                    stall emulator initialization on already-provisioned devices.
                """

                config = android_world_controller.config_classes.AndroidEnvConfig(
                    task=android_world_controller.config_classes.FilesystemTaskConfig(
                        path=android_world_controller._write_default_task_proto()
                    ),
                    simulator=android_world_controller.config_classes.EmulatorConfig(
                        emulator_launcher=android_world_controller.config_classes.EmulatorLauncherConfig(
                            emulator_console_port=console_port,
                            adb_port=console_port + 1,
                            grpc_port=grpc_port,
                        ),
                        adb_controller=android_world_controller.config_classes.AdbControllerConfig(
                            adb_path=adb_path
                        ),
                    ),
                )
                android_env_instance = android_world_controller.loader.load(config)
                logging.info("Setting up AndroidWorldController.")
                controller_kwargs: dict[str, object] = {
                    "install_a11y_forwarding_app": False,
                    "a11y_method": android_world_controller.A11yMethod.UIAUTOMATOR,
                }
                return android_world_controller.AndroidWorldController(
                    android_env_instance,
                    **controller_kwargs,
                )

            android_world_controller.get_controller = _get_controller_without_reinstall

        original_allocate_step_budget = getattr(
            suite_utils, "_allocate_step_budget", None
        )
        fixed_max_steps = max(1, int(args.max_steps))
        if callable(original_allocate_step_budget):
            suite_utils._allocate_step_budget = lambda task_complexity: fixed_max_steps

        original_set_datetime = datetime_utils.set_datetime

        def _safe_set_datetime(controller: object, dt: object) -> None:
            """Best-effort device time freeze for hosts that cannot set system time.

            Args:
                controller: AndroidWorld device controller.
                dt: Target datetime requested by the task initializer.
            """

            try:
                original_set_datetime(controller, dt)
            except Exception as exc:  # noqa: BLE001
                message = str(exc or "")
                if "Operation not permitted" in message or "cannot set date" in message:
                    logger.warning(
                        "skip AndroidWorld set_datetime due to host/device permission: %s",
                        message,
                    )
                    return
                raise

        datetime_utils.set_datetime = _safe_set_datetime

        env = env_launcher.load_and_setup_env(
            console_port=int(args.console_port),
            emulator_setup=bool(args.perform_emulator_setup),
            adb_path=str(args.adb_path or ""),
            grpc_port=int(args.console_port) + 3000,
        )

        task_registry = registry.TaskRegistry()
        suite = suite_utils.create_suite(
            task_registry.get_registry(family=args.suite_family),
            n_task_combinations=int(args.n_task_combinations),
            seed=int(args.task_random_seed),
            tasks=[item.strip() for item in str(args.tasks).split(",") if item.strip()],
            use_identical_params=bool(args.fixed_task_seed),
        )
        suite.suite_family = args.suite_family
        _patch_contacts_draft_success_eval(
            suite,
            adb_serial=str(
                os.environ.get("ANDROID_SERIAL") or f"emulator-{int(args.console_port)}"
            ).strip(),
        )

        agent = build_agent(
            env=env,
            utg_store_path=args.utg_store_path,
            adb_serial=str(
                os.environ.get("ANDROID_SERIAL") or f"emulator-{int(args.console_port)}"
            ).strip(),
        )
        if resolved_miss_policy == "official_agent":
            official_agent = _build_official_androidworld_agent(
                env=env,
                official_agent_name=str(args.official_agent_name or ""),
            )
            agent = _enable_official_agent_fallback(
                agent,
                official_agent=official_agent,
                official_agent_name=str(args.official_agent_name or ""),
            )

        checkpoint_dir = (
            str(Path(args.checkpoint_dir).expanduser().resolve())
            if args.checkpoint_dir
            else checkpointer_lib.create_run_directory(args.output_path)
        )
        checkpointer = _SanitizingCheckpointer(
            checkpointer_lib.IncrementalCheckpointer(checkpoint_dir)
        )
        original_run_task = getattr(suite_utils, "_run_task", None)
        if callable(original_run_task):
            canonical_run_log_path = (
                Path(get_runtime_file("logs", "run_logs.jsonl")).expanduser().resolve()
            )
            canonical_run_logger = UTGRunLogger(
                enabled=True,
                path=str(canonical_run_log_path),
            )

            def _wrapped_run_task(task, run_episode, env, demo_mode):
                task_name = str(getattr(task, "name", "") or "human_task")
                result: dict[str, Any] | None = None
                goal_text = str(getattr(task, "goal", "") or getattr(task, "name", ""))
                started_at = _utc_now_iso()
                started_perf = perf_counter()
                existing_run_ids = {
                    str(item.get("run_id") or "").strip()
                    for item in canonical_run_logger.load_materialized_runs()
                    if str(item.get("run_id") or "").strip()
                }
                try:
                    result = original_run_task(task, run_episode, env, demo_mode)
                    return result
                finally:
                    # 保存 OmniFlow 收集的 run_log
                    try:
                        if hasattr(agent, "save_run_log") and callable(
                            agent.save_run_log
                        ):
                            task_success = (
                                float((result or {}).get("is_successful") or 0.0) > 0.5
                                if isinstance(result, dict)
                                else False
                            )
                            agent.save_run_log(
                                success=task_success,
                                done_reason="task_successful"
                                if task_success
                                else "task_failed",
                            )
                    except Exception as exc:
                        print(f"[warn] failed to save OmniFlow run_log: {exc}")

                    try:
                        if canonical_run_log_path.exists():
                            appended_events = [
                                dict(item)
                                for item in canonical_run_logger.load_materialized_runs()
                                if str(item.get("run_id") or "").strip()
                                not in existing_run_ids
                                and str(item.get("goal") or "").strip() == goal_text
                                and isinstance(item.get("steps"), list)
                            ]
                            if len(appended_events) > 1:
                                merged_steps: list[dict[str, Any]] = []
                                for event in appended_events:
                                    for step in list(event.get("steps") or []):
                                        step_payload = dict(step or {})
                                        step_payload["step_index"] = len(merged_steps)
                                        provider_detail = dict(
                                            step_payload.get("provider_detail") or {}
                                        )
                                        source_run_id = (
                                            str(event.get("run_id") or "").strip()
                                            or None
                                        )
                                        step_payload.setdefault(
                                            "source_run_id",
                                            source_run_id,
                                        )
                                        if source_run_id:
                                            provider_detail.setdefault(
                                                "source_run_id",
                                                source_run_id,
                                            )
                                        if provider_detail:
                                            step_payload["provider_detail"] = (
                                                provider_detail
                                            )
                                        merged_steps.append(step_payload)
                                final_observation = None
                                for event in reversed(appended_events):
                                    candidate = dict(
                                        event.get("final_observation") or {}
                                    )
                                    if candidate:
                                        final_observation = candidate
                                        break
                                task_success = False
                                if isinstance(result, dict):
                                    task_success = (
                                        float(result.get("is_successful") or 0.0) > 0.5
                                    )
                                aggregate_event = {
                                    # 聚合 run 统一通过 ingest_run_log 写回 canonical event stream
                                    "goal": goal_text,
                                    "success": task_success,
                                    "done_reason": str(
                                        appended_events[-1].get("done_reason")
                                        or (
                                            "task_successful"
                                            if task_success
                                            else "task_failed"
                                        )
                                    ),
                                    "started_at": str(
                                        appended_events[0].get("started_at")
                                        or started_at
                                    ),
                                    "finished_at": _utc_now_iso(),
                                    "duration_ms": max(
                                        0.0,
                                        (perf_counter() - started_perf) * 1000.0,
                                    ),
                                    "step_count": len(merged_steps),
                                    "steps": merged_steps,
                                    "final_observation": final_observation,
                                    "extra": {
                                        "suite_family": str(
                                            args.suite_family or ""
                                        ).strip(),
                                        "task_name": task_name,
                                        "task_seed": (
                                            dict(result or {}).get("seed")
                                            if isinstance(result, dict)
                                            else None
                                        ),
                                        "androidworld_task_aggregate": True,
                                        "aggregated_from_run_ids": [
                                            str(event.get("run_id") or "").strip()
                                            for event in appended_events
                                            if str(event.get("run_id") or "").strip()
                                        ],
                                        "aggregated_from_step_count": len(
                                            appended_events
                                        ),
                                        "aggregated_from": "suite_utils._run_task",
                                    },
                                }
                                from src.integrations.utg_api import ingest_run_log

                                asyncio.run(
                                    ingest_run_log(
                                        agent.runtime,
                                        run_log=to_serializable(aggregate_event),
                                        auto_import=False,
                                    )
                                )
                    except Exception as exc:  # noqa: BLE001
                        print(
                            f"[warn] failed to aggregate canonical run log for {task_name}: {exc}"
                        )

            suite_utils._run_task = _wrapped_run_task
        print(
            "Starting eval with "
            f"mainline={MODE_UTG_ONLY} max_steps={fixed_max_steps} "
            f"and writing to {checkpoint_dir}"
        )
        suite_utils.run(
            suite,
            agent,
            checkpointer=checkpointer,
            demo_mode=False,
        )
        print(
            f"Finished running mainline={MODE_UTG_ONLY} "
            f"max_steps={fixed_max_steps} on {args.suite_family} family. Wrote to {checkpoint_dir}."
        )
        return 0
    finally:
        if "android_world_controller" in locals() and callable(original_get_controller):
            android_world_controller.get_controller = original_get_controller
        if "suite_utils" in locals() and callable(original_allocate_step_budget):
            suite_utils._allocate_step_budget = original_allocate_step_budget
        if "suite_utils" in locals() and callable(original_run_task):
            suite_utils._run_task = original_run_task
        if "datetime_utils" in locals() and "original_set_datetime" in locals():
            datetime_utils.set_datetime = original_set_datetime
        if env is not None:
            env.close()
        if previous_action_effect_enabled is None:
            os.environ.pop("UTG_ACTION_EFFECT_ENABLED", None)
        else:
            os.environ["UTG_ACTION_EFFECT_ENABLED"] = previous_action_effect_enabled
        if previous_terminal_verify is None:
            os.environ.pop("UTG_EXPLICIT_TERMINAL_NODE_VERIFY", None)
        else:
            os.environ["UTG_EXPLICIT_TERMINAL_NODE_VERIFY"] = previous_terminal_verify


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
