"""
Infrastructure package root.
"""
