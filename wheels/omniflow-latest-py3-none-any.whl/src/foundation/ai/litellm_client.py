"""
Unified LLM client using LiteLLM.

Replaces scattered OpenAI/DashScope initialization with a single interface.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional

import litellm
from tenacity import retry, stop_after_attempt, wait_exponential

from src.foundation.config import config

logger = logging.getLogger(__name__)

# Suppress LiteLLM's verbose logging
litellm.suppress_debug_info = True


def get_model_name(provider: str, model: Optional[str] = None) -> str:
    """Get LiteLLM model name for a provider.

    Args:
        provider: Provider name (dashscope, openai, etc.)
        model: Optional model override.

    Returns:
        LiteLLM-compatible model string.
    """
    if provider == "dashscope":
        base_model = model or "qwen-turbo"
        # LiteLLM uses openai/ prefix with custom base_url for dashscope
        return f"openai/{base_model}"
    elif provider == "openai":
        return model or "gpt-4o-mini"
    else:
        return model or "gpt-4o-mini"


def get_api_config(provider: str) -> Dict[str, Any]:
    """Get API configuration for a provider.

    Args:
        provider: Provider name.

    Returns:
        Dict with api_key and optional api_base.
    """
    if provider == "dashscope":
        return {
            "api_key": config.DASHSCOPE_API_KEY.get_secret_value(),
            "api_base": config.DASHSCOPE_BASE_URL
            or "https://dashscope.aliyuncs.com/compatible-mode/v1",
        }
    elif provider == "openai":
        api_key = config.OPENAI_API_KEY.get_secret_value()
        if api_key:
            return {"api_key": api_key}
        return {}
    return {}


def complete(
    prompt: str,
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
    max_tokens: int = 2048,
) -> str:
    """Complete a prompt using LiteLLM.

    Args:
        prompt: The prompt text.
        provider: LLM provider (dashscope, openai).
        model: Optional model override.
        timeout: Request timeout in seconds.
        max_tokens: Maximum tokens in response.

    Returns:
        Completion text or empty string on failure.
    """
    model_name = get_model_name(provider, model)
    api_config = get_api_config(provider)

    try:
        response = litellm.completion(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            timeout=timeout,
            max_tokens=max_tokens,
            **api_config,
        )
        return response.choices[0].message.content or ""
    except Exception as exc:
        logger.warning("LLM completion failed: %s", exc)
        return ""


async def acomplete(
    prompt: str,
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
    max_tokens: int = 2048,
) -> str:
    """Async complete a prompt using LiteLLM.

    Args:
        prompt: The prompt text.
        provider: LLM provider (dashscope, openai).
        model: Optional model override.
        timeout: Request timeout in seconds.
        max_tokens: Maximum tokens in response.

    Returns:
        Completion text or empty string on failure.
    """
    model_name = get_model_name(provider, model)
    api_config = get_api_config(provider)

    try:
        response = await litellm.acompletion(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            timeout=timeout,
            max_tokens=max_tokens,
            **api_config,
        )
        return response.choices[0].message.content or ""
    except Exception as exc:
        logger.warning("LLM async completion failed: %s", exc)
        return ""


@retry(
    stop=stop_after_attempt(2),
    wait=wait_exponential(multiplier=1, min=1, max=4),
    reraise=False,
)
def complete_json(
    prompt: str,
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
) -> Dict[str, Any]:
    """Complete a prompt and parse JSON response.

    Args:
        prompt: The prompt text (should request JSON output).
        provider: LLM provider.
        model: Optional model override.
        timeout: Request timeout in seconds.

    Returns:
        Parsed JSON dict or empty dict on failure.
    """
    raw = complete(prompt, provider=provider, model=model, timeout=timeout)
    return extract_json(raw)


async def acomplete_vision(
    prompt: str,
    *,
    image_base64: Optional[str] = None,
    image_url: Optional[str] = None,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 60.0,
    max_tokens: int = 2048,
) -> str:
    """Async complete with vision (image) input using LiteLLM.

    Args:
        prompt: The text prompt.
        image_base64: Base64 encoded image (PNG/JPEG).
        image_url: Image URL (alternative to base64).
        provider: LLM provider (openai, dashscope).
        model: Optional model override (defaults to vision model).
        timeout: Request timeout in seconds.
        max_tokens: Maximum tokens in response.

    Returns:
        Completion text or empty string on failure.
    """
    # Use vision model by default
    if model is None:
        model = "gpt-4o" if provider == "openai" else "qwen-vl-plus"

    model_name = get_model_name(provider, model)
    api_config = get_api_config(provider)

    # Build message content with image
    content = []

    if image_base64:
        # Detect image type from base64 header or default to jpeg
        if image_base64.startswith("data:"):
            image_data = image_base64
        else:
            # Assume JPEG if no header
            image_data = f"data:image/jpeg;base64,{image_base64}"
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": image_data},
            }
        )
    elif image_url:
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": image_url},
            }
        )

    content.append({"type": "text", "text": prompt})

    try:
        response = await litellm.acompletion(
            model=model_name,
            messages=[{"role": "user", "content": content}],
            timeout=timeout,
            max_tokens=max_tokens,
            **api_config,
        )
        return response.choices[0].message.content or ""
    except Exception as exc:
        logger.warning("VLM async completion failed: %s", exc)
        return ""


async def acomplete_json(
    prompt: str,
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
) -> Dict[str, Any]:
    """Async complete a prompt and parse JSON response.

    Args:
        prompt: The prompt text (should request JSON output).
        provider: LLM provider.
        model: Optional model override.
        timeout: Request timeout in seconds.

    Returns:
        Parsed JSON dict or empty dict on failure.
    """
    raw = await acomplete(prompt, provider=provider, model=model, timeout=timeout)
    return extract_json(raw)


async def acomplete_with_tools(
    prompt: str,
    tools: list[Dict[str, Any]],
    *,
    provider: str = "openai",
    model: Optional[str] = None,
    timeout: float = 30.0,
    tool_choice: str = "auto",
) -> Dict[str, Any]:
    """Async complete with tool calling support.

    Args:
        prompt: The prompt text.
        tools: List of tool definitions in OpenAI format.
        provider: LLM provider (openai, dashscope).
        model: Optional model override.
        timeout: Request timeout in seconds.
        tool_choice: "auto", "required", or specific tool name.

    Returns:
        Dict with 'name' and 'arguments' keys, or empty dict on failure.
    """
    model_name = get_model_name(provider, model)
    api_config = get_api_config(provider)

    try:
        response = await litellm.acompletion(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            tools=tools,
            tool_choice=tool_choice,
            timeout=timeout,
            **api_config,
        )

        # Extract tool call
        message = response.choices[0].message
        if not message.tool_calls:
            return {}

        tool_call = message.tool_calls[0]
        return {
            "name": tool_call.function.name,
            "arguments": json.loads(tool_call.function.arguments),
        }
    except Exception as exc:
        logger.warning("Tool calling completion failed: %s", exc)
        return {}


def extract_json(text: str) -> Dict[str, Any]:
    """Extract JSON from LLM response text.

    Handles markdown code blocks and raw JSON.

    Args:
        text: Raw LLM response.

    Returns:
        Parsed dict or empty dict.
    """
    text = (text or "").strip()
    if not text:
        return {}

    # Try direct parse first
    try:
        result = json.loads(text)
        if isinstance(result, dict):
            return result
    except json.JSONDecodeError:
        pass

    # Try extracting from markdown code block
    code_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if code_match:
        try:
            result = json.loads(code_match.group(1).strip())
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

    # Try extracting any JSON object
    json_match = re.search(r"\{.*\}", text, re.DOTALL)
    if json_match:
        try:
            result = json.loads(json_match.group(0))
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

    return {}


def resolve_provider() -> Optional[str]:
    """Auto-detect available LLM provider from config.

    Returns:
        Provider name or None if none configured.
    """
    if config.DASHSCOPE_API_KEY.get_secret_value():
        return "dashscope"
    if config.OPENAI_API_KEY.get_secret_value():
        return "openai"
    return None


__all__ = [
    "complete",
    "acomplete",
    "acomplete_vision",
    "acomplete_with_tools",
    "complete_json",
    "acomplete_json",
    "extract_json",
    "resolve_provider",
    "get_model_name",
    "get_api_config",
]
