from __future__ import annotations

from typing import Dict, Optional

PROVIDER_ALIAS_MAP: Dict[str, str] = {
    "dashscope": "dashscope",
    "qwen": "dashscope",
    "ali": "dashscope",
    "openai": "openai",
    "oa": "openai",
}

PROVIDER_DEFAULT_MODELS: Dict[str, Dict[str, str]] = {
    "llm": {"dashscope": "qwen-turbo", "openai": "gpt-4o-mini"},
    "vlm": {"dashscope": "qwen-vl-plus", "openai": "gpt-4o-mini"},
}
PROVIDER_DEFAULT_BASE_URLS: Dict[str, str] = {
    "dashscope": "https://dashscope.aliyuncs.com/compatible-mode/v1",
}

MODEL_KIND_LLM = "llm"
MODEL_KIND_VLM = "vlm"
MODEL_CONDITION_VLM = "vlm"
MODEL_CONDITION_LLM = "llm"
MODEL_CONDITION_CHATBOT = "chatbot"


def resolve_provider_alias(provider: Optional[str]) -> Optional[str]:
    if provider is None:
        return None
    key = provider.strip().lower()
    if key in PROVIDER_ALIAS_MAP:
        return PROVIDER_ALIAS_MAP[key]
    raise ValueError(f"Unsupported provider: {provider}")


def default_model_for_provider(provider: str, *, kind: str) -> str:
    kind_map = PROVIDER_DEFAULT_MODELS.get(kind) or {}
    if provider in kind_map:
        return kind_map[provider]
    raise ValueError(
        f"Unsupported provider/kind pair: provider={provider}, kind={kind}"
    )


def default_base_url_for_provider(provider: str) -> Optional[str]:
    return PROVIDER_DEFAULT_BASE_URLS.get(provider)


def resolve_llm_provider(provider: Optional[str]) -> Optional[str]:
    """Resolve LLM provider from explicit value or environment.

    Args:
        provider: Explicit provider name or None for auto-detection.

    Returns:
        Resolved provider name or None if unavailable.

    Raises:
        ValueError: If explicit provider is not supported.
    """
    from src.foundation.config import config

    if provider:
        resolved = resolve_provider_alias(provider)
        if resolved is None:
            raise ValueError(f"Unsupported LLM provider: {provider}")
        return resolved

    if config.DASHSCOPE_API_KEY.get_secret_value():
        return "dashscope"
    if config.OPENAI_API_KEY.get_secret_value():
        return "openai"
    return None


def default_llm_model(provider: str) -> str:
    """Get default LLM model for a provider."""
    return default_model_for_provider(provider, kind=MODEL_KIND_LLM)
