"""
LLM completion utilities with timeout handling.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any, Dict

logger = logging.getLogger(__name__)


def llm_complete_with_timeout(
    chat: Any,
    prompt: str,
    timeout_s: float = 30.0,
) -> str:
    """Run LLM completion with timeout in a worker thread.

    Args:
        chat: LLM chat client with complete(prompt) method.
        prompt: Prompt text.
        timeout_s: Timeout in seconds.

    Returns:
        Completion text or empty string on timeout/error.
    """
    output: Dict[str, str] = {}
    error: Dict[str, BaseException] = {}

    def _worker() -> None:
        try:
            text = chat.complete(prompt)
            output["text"] = str(text or "")
        except BaseException as exc:  # noqa: BLE001
            error["err"] = exc

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    thread.join(timeout_s)

    if thread.is_alive():
        logger.warning("LLM completion timeout after %.1fs", timeout_s)
        return ""
    if "err" in error:
        logger.warning("LLM completion failed: %s", error["err"])
        return ""
    return output.get("text", "")


async def llm_complete_with_timeout_async(
    chat: Any,
    prompt: str,
    timeout_s: float = 30.0,
) -> str:
    """Run LLM completion with timeout asynchronously.

    Args:
        chat: LLM chat client with complete(prompt) method.
        prompt: Prompt text.
        timeout_s: Timeout in seconds.

    Returns:
        Completion text or empty string on timeout/error.
    """
    try:
        return str(
            await asyncio.wait_for(
                asyncio.to_thread(chat.complete, prompt),
                timeout=timeout_s,
            )
            or ""
        )
    except asyncio.TimeoutError:
        logger.warning("LLM completion timeout after %.1fs", timeout_s)
        return ""
    except Exception as exc:  # noqa: BLE001
        logger.warning("LLM completion failed: %s", exc)
        return ""


__all__ = [
    "llm_complete_with_timeout",
    "llm_complete_with_timeout_async",
]
