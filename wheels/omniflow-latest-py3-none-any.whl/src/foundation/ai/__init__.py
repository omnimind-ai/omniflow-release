"""Stable provider-catalog helpers, LLM clients, and chat adapters."""

from abc import ABC, abstractmethod
import asyncio
import logging
from typing import Optional

import httpx
from openai import AsyncOpenAI, OpenAI

from src.foundation.config import config

from .completion import (
    llm_complete_with_timeout,
    llm_complete_with_timeout_async,
)
from .litellm_client import (
    acomplete,
    acomplete_json,
    acomplete_vision,
    complete,
    complete_json,
    extract_json,
    get_api_config,
    get_model_name,
    resolve_provider,
)
from .provider_catalog import (
    MODEL_KIND_LLM,
    MODEL_KIND_VLM,
    default_base_url_for_provider,
    default_llm_model,
    default_model_for_provider,
    resolve_llm_provider,
    resolve_provider_alias,
)

logger = logging.getLogger(__name__)


class BaseLLMChat(ABC):
    """Minimal sync/async chat abstraction used by mutation helpers."""

    @abstractmethod
    def complete(self, prompt: str) -> str:
        """Synchronously return one plain-text completion for the given prompt."""

    async def acomplete(self, prompt: str) -> str:
        """Asynchronously return one plain-text completion for the given prompt."""

        return await asyncio.to_thread(self.complete, prompt)


class OpenAILLMChat(BaseLLMChat):
    """Minimal OpenAI-compatible chat adapter used by mutation/update helpers."""

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        trust_env: bool = True,
    ) -> None:
        self.model = model
        resolved_api_key = api_key or config.OPENAI_API_KEY.get_secret_value()
        resolved_base_url = base_url or config.OPENAI_BASE_URL
        if not resolved_api_key:
            raise ValueError(
                "OpenAI API Key must be provided or set in .env file as OPENAI_API_KEY"
            )
        if not resolved_base_url:
            raise ValueError(
                "OpenAI Base URL must be provided or set in .env file as OPENAI_BASE_URL"
            )
        self.client = AsyncOpenAI(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
            http_client=httpx.AsyncClient(trust_env=trust_env),
        )
        self.sync_client = OpenAI(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
            http_client=httpx.Client(trust_env=trust_env),
        )
        logger.debug(
            "OpenAILLMChat initialized with model=%s base_url=%s trust_env=%s",
            model,
            resolved_base_url,
            trust_env,
        )

    async def acomplete(self, prompt: str) -> str:
        """Run one OpenAI-compatible chat completion and return the text body."""

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],  # type: ignore[arg-type]
        )
        result = response.choices[0].message.content
        if result is None:
            raise RuntimeError("OpenAI LLM Chat error: response content is None")
        return result

    def complete(self, prompt: str) -> str:
        """
        Run one synchronous OpenAI-compatible chat completion.

        Args:
            prompt: Plain-text prompt already assembled by the caller.

        Returns:
            One plain-text completion body from the configured chat model.
        """

        response = self.sync_client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],  # type: ignore[arg-type]
        )
        result = response.choices[0].message.content
        if result is None:
            raise RuntimeError("OpenAI LLM Chat error: response content is None")
        return result


__all__ = [
    # Chat adapters
    "BaseLLMChat",
    "OpenAILLMChat",
    # Provider catalog
    "MODEL_KIND_LLM",
    "MODEL_KIND_VLM",
    "default_base_url_for_provider",
    "default_llm_model",
    "default_model_for_provider",
    "resolve_llm_provider",
    "resolve_provider_alias",
    # LiteLLM client
    "complete",
    "acomplete",
    "acomplete_vision",
    "complete_json",
    "acomplete_json",
    "extract_json",
    "resolve_provider",
    "get_model_name",
    "get_api_config",
    # Completion utilities
    "llm_complete_with_timeout",
    "llm_complete_with_timeout_async",
]
