from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
import re
import select
import subprocess
import threading
import time
from typing import Any, Dict, List, Optional, Sequence
import uuid

from src.foundation.paths import get_runtime_file

PRINTABLE_KEY_MAP: Dict[str, str] = {
    **{f"KEY_{chr(code)}": chr(code).lower() for code in range(ord("A"), ord("Z") + 1)},
    **{f"KEY_{digit}": str(digit) for digit in range(10)},
    "KEY_SPACE": " ",
    "KEY_COMMA": ",",
    "KEY_DOT": ".",
    "KEY_MINUS": "-",
    "KEY_SLASH": "/",
    "KEY_AT": "@",
    "KEY_APOSTROPHE": "'",
}

CONTROL_KEY_ACTIONS = {
    "KEY_BACK": "back",
    "KEY_HOME": "home",
    "KEY_ENTER": "enter",
    "KEY_NUMPAD_ENTER": "enter",
}

SHIFT_KEYS = {"KEY_LEFTSHIFT", "KEY_RIGHTSHIFT"}
X_CODES = {"ABS_MT_POSITION_X", "ABS_X"}
Y_CODES = {"ABS_MT_POSITION_Y", "ABS_Y"}
TRACKING_CODES = {"ABS_MT_TRACKING_ID"}
PRESSURE_CODES = {"ABS_MT_PRESSURE", "ABS_PRESSURE"}
TOUCH_START_CODES = {"BTN_TOUCH"}


@dataclass
class GetEventDeviceInfo:
    path: str
    name: str = ""
    abs_ranges: Dict[str, tuple[int, int]] = field(default_factory=dict)
    keys: set[str] = field(default_factory=set)

    @property
    def is_touch(self) -> bool:
        has_x = any(code in self.abs_ranges for code in X_CODES)
        has_y = any(code in self.abs_ranges for code in Y_CODES)
        return has_x and has_y


@dataclass
class GetEventLine:
    ts: float
    device: str
    event_type: str
    code: str
    value: str

    @property
    def int_value(self) -> Optional[int]:
        return _coerce_event_value(self.value)


@dataclass
class GestureAction:
    action: Dict[str, Any]
    ended_at: float


@dataclass
class _GesturePoint:
    ts: float
    x: int
    y: int


class GestureBuilder:
    def __init__(
        self,
        *,
        touch_device: GetEventDeviceInfo,
        screen_width: int,
        screen_height: int,
        tap_slop_px: int = 24,
        long_press_ms: int = 550,
    ) -> None:
        self.touch_device = touch_device
        self.screen_width = max(1, int(screen_width))
        self.screen_height = max(1, int(screen_height))
        self.tap_slop_px = max(1, int(tap_slop_px))
        self.long_press_ms = max(1, int(long_press_ms))
        self._raw_x: Optional[int] = None
        self._raw_y: Optional[int] = None
        self._active = False
        self._finish_on_syn = False
        self._points: List[_GesturePoint] = []
        self._started_at: Optional[float] = None

    def would_start(self, event: GetEventLine) -> bool:
        if event.device != self.touch_device.path:
            return False
        if (
            event.event_type == "EV_KEY"
            and event.code in TOUCH_START_CODES
            and _is_key_down(event.value)
        ):
            return True
        if event.event_type == "EV_ABS" and event.code in TRACKING_CODES:
            value = event.int_value
            return value is not None and value >= 0 and not self._active
        return False

    def handle_event(self, event: GetEventLine) -> List[GestureAction]:
        if event.device != self.touch_device.path:
            return []

        emitted: List[GestureAction] = []

        if event.event_type == "EV_ABS":
            value = event.int_value
            if value is None:
                return []
            if event.code in X_CODES:
                self._raw_x = value
            elif event.code in Y_CODES:
                self._raw_y = value
            elif event.code in TRACKING_CODES:
                if value >= 0 and not self._active:
                    self._start(event.ts)
                elif value < 0 and self._active:
                    self._finish_on_syn = True
            elif event.code in PRESSURE_CODES and self._active and value <= 0:
                emitted.append(self._finish(event.ts))
        elif event.event_type == "EV_KEY" and event.code in TOUCH_START_CODES:
            if _is_key_down(event.value) and not self._active:
                self._start(event.ts)
            elif _is_key_up(event.value) and self._active:
                self._finish_on_syn = True
        elif event.event_type == "EV_SYN" and event.code == "SYN_REPORT":
            if self._active:
                self._append_current_point(event.ts)
            if self._finish_on_syn and self._active:
                emitted.append(self._finish(event.ts))
        return emitted

    def flush(self, ts: Optional[float] = None) -> List[GestureAction]:
        if not self._active:
            return []
        return [self._finish(float(ts or time.monotonic()))]

    def _start(self, ts: float) -> None:
        self._active = True
        self._finish_on_syn = False
        self._points = []
        self._started_at = ts
        self._append_current_point(ts)

    def _append_current_point(self, ts: float) -> None:
        if self._raw_x is None or self._raw_y is None:
            return
        point = _GesturePoint(
            ts=ts,
            x=_map_axis(
                self._raw_x,
                self.touch_device.abs_ranges.get("ABS_MT_POSITION_X")
                or self.touch_device.abs_ranges.get("ABS_X"),
                self.screen_width,
            ),
            y=_map_axis(
                self._raw_y,
                self.touch_device.abs_ranges.get("ABS_MT_POSITION_Y")
                or self.touch_device.abs_ranges.get("ABS_Y"),
                self.screen_height,
            ),
        )
        if (
            self._points
            and self._points[-1].x == point.x
            and self._points[-1].y == point.y
        ):
            self._points[-1].ts = ts
            return
        self._points.append(point)

    def _finish(self, ts: float) -> GestureAction:
        self._append_current_point(ts)
        points = list(self._points or [])
        if not points:
            points = [_GesturePoint(ts=ts, x=0, y=0)]
        start = points[0]
        end = points[-1]
        duration_ms = max(0.0, (ts - float(self._started_at or ts)) * 1000.0)
        dx = end.x - start.x
        dy = end.y - start.y
        distance = max(abs(dx), abs(dy))

        if distance <= self.tap_slop_px:
            if duration_ms >= self.long_press_ms:
                action = {
                    "type": "long_press",
                    "params": {"x": start.x, "y": start.y},
                    "description": "recorded_long_press",
                }
            else:
                action = {
                    "type": "click",
                    "params": {"x": start.x, "y": start.y},
                    "description": "recorded_click",
                }
        else:
            if abs(dx) >= abs(dy):
                direction = "right" if dx >= 0 else "left"
                swipe_distance = abs(dx)
            else:
                direction = "down" if dy >= 0 else "up"
                swipe_distance = abs(dy)
            action = {
                "type": "swipe",
                "params": {
                    "x": start.x,
                    "y": start.y,
                    "direction": direction,
                    "distance": int(swipe_distance),
                },
                "description": "recorded_swipe",
            }

        self._active = False
        self._finish_on_syn = False
        self._points = []
        self._started_at = None
        return GestureAction(action=action, ended_at=ts)


class KeyBuffer:
    def __init__(self) -> None:
        self._chars: List[str] = []
        self._shift = False

    @property
    def has_text(self) -> bool:
        return bool(self._chars)

    def handle_event(self, event: GetEventLine) -> List[GestureAction]:
        if event.event_type != "EV_KEY":
            return []
        key_name = event.code
        if key_name in SHIFT_KEYS:
            if _is_key_down(event.value):
                self._shift = True
            elif _is_key_up(event.value):
                self._shift = False
            return []
        if not _is_key_down(event.value):
            return []
        if key_name == "KEY_DEL":
            if self._chars:
                self._chars.pop()
            return []
        if key_name in PRINTABLE_KEY_MAP:
            char = PRINTABLE_KEY_MAP[key_name]
            self._chars.append(char.upper() if self._shift and char.isalpha() else char)
            return []
        actions = self.flush(event.ts)
        mapped = CONTROL_KEY_ACTIONS.get(key_name)
        if mapped:
            actions.append(
                GestureAction(
                    action={
                        "type": "press_key",
                        "params": {"key": mapped},
                        "description": f"recorded_press_{mapped}",
                    },
                    ended_at=event.ts,
                )
            )
        return actions

    def flush(self, ts: Optional[float] = None) -> List[GestureAction]:
        if not self._chars:
            return []
        text = "".join(self._chars)
        self._chars = []
        return [
            GestureAction(
                action={
                    "type": "input_text",
                    "params": {"text": text},
                    "description": "recorded_input_text",
                },
                ended_at=float(ts or time.monotonic()),
            )
        ]


def parse_getevent_capabilities(text: str) -> Dict[str, GetEventDeviceInfo]:
    devices: Dict[str, GetEventDeviceInfo] = {}
    current: Optional[GetEventDeviceInfo] = None
    for raw_line in str(text or "").splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if stripped.startswith("add device "):
            path = line.split(":", 1)[-1].strip()
            current = GetEventDeviceInfo(path=path)
            devices[path] = current
            continue
        if current is None:
            continue
        if stripped.startswith("name:"):
            current.name = stripped.split(":", 1)[1].strip().strip('"')
        for axis in ("ABS_MT_POSITION_X", "ABS_MT_POSITION_Y", "ABS_X", "ABS_Y"):
            if axis in line:
                min_match = re.search(r"min\s+(-?\d+)", line)
                max_match = re.search(r"max\s+(-?\d+)", line)
                if min_match and max_match:
                    current.abs_ranges[axis] = (
                        int(min_match.group(1)),
                        int(max_match.group(1)),
                    )
        for token in re.findall(r"(?:KEY|BTN|ABS)_[A-Z0-9_]+", line):
            if token.startswith("KEY_") or token == "BTN_TOUCH":
                current.keys.add(token)
    return devices


def detect_touch_device(
    devices: Dict[str, GetEventDeviceInfo], preferred_path: Optional[str] = None
) -> GetEventDeviceInfo:
    if preferred_path:
        device = devices.get(preferred_path)
        if device is None:
            raise ValueError(f"Touch device not found: {preferred_path}")
        return device
    touch_devices = [device for device in devices.values() if device.is_touch]
    if touch_devices:
        touch_devices.sort(key=lambda item: _event_sort_key(item.path))
        return touch_devices[0]
    raise ValueError("No touch-capable input device found in getevent -pl output.")


def _event_sort_key(path: str) -> tuple[int, str]:
    match = re.search(r"event(\d+)$", str(path or ""))
    if not match:
        return (10**9, str(path or ""))
    return (int(match.group(1)), str(path or ""))


def parse_screen_size(text: str) -> tuple[int, int]:
    match = re.search(r"(\d+)x(\d+)", str(text or ""))
    if not match:
        raise ValueError(f"Unable to parse screen size from: {text!r}")
    return int(match.group(1)), int(match.group(2))


def parse_getevent_line(line: str) -> Optional[GetEventLine]:
    match = re.match(
        r"^\[\s*(?P<ts>[0-9.]+)\]\s+(?P<device>/dev/input/event\d+):\s+(?P<etype>\S+)\s+(?P<code>\S+)\s+(?P<value>\S+)",
        str(line or "").strip(),
    )
    if not match:
        return None
    return GetEventLine(
        ts=float(match.group("ts")),
        device=match.group("device"),
        event_type=match.group("etype"),
        code=match.group("code"),
        value=match.group("value"),
    )


def build_run_log_payload(
    *,
    description: str,
    steps: Sequence[Dict[str, Any]],
    actions: Sequence[Dict[str, Any]],
    start_xml: str,
    end_xml: str,
    package_name: str,
    user_prompt: Optional[str] = None,
    function_parameters: Optional[Dict[str, str]] = None,
    function_name: Optional[str] = None,
    function_description: Optional[str] = None,
    function_id: Optional[str] = None,
    recorded_xml_backfill: bool = False,
    auto_bind_target_parameter: bool = False,
    trace_id: Optional[str] = None,
    result_success: Optional[bool] = None,
) -> Dict[str, Any]:
    resolved_trace_id = trace_id or f"record_{uuid.uuid4().hex[:12]}"
    resolved_function_name = function_name or f"record_function_{resolved_trace_id[:8]}"
    extra: Dict[str, Any] = {
        "user_prompt": user_prompt or description,
        "function_description": function_description or description,
        "function_name": resolved_function_name,
        "package_name": package_name,
        "start_xml": start_xml,
        "end_xml": end_xml,
        "actions": list(actions),
    }
    if function_parameters:
        extra["function_parameters"] = dict(function_parameters)
    if function_id:
        extra["function_id"] = function_id
    if recorded_xml_backfill:
        extra["recorded_xml_backfill"] = True
    if auto_bind_target_parameter:
        extra["auto_bind_target_parameter"] = True
    return {
        "trace_id": resolved_trace_id,
        "source": "record",
        "steps": list(steps),
        "final_state": {"package_name": package_name},
        "result": {
            "success": bool(actions) if result_success is None else bool(result_success)
        },
        "extra": extra,
    }


class GetEventRunLogSession:
    """Record one run log in the background and write the existing run-log schema.

    Args:
        adb_bin: adb binary used for all shell and stream commands.
        serial: Target adb serial. `None` or `"auto"` follows existing auto-resolve
            behavior; callers can pass a concrete emulator serial to avoid ambiguity.
        description: User-facing function description stored into `extra.function_description`.
        output_path: Optional final run-log output path. When omitted, the recorder
            writes under `runtime/recordings/`.
        function_parameters: Optional parameter schema attached into `extra`.
        prompt: Optional original prompt/goal text. Falls back to `description`.
        function_name: Optional function name written into `extra.function_name`.
        function_description: Optional function description stored into `extra`.
        function_id: Optional caller-supplied function id for later import/writeback.
        device_path: Optional explicit `/dev/input/event*` touch device path.
        use_su: Whether shell stream commands should try `su -c` when available.
        post_action_delay_ms: Delay after each emitted action before capturing XML.
        tap_slop_px: Tap-vs-swipe threshold in physical pixels.
        long_press_ms: Minimum press duration that should be classified as long press.
        recorded_xml_backfill: Whether all observed XML snapshots should be
            written as backfill samples for later UTG import.
        auto_bind_target_parameter: Preserve the existing target-parameter auto-bind toggle.
        debug_raw_getevent: Whether to also dump raw `getevent` lines to disk.
        raw_getevent_output_path: Optional explicit raw log path. When omitted but
            debug is enabled, the recorder derives `<run_log_basename>.getevent.log`.
    """

    def __init__(
        self,
        *,
        adb_bin: str = "adb",
        serial: Optional[str] = None,
        description: str,
        output_path: Optional[str] = None,
        function_parameters: Optional[Dict[str, str]] = None,
        prompt: Optional[str] = None,
        function_name: Optional[str] = None,
        function_description: Optional[str] = None,
        function_id: Optional[str] = None,
        device_path: Optional[str] = None,
        use_su: bool = True,
        post_action_delay_ms: int = 150,
        tap_slop_px: int = 24,
        long_press_ms: int = 550,
        recorded_xml_backfill: bool = False,
        auto_bind_target_parameter: bool = False,
        debug_raw_getevent: bool = False,
        raw_getevent_output_path: Optional[str] = None,
    ) -> None:
        self.adb_bin = adb_bin
        self.serial = serial
        self.description = description
        self.output_path = (
            Path(output_path)
            if output_path
            else get_runtime_file(
                "recordings", f"record_{uuid.uuid4().hex[:12]}.run_log.json"
            )
        )
        self.function_parameters = dict(function_parameters or {})
        self.prompt = prompt
        self.function_name = function_name
        self.function_description = function_description
        self.function_id = function_id
        self.device_path = device_path
        self.use_su = use_su
        self.post_action_delay_ms = int(post_action_delay_ms)
        self.tap_slop_px = int(tap_slop_px)
        self.long_press_ms = int(long_press_ms)
        self.recorded_xml_backfill = bool(recorded_xml_backfill)
        self.auto_bind_target_parameter = bool(auto_bind_target_parameter)
        self.debug_raw_getevent = bool(debug_raw_getevent)
        self.raw_getevent_output_path = raw_getevent_output_path
        self.trace_id = f"record_{uuid.uuid4().hex[:12]}"
        self.raw_output_path = _resolve_raw_getevent_path(
            run_log_path=self.output_path,
            trace_id=self.trace_id,
            enabled=self.debug_raw_getevent,
            explicit_path=self.raw_getevent_output_path,
        )
        self._shell_mode = "shell"
        self._process: Optional[subprocess.Popen[str]] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._raw_log_handle: Optional[Any] = None
        self._gesture_builder: Optional[GestureBuilder] = None
        self._key_buffer: Optional[KeyBuffer] = None
        self._started = False
        self._stopped = False
        self.start_xml = ""
        self.current_xml = ""
        self.current_package = "com.example.app"
        self.steps: List[Dict[str, Any]] = []
        self.actions: List[Dict[str, Any]] = []

    def start(self) -> "GetEventRunLogSession":
        """Start `adb getevent` streaming in a background thread.

        Returns:
            The started session so callers can keep using a single expression.
        """

        if self._started:
            return self
        self.serial = resolve_adb_serial(adb_bin=self.adb_bin, serial=self.serial)
        self._shell_mode = _resolve_shell_mode(
            self.adb_bin, self.serial, use_su=self.use_su
        )
        capabilities = parse_getevent_capabilities(
            _adb_shell_output(
                self.adb_bin, self.serial, self._shell_mode, "getevent -pl"
            )
        )
        touch_device = detect_touch_device(
            capabilities, preferred_path=self.device_path
        )
        screen_width, screen_height = parse_screen_size(
            _adb_output(self.adb_bin, self.serial, ["shell", "wm", "size"])
        )
        self._gesture_builder = GestureBuilder(
            touch_device=touch_device,
            screen_width=screen_width,
            screen_height=screen_height,
            tap_slop_px=self.tap_slop_px,
            long_press_ms=self.long_press_ms,
        )
        self._key_buffer = KeyBuffer()
        self.current_xml = _capture_xml(self.adb_bin, self.serial)
        self.start_xml = self.current_xml
        self.current_package = (
            _capture_package(self.adb_bin, self.serial) or "com.example.app"
        )
        cmd = _adb_shell_stream_cmd(
            self.adb_bin, self.serial, self._shell_mode, "getevent -lt"
        )
        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if self.raw_output_path is not None:
            self.raw_output_path.parent.mkdir(parents=True, exist_ok=True)
            self._raw_log_handle = self.raw_output_path.open("w", encoding="utf-8")
        self._stop_event.clear()
        self._reader_thread = threading.Thread(
            target=self._run_reader_loop,
            name=f"getevent_runlog_{self.trace_id}",
            daemon=True,
        )
        self._started = True
        self._reader_thread.start()
        return self

    def stop(self) -> None:
        """Stop background recording and flush any pending text/gesture buffers."""

        if not self._started or self._stopped:
            return
        self._stop_event.set()
        if self._process is not None:
            try:
                self._process.terminate()
            except Exception:
                pass
        if self._reader_thread is not None:
            self._reader_thread.join(timeout=5)
        if self._process is not None:
            try:
                self._process.wait(timeout=2)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
        if self._raw_log_handle is not None:
            self._raw_log_handle.close()
            self._raw_log_handle = None
        if self._key_buffer is not None and self._gesture_builder is not None:
            for emitted_action in [
                *self._key_buffer.flush(),
                *self._gesture_builder.flush(),
            ]:
                self._record_emitted_action(emitted_action)
        self._stopped = True

    def write_run_log(
        self,
        *,
        output_path: Optional[str] = None,
        result_success: Optional[bool] = None,
    ) -> Path:
        """Write the recorded payload using the existing run-log JSON schema.

        Args:
            output_path: Optional override for the final `.run_log.json` file path.
            result_success: Optional task-level success bit. When omitted, the
                payload preserves the existing `bool(actions)` fallback.

        Returns:
            Path to the written `run_log.json` file.
        """

        self.stop()
        target = Path(output_path) if output_path else self.output_path
        payload = build_run_log_payload(
            description=self.description,
            steps=self.steps,
            actions=self.actions,
            start_xml=self.start_xml,
            end_xml=self.current_xml,
            package_name=self.current_package,
            user_prompt=self.prompt,
            function_parameters=self.function_parameters or None,
            function_name=self.function_name,
            function_description=self.function_description,
            function_id=self.function_id,
            recorded_xml_backfill=self.recorded_xml_backfill,
            auto_bind_target_parameter=self.auto_bind_target_parameter,
            trace_id=self.trace_id,
            result_success=result_success,
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return target

    def _run_reader_loop(self) -> None:
        if self._process is None or self._process.stdout is None:
            return
        while not self._stop_event.is_set():
            ready, _, _ = select.select([self._process.stdout], [], [], 0.25)
            if not ready:
                continue
            raw_line = self._process.stdout.readline()
            if not raw_line:
                break
            if self._raw_log_handle is not None:
                self._raw_log_handle.write(raw_line)
            event = parse_getevent_line(raw_line)
            if event is None:
                continue
            emitted: List[GestureAction] = []
            assert self._gesture_builder is not None
            assert self._key_buffer is not None
            if self._gesture_builder.would_start(event) and self._key_buffer.has_text:
                emitted.extend(self._key_buffer.flush(event.ts))
            emitted.extend(self._key_buffer.handle_event(event))
            emitted.extend(self._gesture_builder.handle_event(event))
            for emitted_action in emitted:
                self._record_emitted_action(emitted_action)

    def _record_emitted_action(self, emitted_action: GestureAction) -> None:
        if self.post_action_delay_ms > 0:
            time.sleep(self.post_action_delay_ms / 1000.0)
        after_xml = _capture_xml(self.adb_bin, self.serial)
        after_package = (
            _capture_package(self.adb_bin, self.serial) or self.current_package
        )

        # 从坐标匹配目标元素
        target_element = self._extract_target_element(
            xml=self.current_xml,
            action=emitted_action.action,
        )

        # 输出统一格式
        self.steps.append(
            {
                "step_index": len(self.steps),
                "source": "human",
                "observation_before_act": {
                    "xml": self.current_xml,
                    "package_name": self.current_package,
                    "activity_name": "",
                },
                "plan": {
                    "tool_name": "run_action",
                    "tool_args": {"action": emitted_action.action},
                },
                "executed_actions": [emitted_action.action],
                "act_result": {"success": True},
                "target_element": target_element,
                "selection_source": "human",
                "execution_source": "human_step",
            }
        )
        self.actions.append(emitted_action.action)
        self.current_xml = after_xml
        self.current_package = after_package

    def _extract_target_element(
        self, xml: str, action: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """从坐标匹配目标元素"""
        action_type = str(action.get("type") or "").lower()
        params = action.get("params") or {}

        if action_type in ("click", "long_press"):
            x, y = params.get("x"), params.get("y")
        elif action_type == "swipe":
            x, y = params.get("x"), params.get("y")
        else:
            return None

        if x is None or y is None or not xml:
            return None

        try:
            from src.utg.assets.embedding.element_embedding import UITree

            tree = UITree(xml, is_file=False)
            element = tree.get_element_at_coords(float(x), float(y))
            if not element:
                return None
            return {
                "resource_id": element.get("resource-id"),
                "text": element.get("text"),
                "content_desc": element.get("content-desc"),
                "class_name": element.get("class"),
                "bounds": element.get("bound_list"),
                "match_method": "coordinate_lookup",
            }
        except Exception:
            return None


def start_getevent_run_log_session(
    **kwargs: Any,
) -> GetEventRunLogSession:
    """Create and start one background getevent recorder session.

    Args:
        **kwargs: Same keyword arguments accepted by `GetEventRunLogSession`.

    Returns:
        A started session that can later be stopped and written by the caller.
    """

    return GetEventRunLogSession(**kwargs).start()


def record_run_log(
    *,
    adb_bin: str = "adb",
    serial: Optional[str] = None,
    description: str,
    output_path: Optional[str] = None,
    duration_seconds: Optional[float] = None,
    function_parameters: Optional[Dict[str, str]] = None,
    prompt: Optional[str] = None,
    function_name: Optional[str] = None,
    function_description: Optional[str] = None,
    function_id: Optional[str] = None,
    device_path: Optional[str] = None,
    use_su: bool = True,
    post_action_delay_ms: int = 150,
    tap_slop_px: int = 24,
    long_press_ms: int = 550,
    recorded_xml_backfill: bool = False,
    auto_bind_target_parameter: bool = False,
    debug_raw_getevent: bool = False,
    raw_getevent_output_path: Optional[str] = None,
) -> Path:
    session = start_getevent_run_log_session(
        adb_bin=adb_bin,
        serial=serial,
        description=description,
        output_path=output_path,
        function_parameters=function_parameters,
        prompt=prompt,
        function_name=function_name,
        function_description=function_description,
        function_id=function_id,
        device_path=device_path,
        use_su=use_su,
        post_action_delay_ms=post_action_delay_ms,
        tap_slop_px=tap_slop_px,
        long_press_ms=long_press_ms,
        recorded_xml_backfill=recorded_xml_backfill,
        auto_bind_target_parameter=auto_bind_target_parameter,
        debug_raw_getevent=debug_raw_getevent,
        raw_getevent_output_path=raw_getevent_output_path,
    )
    deadline = time.monotonic() + float(duration_seconds) if duration_seconds else None
    try:
        while True:
            if deadline is not None and time.monotonic() >= deadline:
                break
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    return session.write_run_log()


def _resolve_raw_getevent_path(
    *,
    run_log_path: Path,
    trace_id: str,
    enabled: bool,
    explicit_path: Optional[str],
) -> Optional[Path]:
    if explicit_path:
        return Path(explicit_path)
    if not enabled:
        return None
    runlog_name = run_log_path.name
    if runlog_name.endswith(".run_log.json"):
        return run_log_path.with_name(
            runlog_name[: -len(".run_log.json")] + ".getevent.log"
        )
    if run_log_path.suffix:
        return run_log_path.with_suffix(".getevent.log")
    return get_runtime_file("recordings", f"{trace_id}.getevent.log")


def _adb_output(adb_bin: str, serial: Optional[str], args: List[str]) -> str:
    cmd = [adb_bin]
    if serial:
        cmd.extend(["-s", serial])
    cmd.extend(args)
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(
            (result.stderr or result.stdout or "adb command failed").strip()
        )
    return str(result.stdout or "")


def parse_adb_devices_output(text: str) -> List[str]:
    serials: List[str] = []
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("List of devices attached"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        if state == "device":
            serials.append(serial)
    return serials


def resolve_adb_serial(*, adb_bin: str, serial: Optional[str]) -> Optional[str]:
    normalized = str(serial or "").strip()
    if normalized and normalized.lower() != "auto":
        return normalized
    serials = parse_adb_devices_output(_adb_output(adb_bin, None, ["devices"]))
    if len(serials) == 1:
        return serials[0]
    if not serials:
        raise RuntimeError(
            "No adb device is online. Connect a device or pass --serial <device>."
        )
    raise RuntimeError(
        "Multiple adb devices are online; pass --serial <device> or --serial auto only when one device is connected. "
        f"Detected: {', '.join(serials)}"
    )


def _resolve_shell_mode(adb_bin: str, serial: Optional[str], *, use_su: bool) -> str:
    if not use_su:
        return "plain"
    whoami = _adb_output(adb_bin, serial, ["shell", "whoami"]).strip().lower()
    if whoami == "root":
        return "plain"
    try:
        su_whoami = (
            _adb_output(adb_bin, serial, ["shell", "su", "-c", "whoami"])
            .strip()
            .lower()
        )
        if su_whoami == "root":
            return "su-c"
    except Exception:
        pass
    raise RuntimeError(
        "Root shell unavailable: adb shell is not root and `su -c` did not work."
    )


def _adb_shell_output(
    adb_bin: str, serial: Optional[str], shell_mode: str, command: str
) -> str:
    return _adb_output(adb_bin, serial, _adb_shell_args(shell_mode, command))


def _adb_shell_stream_cmd(
    adb_bin: str, serial: Optional[str], shell_mode: str, command: str
) -> List[str]:
    cmd = [adb_bin]
    if serial:
        cmd.extend(["-s", serial])
    cmd.extend(_adb_shell_args(shell_mode, command))
    return cmd


def _adb_shell_args(shell_mode: str, command: str) -> List[str]:
    if shell_mode == "plain":
        return ["shell", *command.split()]
    if shell_mode == "su-c":
        return ["shell", "su", "-c", command]
    raise ValueError(f"Unsupported shell mode: {shell_mode}")


def _capture_xml(adb_bin: str, serial: Optional[str]) -> str:
    shell_mode = _resolve_shell_mode(adb_bin, serial, use_su=True)
    if shell_mode == "plain":
        output = _adb_output(
            adb_bin, serial, ["exec-out", "uiautomator", "dump", "/dev/tty"]
        )
    else:
        output = _adb_shell_output(
            adb_bin, serial, shell_mode, "uiautomator dump /dev/tty"
        )
    xml_start = output.find("<?xml")
    if xml_start < 0:
        xml_start = output.find("<hierarchy")
    if xml_start < 0:
        raise RuntimeError("uiautomator dump did not return XML payload")
    return output[xml_start:].strip()


def _capture_package(adb_bin: str, serial: Optional[str]) -> Optional[str]:
    output = _adb_output(adb_bin, serial, ["shell", "dumpsys", "window", "windows"])
    patterns = (
        r"mCurrentFocus=.*?\s([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)",
        r"mFocusedApp=.*?\s([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)",
    )
    for pattern in patterns:
        match = re.search(pattern, output)
        if match:
            return match.group(1)
    top_output = _adb_output(adb_bin, serial, ["shell", "dumpsys", "activity", "top"])
    top_match = re.search(r"\bACTIVITY\s+([A-Za-z0-9_.$]+)/", top_output)
    if top_match:
        return top_match.group(1)
    return None


def _coerce_event_value(value: str) -> Optional[int]:
    raw = str(value or "").strip()
    lowered = raw.lower()
    if lowered == "down":
        return 1
    if lowered == "up":
        return 0
    try:
        if raw.startswith("0x"):
            parsed = int(raw, 16)
        elif re.fullmatch(r"[0-9a-fA-F]{1,8}", raw):
            parsed = int(raw, 16)
        else:
            parsed = int(raw)
    except Exception:
        return None
    if parsed >= 2**31:
        parsed -= 2**32
    return parsed


def _is_key_down(value: str) -> bool:
    parsed = _coerce_event_value(value)
    return str(value or "").strip().lower() == "down" or parsed in {1}


def _is_key_up(value: str) -> bool:
    parsed = _coerce_event_value(value)
    return str(value or "").strip().lower() == "up" or parsed in {0}


def _map_axis(raw_value: int, axis_range: Optional[tuple[int, int]], size: int) -> int:
    if axis_range is None:
        return max(0, min(int(raw_value), size - 1))
    min_value, max_value = axis_range
    if max_value <= min_value:
        return max(0, min(int(raw_value), size - 1))
    normalized = (float(raw_value) - float(min_value)) / float(max_value - min_value)
    normalized = min(1.0, max(0.0, normalized))
    return int(round(normalized * float(size - 1)))
