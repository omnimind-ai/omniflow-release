import logging
import os
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, SecretStr, ValidationError

try:
    from dotenv import dotenv_values, load_dotenv
except Exception:  # pragma: no cover

    def load_dotenv(*args, **kwargs) -> bool:  # type: ignore[override]
        _ = (args, kwargs)
        return False

    def dotenv_values(*args, **kwargs) -> dict[str, str]:  # type: ignore[override]
        _ = (args, kwargs)
        return {}


class ConfigModel(BaseModel):
    """Minimal runtime config sourced from .env / environment variables."""

    DEVICE_BACKEND: Optional[str] = None
    DEVICE_TARGET: Optional[str] = None
    UIAUTOMATOR2_DEVICE: Optional[str] = None
    OMNIFLOW_DEVSERVER_BASE_URL: Optional[str] = None
    OMNIFLOW_UTG_STORE_PATH: Optional[str] = None
    DASHSCOPE_API_KEY: SecretStr = SecretStr("")
    DASHSCOPE_BASE_URL: Optional[str] = None
    OPENAI_API_KEY: SecretStr = SecretStr("")
    OPENAI_BASE_URL: Optional[str] = None


logger = logging.getLogger(__name__)


def _resolve_dotenv_path(dotenv_path: Optional[str] = None) -> Optional[Path]:
    """Resolve the primary local override file used for runtime config loading."""

    if dotenv_path:
        candidate = Path(dotenv_path).expanduser()
        return candidate if candidate.exists() else None
    candidate = Path(__file__).resolve().parents[2] / ".env"
    return candidate if candidate.exists() else None


def _resolve_default_dotenv_path() -> Optional[Path]:
    """Resolve the tracked default config file shipped with the repository."""

    candidate = Path(__file__).resolve().parents[2] / ".env.defaults"
    return candidate if candidate.exists() else None


def _read_dotenv_map(dotenv_path: Optional[Path]) -> dict[str, str]:
    """Read one dotenv file into a plain string map.

    Args:
        dotenv_path: Existing dotenv file path, or `None` when that layer is absent.

    Returns:
        Parsed key/value mapping. Missing files return an empty map.
    """

    if dotenv_path is None:
        return {}
    try:
        return {
            str(k): str(v)
            for k, v in dotenv_values(dotenv_path).items()
            if k is not None and v is not None
        }
    except OSError as exc:
        logger.warning("Failed to parse .env file %s: %s", dotenv_path, exc)
        return {}


def _choose_env_value(field_name: str, dotenv_map: dict[str, str]) -> Optional[str]:
    env_value = os.getenv(field_name)
    if env_value is not None and str(env_value).strip() != "":
        return env_value
    file_value = dotenv_map.get(field_name)
    if file_value is not None and str(file_value).strip() != "":
        return str(file_value)
    return env_value


def _load_config(dotenv_path: Optional[str] = None) -> ConfigModel:
    resolved_dotenv_path = _resolve_dotenv_path(dotenv_path)
    resolved_default_dotenv_path = _resolve_default_dotenv_path()
    try:
        if resolved_dotenv_path is not None:
            load_dotenv(dotenv_path=resolved_dotenv_path, override=False)
        if (
            resolved_default_dotenv_path is not None
            and resolved_default_dotenv_path != resolved_dotenv_path
        ):
            load_dotenv(dotenv_path=resolved_default_dotenv_path, override=False)
    except (OSError, AssertionError) as exc:
        logger.warning("Failed to load .env file: %s", exc)

    dotenv_map = _read_dotenv_map(resolved_default_dotenv_path)
    dotenv_map.update(_read_dotenv_map(resolved_dotenv_path))

    loaded_vars = {
        field_name: _choose_env_value(field_name, dotenv_map)
        for field_name in ConfigModel.model_fields
        if _choose_env_value(field_name, dotenv_map) is not None
    }

    try:
        return ConfigModel(**loaded_vars)  # type: ignore[arg-type]
    except ValidationError as exc:
        raise ValueError(f"Configuration validation error: {exc.errors()}") from exc


config: ConfigModel = _load_config()
