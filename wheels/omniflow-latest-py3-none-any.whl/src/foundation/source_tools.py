from __future__ import annotations

from dataclasses import fields, is_dataclass
import json
import os
from pathlib import Path
import re
from typing import Any
import xml.etree.ElementTree as ET


def to_serializable(value: Any, *, drop_private: bool = False) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value):
        payload = {}
        for field in fields(value):
            name = str(field.name or "")
            if drop_private and name.startswith("_"):
                continue
            payload[name] = to_serializable(
                getattr(value, name),
                drop_private=drop_private,
            )
        return payload
    if isinstance(value, dict):
        return {
            key: to_serializable(item, drop_private=drop_private)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [to_serializable(item, drop_private=drop_private) for item in value]
    module_name = str(
        getattr(getattr(value, "__class__", None), "__module__", "") or ""
    )
    if module_name.startswith("numpy") and hasattr(value, "tolist"):
        try:
            return to_serializable(value.tolist(), drop_private=drop_private)
        except Exception:
            pass
    for attr_name in ("model_dump", "to_dict", "dict"):
        method = getattr(value, attr_name, None)
        if callable(method):
            try:
                return to_serializable(method(), drop_private=drop_private)
            except Exception:
                pass
    if hasattr(value, "__dict__"):
        try:
            items = dict(value.__dict__)
            if drop_private:
                items = {
                    key: item
                    for key, item in items.items()
                    if not str(key).startswith("_")
                }
            return {
                key: to_serializable(item, drop_private=drop_private)
                for key, item in items.items()
            }
        except Exception:
            pass
    return value


def to_jsonable(value: Any, *, drop_private: bool = False) -> Any:
    serialized = to_serializable(value, drop_private=drop_private)
    if serialized is value:
        return str(value)
    return serialized


def read_attr(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def read_xml_attr(attrs: dict[str, Any], key: str) -> str:
    if key in attrs:
        return str(attrs.get(key) or "")
    dashed = key.replace("_", "-")
    if dashed in attrs:
        return str(attrs.get(dashed) or "")
    underscored = key.replace("-", "_")
    if underscored in attrs:
        return str(attrs.get(underscored) or "")
    for attr_key, value in attrs.items():
        text = str(attr_key or "")
        if text.endswith("}" + key) or text.endswith(":" + key):
            return str(value or "")
    return ""


def parse_bool(value: Any, *, default: bool | None = None) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value or "").strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


def read_env_text(name: str) -> str | None:
    value = os.getenv(name)
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def read_env_bool(name: str, default: bool) -> bool:
    parsed = parse_bool(os.getenv(name), default=default)
    return bool(default if parsed is None else parsed)


def read_env_int(name: str, default: int, *, minimum: int = 0) -> int:
    raw = read_env_text(name)
    if raw is None:
        return max(minimum, int(default))
    try:
        value = int(raw)
    except Exception:
        return max(minimum, int(default))
    return max(minimum, value)


def read_env_float(name: str, default: float, *, minimum: float = 0.0) -> float:
    raw = read_env_text(name)
    if raw is None:
        return max(minimum, float(default))
    try:
        value = float(raw)
    except Exception:
        return max(minimum, float(default))
    if value < minimum:
        return float(minimum)
    return float(value)


def safe_int(value: Any) -> int | None:
    try:
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def escape_xml_text(value: Any) -> str:
    text = str(value or "")
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def parse_bounds(bounds_text: Any) -> tuple[int, int, int, int] | None:
    match = re.match(
        r"^\[(\-?\d+),(\-?\d+)\]\[(\-?\d+),(\-?\d+)\]$", str(bounds_text or "").strip()
    )
    if not match:
        return None
    x1, y1, x2, y2 = (int(match.group(i)) for i in range(1, 5))
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def parse_bounds_center(bounds_text: Any) -> tuple[int, int] | None:
    bounds = parse_bounds(bounds_text)
    if bounds is None:
        return None
    x1, y1, x2, y2 = bounds
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def find_clickable_node_id_by_prompt(xml_text: str, prompt: str) -> str | None:
    """Return the best clickable node id matching a natural-language click prompt.

    Args:
        xml_text: Current page XML used for live node lookup.
        prompt: Human-facing target text such as a shop name or button label.

    Returns:
        The matched node id after walking up to a clickable/focusable ancestor when
        available. Returns ``None`` when the prompt cannot be resolved safely.
    """

    if not xml_text or not prompt:
        return None
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return None

    target = prompt.strip().lower()
    target_nospace = re.sub(r"\s+", "", target)
    parent_map = {child: parent for parent in root.iter() for child in parent}
    best: str | None = None
    best_score = -1

    for elem in root.iter():
        attrs = elem.attrib
        node_id = read_xml_attr(attrs, "id")
        if not node_id:
            continue

        text = read_xml_attr(attrs, "text").strip()
        hint = read_xml_attr(attrs, "hint-text").strip()
        desc = read_xml_attr(attrs, "content-desc").strip()
        rid = read_xml_attr(attrs, "resource-id").strip()
        rid_raw = read_xml_attr(attrs, "resource-id-raw").strip()
        candidates_lower = [
            value.lower() for value in (text, hint, desc, rid, rid_raw) if value
        ]
        if not candidates_lower:
            continue

        score = 0
        for value in candidates_lower:
            value_nospace = re.sub(r"\s+", "", value)
            if value == target:
                score = max(score, 120)
            elif target in value:
                score = max(score, 90)
            elif target_nospace and target_nospace == value_nospace:
                score = max(score, 80)
            elif target_nospace and target_nospace in value_nospace:
                score = max(score, 70)
        if score <= 0:
            continue

        if read_xml_attr(attrs, "editable").lower() == "true":
            score += 8

        clickable_id = _find_clickable_ancestor_id(elem, parent_map)
        if clickable_id:
            score += 10
            node_id = clickable_id

        if score > best_score:
            best_score = score
            best = node_id
    return best


def find_node_center_by_id(xml_text: str, node_id: str) -> tuple[int, int] | None:
    """Return the center point of a node id from XML bounds.

    Args:
        xml_text: Current page XML containing runtime node bounds.
        node_id: Node identifier that should exist in the XML.

    Returns:
        The integer center point `(x, y)` when bounds are valid, else ``None``.
    """

    if not xml_text or not node_id:
        return None
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return None

    for elem in root.iter():
        attrs = elem.attrib
        if read_xml_attr(attrs, "id") != node_id:
            continue
        return parse_bounds_center(read_xml_attr(attrs, "bounds"))
    return None


def _find_clickable_ancestor_id(
    elem: ET.Element, parent_map: dict[ET.Element, ET.Element]
) -> str | None:
    """Walk upward and return the nearest clickable/focusable ancestor node id."""

    current = elem
    while current is not None:
        attrs = current.attrib
        clickable = read_xml_attr(attrs, "clickable").lower() == "true"
        focusable = read_xml_attr(attrs, "focusable").lower() == "true"
        if clickable or focusable:
            node_id = read_xml_attr(attrs, "id")
            if node_id:
                return node_id
        current = parent_map.get(current)
    return None


def dump_json(
    payload: Any,
    *,
    indent: int | None = 2,
    ensure_ascii: bool = False,
    drop_private: bool = False,
) -> str:
    return json.dumps(
        to_serializable(payload, drop_private=drop_private),
        ensure_ascii=ensure_ascii,
        indent=indent,
    )


def write_json(
    path_value: str | Path,
    payload: Any,
    *,
    indent: int | None = 2,
    ensure_ascii: bool = False,
    drop_private: bool = False,
) -> Path:
    path = Path(path_value).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        dump_json(
            payload,
            indent=indent,
            ensure_ascii=ensure_ascii,
            drop_private=drop_private,
        ),
        encoding="utf-8",
    )
    return path
