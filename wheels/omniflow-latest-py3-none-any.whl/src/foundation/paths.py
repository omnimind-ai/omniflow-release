from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

RUNTIME_ENV_KEY = "OMNIFLOW_RUNTIME_DIR"


def get_runtime_root() -> Path:
    """返回统一的运行产物目录（日志/临时文件/测试输出等）。"""
    env_value = os.getenv(RUNTIME_ENV_KEY)
    if env_value:
        root = Path(env_value).expanduser()
    else:
        root = Path(__file__).resolve().parents[2] / "runtime"
    root.mkdir(parents=True, exist_ok=True)
    return root


def get_runtime_dir(*parts: str) -> Path:
    path = get_runtime_root().joinpath(*parts)
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_runtime_file(*parts: str) -> Path:
    path = get_runtime_root().joinpath(*parts)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_utg_bundle_dir(utg_path: Optional[str] = None) -> Path:
    """
    返回 UTG bundle 统一目录。

    优先级：
    1) 显式 utg_path 的父目录
    2) 环境变量 OMNIFLOW_UTG_STORE_PATH 的父目录
    3) runtime/utg
    """
    if utg_path:
        candidate = Path(utg_path).expanduser()
        if candidate.suffix:
            bundle = candidate.parent
        else:
            bundle = candidate
        bundle.mkdir(parents=True, exist_ok=True)
        return bundle

    # Check unified settings
    from src.foundation.settings import settings

    if settings.storage.utg_store_path:
        candidate = Path(settings.storage.utg_store_path).expanduser()
        bundle = candidate.parent if candidate.suffix else candidate
        bundle.mkdir(parents=True, exist_ok=True)
        return bundle

    return get_runtime_dir("utg")


def get_utg_bundle_file(filename: str, utg_path: Optional[str] = None) -> Path:
    path = get_utg_bundle_dir(utg_path).joinpath(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_default_utg_store_file() -> Path:
    """返回默认 UTG store 路径（runtime/utg/utg_store.json）。"""
    return get_utg_bundle_file("utg_store.json")


def get_default_trigger_pool_file() -> Path:
    """返回默认 trigger pool 配置路径（runtime/utg/trigger_pool.json）。"""
    return get_utg_bundle_file("trigger_pool.json")


def get_raw_assets_dir(*parts: str) -> Path:
    """Return the raw assets directory for local-only storage.

    Raw assets (XML, screenshots) are stored here for debugging purposes
    but are NOT uploaded. The UTG only stores path indices pointing here.

    Structure:
        runtime/raw/runs/{run_id}/      - Assets organized by run
        runtime/raw/nodes/{node_id}/    - Assets organized by node

    Args:
        *parts: Optional subdirectory path components.

    Returns:
        Path to the raw assets directory or subdirectory.
    """
    path = get_runtime_root().joinpath("raw", *parts)
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_raw_run_assets_dir(run_id: str) -> Path:
    """Return the raw assets directory for a specific run.

    Args:
        run_id: The run identifier.

    Returns:
        Path to runtime/raw/runs/{run_id}/
    """
    return get_raw_assets_dir("runs", run_id)


def get_raw_node_assets_dir(node_id: str) -> Path:
    """Return the raw assets directory for a specific node.

    Args:
        node_id: The node identifier.

    Returns:
        Path to runtime/raw/nodes/{node_id}/
    """
    return get_raw_assets_dir("nodes", node_id)


def _migrate_from_candidates(target: Path, candidates: list[Path]) -> Path:
    for candidate in candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            raw = candidate.read_text(encoding="utf-8")
            if not raw.strip():
                continue
            target.write_text(raw, encoding="utf-8")
            break
        except Exception:
            continue
    return target
