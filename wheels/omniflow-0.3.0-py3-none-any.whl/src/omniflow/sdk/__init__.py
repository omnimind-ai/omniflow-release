"""
OmniFlow SDK

调用 OmniFlow 服务的客户端。

使用:
    from src.omniflow.sdk import OmniFlowClient

    client = OmniFlowClient("http://localhost:9417")

    result = client.compile("打开设置")
    if result.matched:
        client.execute(result.function_id, bridge_url, token)
"""

from .client import AsyncOmniFlowClient, OmniFlowClient
from .models import CompileContext, CompileResult, ExecuteResult, IngestResult

__all__ = [
    "OmniFlowClient",
    "AsyncOmniFlowClient",
    "CompileContext",
    "CompileResult",
    "ExecuteResult",
    "IngestResult",
]
