"""
OmniFlow SDK Client

HTTP client for interacting with OmniFlow Provider API.

Usage:
    from omniflow.sdk import OmniFlowClient

    client = OmniFlowClient("http://localhost:9417")

    # Compile: check if goal matches cached function
    result = client.compile("打开设置")
    if result.matched and result.confidence > 0.85:
        # Execute cached function
        exec_result = client.execute(
            result.function_id,
            bridge_url="http://127.0.0.1:8899/utg",
            bridge_token="your-token",
        )

    # Ingest: record execution trace
    ingest_result = client.ingest({
        "goal": "打开设置",
        "success": True,
        "steps": [...],
    })
"""

from __future__ import annotations

import os
from typing import Any

from .models import CompileContext, CompileResult, ExecuteResult, IngestResult


def _get_default_base_url() -> str:
    """Get default base URL from environment or use default."""
    return os.getenv("OMNIFLOW_URL", "http://localhost:9417")


class OmniFlowClient:
    """OmniFlow SDK Client.

    A simple HTTP client for the OmniFlow Provider API.

    Attributes:
        base_url: Base URL of the OmniFlow provider service.
        timeout: Request timeout in seconds.

    Example:
        >>> client = OmniFlowClient()
        >>> result = client.compile("打开设置")
        >>> print(f"Matched: {result.matched}, Function: {result.function_id}")
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        timeout: float = 30.0,
    ):
        """Initialize OmniFlow client.

        Args:
            base_url: Base URL of OmniFlow provider. Defaults to OMNIFLOW_URL
                environment variable or http://localhost:9417.
            timeout: Request timeout in seconds. Defaults to 30s.
        """
        self.base_url = (base_url or _get_default_base_url()).rstrip("/")
        self.timeout = timeout
        self._session = None

    def _get_session(self):
        """Get or create HTTP session."""
        if self._session is None:
            try:
                import httpx

                self._session = httpx.Client(timeout=self.timeout)
            except ImportError:
                self._session = "urllib"
        return self._session

    def _post(self, path: str, data: dict[str, Any]) -> dict[str, Any]:
        """Make POST request to API."""
        import json

        url = f"{self.base_url}{path}"
        session = self._get_session()

        if session == "urllib":
            import urllib.request

            req = urllib.request.Request(
                url,
                data=json.dumps(data).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        else:
            response = session.post(url, json=data)
            response.raise_for_status()
            return response.json()

    def compile(
        self,
        goal: str,
        *,
        context: CompileContext | dict[str, Any] | None = None,
        match_scope: str | list[str] | None = None,
    ) -> CompileResult:
        """Compile goal to find matching cached function.

        Args:
            goal: Natural-language task goal.
            context: Optional compile context (current node, package, etc).
            match_scope: Optional function id(s) to restrict matching.

        Returns:
            CompileResult with match status and function details.

        Example:
            >>> result = client.compile("打开设置")
            >>> if result.matched:
            ...     print(f"Found function: {result.function_id}")
        """
        payload: dict[str, Any] = {"goal": goal}

        if context is not None:
            if isinstance(context, CompileContext):
                payload["context"] = context.model_dump(exclude_none=True)
            else:
                payload["context"] = context

        if match_scope is not None:
            payload["match_scope"] = match_scope

        response = self._post("/compile", payload)
        return CompileResult.from_api_response(response)

    def execute(
        self,
        function_id: str,
        bridge_url: str,
        bridge_token: str,
        *,
        goal: str = "",
        arguments: dict[str, str] | None = None,
        context: dict[str, Any] | None = None,
        skip_terminal_verify: bool = False,
    ) -> ExecuteResult:
        """Execute a cached function via the bridge.

        Args:
            function_id: Function id to execute.
            bridge_url: OOB bridge base URL (e.g., "http://127.0.0.1:8899/utg").
            bridge_token: Bearer token for the bridge.
            goal: Original task goal for context.
            arguments: Optional function arguments.
            context: Optional execution context.
            skip_terminal_verify: Skip terminal verification.

        Returns:
            ExecuteResult with execution status.

        Example:
            >>> result = client.execute(
            ...     "open_settings",
            ...     bridge_url="http://127.0.0.1:8899/utg",
            ...     bridge_token="token",
            ... )
            >>> print(f"Success: {result.success}, Steps: {result.steps_executed}")
        """
        payload: dict[str, Any] = {
            "function_id": function_id,
            "bridge_base_url": bridge_url,
            "bridge_token": bridge_token,
            "goal": goal or f"execute:{function_id}",
            "arguments": arguments or {},
            "context": context or {},
            "skip_terminal_verify": skip_terminal_verify,
        }

        response = self._post("/functions/execute", payload)
        return ExecuteResult.from_api_response(response)

    def ingest(
        self,
        run_log: dict[str, Any],
        *,
        auto_import: bool = False,
        client_user_id: str | None = None,
        client_session_id: str | None = None,
    ) -> IngestResult:
        """Ingest execution trace into OmniFlow.

        Args:
            run_log: Run log payload with goal, steps, etc.
            auto_import: Auto-import as local UTG asset.
            client_user_id: Optional user identifier.
            client_session_id: Optional session identifier.

        Returns:
            IngestResult with ingestion status.

        Example:
            >>> result = client.ingest({
            ...     "goal": "打开设置",
            ...     "success": True,
            ...     "steps": [{"observation_before_act": {...}, "tool_call": {...}}],
            ... })
            >>> print(f"Run ID: {result.run_id}")
        """
        payload: dict[str, Any] = {
            "run_log": run_log,
            "auto_import": auto_import,
        }

        if client_user_id:
            payload["client_user_id"] = client_user_id
        if client_session_id:
            payload["client_session_id"] = client_session_id

        response = self._post("/run_logs/ingest", payload)
        return IngestResult.from_api_response(response)

    def close(self) -> None:
        """Close the HTTP session."""
        if self._session is not None and self._session != "urllib":
            self._session.close()
            self._session = None

    def __enter__(self) -> "OmniFlowClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()


class AsyncOmniFlowClient:
    """Async OmniFlow SDK Client.

    Async version of OmniFlowClient using httpx.AsyncClient.

    Example:
        >>> async with AsyncOmniFlowClient() as client:
        ...     result = await client.compile("打开设置")
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        timeout: float = 30.0,
    ):
        """Initialize async OmniFlow client.

        Args:
            base_url: Base URL of OmniFlow provider.
            timeout: Request timeout in seconds.
        """
        self.base_url = (base_url or _get_default_base_url()).rstrip("/")
        self.timeout = timeout
        self._client = None

    async def _get_client(self):
        """Get or create async HTTP client."""
        if self._client is None:
            import httpx

            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def _post(self, path: str, data: dict[str, Any]) -> dict[str, Any]:
        """Make async POST request to API."""
        url = f"{self.base_url}{path}"
        client = await self._get_client()
        response = await client.post(url, json=data)
        response.raise_for_status()
        return response.json()

    async def compile(
        self,
        goal: str,
        *,
        context: CompileContext | dict[str, Any] | None = None,
        match_scope: str | list[str] | None = None,
    ) -> CompileResult:
        """Compile goal to find matching cached function (async).

        See OmniFlowClient.compile for details.
        """
        payload: dict[str, Any] = {"goal": goal}

        if context is not None:
            if isinstance(context, CompileContext):
                payload["context"] = context.model_dump(exclude_none=True)
            else:
                payload["context"] = context

        if match_scope is not None:
            payload["match_scope"] = match_scope

        response = await self._post("/compile", payload)
        return CompileResult.from_api_response(response)

    async def execute(
        self,
        function_id: str,
        bridge_url: str,
        bridge_token: str,
        *,
        goal: str = "",
        arguments: dict[str, str] | None = None,
        context: dict[str, Any] | None = None,
        skip_terminal_verify: bool = False,
    ) -> ExecuteResult:
        """Execute a cached function via the bridge (async).

        See OmniFlowClient.execute for details.
        """
        payload: dict[str, Any] = {
            "function_id": function_id,
            "bridge_base_url": bridge_url,
            "bridge_token": bridge_token,
            "goal": goal or f"execute:{function_id}",
            "arguments": arguments or {},
            "context": context or {},
            "skip_terminal_verify": skip_terminal_verify,
        }

        response = await self._post("/functions/execute", payload)
        return ExecuteResult.from_api_response(response)

    async def ingest(
        self,
        run_log: dict[str, Any],
        *,
        auto_import: bool = False,
        client_user_id: str | None = None,
        client_session_id: str | None = None,
    ) -> IngestResult:
        """Ingest execution trace into OmniFlow (async).

        See OmniFlowClient.ingest for details.
        """
        payload: dict[str, Any] = {
            "run_log": run_log,
            "auto_import": auto_import,
        }

        if client_user_id:
            payload["client_user_id"] = client_user_id
        if client_session_id:
            payload["client_session_id"] = client_session_id

        response = await self._post("/run_logs/ingest", payload)
        return IngestResult.from_api_response(response)

    async def close(self) -> None:
        """Close the async HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "AsyncOmniFlowClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
