"""
PageVectorSet: Privacy-safe representation for multi-user UTG aggregation.

This module provides data structures and utilities to convert XML UI hierarchies
into vector-only representations that:
1. Preserve all information needed for action coordinate mapping
2. Remove all raw text/content that could leak user data
3. Support the same matching algorithms as original XML

Use Cases:
- Multi-user data aggregation (shared vector DB)
- Privacy-safe UTG storage and transmission
- Cross-device action adaptation without XML exposure
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from src.utg.assets.embedding.element_embedding import UITree

logger = logging.getLogger(__name__)


# ==============================================================================
# Data Structures
# ==============================================================================


@dataclass
class ElementVectorRecord:
    """
    Privacy-safe vector representation of one XML/UI element.

    Contains all information needed for:
    1. Similarity computation (vector)
    2. Coordinate mapping (`bounds` as geometry truth; `center` / `area`
       are derived at runtime)
    3. Optional parent annotation for tree display

    Does NOT contain:
    - Raw text content
    - Raw content-desc
    - Any user-identifiable information
    """

    id: str
    vector: np.ndarray  # Pre-computed feature vector

    # Geometry primary truth for coordinate mapping
    bounds: Tuple[int, int, int, int]  # [x1, y1, x2, y2]
    parent_id: Optional[str] = None

    # Runtime-only optional fields kept for local XML-built pages.
    text_hash: str = ""
    content_desc_hash: str = ""
    resource_id: str = ""
    class_name: str = ""
    package: str = ""
    flags: int = 0
    feature_dict: Dict[str, Any] = field(default_factory=dict)

    @property
    def center(self) -> Tuple[float, float]:
        """Return the element center derived from `bounds`."""
        x1, y1, x2, y2 = self.bounds
        return ((float(x1) + float(x2)) / 2.0, (float(y1) + float(y2)) / 2.0)

    @property
    def area(self) -> float:
        """Return the element area derived from `bounds`."""
        x1, y1, x2, y2 = self.bounds
        return float(max(0, int(x2) - int(x1)) * max(0, int(y2) - int(y1)))

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize to one JSON-compatible dict.

        The payload only persists primary geometry truth via `bounds`.
        Redundant derived fields such as `center` and `area` stay runtime-only.
        """
        return {
            "id": self.id,
            "vector": self.vector.tolist(),
            "bounds": list(self.bounds),
            "parent_id": self.parent_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ElementVectorRecord":
        """Deserialize one minimal element payload."""
        return cls(
            id=data["id"],
            vector=np.array(data["vector"], dtype=np.float32),
            bounds=tuple(data["bounds"]),
            parent_id=data.get("parent_id"),
        )


@dataclass
class PageVectorSet:
    """
    Privacy-safe vector representation of a full UI page.

    Replaces raw XML storage with pre-computed vectors while
    preserving all functionality needed for action mapping.
    """

    page_id: str
    root_bounds: Tuple[int, int, int, int]  # [x1, y1, x2, y2]
    elements: List[ElementVectorRecord]
    package_name: str

    # Page-level vector for fast similarity search
    page_vector: Optional[np.ndarray] = None

    # Metadata
    created_at: str = ""
    source_device: str = ""
    fingerprint: str = ""  # Content hash for cache validation

    def get_element_by_id(self, element_id: str) -> Optional[ElementVectorRecord]:
        """Find one element by ID."""
        for element in self.elements:
            if element.id == element_id:
                return element
        return None

    def get_element_at_coords(
        self, x: float, y: float
    ) -> Optional[ElementVectorRecord]:
        """Find the smallest element containing the coordinates."""
        candidates = []
        for element in self.elements:
            b = element.bounds
            if b[0] <= x <= b[2] and b[1] <= y <= b[3]:
                candidates.append(element)
        if not candidates:
            return None
        return min(candidates, key=lambda e: e.area)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        return {
            "page_id": self.page_id,
            "package_name": self.package_name,
            "root_bounds": list(self.root_bounds),
            "page_vector": self.page_vector.tolist()
            if self.page_vector is not None
            else None,
            "elements": [element.to_dict() for element in self.elements],
        }

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PageVectorSet":
        """Deserialize from dict."""
        page_vec = data.get("page_vector")
        return cls(
            page_id=data["page_id"],
            root_bounds=tuple(data["root_bounds"]),
            elements=[
                ElementVectorRecord.from_dict(element)
                for element in data.get("elements", [])
            ],
            package_name=data.get("package_name", ""),
            page_vector=np.array(page_vec, dtype=np.float32)
            if page_vec is not None
            else None,
            fingerprint=compute_page_fingerprint(data),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "PageVectorSet":
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))


# ==============================================================================
# Conversion Functions
# ==============================================================================


def _hash_text(text: str) -> str:
    """One-way hash of text content for privacy."""
    if not text:
        return ""
    clean = str(text).strip().lower()
    if not clean:
        return ""
    return hashlib.sha256(clean.encode("utf-8")).hexdigest()[:16]


def _encode_flags(element: Dict[str, Any]) -> int:
    """Encode boolean state flags into bitmask."""
    flags = 0
    if _is_true(element, "clickable"):
        flags |= 1
    if _is_true(element, "focusable"):
        flags |= 2
    if _is_true(element, "editable"):
        flags |= 4
    if _is_true(element, "scrollable"):
        flags |= 8
    if _is_true(element, "checkable"):
        flags |= 16
    if _is_true(element, "selected"):
        flags |= 32
    if _is_true(element, "enabled", default=True):
        flags |= 64
    if _is_true(element, "visible", "visible-to-user", default=True):
        flags |= 128
    return flags


def _is_true(element: Dict[str, Any], *keys: str, default: bool = False) -> bool:
    """Check if any of the keys is true in one XML element payload."""
    for key in keys:
        value = element.get(key)
        if value in (None, ""):
            continue
        return str(value).lower() == "true"
    return default


def _anonymize_feature_dict(feature_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remove raw text from feature dict while preserving computed features.

    The text hash is already computed in the features, so we just need to
    remove the raw_text field to ensure privacy.
    """
    result = {"features": {}}

    for category, features in feature_dict.get("features", {}).items():
        if category == "text":
            # Keep has_text flag but remove raw_text
            result["features"]["text"] = {
                "has_text": features.get("has_text", False),
                "has_content": features.get("has_content", False),
                # raw_text_hash is computed by processor, not stored as string
            }
        elif category == "human":
            sanitized = dict(features)
            if sanitized.get("content_hash"):
                sanitized["content_hash"] = _hash_text(str(sanitized["content_hash"]))
            result["features"]["human"] = sanitized
        else:
            # Copy other categories as-is (geometry, state, structure)
            result["features"][category] = dict(features)

    return result


def compute_page_fingerprint(page: "PageVectorSet | Dict[str, Any]") -> str:
    """
    Build one deterministic fingerprint from the minimal page payload.

    Args:
        page: One `PageVectorSet` instance or serialized minimal payload.

    Returns:
        A short SHA-256 digest used for runtime cache / freshness checks.
    """

    if isinstance(page, PageVectorSet):
        payload = {
            "package_name": str(page.package_name or ""),
            "root_bounds": list(page.root_bounds),
            "page_vector": (
                np.asarray(page.page_vector, dtype=np.float32).round(6).tolist()
                if page.page_vector is not None
                else None
            ),
            "elements": [
                {
                    "id": str(element.id or ""),
                    "bounds": list(element.bounds),
                    "parent_id": element.parent_id,
                    "vector": np.asarray(element.vector, dtype=np.float32)
                    .round(6)
                    .tolist(),
                }
                for element in list(page.elements or [])
            ],
        }
    else:
        payload = {
            "package_name": str(page.get("package_name", "") or ""),
            "root_bounds": list(page.get("root_bounds", []) or []),
            "page_vector": page.get("page_vector"),
            "elements": [
                {
                    "id": str(element.get("id", "") or ""),
                    "bounds": list(element.get("bounds", []) or []),
                    "parent_id": element.get("parent_id"),
                    "vector": element.get("vector"),
                }
                for element in list(page.get("elements", []) or [])
                if isinstance(element, dict)
            ],
        }
    encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()[:16]


def xml_to_vector_set(
    xml_content: str,
    page_id: str,
    *,
    screenshot: Optional[np.ndarray] = None,
    package_name: str = "",
    source_device: str = "",
    created_at: str = "",
) -> PageVectorSet:
    """
    Convert XML UI hierarchy to privacy-safe PageVectorSet.

    This function:
    1. Parses XML into UITree (with optional screenshot for visual hash)
    2. Extracts and vectorizes all elements
    3. Hashes all text content
    4. Returns PageVectorSet without any raw text

    Args:
        xml_content: Raw XML string of UI hierarchy
        page_id: Unique identifier for this page
        screenshot: Optional screenshot (H, W, C) for visual hash of icon elements
        package_name: App package name (optional, will be extracted from XML if not provided)
        source_device: Device identifier (optional)
        created_at: Timestamp string (optional)

    Returns:
        PageVectorSet with all elements vectorized and anonymized
    """
    # Parse XML with optional screenshot
    ui_tree = UITree(xml_content, is_file=False, screenshot=screenshot)

    if not ui_tree.elements:
        return PageVectorSet(
            page_id=page_id,
            root_bounds=(0, 0, 1080, 1920),
            elements=[],
            package_name=package_name,
            created_at=created_at,
            source_device=source_device,
        )

    # Extract package from the first element if not provided.
    if not package_name:
        package_name = str(ui_tree.elements[0].get("package", "") or "")

    # Convert elements.
    element_records = []
    for element in ui_tree.elements:
        element_id = str(element.get("id", ""))

        # Get pre-computed vector
        vector = ui_tree.vectors.get(element_id)
        if vector is None:
            continue

        # Get and anonymize feature dict for runtime-only local matching.
        feature_dict = ui_tree.feature_dicts.get(element_id, {})
        anon_features = _anonymize_feature_dict(feature_dict)

        # Hash text content
        text = str(element.get("text", "") or "")
        content_desc = str(element.get("content-desc", "") or "")

        record = ElementVectorRecord(
            id=element_id,
            vector=vector,
            bounds=tuple(element.get("bound_list", [0, 0, 0, 0])),
            text_hash=_hash_text(text),
            content_desc_hash=_hash_text(content_desc),
            resource_id=str(element.get("resource-id", "") or ""),
            class_name=str(element.get("class", "") or ""),
            package=str(element.get("package", "") or ""),
            flags=_encode_flags(element),
            parent_id=element.get("parent_id"),
            feature_dict=anon_features,
        )
        element_records.append(record)

    page = PageVectorSet(
        page_id=page_id,
        root_bounds=tuple(ui_tree.root_bounds),
        elements=element_records,
        package_name=package_name,
        page_vector=None,  # Can be computed later by PageEncoder
        created_at=created_at,
        source_device=source_device,
    )
    page.fingerprint = compute_page_fingerprint(page)
    return page


# ==============================================================================
# 坐标映射 (使用统一的 UTGMatcher)
# ==============================================================================


def match_coordinates(
    source: PageVectorSet,
    target: PageVectorSet,
    x: float,
    y: float,
) -> Dict[str, Any]:
    """
    坐标映射主入口。

    使用 UTGMatcher 的锚点扩散算法进行跨页面坐标映射。

    Args:
        source: 源 PageVectorSet
        target: 目标 PageVectorSet
        x: 源 X 坐标
        y: 源 Y 坐标

    Returns:
        包含目标坐标和映射信息的字典
    """
    from src.utg.assets.embedding.element_match import UTGMatcher

    try:
        matcher = UTGMatcher(source=source, target=target)
        result = matcher.map_coordinates(float(x), float(y))

        if result is None:
            return {
                "new_x": x,
                "new_y": y,
                "mapped": False,
                "debug": matcher.last_debug,
            }

        return {
            "new_x": float(result["new_x"]),
            "new_y": float(result["new_y"]),
            "mapped": True,
            "mapping_mode": "element_match",
            "debug": result.get("debug", {}),
        }
    except Exception as exc:
        return {
            "new_x": x,
            "new_y": y,
            "mapped": False,
            "debug": {"error": str(exc)},
        }
