"""
Embedding/Matching configuration (64-dim dual-perspective design).

Node Vector 设计原则：
- Human Observation (32维): 用户看到什么
- Programmer Observation (32维): 开发者定义什么
- 空间信息由 Anchor 算法处理，不在 Node Vector 中
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class ElementEmbeddingConfig:
    """
    Node Embedding 配置 (64维，双视角 Observation 设计)

    ┌─────────────────────────────────────────────────────────────┐
    │ Human Observation (32维) - 用户看到什么                     │
    │   content_hash: 16   (内容指纹)                             │
    │   content_type: 4    (文字/图标/空/混合)                    │
    │   affordance: 4      (可操作感知)                           │
    │   prominence: 4      (视觉重要性)                           │
    │   visual_state: 4    (视觉状态)                             │
    ├─────────────────────────────────────────────────────────────┤
    │ Programmer Observation (32维) - 开发者定义什么              │
    │   class_type: 8      (控件类型 hash)                        │
    │   attributes: 8      (交互属性)                             │
    │   struct_hash: 12    (结构指纹)                             │
    │   hierarchy: 2       (层级信息)                             │
    │   id_hint: 2         (命名暗示)                             │
    └─────────────────────────────────────────────────────────────┘

    设计原则:
    - Node Vector = 身份 (WHAT): 内容、行为、结构、类型
    - Anchor 算法 = 空间 (WHERE): 坐标投影、几何验证
    - Page Vector = 上下文 (CONTEXT): 区域池化、功能锚点
    """

    # ==========================================================================
    # Human Observation (32维) - 用户看到什么
    # ==========================================================================

    # -------------------- content_hash (16维) --------------------
    # 用户看到的文字或图标的指纹
    content_hash_dim: int = 16
    text_truncate_len: int = 10
    text_clean_regex: str = r"[^\w\u4e00-\u9fff]"
    chinese_regex: str = r"[\u4e00-\u9fff]"
    trigram_pad_prefix: str = "^"
    trigram_pad_suffix: str = "$"

    # Visual hash 配置 (用于无文本图标，与 content_hash 兼容)
    # 传入 screenshot 时，对图标/无文本节点使用 visual hash
    visual_hash_dim: int = 16  # 与 content_hash_dim 相同
    visual_hash_max_area_ratio: float = 0.20  # 面积占比 <= 20% 时才用 visual hash
    visual_hash_min_text_len: int = 2  # 文本长度 < 2 视为无文本

    # -------------------- content_type (4维) --------------------
    # 用户看到的内容类型: text/icon/empty/mixed
    content_type_dim: int = 4

    # 图标类控件 (用于判断 content_type)
    icon_class_names: List[str] = field(
        default_factory=lambda: [
            "ImageView",
            "ImageButton",
            "AppCompatImageView",
            "CircleImageView",
            "RoundedImageView",
            "ShapeableImageView",
        ]
    )

    # -------------------- affordance (4维) --------------------
    # 用户感知的可操作性: 看起来能点?能输入?能滚动?能切换?
    affordance_dim: int = 4
    affordance_features: List[str] = field(
        default_factory=lambda: [
            "looks_tappable",  # 看起来能点击 (按钮样式)
            "looks_typeable",  # 看起来能输入 (输入框样式)
            "looks_scrollable",  # 看起来能滚动 (列表样式)
            "looks_toggleable",  # 看起来能切换 (开关样式)
        ]
    )

    # -------------------- prominence (4维) --------------------
    # 视觉重要性: 面积大小分桶
    prominence_dim: int = 4
    prominence_bins: List[float] = field(
        default_factory=lambda: [0.005, 0.02, 0.08]  # tiny/small/medium/large
    )

    # -------------------- visual_state (4维) --------------------
    # 视觉状态: 看起来选中?禁用?聚焦?主要?
    visual_state_dim: int = 4
    visual_state_features: List[str] = field(
        default_factory=lambda: [
            "appears_selected",  # 看起来被选中 (高亮)
            "appears_disabled",  # 看起来被禁用 (灰色)
            "appears_focused",  # 看起来有焦点 (边框)
            "appears_primary",  # 看起来是主要操作 (醒目)
        ]
    )

    # ==========================================================================
    # Programmer Observation (32维) - 开发者定义什么
    # ==========================================================================

    # -------------------- class_type (8维) --------------------
    # 控件类型指纹: hash(class_suffix)
    class_type_dim: int = 8

    # -------------------- attributes (8维) --------------------
    # 开发者设置的交互属性
    attributes_dim: int = 8
    attribute_features: List[str] = field(
        default_factory=lambda: [
            "clickable",
            "long_clickable",
            "focusable",
            "editable",
            "scrollable",
            "checkable",
            "enabled",
            "selected",
        ]
    )

    # -------------------- struct_hash (12维) --------------------
    # 子树结构指纹
    struct_hash_dim: int = 12
    struct_hash_depth: int = 2

    # -------------------- hierarchy (2维) --------------------
    # 层级信息: is_leaf, has_siblings
    hierarchy_dim: int = 2

    # -------------------- id_hint (2维) --------------------
    # resource-id 命名暗示
    id_hint_dim: int = 2
    id_action_prefixes: List[str] = field(
        default_factory=lambda: ["btn_", "button_", "ib_", "fab_", "action_"]
    )
    id_input_prefixes: List[str] = field(
        default_factory=lambda: ["et_", "edit_", "input_", "search_", "txt_"]
    )

    # ==========================================================================
    # Category Weights (类别权重)
    # ==========================================================================

    # Human Observation (32维)
    human_weight: float = 0.55  # 用户视角权重更高

    # Programmer Observation (32维)
    programmer_weight: float = 0.45

    # Human Observation 内部权重
    human_component_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "content_hash": 0.50,  # 16维，内容是核心
            "content_type": 0.12,  # 4维
            "affordance": 0.15,  # 4维，可操作感知重要
            "prominence": 0.10,  # 4维
            "visual_state": 0.13,  # 4维
        }
    )

    # Programmer Observation 内部权重
    programmer_component_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "class_type": 0.25,  # 8维
            "attributes": 0.30,  # 8维，交互属性重要
            "struct_hash": 0.30,  # 12维，结构重要
            "hierarchy": 0.08,  # 2维
            "id_hint": 0.07,  # 2维
        }
    )

    def get_total_dim(self) -> int:
        """获取向量总维度 = 64"""
        human_dim = (
            self.content_hash_dim  # 16
            + self.content_type_dim  # 4
            + self.affordance_dim  # 4
            + self.prominence_dim  # 4
            + self.visual_state_dim  # 4
        )  # = 32

        programmer_dim = (
            self.class_type_dim  # 8
            + self.attributes_dim  # 8
            + self.struct_hash_dim  # 12
            + self.hierarchy_dim  # 2
            + self.id_hint_dim  # 2
        )  # = 32

        return human_dim + programmer_dim  # = 64

    def get_dim_weights(self) -> List[float]:
        """
        获取 64 维的完整权重列表

        Returns:
            64 维权重列表，与向量维度一一对应
        """
        weights = []

        # ===== Human Observation (32维) =====
        h_total = sum(self.human_component_weights.values())
        h_w = self.human_component_weights

        # content_hash: 16维
        for _ in range(self.content_hash_dim):
            weights.append(
                self.human_weight
                * h_w["content_hash"]
                / h_total
                / self.content_hash_dim
            )
        # content_type: 4维
        for _ in range(self.content_type_dim):
            weights.append(
                self.human_weight
                * h_w["content_type"]
                / h_total
                / self.content_type_dim
            )
        # affordance: 4维
        for _ in range(self.affordance_dim):
            weights.append(
                self.human_weight * h_w["affordance"] / h_total / self.affordance_dim
            )
        # prominence: 4维
        for _ in range(self.prominence_dim):
            weights.append(
                self.human_weight * h_w["prominence"] / h_total / self.prominence_dim
            )
        # visual_state: 4维
        for _ in range(self.visual_state_dim):
            weights.append(
                self.human_weight
                * h_w["visual_state"]
                / h_total
                / self.visual_state_dim
            )

        # ===== Programmer Observation (32维) =====
        p_total = sum(self.programmer_component_weights.values())
        p_w = self.programmer_component_weights

        # class_type: 8维
        for _ in range(self.class_type_dim):
            weights.append(
                self.programmer_weight
                * p_w["class_type"]
                / p_total
                / self.class_type_dim
            )
        # attributes: 8维
        for _ in range(self.attributes_dim):
            weights.append(
                self.programmer_weight
                * p_w["attributes"]
                / p_total
                / self.attributes_dim
            )
        # struct_hash: 12维
        for _ in range(self.struct_hash_dim):
            weights.append(
                self.programmer_weight
                * p_w["struct_hash"]
                / p_total
                / self.struct_hash_dim
            )
        # hierarchy: 2维
        for _ in range(self.hierarchy_dim):
            weights.append(
                self.programmer_weight * p_w["hierarchy"] / p_total / self.hierarchy_dim
            )
        # id_hint: 2维
        for _ in range(self.id_hint_dim):
            weights.append(
                self.programmer_weight * p_w["id_hint"] / p_total / self.id_hint_dim
            )

        # 归一化
        total = sum(weights)
        if total > 0:
            weights = [w / total for w in weights]

        return weights

    # ==========================================================================
    # Legacy aliases (兼容旧代码)
    # ==========================================================================

    @property
    def text_hash_dim(self) -> int:
        return self.content_hash_dim

    @property
    def text_weight(self) -> float:
        return self.human_weight * self.human_component_weights.get("content_hash", 0.5)

    @property
    def semantic_weight(self) -> float:
        return self.human_weight

    @property
    def interactive_weight(self) -> float:
        return self.programmer_weight * self.programmer_component_weights.get(
            "attributes", 0.3
        )

    @property
    def structural_weight(self) -> float:
        return self.programmer_weight * self.programmer_component_weights.get(
            "struct_hash", 0.3
        )


@dataclass
class PageEncodingConfig:
    """Page Vector 编码配置。"""

    # Spatial pooling for the fixed 8-slice page IR.
    header_ratio: float = 0.15
    footer_ratio: float = 0.85
    root_height_default: int = 1920
