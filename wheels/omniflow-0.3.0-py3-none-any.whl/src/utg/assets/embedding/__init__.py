"""Stable public embedding / matching facade.

Do not re-export internal encoders, thresholds, or debug-only helpers here.
Import concrete modules directly when you need implementation details.
"""

from .element_embedding import TextHashEncoder
from .element_match import (
    UTGMatcher,
    adapt_action_coordinates,
    adapt_coordinates,
    match_element,
    resolve_action_source_xml,
)
from .page_match import UTGMatchEngine
from .stats import UTGStatsCollector
from .vector_set import (
    ElementVectorRecord,
    PageVectorSet,
    compute_page_fingerprint,
    match_coordinates,
    xml_to_vector_set,
)
from .xml_api import (
    build_ui_tree,
    encode_xml_elements,
    encode_xml_page,
    match_xml_coordinates,
    xml_similarity,
)

__all__ = [
    "TextHashEncoder",
    "build_ui_tree",
    "encode_xml_elements",
    "encode_xml_page",
    "match_xml_coordinates",
    "xml_similarity",
    "UTGMatchEngine",
    "UTGStatsCollector",
    "UTGMatcher",
    "adapt_action_coordinates",
    "adapt_coordinates",
    "resolve_action_source_xml",
    "match_element",
    # Privacy-safe vector set representation
    "ElementVectorRecord",
    "PageVectorSet",
    "compute_page_fingerprint",
    "xml_to_vector_set",
    "match_coordinates",
]
