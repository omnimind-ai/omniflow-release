from __future__ import annotations

import logging
import math
import re
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import numpy as np

# === 关键引用 ===
from src.utg.assets.embedding.element_embedding import (
    ElementVectorizer,
)

if TYPE_CHECKING:
    from src.utg.assets.embedding.vector_set import PageVectorSet

logger = logging.getLogger(__name__)


# ==============================================================================
# PageVectorSet 兼容视图
# ==============================================================================


class _CompatView:
    """PageVectorSet 的兼容视图，模拟原 UITree 的访问接口"""

    def __init__(self, vs: "PageVectorSet"):
        self.vs = vs
        self.root_bounds = list(vs.root_bounds)

        # 构建元素列表和映射
        self.elements: List[Dict[str, Any]] = []
        self.element_map: Dict[str, Dict[str, Any]] = {}
        self.vectors: Dict[str, np.ndarray] = {}
        self.feature_dicts: Dict[str, Dict[str, Any]] = {}

        for element in vs.elements:
            elem = {
                "id": element.id,
                "bound_list": list(element.bounds),
                "bounds": list(element.bounds),
                "center": element.center,
                "area": element.area,
                "class": element.class_name,
                "resource-id": element.resource_id,
                "package": element.package
                or str(getattr(vs, "package_name", "") or ""),
                "text_hash": element.text_hash,
                "content_desc_hash": element.content_desc_hash,
                "has_text": bool(element.text_hash),
                "parent_id": element.parent_id,
                # 从 flags 解码布尔属性
                "clickable": bool(element.flags & 1),
                "focusable": bool(element.flags & 2),
                "editable": bool(element.flags & 4),
                "scrollable": bool(element.flags & 8),
                "checkable": bool(element.flags & 16),
                "selected": bool(element.flags & 32),
                "enabled": bool(element.flags & 64),
                "visible": bool(element.flags & 128),
            }
            self.elements.append(elem)
            self.element_map[element.id] = elem
            self.vectors[element.id] = element.vector
            payload = dict(element.feature_dict or {})
            payload["_vector"] = element.vector
            self.feature_dicts[element.id] = payload

        for elem in self.elements:
            parent_id = elem.get("parent_id")
            if not parent_id:
                continue
            parent = self.element_map.get(str(parent_id))
            if parent is None:
                continue
            parent.setdefault("children_ids", []).append(elem["id"])

    def get_element_at_coords(self, x: float, y: float) -> Optional[Dict[str, Any]]:
        """根据坐标查找最小的包含该点的元素"""
        candidates = []
        for elem in self.elements:
            bounds = elem.get("bound_list", [0, 0, 0, 0])
            if bounds[0] <= x <= bounds[2] and bounds[1] <= y <= bounds[3]:
                candidates.append(elem)
        if not candidates:
            return None
        return min(candidates, key=lambda e: e.get("area", float("inf")))

    def get_text(self, element: Dict[str, Any]) -> str:
        """获取元素文本标记（用于判断是否有文本内容）"""
        if element.get("has_text") or element.get("text_hash"):
            return "[has_text]"
        return ""


# ==============================================================================
# UTG 匹配核心 (UTGMatcher)
# ==============================================================================


def _xml_to_vector_set(
    xml_input: str,
    screenshot: Optional[np.ndarray] = None,
) -> "PageVectorSet":
    """将 XML 转换为 PageVectorSet"""
    from src.utg.assets.embedding.vector_set import xml_to_vector_set

    is_file = not str(xml_input or "").lstrip().startswith("<")
    if is_file:
        with open(xml_input, "r", encoding="utf-8") as f:
            xml_content = f.read()
    else:
        xml_content = xml_input
    return xml_to_vector_set(xml_content, page_id="__temp__", screenshot=screenshot)


class UTGMatcher:
    """
    实现基于锚点扩散的坐标映射算法。

    内部统一使用 PageVectorSet 作为数据表示。
    支持 XML 或 PageVectorSet 输入，XML 会自动转换。
    """

    def __init__(
        self,
        source: Union[str, "PageVectorSet"],
        target: Union[str, "PageVectorSet"],
        *,
        source_screenshot: Optional[np.ndarray] = None,
        target_screenshot: Optional[np.ndarray] = None,
    ):
        """
        初始化匹配器。

        Args:
            source: 源数据，支持 XML 字符串或 PageVectorSet
            target: 目标数据，支持 XML 字符串或 PageVectorSet
            source_screenshot: 源截图 (H,W,C)，用于图标元素的 visual hash
            target_screenshot: 目标截图 (H,W,C)，用于图标元素的 visual hash
        """
        from src.utg.assets.embedding.vector_set import PageVectorSet

        # 统一转换为 PageVectorSet
        if isinstance(source, str):
            self.src_vs = _xml_to_vector_set(source, screenshot=source_screenshot)
        elif isinstance(source, PageVectorSet):
            self.src_vs = source
        else:
            raise TypeError(f"Unsupported source type: {type(source)}")

        if isinstance(target, str):
            self.tgt_vs = _xml_to_vector_set(target, screenshot=target_screenshot)
        elif isinstance(target, PageVectorSet):
            self.tgt_vs = target
        else:
            raise TypeError(f"Unsupported target type: {type(target)}")

        # 构建兼容的访问接口 (保持与原 UTGMatcher API 兼容)
        self.src_tree = self._build_compat_view(self.src_vs)
        self.tgt_tree = self._build_compat_view(self.tgt_vs)

        # 初始化向量化器 (用于计算相似度)
        self.vectorizer = ElementVectorizer()

        # 计算全局分辨率缩放
        self.global_scale = self._calculate_global_scale()
        self.last_debug: Dict[str, Any] = {}
        self._last_anchor_debug: Dict[str, Any] = {}
        self._last_fallback_debug: Dict[str, Any] = {}

    def _build_compat_view(self, vs: "PageVectorSet") -> "_CompatView":
        """构建兼容视图，提供 elements/element_map/feature_dicts 等访问"""
        return _CompatView(vs)

    def _element_summary(self, element: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not isinstance(element, dict):
            return {}
        return {
            "id": element.get("id"),
            "class": element.get("class"),
            "text": element.get("text"),
            "content_desc": element.get("content-desc"),
            "package": element.get("package"),
            "bounds": element.get("bounds"),
            "bound_list": element.get("bound_list"),
            "center": element.get("center"),
            "area": element.get("area"),
            "clickable": element.get("clickable"),
            "focusable": element.get("focusable"),
            "editable": element.get("editable"),
            "resource_id": element.get("resource-id"),
        }

    def map_coordinates(self, x: float, y: float) -> Optional[Dict]:
        """
        输入旧坐标，返回映射后的新坐标及置信度。
        采用相对比例映射 (Percentage Projection)，适应不同分辨率或UI缩放。
        """
        self.last_debug = {
            "status": "started",
            "input": {"x": float(x), "y": float(y)},
            "global_scale": dict(self.global_scale),
        }
        src_element = self.src_tree.get_element_at_coords(x, y)
        if not src_element:
            self.last_debug["status"] = "missing_src_element"
            return None

        self.last_debug["src_element"] = self._element_summary(src_element)
        matches = self.find_best_match(src_element["id"])
        self.last_debug["projection_basis"] = {
            "input_point": {"x": float(x), "y": float(y)},
            "source_element_center": {
                "x": float(src_element["center"][0]),
                "y": float(src_element["center"][1]),
            },
            "anchor_projection_uses": "source_element_center",
            "final_point_projection_uses": "input_point_relative_to_matched_element_bounds",
        }
        for vote_record in self.last_debug.get("vote_records", []) or []:
            old_anchor = vote_record.get("old_anchor") or {}
            new_anchor = vote_record.get("new_anchor") or {}
            old_center = old_anchor.get("center") or [None, None]
            new_center = new_anchor.get("center") or [None, None]
            src_center = src_element.get("center") or [None, None]
            if None in old_center or None in new_center or None in src_center:
                continue
            raw_offset_x = float(src_center[0]) - float(old_center[0])
            raw_offset_y = float(src_center[1]) - float(old_center[1])
            scaled_offset_x = raw_offset_x * float(self.global_scale["sx"])
            scaled_offset_y = raw_offset_y * float(self.global_scale["sy"])
            vote_record["projection_chain"] = {
                "input_point": {"x": float(x), "y": float(y)},
                "source_element_center": {
                    "x": float(src_center[0]),
                    "y": float(src_center[1]),
                },
                "old_anchor_center": {
                    "x": float(old_center[0]),
                    "y": float(old_center[1]),
                },
                "new_anchor_center": {
                    "x": float(new_center[0]),
                    "y": float(new_center[1]),
                },
                "raw_offset_from_old_anchor": {
                    "dx": float(raw_offset_x),
                    "dy": float(raw_offset_y),
                },
                "global_scale": {
                    "sx": float(self.global_scale["sx"]),
                    "sy": float(self.global_scale["sy"]),
                },
                "scaled_offset": {
                    "dx": float(scaled_offset_x),
                    "dy": float(scaled_offset_y),
                },
                "predicted_point": dict(vote_record.get("predicted_point") or {}),
            }
        self.last_debug["match_results"] = [
            {
                "element": self._element_summary(item.get("element")),
                "match_score": float(item.get("match_score", 0.0) or 0.0),
                "direct_similarity": float(
                    item.get("direct_similarity", 0.0) or 0.0
                ),
                "votes": list(item.get("votes") or []),
            }
            for item in list(matches or [])
        ]
        if not matches:
            self.last_debug["status"] = "no_match_candidates"
            return None

        best_match = matches[0]
        target_element = best_match["element"]
        sb = src_element["bound_list"]
        src_w = sb[2] - sb[0]
        src_h = sb[3] - sb[1]
        ratio_x = (x - sb[0]) / src_w if src_w > 0 else 0.5
        ratio_y = (y - sb[1]) / src_h if src_h > 0 else 0.5
        tb = target_element["bound_list"]
        tgt_w = tb[2] - tb[0]
        tgt_h = tb[3] - tb[1]
        new_x = tb[0] + (tgt_w * ratio_x)
        new_y = tb[1] + (tgt_h * ratio_y)

        self.last_debug["status"] = "ok"
        self.last_debug["selected_match"] = {
            "element": self._element_summary(target_element),
            "match_score": float(best_match.get("match_score", 0.0) or 0.0),
            "direct_similarity": float(
                best_match.get("direct_similarity", 0.0) or 0.0
            ),
        }
        self.last_debug["projection"] = {
            "source_bounds": list(sb),
            "target_bounds": list(tb),
            "ratio_x": float(ratio_x),
            "ratio_y": float(ratio_y),
            "new_x": float(new_x),
            "new_y": float(new_y),
        }

        return {
            "new_x": new_x,
            "new_y": new_y,
            "src_element": src_element,
            "target_element": target_element,
            "match_score": float(best_match.get("match_score", 0.0) or 0.0),
            "top3_candidates": [
                {
                    "element": self._element_summary(item.get("element")),
                    "match_score": float(item.get("match_score", 0.0) or 0.0),
                }
                for item in list(matches[:3] or [])
            ],
            "debug": dict(self.last_debug),
        }

    def find_best_match(self, src_element_id: str, max_anchors: int = 5) -> List[Dict]:
        """
        统一主流程：
        1. 用 reciprocal best-match 选出 anchor 对。
        2. 用 anchor 把源元素中心投影到目标页。
        3. 用 direct similarity 和 projected-point 几何一致性共同选出目标元素。
        """
        src_element = self.src_tree.element_map.get(src_element_id)
        if not src_element:
            return []

        debug: Dict[str, Any] = {
            "src_element_id": src_element_id,
            "anchor_selection": {},
            "vote_records": [],
            "fallback_used": False,
            "match_results": [],
        }
        anchor_pairs = self._get_anchors(max_anchor_count=max_anchors)
        debug["anchor_selection"] = dict(self._last_anchor_debug)
        if not anchor_pairs:
            debug["fallback_used"] = True
            fallback = self._fallback_match(src_element_id)
            debug["match_results"] = [
                {
                    "element": self._element_summary(item.get("element")),
                    "match_score": float(item.get("match_score", 0.0) or 0.0),
                    "direct_similarity": float(
                        item.get("direct_similarity", 0.0) or 0.0
                    ),
                    "votes": list(item.get("votes") or []),
                }
                for item in list(fallback or [])
            ]
            self.last_debug.update(debug)
            return fallback

        src_feats = self.src_tree.feature_dicts[src_element_id]
        root_bounds = self.tgt_tree.root_bounds
        root_w = max(1.0, float(root_bounds[2]) - float(root_bounds[0]))
        root_h = max(1.0, float(root_bounds[3]) - float(root_bounds[1]))
        page_diag = max(1.0, math.hypot(root_w, root_h))
        candidate_scores: Dict[str, Dict[str, Any]] = {}
        for tgt_element in self.tgt_tree.elements:
            tgt_element_id = tgt_element["id"]
            tgt_feats = self.tgt_tree.feature_dicts[tgt_element_id]
            candidate_scores[tgt_element_id] = {
                "element": tgt_element,
                "direct_similarity": float(
                    self.calculate_embed_similarity(src_feats, tgt_feats)
                ),
                "votes": [],
            }

        for anchor_index, (old_anchor, new_anchor) in enumerate(anchor_pairs):
            anchor_similarity = float(
                max(
                    0.0,
                    min(
                        1.0,
                        self.calculate_embed_similarity(
                            self.src_tree.feature_dicts[old_anchor["id"]],
                            self.tgt_tree.feature_dicts[new_anchor["id"]],
                        ),
                    ),
                )
            )
            pred_x, pred_y = self._reverse_function(
                src_element["center"], old_anchor["center"], new_anchor["center"]
            )
            ranked_candidates: List[Dict[str, Any]] = []
            for data in candidate_scores.values():
                candidate = data["element"]
                center_x, center_y = candidate["center"]
                distance = math.hypot(float(pred_x) - float(center_x), float(pred_y) - float(center_y))
                normalized_distance = distance / page_diag
                geometry_score = float(max(0.0, 1.0 - normalized_distance))
                contribution = anchor_similarity * geometry_score
                contribution_row = {
                    "anchor_index": int(anchor_index),
                    "anchor_similarity": float(anchor_similarity),
                    "geometry_score": float(geometry_score),
                    "contribution": float(contribution),
                    "predicted_point": {"x": float(pred_x), "y": float(pred_y)},
                    "distance": float(distance),
                    "normalized_distance": float(normalized_distance),
                    "element": self._element_summary(candidate),
                }
                data["votes"].append(contribution_row)
                ranked_candidates.append(
                    {
                        "element": self._element_summary(candidate),
                        "direct_similarity": float(data["direct_similarity"]),
                        "geometry_score": float(geometry_score),
                        "contribution": float(contribution),
                    }
                )
            ranked_candidates.sort(key=lambda row: row["contribution"], reverse=True)
            debug["vote_records"].append(
                {
                    "anchor_index": int(anchor_index),
                    "old_anchor": self._element_summary(old_anchor),
                    "new_anchor": self._element_summary(new_anchor),
                    "anchor_similarity": float(anchor_similarity),
                    "predicted_point": {"x": float(pred_x), "y": float(pred_y)},
                    "top_candidates": ranked_candidates[:5],
                }
            )

        scored_rows: List[Dict[str, Any]] = []
        for data in candidate_scores.values():
            direct_similarity = float(data["direct_similarity"])
            votes = sorted(
                list(data.get("votes") or []),
                key=lambda row: row.get("contribution", 0.0),
                reverse=True,
            )
            if not votes:
                continue
            spatial_score = float(
                sum(vote["contribution"] for vote in votes) / len(votes)
            )
            match_score = direct_similarity * spatial_score
            if match_score <= 0.0:
                continue
            scored_rows.append(
                {
                    "element": data["element"],
                    "direct_similarity": direct_similarity,
                    "match_score": float(match_score),
                    "votes": votes[:5],
                }
            )

        if not scored_rows:
            debug["fallback_used"] = True
            fallback = self._fallback_match(src_element_id)
            debug["match_results"] = [
                {
                    "element": self._element_summary(item.get("element")),
                    "match_score": float(item.get("match_score", 0.0) or 0.0),
                    "direct_similarity": float(
                        item.get("direct_similarity", 0.0) or 0.0
                    ),
                    "votes": list(item.get("votes") or []),
                }
                for item in list(fallback or [])
            ]
            self.last_debug.update(debug)
            return fallback

        scored_rows.sort(key=lambda row: row["match_score"], reverse=True)
        results = []
        for row in scored_rows[:5]:
            results.append(
                {
                    "element": row["element"],
                    "direct_similarity": float(
                        row.get("direct_similarity", 0.0) or 0.0
                    ),
                    "match_score": float(row.get("match_score", 0.0) or 0.0),
                    "votes": list(row.get("votes") or []),
                }
            )

        debug["match_results"] = [
            {
                "element": self._element_summary(row.get("element")),
                "direct_similarity": float(
                    row.get("direct_similarity", 0.0) or 0.0
                ),
                "match_score": float(row.get("match_score", 0.0) or 0.0),
                "votes": list(row.get("votes") or []),
            }
            for row in scored_rows[:5]
        ]
        self.last_debug.update(debug)
        return results

    def _get_anchors(self, max_anchor_count: int) -> List[Tuple[Dict, Dict]]:
        """Select reciprocal best-match anchors without extra heuristic gating."""
        all_source_best_matches: List[Dict[str, Any]] = []
        best_target_by_source: List[Tuple[Dict[str, Any], Dict[str, Any], float]] = []

        best_source_by_target: Dict[str, Tuple[Dict[str, Any], float]] = {}

        for new_n in self.tgt_tree.elements:
            new_feats = self.tgt_tree.feature_dicts[new_n["id"]]
            best_source = None
            max_sim = -1.0
            for old_n in self.src_tree.elements:
                old_feats = self.src_tree.feature_dicts[old_n["id"]]
                sim = self.calculate_embed_similarity(old_feats, new_feats)
                if sim > max_sim:
                    max_sim = sim
                    best_source = old_n
            if best_source is not None:
                best_source_by_target[new_n["id"]] = (best_source, float(max_sim))

        for old_n in self.src_tree.elements:
            old_feats = self.src_tree.feature_dicts[old_n["id"]]
            best_match_in_tgt = None
            max_sim = -1.0
            for new_n in self.tgt_tree.elements:
                new_feats = self.tgt_tree.feature_dicts[new_n["id"]]
                sim = self.calculate_embed_similarity(old_feats, new_feats)
                if sim > max_sim:
                    max_sim = sim
                    best_match_in_tgt = new_n
            reciprocal_match = (
                best_match_in_tgt is not None
                and best_source_by_target.get(best_match_in_tgt["id"], ({}, -1.0))[0].get("id")
                == old_n["id"]
            )
            row = {
                "source_element": self._element_summary(old_n),
                "best_target_element": self._element_summary(best_match_in_tgt),
                "similarity": float(max_sim),
                "accepted": bool(best_match_in_tgt and reciprocal_match and max_sim > 0.0),
            }
            all_source_best_matches.append(row)
            if best_match_in_tgt and reciprocal_match and max_sim > 0.0:
                best_target_by_source.append((old_n, best_match_in_tgt, float(max_sim)))

        best_target_by_source.sort(key=lambda x: x[2], reverse=True)
        pairs = []
        selected_pairs: List[Dict[str, Any]] = []
        seen_tgt = set()
        for o, n, raw_sim in best_target_by_source:
            if len(pairs) >= max_anchor_count:
                break
            if n["id"] in seen_tgt:
                continue
            pairs.append((o, n))
            seen_tgt.add(n["id"])
            selected_pairs.append(
                {
                    "source_element": self._element_summary(o),
                    "target_element": self._element_summary(n),
                    "similarity": float(raw_sim),
                }
            )

        self._last_anchor_debug = {
            "max_anchor_count": int(max_anchor_count),
            "all_source_best_matches": all_source_best_matches,
            "selected_pairs": selected_pairs,
        }
        return pairs

    def calculate_embed_similarity(self, feats1: Dict, feats2: Dict) -> float:
        """
        计算两个特征字典对应向量的余弦相似度。
        """
        vec1 = self._vector_from_features(feats1)
        vec2 = self._vector_from_features(feats2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        if norm1 < 1e-6 or norm2 < 1e-6:
            return 0.0
        return float(np.dot(vec1, vec2) / (norm1 * norm2))

    @staticmethod
    def _vector_from_features(features: Dict[str, Any]) -> np.ndarray:
        """Return one element vector from feature payload or embedded shortcut."""
        if isinstance(features, dict) and features.get("_vector") is not None:
            return np.asarray(features["_vector"], dtype=np.float32)
        return ElementVectorizer().to_vector(features)

    def _fallback_match(self, src_element_id: str) -> List[Dict]:
        """保底策略：直接计算向量相似度"""
        src_feats = self.src_tree.feature_dicts[src_element_id]
        src_vec = self._vector_from_features(src_feats)

        candidates = []
        for tgt_elem in self.tgt_tree.elements:
            tgt_feats = self.tgt_tree.feature_dicts[tgt_elem["id"]]
            tgt_vec = self._vector_from_features(tgt_feats)
            dot = np.dot(src_vec, tgt_vec)
            sim = dot / (np.linalg.norm(src_vec) * np.linalg.norm(tgt_vec) + 1e-6)
            candidates.append({"element": tgt_elem, "score": float(sim)})

        candidates.sort(key=lambda x: x["score"], reverse=True)
        top_k = candidates[:5]
        self._last_fallback_debug = {
            "top_k": [
                {
                    "element": self._element_summary(item["element"]),
                    "score": float(item["score"]),
                }
                for item in top_k
            ]
        }
        out = []
        for c in top_k:
            out.append(
                {
                    "element": c["element"],
                    "direct_similarity": float(c["score"]),
                    "match_score": float(c["score"]),
                    "votes": [],
                }
            )
        return out

    def _reverse_function(self, src_c, anchor_old_c, anchor_new_c):
        """计算相对坐标投影：先取源点相对旧锚点的偏移，再做全局 x/y 拉伸。"""
        offset_x = (src_c[0] - anchor_old_c[0]) * self.global_scale["sx"]
        offset_y = (src_c[1] - anchor_old_c[1]) * self.global_scale["sy"]
        return anchor_new_c[0] + offset_x, anchor_new_c[1] + offset_y

    def _calculate_global_scale(self):
        """计算全局缩放比例"""
        b1 = self.src_tree.root_bounds
        b2 = self.tgt_tree.root_bounds
        w1, h1 = b1[2] - b1[0], b1[3] - b1[1]
        w2, h2 = b2[2] - b2[0], b2[3] - b2[1]
        return {"sx": w2 / (w1 + 1e-6), "sy": h2 / (h1 + 1e-6)}


#
_ROOT_BOUNDS_PATTERN = re.compile(r"bounds=\"\[(\d+),(\d+)\]\[(\d+),(\d+)\]\"")


def _extract_root_size(xml_text: str) -> Optional[Tuple[float, float]]:
    if not xml_text:
        return None
    match = _ROOT_BOUNDS_PATTERN.search(xml_text)
    if not match:
        return None
    x1, y1, x2, y2 = [float(item) for item in match.groups()]
    width = max(0.0, x2 - x1)
    height = max(0.0, y2 - y1)
    if width <= 0.0 or height <= 0.0:
        return None
    return width, height


def _scaled_coordinate_projection(
    old_xml: str,
    new_xml: str,
    x: float,
    y: float,
) -> Optional[Tuple[float, float]]:
    src_size = _extract_root_size(old_xml)
    dst_size = _extract_root_size(new_xml)
    if not src_size or not dst_size:
        return None
    src_w, src_h = src_size
    dst_w, dst_h = dst_size
    if src_w <= 0.0 or src_h <= 0.0:
        return None
    return (float(x) * (dst_w / src_w), float(y) * (dst_h / src_h))


def match_element(
    old_xml,
    new_xml,
    x,
    y,
    *,
    allow_scaled_fallback: bool = True,
) -> dict:
    """
    跨 XML 坐标映射统一入口。
    先尝试元素匹配，再做绝对坐标拉伸兜底；兜底失败时返回原坐标。
    返回字段至少包含: new_x, new_y, mapping_mode。
    """
    source_xml = str(old_xml or "").strip()
    target_xml = str(new_xml or "").strip()
    src_x = float(x)
    src_y = float(y)

    if not source_xml or not target_xml:
        return {
            "new_x": src_x,
            "new_y": src_y,
            "mapping_mode": "identity_missing_xml",
            "mapped": False,
            "debug": {
                "status": "identity_missing_xml",
                "input": {"x": src_x, "y": src_y},
                "allow_scaled_fallback": bool(allow_scaled_fallback),
            },
        }

    mapped: Optional[dict] = None
    matcher: Optional[UTGMatcher] = None
    exception_text = ""
    try:
        matcher = UTGMatcher(source=source_xml, target=target_xml)
        mapped = matcher.map_coordinates(float(src_x), float(src_y))
    except Exception as exc:
        exception_text = str(exc)
        logger.warning("Coordinate mapping failed in match_element: %s", exc)

    if isinstance(mapped, dict) and "new_x" in mapped and "new_y" in mapped:
        out = dict(mapped)
        out["new_x"] = float(mapped["new_x"])
        out["new_y"] = float(mapped["new_y"])
        out["mapping_mode"] = "element_match"
        out["mapped"] = True
        debug = dict(out.get("debug") or {})
        debug["allow_scaled_fallback"] = bool(allow_scaled_fallback)
        if exception_text:
            debug["exception"] = exception_text
        out["debug"] = debug
        return out

    scaled = None
    if allow_scaled_fallback:
        scaled = _scaled_coordinate_projection(source_xml, target_xml, src_x, src_y)
    if scaled is not None:
        debug = {
            "status": "scaled_fallback",
            "input": {"x": src_x, "y": src_y},
            "allow_scaled_fallback": bool(allow_scaled_fallback),
            "matcher_debug": dict(getattr(matcher, "last_debug", {}) or {}),
            "exception": exception_text or None,
            "scaled_projection": {
                "available": True,
                "x": float(scaled[0]),
                "y": float(scaled[1]),
            },
        }
        return {
            "new_x": float(scaled[0]),
            "new_y": float(scaled[1]),
            "mapping_mode": "scaled_fallback",
            "mapped": True,
            "debug": debug,
        }

    debug = {
        "status": "identity_no_mapping",
        "input": {"x": src_x, "y": src_y},
        "allow_scaled_fallback": bool(allow_scaled_fallback),
        "matcher_debug": dict(getattr(matcher, "last_debug", {}) or {}),
    }
    if exception_text:
        debug["exception"] = exception_text
    return {
        "new_x": src_x,
        "new_y": src_y,
        "mapping_mode": "identity_no_mapping",
        "mapped": False,
        "debug": debug,
    }


def adapt_action_coordinates(
    action: Any,
    *,
    new_xml: Optional[str],
    node: Optional[Any] = None,
    allow_scaled_fallback: bool = True,
    return_debug: bool = False,
) -> Tuple[Any, bool] | Tuple[Any, bool, Dict[str, Any]]:
    """
    统一 action 坐标适配入口。
    仅处理带 `params.x/params.y` 的动作，返回 `(adapted_action, applied)`；当 `return_debug=True` 时额外返回调试信息。
    """
    params = getattr(action, "params", None)
    debug: Dict[str, Any] = {
        "applied": False,
        "mapping_mode": "",
        "source_x": None,
        "source_y": None,
        "target_x": None,
        "target_y": None,
        "source_xml_len": 0,
        "target_xml_len": 0,
    }
    if not isinstance(params, dict):
        return (action, False, debug) if return_debug else (action, False)
    if "x" not in params or "y" not in params:
        return (action, False, debug) if return_debug else (action, False)

    target_xml = str(new_xml or "").strip()
    source_xml = resolve_action_source_xml(
        action=action, node=node, target_xml=target_xml
    )
    if not source_xml:
        source_xml = target_xml

    try:
        src_x = float(params["x"])
        src_y = float(params["y"])
    except Exception:
        return (action, False, debug) if return_debug else (action, False)

    if source_xml and target_xml:
        source_root_match = _ROOT_BOUNDS_PATTERN.search(source_xml)
        if source_root_match:
            src_root_x1, src_root_y1, src_root_x2, src_root_y2 = [
                float(item) for item in source_root_match.groups()
            ]
            if not (
                src_root_x1 <= float(src_x) <= src_root_x2
                and src_root_y1 <= float(src_y) <= src_root_y2
            ):
                debug["source_xml_space"] = "coords_outside_source_root"
                source_xml = target_xml

    debug["source_x"] = src_x
    debug["source_y"] = src_y
    debug["source_xml_len"] = len(source_xml)
    debug["target_xml_len"] = len(target_xml)
    if isinstance(getattr(action, "params", None), dict):
        debug["source_xml_ref"] = str(action.params.get("xml_ref") or "").strip()

    mapped = match_element(
        source_xml,
        target_xml,
        src_x,
        src_y,
        allow_scaled_fallback=allow_scaled_fallback,
    )
    if not isinstance(mapped, dict):
        return (action, False, debug) if return_debug else (action, False)
    debug["mapping_mode"] = str(mapped.get("mapping_mode") or "")
    if isinstance(mapped.get("debug"), dict):
        debug["matcher_debug"] = dict(mapped.get("debug") or {})
    if "new_x" not in mapped or "new_y" not in mapped:
        return (action, False, debug) if return_debug else (action, False)

    debug["target_x"] = float(mapped.get("new_x") or src_x)
    debug["target_y"] = float(mapped.get("new_y") or src_y)
    if mapped.get("mapped") is False:
        return (action, False, debug) if return_debug else (action, False)

    if not hasattr(action, "model_copy"):
        return (action, False, debug) if return_debug else (action, False)

    adapted = action.model_copy(deep=True)
    adapted_params = getattr(adapted, "params", None)
    if not isinstance(adapted_params, dict):
        return (action, False, debug) if return_debug else (action, False)
    adapted.params["x"] = float(mapped["new_x"])
    adapted.params["y"] = float(mapped["new_y"])
    debug["applied"] = True
    return (adapted, True, debug) if return_debug else (adapted, True)


def resolve_action_source_xml(
    *,
    action: Any,
    node: Optional[Any] = None,
    target_xml: str = "",
) -> str:
    params = getattr(action, "params", None)
    xml_ref = ""
    if isinstance(params, dict):
        # 优先使用内联的 source_xml（来自 run_log import）
        source_xml = str(params.get("source_xml") or "").strip()
        if source_xml:
            return source_xml
        xml_ref = str(params.get("xml_ref") or "").strip()

    if node is not None:
        node_repr = getattr(node, "repr", None)
        if (
            node_repr is not None
            and xml_ref
            and hasattr(node_repr, "resolve_xml_by_ref")
        ):
            try:
                resolved = str(node_repr.resolve_xml_by_ref(xml_ref) or "").strip()
            except Exception:
                resolved = ""
            if resolved:
                return resolved
        node_xmls = getattr(node_repr, "xmls", None)
        if isinstance(node_xmls, list) and node_xmls:
            text = str(node_xmls[0] or "").strip()
            if text:
                return text
    return str(target_xml or "").strip()


# ==============================================================================
# Public API: adapt_coordinates
# ==============================================================================


def adapt_coordinates(
    source_xml: str,
    target_xml: str,
    source_x: float,
    source_y: float,
) -> dict:
    """
    Action 坐标映射的标准 API。

    输入:
        source_xml: 源页面 XML (UI Hierarchy)
        target_xml: 目标页面 XML
        source_x: 源点击坐标 X
        source_y: 源点击坐标 Y

    输出:
        {
            "target_x": float,        # 映射后的坐标 X
            "target_y": float,        # 映射后的坐标 Y
            "mapped": bool,           # 是否成功映射
            "confidence": float,      # 置信度 0-1
            "matched_element": {...},    # 匹配到的目标元素
            "source_element": {...},     # 源元素
            "mapping_mode": str,      # 映射模式
            "debug": {...},           # 调试信息
        }

    使用示例:
        >>> result = adapt_coordinates(
        ...     source_xml="<hierarchy>...</hierarchy>",
        ...     target_xml="<hierarchy>...</hierarchy>",
        ...     source_x=540.0,
        ...     source_y=1200.0,
        ... )
        >>> if result["mapped"]:
        ...     print(f"映射到 ({result['target_x']}, {result['target_y']})")
        ...     print(f"置信度: {result['confidence']:.2%}")
    """
    result = match_element(
        old_xml=source_xml,
        new_xml=target_xml,
        x=source_x,
        y=source_y,
        allow_scaled_fallback=True,
    )

    # 提取置信度
    confidence = 0.0
    if result.get("mapped"):
        confidence = float(result.get("match_score", 0.0) or 0.0)
        if confidence == 0.0:
            debug = result.get("debug") or {}
            selected = debug.get("selected_match") or {}
            confidence = float(selected.get("match_score", 0.0) or 0.0)

    # 提取元素信息
    matched_element = None
    source_element = None
    if isinstance(result.get("target_element"), dict):
        matched_element = {
            "id": result["target_element"].get("id"),
            "class": result["target_element"].get("class"),
            "text": result["target_element"].get("text"),
            "content_desc": result["target_element"].get("content-desc"),
            "resource_id": result["target_element"].get("resource-id"),
            "bounds": result["target_element"].get("bound_list"),
            "center": result["target_element"].get("center"),
            "clickable": result["target_element"].get("clickable"),
        }
    if isinstance(result.get("src_element"), dict):
        source_element = {
            "id": result["src_element"].get("id"),
            "class": result["src_element"].get("class"),
            "text": result["src_element"].get("text"),
            "content_desc": result["src_element"].get("content-desc"),
            "resource_id": result["src_element"].get("resource-id"),
            "bounds": result["src_element"].get("bound_list"),
            "center": result["src_element"].get("center"),
            "clickable": result["src_element"].get("clickable"),
        }

    return {
        "target_x": float(result.get("new_x", source_x)),
        "target_y": float(result.get("new_y", source_y)),
        "mapped": bool(result.get("mapped", False)),
        "confidence": float(confidence),
        "matched_element": matched_element,
        "source_element": source_element,
        "mapping_mode": str(result.get("mapping_mode", "")),
        "debug": result.get("debug"),
    }
