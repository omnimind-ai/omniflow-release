import logging
import os
from pathlib import Path
import pickle
from typing import Any, Dict, List, Optional

import numpy as np

from src.foundation.paths import get_runtime_file
from src.utg.assets.embedding.config import ElementEmbeddingConfig, PageEncodingConfig
from src.utg.assets.embedding.element_embedding import ElementVectorizer, UITree

logger = logging.getLogger(__name__)


class EnhancedPageEncoder:
    """
    Encode one page into a fixed 8-slice page IR.

    Args:
        config: Page-level slice configuration. Only spatial cut ratios are used.
        element_config: Element vector configuration whose output is pooled into
            each page slice.

    Returns:
        A normalized page vector with 8 contiguous element-sized slices:
        `global_all / app_topbar / footer / middle_region / selected_target /
        body_actionable / body_focus_target / body_display_text`.
    """

    def __init__(
        self,
        config: Optional[PageEncodingConfig] = None,
        element_config: Optional[ElementEmbeddingConfig] = None,
    ):
        self.config = config or PageEncodingConfig()
        self.element_config = element_config or ElementEmbeddingConfig()
        self.element_vectorizer = ElementVectorizer(self.element_config)
        self.element_dim = self.element_vectorizer.total_dim
        self.anchor_dim = 0
        self.page_dim = self.element_dim * 8

    def _empty_payload(self, package_filter: Optional[str]) -> Dict[str, Any]:
        """
        Build the zero-vector payload used when a page has no encodable elements.

        Args:
            package_filter: Explicit package filter passed by the caller, if any.

        Returns:
            A minimal debug payload with empty slice memberships.
        """
        return {
            "vector": np.zeros(self.page_dim, dtype=np.float32),
            "analysis": {
                "package_filter": package_filter,
                "app_topbar_cut": None,
                "footer_cut": None,
                "global_all_element_ids": [],
                "app_topbar_element_ids": [],
                "footer_element_ids": [],
                "middle_region_element_ids": [],
                "selected_target_element_ids": [],
                "body_actionable_element_ids": [],
                "body_focus_target_element_ids": [],
                "body_display_text_element_ids": [],
            },
        }

    def _pool(self, element_matrix: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """
        Pool one slice with plain max over the selected elements.

        Args:
            element_matrix: `(num_elements, element_dim)` matrix aligned to XML order.
            mask: Boolean selector for the elements that belong to this slice.

        Returns:
            The pooled slice vector, or zeros when the slice is empty.
        """
        if not np.any(mask):
            return np.zeros(self.element_dim, dtype=np.float32)
        return np.max(element_matrix[mask], axis=0).astype(np.float32)

    def analyze(
        self,
        ui_tree: UITree,
        encode_context: Optional[Dict[str, Any]] = None,
        *,
        top_n: int = 12,
    ) -> Dict[str, Any]:
        """
        Encode the page and return the minimal slice-level debug payload.

        Args:
            ui_tree: Parsed UI tree whose element order defines all masks.
            encode_context: Optional caller context. Only explicit `package_name`
                or `package` is honored, and only as a package filter.
            top_n: Compatibility-only debug knob kept in the public signature.

        Returns:
            A dict with the normalized page vector and slice memberships.
        """
        del top_n

        aligned_elements: List[Dict[str, Any]] = []
        aligned_vectors: List[np.ndarray] = []
        for elem in ui_tree.elements:
            elem_id = elem.get("id")
            vec = ui_tree.vectors.get(elem_id)
            if vec is None:
                continue
            aligned_elements.append(elem)
            aligned_vectors.append(vec)

        package_filter = str(
            (encode_context or {}).get("package_name")
            or (encode_context or {}).get("package")
            or ""
        ).strip()
        if not package_filter:
            package_filter = None

        if not aligned_vectors:
            return self._empty_payload(package_filter)

        element_matrix = np.stack(aligned_vectors)
        num_elements = len(aligned_elements)

        root_h = ui_tree.root_bounds[3] - ui_tree.root_bounds[1]
        if root_h <= 0:
            root_h = self.config.root_height_default
        y_ratios = np.array(
            [float(n.get("center", (0, 0))[1]) / float(root_h) for n in aligned_elements]
        )

        texts = [ui_tree.get_text(elem) for elem in aligned_elements]
        has_text = np.array([bool(str(text or "").strip()) for text in texts], dtype=bool)
        child_counts = np.array(
            [len(list(elem.get("children_ids") or [])) for elem in aligned_elements],
            dtype=np.int32,
        )

        def is_true(elem: Dict[str, object], *keys: str, default: bool = False) -> bool:
            for key in keys:
                value = elem.get(key)
                if value in (None, ""):
                    continue
                return str(value).lower() == "true"
            return default

        is_actionable = np.array(
            [
                (
                    is_true(elem, "clickable")
                    or is_true(elem, "checkable")
                    or is_true(elem, "long-clickable")
                )
                and is_true(elem, "enabled", default=True)
                and is_true(elem, "visible", "visible-to-user", default=True)
                for elem in aligned_elements
            ],
            dtype=bool,
        )
        is_focus_target = np.array(
            [
                (
                    is_true(elem, "focusable")
                    or is_true(elem, "editable")
                    or is_true(elem, "focused")
                )
                and is_true(elem, "enabled", default=True)
                and is_true(elem, "visible", "visible-to-user", default=True)
                for elem in aligned_elements
            ],
            dtype=bool,
        )
        is_display_text = np.array(
            [
                bool(has_text[idx])
                and int(child_counts[idx]) == 0
                and not bool(is_actionable[idx])
                and not bool(is_focus_target[idx])
                for idx in range(num_elements)
            ],
            dtype=bool,
        )
        is_root = np.array(
            [str(elem.get("id") or "") == "__aw_root__" for elem in aligned_elements],
            dtype=bool,
        )

        package_names = np.array(
            [str(elem.get("package") or "").strip() for elem in aligned_elements],
            dtype=object,
        )
        app_package_mask = np.ones(num_elements, dtype=bool)
        if package_filter:
            app_package_mask = package_names == package_filter

        global_mask = ~is_root
        footer_cut = float(np.quantile(y_ratios, self.config.footer_ratio))

        topbar_reference_mask = (~is_root) & app_package_mask
        if not np.any(topbar_reference_mask):
            topbar_reference_mask = ~is_root
        if not np.any(topbar_reference_mask):
            topbar_reference_mask = np.ones(num_elements, dtype=bool)
        app_topbar_cut = float(
            np.quantile(y_ratios[topbar_reference_mask], self.config.header_ratio)
        )

        app_topbar_mask = (~is_root) & (y_ratios <= app_topbar_cut)
        if package_filter:
            app_topbar_mask &= app_package_mask
        footer_mask = (~is_root) & (y_ratios >= footer_cut)
        middle_region_mask = (
            app_package_mask & (~is_root) & (~app_topbar_mask) & (~footer_mask)
        )

        def is_selected_like(elem: Dict[str, object]) -> bool:
            return (
                is_true(elem, "selected")
                or is_true(elem, "activated")
                or (is_true(elem, "checkable") and is_true(elem, "checked"))
            )

        selected_like = np.array(
            [is_selected_like(elem) for elem in aligned_elements], dtype=bool
        )
        selected_target_mask = app_package_mask & (~is_root) & selected_like
        selected_footer_mask = selected_target_mask & footer_mask
        selected_middle_mask = selected_target_mask & middle_region_mask
        if np.any(selected_footer_mask):
            selected_output_mask = selected_footer_mask
        elif np.any(selected_middle_mask):
            selected_output_mask = selected_middle_mask
        else:
            selected_output_mask = selected_target_mask

        body_actionable_mask = middle_region_mask & is_actionable
        body_focus_target_mask = middle_region_mask & is_focus_target
        body_display_text_mask = middle_region_mask & is_display_text

        final_vec = np.concatenate(
            [
                self._pool(element_matrix, global_mask),
                self._pool(element_matrix, app_topbar_mask),
                self._pool(element_matrix, footer_mask),
                self._pool(element_matrix, middle_region_mask),
                self._pool(element_matrix, selected_output_mask),
                self._pool(element_matrix, body_actionable_mask),
                self._pool(element_matrix, body_focus_target_mask),
                self._pool(element_matrix, body_display_text_mask),
            ]
        ).astype(np.float32)
        norm = np.linalg.norm(final_vec)
        if norm > 1e-9:
            final_vec /= norm

        analysis = {
            "package_filter": package_filter,
            "app_topbar_cut": round(float(app_topbar_cut), 4),
            "footer_cut": round(float(footer_cut), 4),
            "global_all_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(global_mask)
            ],
            "app_topbar_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(app_topbar_mask)
            ],
            "footer_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(footer_mask)
            ],
            "middle_region_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(middle_region_mask)
            ],
            "selected_target_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(selected_output_mask)
            ],
            "body_actionable_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_actionable_mask)
            ],
            "body_focus_target_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_focus_target_mask)
            ],
            "body_display_text_element_ids": [
                str(aligned_elements[idx].get("id") or "")
                for idx in np.flatnonzero(body_display_text_mask)
            ],
        }
        return {"vector": final_vec.astype(np.float32), "analysis": analysis}

    def encode(
        self, ui_tree: UITree, encode_context: Optional[Dict[str, Any]] = None
    ) -> np.ndarray:
        """
        Encode one UI tree into the normalized page vector.

        Args:
            ui_tree: Parsed XML page tree.
            encode_context: Optional caller context passed through to `analyze`.

        Returns:
            The normalized page vector.
        """
        return self.analyze(ui_tree, encode_context=encode_context)["vector"]


class LiteVectorDB:
    """Simple in-process page vector store used by UTG page matching."""

    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or str(get_runtime_file("cache", "ui_auto_enhanced.db"))
        self.encoder = EnhancedPageEncoder()
        self.ids: List[str] = []
        self.vectors: Optional[np.ndarray] = None
        self.metadata: Dict[str, Dict] = {}
        self.load()

    def add_page(
        self,
        page_id: str,
        xml_content: str,
        meta: Optional[Dict[str, Any]] = None,
        encode_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Encode one XML page and upsert it into the vector store.

        Args:
            page_id: Stable page identifier inside the vector DB.
            xml_content: XML snapshot to encode.
            meta: Arbitrary page metadata stored alongside the vector.
            encode_context: Optional package filter context for encoding.
        """
        tree = UITree(xml_content, is_file=False)
        vec = self.encoder.encode(tree, encode_context=encode_context)

        if page_id in self.metadata:
            idx = self.ids.index(page_id)
            if self.vectors is None:
                self.vectors = np.array([vec], dtype=np.float32)
                self.ids = [page_id]
            else:
                self.vectors[idx] = vec
        else:
            if self.vectors is None:
                self.vectors = np.array([vec], dtype=np.float32)
            else:
                self.vectors = np.vstack([self.vectors, vec])
            self.ids.append(page_id)

        self.metadata[page_id] = meta or {}

    def add_page_with_vector(
        self,
        page_id: str,
        vec: np.ndarray,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Upsert one pre-computed page vector into the vector store.

        Args:
            page_id: Stable page identifier inside the vector DB.
            vec: Pre-computed page vector following the current page encoder
                contract. The vector is stored as `float32`.
            meta: Arbitrary page metadata stored alongside the vector.

        Returns:
            None. The vector DB is updated in place.
        """
        page_vec = np.asarray(vec, dtype=np.float32).reshape(-1)
        if page_vec.shape != (self.encoder.page_dim,):
            raise ValueError(
                f"page vector shape mismatch: expected {(self.encoder.page_dim,)}, "
                f"got {page_vec.shape}"
            )

        if page_id in self.metadata:
            idx = self.ids.index(page_id)
            if self.vectors is None:
                self.vectors = np.array([page_vec], dtype=np.float32)
                self.ids = [page_id]
            else:
                self.vectors[idx] = page_vec
        else:
            if self.vectors is None:
                self.vectors = np.array([page_vec], dtype=np.float32)
            else:
                self.vectors = np.vstack([self.vectors, page_vec])
            self.ids.append(page_id)

        self.metadata[page_id] = meta or {}

    def search(
        self,
        xml_content: str,
        top_k: int = 3,
        threshold: float | None = None,
        encode_context: Optional[Dict[str, Any]] = None,
    ) -> List[tuple[str, float, Dict[str, Any]]]:
        """
        Search the vector DB with one XML page query.

        Args:
            xml_content: Query page XML.
            top_k: Maximum number of matches returned.
            threshold: Optional minimum cosine score gate.
            encode_context: Optional package filter context for query encoding.

        Returns:
            Sorted `(page_id, score, metadata)` tuples.
        """
        if self.vectors is None or len(self.vectors) == 0:
            return []

        tree = UITree(xml_content, is_file=False)
        query_vec = self.encoder.encode(tree, encode_context=encode_context)
        scores = np.dot(self.vectors, query_vec)

        k = min(top_k, len(scores))
        top_indices = np.argpartition(scores, -k)[-k:]
        top_indices = top_indices[np.argsort(scores[top_indices])[::-1]]

        results: List[tuple[str, float, Dict[str, Any]]] = []
        for idx in top_indices:
            page_id = self.ids[idx]
            score = float(scores[idx])
            meta = self.metadata.get(page_id, {})
            if threshold is None or score >= threshold:
                results.append((page_id, score, meta))
        return results

    def save(self) -> None:
        """Persist the current vector DB to disk."""
        try:
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
            with open(self.db_path, "wb") as handle:
                pickle.dump(
                    {"ids": self.ids, "vectors": self.vectors, "meta": self.metadata},
                    handle,
                )
            print(f"[DB] Saved {len(self.ids)} pages.")
        except Exception as exc:
            print(f"[DB] Save failed: {exc}")

    def load(self) -> None:
        """Load the vector DB from disk when the cache file exists."""
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "rb") as handle:
                    data = pickle.load(handle)
                    self.ids = data["ids"]
                    self.vectors = data["vectors"]
                    self.metadata = data.get("meta", {})
            except Exception:
                logger.warning("[DB] Load failed, starting fresh.")

    def clear(self) -> None:
        """Reset the in-memory vector DB state."""
        self.ids = []
        self.vectors = None
        self.metadata = {}
