from __future__ import annotations

import contextlib
from functools import lru_cache
import io
from typing import Any, Dict, Optional

import numpy as np

from src.utg.assets.embedding.element_embedding import UITree
from src.utg.assets.embedding.element_match import match_element
from src.utg.assets.embedding.page_embedding import (
    EnhancedPageEncoder,
    LiteVectorDB,
)

_PAGE_ENCODER = EnhancedPageEncoder()


def _normalize_xml(xml: str) -> str:
    return (xml or "").strip()


def build_ui_tree(xml_text: str) -> UITree:
    return UITree(str(xml_text or ""), is_file=False)


def encode_xml_elements(xml_text: str) -> Dict[str, np.ndarray]:
    tree = build_ui_tree(xml_text)
    return dict(tree.vectors)


def encode_xml_page(
    xml_text: str,
    *,
    encode_context: Optional[Dict[str, Any]] = None,
) -> np.ndarray:
    tree = build_ui_tree(xml_text)
    return _PAGE_ENCODER.encode(tree, encode_context=encode_context)


def _build_page_vector(xml_text: str) -> Optional[np.ndarray]:
    normalized = _normalize_xml(xml_text)
    if not normalized:
        return None
    try:
        with (
            contextlib.redirect_stdout(io.StringIO()),
            contextlib.redirect_stderr(io.StringIO()),
        ):
            tree = UITree(normalized, is_file=False)
    except Exception:
        return None
    page_vec = _PAGE_ENCODER.encode(tree)
    if not isinstance(page_vec, np.ndarray) or page_vec.size == 0:
        return None
    norm = float(np.linalg.norm(page_vec))
    if norm <= 1e-6:
        return None
    return (page_vec / norm).astype(np.float32)


@lru_cache(maxsize=256)
def _page_vector_cached(xml_text: str) -> Optional[np.ndarray]:
    return _build_page_vector(xml_text)


def xml_similarity(xml1: str, xml2: str) -> float:
    a = _normalize_xml(xml1)
    b = _normalize_xml(xml2)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    vec_a = _page_vector_cached(a)
    vec_b = _page_vector_cached(b)
    if vec_a is None or vec_b is None:
        return 0.0
    dot = float(np.dot(vec_a, vec_b))
    norm_a = float(np.linalg.norm(vec_a))
    norm_b = float(np.linalg.norm(vec_b))
    if norm_a <= 1e-6 or norm_b <= 1e-6:
        return 0.0
    score = dot / (norm_a * norm_b)
    return max(0.0, min(1.0, score))


def match_xml_coordinates(
    source_xml: str,
    target_xml: str,
    x: int,
    y: int,
    *,
    allow_scaled_fallback: bool = True,
) -> Dict[str, Any]:
    result = match_element(
        source_xml,
        target_xml,
        float(x),
        float(y),
        allow_scaled_fallback=allow_scaled_fallback,
    )
    return dict(result or {})


def search_similar_xml_pages(
    vector_db: LiteVectorDB,
    xml_text: str,
    *,
    top_k: int = 3,
    threshold: float | None = None,
    encode_context: Optional[Dict[str, Any]] = None,
):
    return vector_db.search(
        xml_text,
        top_k=top_k,
        threshold=threshold,
        encode_context=encode_context,
    )


__all__ = [
    "build_ui_tree",
    "encode_xml_elements",
    "encode_xml_page",
    "xml_similarity",
    "match_xml_coordinates",
    "search_similar_xml_pages",
]
