"""UTG core package root.

Import concrete modules directly from `src.utg.core`, `src.utg.runtime`,
`src.utg.execution`, `src.utg.assets`, and `src.utg.log`.
"""

from src.utg.core import Function, UTGGraph, UTGNode

__all__ = ["UTGGraph", "UTGNode", "Function"]
__version__ = "0.3.0"


def __getattr__(name: str):
    if name == "UTGRuntime":
        from src.utg.runtime import UTGRuntime

        return UTGRuntime
    raise AttributeError(name)
