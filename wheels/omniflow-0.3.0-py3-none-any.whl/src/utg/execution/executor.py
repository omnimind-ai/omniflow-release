from __future__ import annotations

import asyncio
from dataclasses import dataclass
import inspect
import json
import logging
import sys
from time import perf_counter
from typing import Any, Dict, Optional

from src.foundation.source_tools import (
    find_clickable_node_id_by_prompt,
    find_node_center_by_id,
    to_jsonable,
)
from src.utg.assets.embedding import adapt_action_coordinates
from src.utg.core.actions import (
    AnyAction,
    CallFunctionAction,
    ClickNodeAction,
    canonical_action_type,
    extract_executed_actions_from_detail,
)
from src.utg.core.models import Function, UTGNode
from src.utg.core.params import ParamRenderer
from src.utg.execution.control.error_codes import (
    EXEC_ACTION_FAIL,
    EXEC_FUNCTION_FAIL,
    EXEC_FUNCTION_NOT_FOUND,
    EXEC_HUMAN_HANDOFF,
    EXEC_NODE_NOT_FOUND,
    EXEC_STATE_STALL,
)
from src.utg.execution.execution_policy import (
    ExecutionPolicyBundle,
    ExecutionPolicyProvider,
    PathControlConfig,
    is_baseline_mode,
)
from src.utg.execution.param_renderer import ActionParamRenderer
from src.utg.execution.protocol import (
    ActFn,
    Observation,
    ObserveFn,
    RouteContext,
    act_on_device,
    is_response_failed,
    observations_equal,
    observe_xml,
)
from src.utg.execution.tracer import ExecutionTracer
from src.utg.execution.utils import (
    observation_to_dict,
    safe_dict,
)

logger = logging.getLogger(__name__)

_MAX_DEVICE_ACTIONS_HISTORY = 100

# Recursion safety limits
_ABSOLUTE_MAX_CALL_DEPTH = 100  # Hard limit to prevent stack overflow
_CYCLE_DETECTION_ENABLED = True  # Enable call cycle detection (A→B→A)


def _normalize_action_type(value: Any) -> str:
    return canonical_action_type(value)


class ActionAdapter:
    """Adapt one rendered action against the live page before device execution.

    Args:
        path_control: Runtime switches for click-prompt resolution and coordinate
            remapping.
    """

    def __init__(self, path_control: Optional[PathControlConfig] = None) -> None:
        self.path_control = path_control or PathControlConfig()
        self.last_adaptation_debug: Dict[str, Any] = {}

    async def adapt(
        self,
        observe: ObserveFn,
        node: UTGNode,
        action: AnyAction,
        *,
        observation: Observation | None = None,
    ) -> AnyAction:
        """Resolve clickPrompt and coordinate remapping using the current XML.

        Args:
            observe: Live observe function used to fetch the latest page XML.
            node: Source UTG node that produced the compiled action coordinates.
            action: Rendered action after parameter substitution but before device send.
            observation: Optional already-captured observation for the current
                action. When it already carries XML, the adapter reuses it
                instead of issuing another live observe.

        Returns:
            A device-ready action. The returned action may be a `click_node`
            rewrite, a coordinate-remapped copy, or the original action.
        """

        self.last_adaptation_debug = {}
        params = getattr(action, "params", None)
        if not isinstance(params, dict):
            return action

        current_xml: Optional[str] = str(getattr(observation, "xml", "") or "").strip()
        if not current_xml:
            current_xml = None
        click_prompt = str(params.get("clickPrompt") or "").strip()
        if click_prompt and self.path_control.enable_click_prompt:
            try:
                if current_xml is None:
                    current_xml = await observe_xml(observe)
                node_id = find_clickable_node_id_by_prompt(current_xml, click_prompt)
                if node_id:
                    if hasattr(getattr(observe, "__self__", None), "click_node"):
                        self.last_adaptation_debug = {
                            "kind": "click_prompt",
                            "click_prompt": click_prompt,
                            "resolution": "click_node",
                            "node_id": node_id,
                        }
                        logger.info(
                            "[coord_map] clickPrompt=%s resolution=click_node node_id=%s",
                            click_prompt,
                            node_id,
                        )
                        return ClickNodeAction(
                            type="click_node",
                            params={"node_id": node_id},
                            description=getattr(action, "description", None),
                        )
                    center = find_node_center_by_id(current_xml, node_id)
                    if center is not None:
                        click_action = action.model_copy(deep=True)
                        click_action.params = {
                            **dict(click_action.params),
                            "x": center[0],
                            "y": center[1],
                            "clickPrompt": click_prompt,
                        }
                        self.last_adaptation_debug = {
                            "kind": "click_prompt",
                            "click_prompt": click_prompt,
                            "resolution": "prompt_center",
                            "target_x": center[0],
                            "target_y": center[1],
                        }
                        logger.info(
                            "[coord_map] clickPrompt=%s resolution=prompt_center target=(%s,%s)",
                            click_prompt,
                            center[0],
                            center[1],
                        )
                        return click_action
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as exc:
                logger.warning(
                    "[run_function] clickPrompt node resolution failed: %s", exc
                )
        if "x" not in params or "y" not in params:
            return action
        if not self.path_control.enable_coordinate_adaptation:
            return action
        if current_xml is None:
            current_xml = await observe_xml(observe)
        adapted, applied, debug = adapt_action_coordinates(
            action,
            new_xml=current_xml,
            node=node,
            return_debug=True,
        )  # type: ignore[misc]
        self.last_adaptation_debug = dict(debug or {})
        logger.info(
            "[coord_map] applied=%s mode=%s src=(%s,%s) target=(%s,%s)",
            applied,
            self.last_adaptation_debug.get("mapping_mode"),
            self.last_adaptation_debug.get("source_x"),
            self.last_adaptation_debug.get("source_y"),
            self.last_adaptation_debug.get("target_x"),
            self.last_adaptation_debug.get("target_y"),
        )
        if not applied:
            return action
        return adapted


@dataclass
class RunFunctionResult:
    success: bool
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    last_action: Optional[AnyAction] = None
    before_observation: Optional[Dict[str, Any]] = None
    final_observation: Optional[Dict[str, Any]] = None
    action_used: Optional[Any] = None
    control_trace: Optional[Dict[str, Any]] = None
    prompt_context: Optional[Dict[str, Any]] = None
    provider_detail: Optional[Dict[str, Any]] = None


class UTGExecutor:
    """Execute one compiled UTG function with a control-bus-first runtime loop."""

    def __init__(
        self,
        stats=None,
        *,
        policy_provider: Optional[ExecutionPolicyProvider] = None,
        control_engine: Optional[Any] = None,
    ) -> None:
        if stats is None:
            from src.utg.assets.embedding import UTGStatsCollector

            stats = UTGStatsCollector()
        self.stats = stats
        self.policy_provider = policy_provider or ExecutionPolicyBundle()
        if control_engine is None:
            from src.utg.execution.control import ControlEngine

            control_engine = ControlEngine(self.policy_provider)
        self.control_engine = control_engine
        self.path_control = self.policy_provider.path_config()
        self.adapter = ActionAdapter(path_control=self.path_control)
        self._last_action_effect_debug: Dict[str, Any] = {}
        self.tracer = ExecutionTracer(self._last_action_effect_debug)

    def snapshot_last_action_effect_debug(self) -> Dict[str, Any]:
        """Return the last post-action observation summary written by executor."""

        return dict(self._last_action_effect_debug or {})

    def snapshot_last_coordinate_adaptation_debug(self) -> Dict[str, Any]:
        """Return the last coordinate adaptation debug payload from the adapter."""

        return dict(getattr(self.adapter, "last_adaptation_debug", {}) or {})

    async def run_action(
        self,
        observe: ObserveFn,
        act: ActFn,
        node: UTGNode,
        action: AnyAction,
        *,
        context: Optional[dict] = None,
    ) -> RunFunctionResult:
        """Execute one action by wrapping it as a one-function body."""

        function = Function(name="__single_action__", actions=[action])
        return await self.run_function(
            observe,
            act,
            node,
            function,
            context=context,
        )

    async def controlled_act(
        self,
        observe: ObserveFn,
        act: ActFn,
        action: AnyAction,
        *,
        context: Optional[dict] = None,
        runtime: Any = None,
        observation: Observation | None = None,
    ) -> dict[str, Any]:
        """Execute one external action through the shared control bus.

        Args:
            observe: Live observe function used for fresh observations.
            act: Live act function used for device execution.
            action: One normalized action proposed by an external agent.
            context: Shared hook context propagated into control and tracing.
            runtime: Optional runtime facade used by control rules.
            observation: Optional caller-provided pre-action observation.

        Returns:
            A compact action result with success/error/final observation and
            prompt_context for the caller's next planning round.
        """

        runtime_ctx = dict(context or {})
        runtime_ctx.setdefault("__utg_control_trace__", {})
        runtime_ctx.setdefault("__utg_control_scope__", "act_hook")
        if "source" in runtime_ctx and "__utg_control_source__" not in runtime_ctx:
            runtime_ctx["__utg_control_source__"] = runtime_ctx["source"]
        runtime_ctx.setdefault("__utg_control_source__", "external")
        runtime_ctx.setdefault("__utg_current_step_index__", 0)
        self._last_action_effect_debug = {}
        if observation is not None:
            self._remember_observation(runtime_ctx, observation)
            runtime_ctx["__utg_reuse_before_action_observation__"] = True
        result = await self.run_function(
            observe,
            act,
            None,
            Function(name="__controlled_act__", actions=[action]),
            context=runtime_ctx,
            runtime=runtime,
        )
        return {
            "success": bool(result.success),
            "error_code": str(result.error_code or "").strip() or None,
            "error_message": str(result.error_message or "").strip() or None,
            "before_observation": dict(result.before_observation or {})
            if isinstance(result.before_observation, dict)
            else None,
            "action_used": to_jsonable(result.action_used),
            "final_observation": dict(result.final_observation or {})
            if isinstance(result.final_observation, dict)
            else None,
            "control_trace": to_jsonable(result.control_trace or {}),
            "prompt_context": dict(result.prompt_context or {}),
            "provider_detail": dict(result.provider_detail or {}),
        }

    async def _safe_observe(
        self,
        observe: ObserveFn,
        *,
        wait_seconds: float = 1.0,
    ) -> Observation:
        """Safe observe: wait for UI to stabilize before observing.

        Args:
            observe: Observe function
            wait_seconds: Wait time in seconds (default: 1.0)

        Returns:
            Observation after waiting
        """
        # Wait for UI to stabilize
        await asyncio.sleep(wait_seconds)

        # Then observe
        return await self.control_engine.observe(
            observe,
            stable=True,
            include_xml=True,
            include_app_info=False,
        )

    async def run_function_simple(
        self,
        observe: ObserveFn,
        act: ActFn,
        node: UTGNode | None,
        function: Function,
        *,
        context: Optional[dict] = None,
        runtime: Any = None,
    ) -> RunFunctionResult:
        """Execute one function with simple flow (no control plane).

        Flow:
        1. For each action:
           - Safe observe (wait 1s + observe UI state)
           - Render parameters
           - Adapt coordinates (if needed)
           - Execute action
        2. Final safe observation

        Observe count: N actions + 1 = N+1 times (vs 15+ in controlled mode)
        """
        logger.info("Running function (simple): %s", function.name)
        self.stats.execution.record_function(len(function.actions))

        runtime_ctx = context if context is not None else {}
        runtime_ctx.setdefault("__utg_current_step_index__", 0)
        runtime_ctx["__utg_current_function_name__"] = function.name
        observe_owner = getattr(observe, "__self__", None)
        if bool(getattr(observe_owner, "_omniflow_offline_lightweight_replay", False)):
            runtime_ctx.setdefault(
                "__utg_disabled_controllers__",
                ["open_app_verify", "no_effect_guard"],
            )

        # Validate arguments
        try:
            function.validate_arguments(
                {
                    str(key): value
                    for key, value in dict(runtime_ctx or {}).items()
                    if not str(key).startswith("__utg_")
                }
            )
        except Exception as exc:
            return self._function_failure(
                message=f"Function argument validation failed: {exc}",
                error_code=EXEC_FUNCTION_FAIL,
            )

        last_action: Optional[AnyAction] = None
        observation: Optional[Observation] = None

        # Execute actions
        for action_index, action in enumerate(function.actions):
            # 1. Safe observe before each action (wait 1s + observe)
            observation = await self._safe_observe(observe, wait_seconds=1.0)

            # 2. Render parameters
            rendered_action = ActionParamRenderer.render(action, runtime_ctx)

            # 3. Handle call_function recursively
            if isinstance(rendered_action, CallFunctionAction):
                call_result = await self._execute_call_function(
                    observe=observe,
                    act=act,
                    action=rendered_action,
                    context=runtime_ctx,
                    runtime=runtime,
                )
                if call_result["kind"] == "abort":
                    return self._function_failure(
                        message=call_result["message"],
                        error_code=call_result["error_code"],
                        last_action=last_action,
                    )
                last_action = rendered_action
                observation = call_result.get("last_observation")
                continue

            # 4. Adapt coordinates if needed
            if node is not None:
                adapted_action = await self.adapter.adapt(
                    observe,
                    node,
                    rendered_action,
                    observation=observation,
                )
            else:
                adapted_action = rendered_action

            # 5. Execute action
            try:
                response = await act_on_device(act, adapted_action)
                if is_response_failed(response):
                    error_msg = (
                        response.get("error_message")
                        if isinstance(response, dict)
                        else "Action execution failed"
                    )
                    return self._function_failure(
                        message=str(error_msg or "Action failed"),
                        error_code=EXEC_ACTION_FAIL,
                        last_action=adapted_action,
                    )
            except Exception as exc:
                return self._function_failure(
                    message=f"Action raised exception: {exc}",
                    error_code=EXEC_ACTION_FAIL,
                    last_action=adapted_action,
                )

            last_action = adapted_action

        # Final safe observation (wait 1s + observe)
        final_observation = await self._safe_observe(observe, wait_seconds=1.0)

        return RunFunctionResult(
            success=True,
            last_action=last_action,
            before_observation=None,
            final_observation=observation_to_dict(final_observation),
            action_used=to_jsonable(last_action),
            control_trace={},
            prompt_context={"source": "simple"},
            provider_detail={},
        )

    async def run_function(
        self,
        observe: ObserveFn,
        act: ActFn,
        node: UTGNode | None,
        function: Function,
        *,
        context: Optional[dict] = None,
        runtime: Any = None,
    ) -> RunFunctionResult:
        """Execute one function with the observe -> before -> execute -> after loop."""

        logger.info("Running function: %s", function.name)
        self.stats.execution.record_function(len(function.actions))

        last_action: Optional[AnyAction] = None
        last_route: RouteContext | None = None
        last_observation: Observation | None = None
        runtime_ctx = context if context is not None else {}
        runtime_ctx.setdefault("__utg_current_step_index__", 0)
        runtime_ctx["__utg_current_function_name__"] = function.name
        try:
            function.validate_arguments(
                {
                    str(key): value
                    for key, value in dict(runtime_ctx or {}).items()
                    if not str(key).startswith("__utg_")
                }
            )
        except Exception as exc:
            return self._function_failure(
                message=f"Function argument validation failed: {exc}",
                error_code=EXEC_FUNCTION_FAIL,
            )
        baseline_no_controller = is_baseline_mode(
            runtime_ctx.get("__utg_execution_mode__")
        )

        for action_index, action in enumerate(function.actions):
            self._last_action_effect_debug = {}
            rendered_action = ActionParamRenderer.render(action, runtime_ctx)

            # Handle call_function action: recursive function invocation
            if isinstance(rendered_action, CallFunctionAction):
                call_result = await self._execute_call_function(
                    observe=observe,
                    act=act,
                    action=rendered_action,
                    context=runtime_ctx,
                    runtime=runtime,
                )
                if call_result["kind"] == "abort":
                    return self._function_failure(
                        message=call_result["message"],
                        error_code=call_result["error_code"],
                        last_action=last_action,
                    )
                last_action = rendered_action
                last_observation = call_result.get("last_observation")
                runtime_ctx["__utg_last_action_type__"] = "call_function"
                continue

            # Inline _get_before_observation
            if action_index == 0 and bool(
                runtime_ctx.get("__utg_reuse_before_action_observation__")
            ):
                cached_observation = runtime_ctx.get("__utg_observation_obj__")
                if isinstance(cached_observation, Observation):
                    runtime_ctx["__utg_reuse_before_action_observation__"] = False
                    before_observation = cached_observation
                else:
                    before_observation = await self.control_engine.observe(
                        observe,
                        stable=True,
                        include_xml=True,
                        include_app_info=False,
                    )
            else:
                before_observation = await self.control_engine.observe(
                    observe,
                    stable=True,
                    include_xml=True,
                    include_app_info=False,
                )
            self._remember_observation(runtime_ctx, before_observation)
            route = RouteContext(
                observe=observe,
                act=act,
                node=node,
                original_action=rendered_action,
                action=rendered_action,
                runtime_context=runtime_ctx,
                before_observation=before_observation,
            )
            last_route = route

            if baseline_no_controller:
                result = await self._execute_baseline_action(
                    route=route,
                    function=function,
                    action_index=action_index,
                    last_action=last_action,
                )
            else:
                result = await self._execute_controlled_action(
                    observe=observe,
                    node=node,
                    route=route,
                    function=function,
                    action_index=action_index,
                    last_action=last_action,
                    runtime=runtime,
                )

            if result["kind"] == "abort":
                return self._function_failure(
                    message=result["message"],
                    error_code=result["error_code"],
                    last_action=last_action,
                    route=route,
                    observation=result.get("observation", before_observation),
                    action_used=route.effective_action or route.action or last_action,
                )

            last_action = result["last_action"]
            last_observation = result["last_observation"]
            runtime_ctx["__utg_last_action_type__"] = _normalize_action_type(
                last_action
            )

        metadata = self._build_result_metadata(
            route=last_route,
            observation=last_observation,
            action_used=last_action,
        )
        return RunFunctionResult(
            success=True,
            last_action=last_action,
            before_observation=metadata["before_observation"],
            final_observation=metadata["final_observation"],
            action_used=metadata["action_used"],
            control_trace=metadata["control_trace"],
            prompt_context=metadata["prompt_context"],
            provider_detail=metadata["provider_detail"],
        )

    async def _execute_call_function(
        self,
        *,
        observe: ObserveFn,
        act: ActFn,
        action: CallFunctionAction,
        context: dict,
        runtime: Any = None,
    ) -> dict[str, Any]:
        """Execute a call_function action by recursively invoking the target function.

        Args:
            observe: Live observe function for device state.
            act: Live act function for device execution.
            action: The call_function action to execute.
            context: Runtime context with parameters.
            runtime: UTG runtime facade for node/function lookup.

        Returns:
            Result dict with 'kind' ('continue' or 'abort') and execution details.
        """
        params = action.params
        target_node_id = str(params.node_id or "").strip()
        target_function_name = str(params.function_name or "").strip()
        call_arguments = dict(params.arguments or {})

        if not target_node_id:
            return {
                "kind": "abort",
                "message": "call_function: missing node_id",
                "error_code": EXEC_NODE_NOT_FOUND,
            }
        if not target_function_name:
            return {
                "kind": "abort",
                "message": "call_function: missing function_name",
                "error_code": EXEC_FUNCTION_NOT_FOUND,
            }

        # Resolve target node and function from runtime
        target_node: Optional[UTGNode] = None
        target_function: Optional[Function] = None

        if runtime is not None:
            # Try runtime.get_node() method
            get_node_fn = getattr(runtime, "get_node", None)
            if callable(get_node_fn):
                target_node = get_node_fn(target_node_id)
            if target_node is None:
                get_node_by_id_fn = getattr(runtime, "get_node_by_id", None)
                if callable(get_node_by_id_fn):
                    target_node = get_node_by_id_fn(target_node_id)
            # Fallback: try runtime.utg.find_node_by_id()
            if target_node is None:
                utg_graph = getattr(runtime, "utg", None) or getattr(
                    runtime, "_utg", None
                )
                if utg_graph is not None:
                    find_fn = getattr(utg_graph, "find_node_by_id", None)
                    if callable(find_fn):
                        target_node = find_fn(target_node_id)

        if target_node is None:
            return {
                "kind": "abort",
                "message": f"call_function: node '{target_node_id}' not found",
                "error_code": EXEC_NODE_NOT_FOUND,
            }

        # Get the target function
        node_functions = getattr(target_node, "functions", None)
        if isinstance(node_functions, dict):
            target_function = node_functions.get(target_function_name)
        if target_function is None and runtime is not None:
            get_function_by_id_fn = getattr(runtime, "get_function_by_id", None)
            if callable(get_function_by_id_fn):
                global_function = get_function_by_id_fn(target_function_name)
                global_start_node_id = (
                    str(getattr(global_function, "start_node_id", "") or "").strip()
                    if global_function is not None
                    else ""
                )
                if global_function is not None and (
                    not global_start_node_id or global_start_node_id == target_node_id
                ):
                    target_function = global_function

        if target_function is None:
            return {
                "kind": "abort",
                "message": (
                    f"call_function: function '{target_function_name}' "
                    f"not found in node '{target_node_id}'"
                ),
                "error_code": EXEC_FUNCTION_NOT_FOUND,
            }

        # Merge arguments: parent context + call_function arguments
        # Render ${param} references in call_arguments
        merged_context = dict(context)
        for key, value in call_arguments.items():
            if isinstance(value, str) and "${" in value:
                merged_context[key] = ParamRenderer.render(value, context, strict=False)
            else:
                merged_context[key] = value

        # Track call depth to prevent infinite recursion
        call_depth = int(merged_context.get("__utg_call_function_depth__", 0) or 0)

        # Safety #1: Hard limit (prevent stack overflow from misconfiguration)
        if call_depth >= _ABSOLUTE_MAX_CALL_DEPTH:
            call_stack = merged_context.get("__utg_call_stack__", [])
            return {
                "kind": "abort",
                "message": (
                    f"call_function: absolute max recursion depth "
                    f"({_ABSOLUTE_MAX_CALL_DEPTH}) exceeded. "
                    f"Call stack: {' -> '.join(call_stack[-10:])}"
                ),
                "error_code": EXEC_FUNCTION_FAIL,
            }

        # Safety #2: Configured depth limit
        max_depth = self.policy_provider.execution_config().max_call_depth
        # Clamp max_depth to absolute maximum
        max_depth = min(max_depth, _ABSOLUTE_MAX_CALL_DEPTH)
        if call_depth >= max_depth:
            call_stack = merged_context.get("__utg_call_stack__", [])
            return {
                "kind": "abort",
                "message": (
                    f"call_function: max recursion depth ({max_depth}) exceeded. "
                    f"Call stack: {' -> '.join(call_stack[-5:])}"
                ),
                "error_code": EXEC_FUNCTION_FAIL,
            }

        # Safety #3: Cycle detection (prevent A→B→A loops)
        if _CYCLE_DETECTION_ENABLED:
            call_stack = list(merged_context.get("__utg_call_stack__", []))
            current_call_id = f"{target_node_id}:{target_function_name}"

            if current_call_id in call_stack:
                # Found a cycle
                cycle_start = call_stack.index(current_call_id)
                cycle = call_stack[cycle_start:] + [current_call_id]
                return {
                    "kind": "abort",
                    "message": (
                        f"call_function: detected call cycle: {' -> '.join(cycle)}. "
                        f"Function '{target_function_name}' is already in the call stack."
                    ),
                    "error_code": EXEC_FUNCTION_FAIL,
                }

            # Update call stack
            call_stack.append(current_call_id)
            merged_context["__utg_call_stack__"] = call_stack
        else:
            # Fallback: maintain minimal call stack for error reporting
            call_stack = merged_context.get("__utg_call_stack__", [])
            call_stack.append(f"{target_node_id}:{target_function_name}")
            merged_context["__utg_call_stack__"] = call_stack

        merged_context["__utg_call_function_depth__"] = call_depth + 1

        logger.info(
            "[call_function] node=%s function=%s depth=%d/%d",
            target_node_id,
            target_function_name,
            call_depth + 1,
            max_depth,
        )

        # Recursively execute the target function
        result = await self.run_function(
            observe,
            act,
            target_node,
            target_function,
            context=merged_context,
            runtime=runtime,
        )

        if not result.success:
            return {
                "kind": "abort",
                "message": result.error_message or "call_function: sub-function failed",
                "error_code": result.error_code or EXEC_FUNCTION_FAIL,
            }

        child_device_actions_ref = merged_context.get("__utg_device_actions__")
        parent_device_actions_ref = context.get("__utg_device_actions__")
        child_device_actions = list(child_device_actions_ref or [])
        if (
            child_device_actions
            and child_device_actions_ref is not parent_device_actions_ref
        ):
            parent_device_actions = context.setdefault("__utg_device_actions__", [])
            if isinstance(parent_device_actions, list):
                for item in child_device_actions:
                    if not isinstance(item, dict):
                        continue
                    parent_device_actions.append(dict(item))
                    if len(parent_device_actions) > _MAX_DEVICE_ACTIONS_HISTORY:
                        parent_device_actions.pop(0)

        child_main_action_frames_ref = merged_context.get("__utg_main_action_frames__")
        parent_main_action_frames_ref = context.get("__utg_main_action_frames__")
        child_main_action_frames = list(child_main_action_frames_ref or [])
        if (
            child_main_action_frames
            and child_main_action_frames_ref is not parent_main_action_frames_ref
        ):
            parent_main_action_frames = context.setdefault(
                "__utg_main_action_frames__", []
            )
            if isinstance(parent_main_action_frames, list):
                for item in child_main_action_frames:
                    if isinstance(item, dict):
                        parent_main_action_frames.append(dict(item))

        child_control_trace = merged_context.get("__utg_control_trace__")
        parent_control_trace_ref = context.get("__utg_control_trace__")
        if (
            isinstance(child_control_trace, dict)
            and child_control_trace is not parent_control_trace_ref
        ):
            parent_control_trace = context.setdefault("__utg_control_trace__", {})
            if isinstance(parent_control_trace, dict):
                for step_index, entries in child_control_trace.items():
                    if not isinstance(entries, list):
                        continue
                    target_entries = parent_control_trace.setdefault(
                        str(step_index), []
                    )
                    if not isinstance(target_entries, list):
                        continue
                    for entry in entries:
                        if isinstance(entry, dict):
                            target_entries.append(dict(entry))

        child_final_observation = merged_context.get("__utg_last_observation__")
        if not isinstance(child_final_observation, dict):
            child_final_observation = getattr(result, "final_observation", None)
        if isinstance(child_final_observation, dict):
            context["__utg_last_observation__"] = dict(child_final_observation)
            context["__utg_has_final_observation__"] = True

        return {
            "kind": "continue",
            "last_observation": result.final_observation,
        }

    async def _execute_baseline_action(
        self,
        *,
        route: RouteContext,
        function: Function,
        action_index: int,
        last_action: Optional[AnyAction],
    ) -> dict[str, Any]:
        """Execute one action in baseline mode (no controller)."""
        runtime_ctx = route.runtime_context
        self.tracer.write_action_trace(
            runtime_ctx.get("__utg_execution_trace_logger__"),
            route=route,
            function=function,
            action_index=action_index,
        )
        executed = await self._execute_effect_actions(
            phase="execute_action",
            route=route,
            observation=route.before_observation,
            actions=[route.action],
            stable=False,
            controller_id="main_action",
        )
        if executed["kind"] == "abort":
            return {
                "kind": "abort",
                "message": executed["message"],
                "error_code": executed["error_code"],
                "observation": route.before_observation,
            }
        return {
            "kind": "continue",
            "last_action": route.effective_action or route.action,
            "last_observation": (
                None
                if runtime_ctx.get("__utg_has_final_observation__") is False
                else executed["observation"]
            ),
        }

    async def _execute_controlled_action(
        self,
        *,
        observe: ObserveFn,
        node: UTGNode | None,
        route: RouteContext,
        function: Function,
        action_index: int,
        last_action: Optional[AnyAction],
        runtime: Any = None,
    ) -> dict[str, Any]:
        """Execute one action with controller phases (prepare -> execute -> after)."""
        runtime_ctx = route.runtime_context

        # Prepare phase
        prepared = await self._prepare_action_for_execution(
            observe=observe,
            node=node,
            route=route,
            observation=route.before_observation,
            runtime=runtime,
        )
        if prepared["kind"] == "abort":
            return {
                "kind": "abort",
                "message": prepared["message"],
                "error_code": prepared["error_code"],
                "observation": route.before_observation,
            }

        # Write trace after adaptation
        self.tracer.write_action_trace(
            runtime_ctx.get("__utg_execution_trace_logger__"),
            route=route,
            function=function,
            action_index=action_index,
        )

        # Execute phase
        executed = await self._run_phase(
            phase="execute_action",
            route=route,
            observation=prepared["observation"],
            runtime=runtime,
        )
        if executed["kind"] == "abort":
            return {
                "kind": "abort",
                "message": executed["message"],
                "error_code": executed["error_code"],
                "observation": prepared["observation"],
            }

        # Skip after_action if requested
        if bool(runtime_ctx.get("__utg_skip_after_action__")):
            return {
                "kind": "continue",
                "last_action": route.effective_action or route.action,
                "last_observation": None,
            }

        # After phase
        after_action = await self._settle_phase(
            phase="after_action",
            route=route,
            observation=executed["observation"],
            runtime=runtime,
        )
        if after_action["kind"] == "abort":
            return {
                "kind": "abort",
                "message": after_action["message"],
                "error_code": after_action["error_code"],
                "observation": executed["observation"],
            }

        return {
            "kind": "continue",
            "last_action": route.effective_action or route.action,
            "last_observation": after_action["observation"],
        }

    async def _prepare_action_for_execution(
        self,
        *,
        observe: ObserveFn,
        node: UTGNode | None,
        route: RouteContext,
        observation: Observation,
        runtime: Any = None,
    ) -> dict[str, Any]:
        """Adapt one action and rerun `before_action` until control becomes stable."""

        rounds = 0
        max_rounds = self.control_engine.max_rounds_per_phase("before_action")
        current_observation = observation
        while True:
            control_scope = str(
                route.runtime_context.get("__utg_control_scope__", "utg_path")
                or "utg_path"
            ).strip()
            if control_scope == "act_hook" or node is None:
                route.action = route.original_action
                route.adaptation_debug = {}
            else:
                route.action = await self.adapter.adapt(
                    observe,
                    node,
                    route.original_action,
                    observation=current_observation,
                )
                route.adaptation_debug = dict(self.adapter.last_adaptation_debug or {})
            route.before_observation = current_observation
            outcome = await self._run_phase(
                phase="before_action",
                route=route,
                observation=current_observation,
                runtime=runtime,
            )
            if outcome["kind"] == "rerun":
                rounds += 1
                if rounds >= max_rounds:
                    return {
                        "kind": "abort",
                        "message": "before_action control did not settle",
                        "error_code": EXEC_STATE_STALL,
                    }
                current_observation = outcome["observation"]
                continue
            if outcome["kind"] == "abort":
                return outcome
            return {"kind": "ready", "observation": current_observation}

    async def _settle_phase(
        self,
        *,
        phase: str,
        route: RouteContext,
        observation: Observation,
        runtime: Any = None,
    ) -> dict[str, Any]:
        """Rerun one phase until no controller requests a refreshed observation."""

        rounds = 0
        max_rounds = self.control_engine.max_rounds_per_phase(phase)
        current_observation = observation
        while True:
            outcome = await self._run_phase(
                phase=phase,
                route=route,
                observation=current_observation,
                runtime=runtime,
            )
            if outcome["kind"] == "rerun":
                rounds += 1
                if rounds >= max_rounds:
                    return {
                        "kind": "abort",
                        "message": f"{phase} control did not settle",
                        "error_code": EXEC_STATE_STALL,
                    }
                current_observation = outcome["observation"]
                continue
            return outcome

    async def _run_phase(
        self,
        *,
        phase: str,
        route: RouteContext,
        observation: Observation,
        runtime: Any = None,
    ) -> dict[str, Any]:
        """Evaluate one phase once and apply the effects emitted by the control bus."""

        route.runtime_context["__utg_current_phase__"] = str(phase or "")
        results = await self.control_engine.collect_effects(
            phase,
            observation,
            route,
            runtime=runtime,
        )
        current_observation = observation
        for result in results:
            for effect in list(result.effects or []):
                effect_kind = str(getattr(effect, "kind", "") or "")
                if effect_kind == "replace_action":
                    route.action = getattr(effect, "action", None)
                    continue
                if effect_kind == "abort":
                    return {
                        "kind": "abort",
                        "message": str(
                            getattr(effect, "reason", "") or "control aborted"
                        ),
                        "error_code": str(
                            getattr(effect, "error_code", "") or EXEC_ACTION_FAIL
                        ),
                    }
                if effect_kind == "human_gate":
                    gate_result = await self._run_human_gate(
                        phase=phase,
                        route=route,
                        observation=current_observation,
                        effect=effect,
                    )
                    if gate_result["kind"] == "abort":
                        return gate_result
                    continue
                if effect_kind == "handoff_human":
                    return {
                        "kind": "abort",
                        "message": str(
                            getattr(effect, "reason", "")
                            or "execution handed off to human"
                        ),
                        "error_code": str(
                            getattr(effect, "error_code", "") or EXEC_HUMAN_HANDOFF
                        ),
                    }
                if effect_kind == "refresh_observation":
                    current_observation = await self._observe(
                        phase=phase,
                        observe=route.observe,
                        stable=bool(getattr(effect, "stable", True)),
                        route=route,
                    )
                    return {"kind": "rerun", "observation": current_observation}
                if effect_kind == "run_actions":
                    executed = await self._execute_effect_actions(
                        phase=phase,
                        route=route,
                        observation=current_observation,
                        actions=list(getattr(effect, "actions", []) or []),
                        stable=bool(getattr(effect, "stable", True)),
                        controller_id=str(getattr(effect, "controller_id", "") or ""),
                    )
                    if executed["kind"] == "abort":
                        return executed
                    current_observation = executed["observation"]
                    if phase == "execute_action":
                        return {"kind": "continue", "observation": current_observation}
                    return {"kind": "rerun", "observation": current_observation}
        return {"kind": "continue", "observation": current_observation}

    async def _run_human_gate(
        self,
        *,
        phase: str,
        route: RouteContext,
        observation: Observation,
        effect: Any,
    ) -> dict[str, Any]:
        """Print one confirmation summary and block until the user allows execution."""

        # Inline _build_human_gate_prompt
        debug = dict(getattr(effect, "debug", {}) or {})
        payload = {
            "phase": str(phase or ""),
            "function_id": str(getattr(getattr(route, "path", None), "id", "") or ""),
            "node_id": str(getattr(getattr(route, "node", None), "id", "") or ""),
            "step_index": getattr(getattr(route, "step", None), "index", None),
            "package_name": str(getattr(observation, "package_name", "") or ""),
            "activity_name": str(getattr(observation, "activity_name", "") or ""),
            "action": debug.get("action"),
            "original_action": debug.get("original_action"),
        }
        prompt = (
            "[human_gate] "
            f"{str(getattr(effect, 'reason', '') or 'manual confirmation required')}\n"
            f"{json.dumps(payload, ensure_ascii=False, indent=2)}"
        )
        print(prompt, file=sys.stderr, flush=True)
        confirmed = await self._confirm_human_gate(route.observe, prompt)
        if confirmed:
            return {"kind": "continue", "observation": observation}
        return {
            "kind": "abort",
            "message": "human gate rejected execution",
            "error_code": EXEC_HUMAN_HANDOFF,
        }

    async def _confirm_human_gate(self, observe: ObserveFn, prompt: str) -> bool:
        """Request explicit confirmation from the host or local terminal."""

        confirm = getattr(
            getattr(observe, "__self__", None), "require_user_confirmation", None
        )
        if callable(confirm):
            try:
                response = confirm(prompt)
                if inspect.isawaitable(response):
                    response = await response
                if bool(getattr(response, "success", False)):
                    data = str(getattr(response, "data", "") or "").strip().lower()
                    return data in {
                        "1",
                        "true",
                        "yes",
                        "y",
                        "ok",
                        "confirm",
                        "confirmed",
                    }
            except Exception as exc:
                logger.debug("Human gate confirmation skipped: %s", exc)
        if not sys.stdin or not sys.stdin.isatty():
            return False
        answer = await asyncio.to_thread(input, "Confirm execution? [y/N]: ")
        return str(answer or "").strip().lower() in {"y", "yes"}

    async def _execute_effect_actions(
        self,
        *,
        phase: str,
        route: RouteContext,
        observation: Observation,
        actions: list[Any],
        stable: bool,
        controller_id: str,
    ) -> dict[str, Any]:
        """Execute one effect action list and immediately re-observe the device."""

        last_action = None
        last_response = None
        for candidate in list(actions or []):
            last_action = candidate
            action_type = canonical_action_type(getattr(candidate, "type", None))
            from src.foundation.settings import settings

            if settings.execution.print_actions:
                print(
                    json.dumps(
                        {
                            "event": "device_action",
                            "phase": str(phase or ""),
                            "controller_id": str(controller_id or ""),
                            "function_id": str(
                                getattr(getattr(route, "path", None), "id", "") or ""
                            ),
                            "node_id": str(
                                getattr(getattr(route, "node", None), "id", "") or ""
                            ),
                            "step_index": getattr(
                                getattr(route, "step", None), "index", None
                            ),
                            "action": to_jsonable(candidate),
                        },
                        ensure_ascii=False,
                    ),
                    file=sys.stderr,
                    flush=True,
                )
            try:
                last_response = await act_on_device(route.act, candidate)
            except Exception as exc:
                return {
                    "kind": "abort",
                    "message": str(exc or "Device action raised exception"),
                    "error_code": EXEC_ACTION_FAIL,
                }
            response_detail = (
                dict(last_response.get("provider_detail") or {})
                if isinstance(last_response, dict)
                and isinstance(last_response.get("provider_detail"), dict)
                else {}
            )
            actual_actions = extract_executed_actions_from_detail(response_detail)
            if not actual_actions:
                actual_actions = [to_jsonable(candidate)]
            for actual_action in actual_actions:
                device_actions = route.runtime_context.setdefault(
                    "__utg_device_actions__", []
                )
                device_actions.append(
                    {
                        "action": to_jsonable(actual_action),
                        "action_type": str(
                            (
                                actual_action.get("type")
                                if isinstance(actual_action, dict)
                                else canonical_action_type(actual_action)
                            )
                            or action_type
                            or ""
                        ),
                        "controller_id": str(controller_id or ""),
                        "phase": str(phase or ""),
                        "kind": "act",
                        "success": not is_response_failed(last_response),
                        "error_code": (
                            None
                            if not is_response_failed(last_response)
                            else EXEC_ACTION_FAIL
                        ),
                    }
                )
                if len(device_actions) > _MAX_DEVICE_ACTIONS_HISTORY:
                    device_actions.pop(0)  # Remove oldest record
                if str(controller_id or "") == "main_action":
                    route.runtime_context.setdefault(
                        "__utg_main_action_frames__", []
                    ).append(
                        {
                            "before_observation": dict(
                                (route.runtime_context or {}).get(
                                    "__utg_last_observation__"
                                )
                                or {}
                            ),
                            "executed_action": to_jsonable(actual_action),
                            "function_id": str(
                                getattr(getattr(route, "path", None), "id", "") or ""
                            )
                            or None,
                            "node_id": str(
                                getattr(getattr(route, "node", None), "id", "") or ""
                            )
                            or None,
                            "sequence_id": str(
                                (route.runtime_context or {}).get(
                                    "__utg_current_function_name__", ""
                                )
                                or ""
                            )
                            or None,
                            "step_index": getattr(
                                getattr(route, "step", None), "index", None
                            ),
                        }
                    )
            if is_response_failed(last_response):
                failure_message = f"Device action failed in {controller_id or phase}"
                if isinstance(last_response, dict):
                    raw_message = str(last_response.get("message") or "").strip()
                    if raw_message:
                        failure_message = raw_message
                return {
                    "kind": "abort",
                    "message": failure_message,
                    "error_code": EXEC_ACTION_FAIL,
                }
            wait_seconds = route.runtime_context.get("__utg_post_action_wait_seconds__")
            try:
                wait_seconds = float(wait_seconds)
            except Exception:
                wait_seconds = float(self.path_control.post_action_wait_seconds)
            if wait_seconds > 0:
                await asyncio.sleep(wait_seconds)
        skip_post_observation = bool(
            route.runtime_context.get("__utg_skip_post_action_observation__")
        )
        refreshed = observation
        if phase == "execute_action" and skip_post_observation:
            route.runtime_context["__utg_last_action_effect_debug__"] = {}
            route.runtime_context["__utg_has_final_observation__"] = False
        else:
            action_type = canonical_action_type(last_action)
            if action_type == "open_app" and (
                phase == "execute_action"
                or str(controller_id or "") == "package_mismatch_open_app"
            ):
                refreshed = await self._observe_open_app_result(
                    route.observe,
                    action=last_action,
                )
            else:
                refreshed = await self._observe(
                    phase=phase,
                    observe=route.observe,
                    stable=stable,
                    route=route,
                )
            self._remember_observation(route.runtime_context, refreshed)
        if str(controller_id or "") == "page_mismatch_press_back":
            route.runtime_context["__utg_page_mismatch_back_attempt_count__"] = (
                int(
                    route.runtime_context.get(
                        "__utg_page_mismatch_back_attempt_count__", 0
                    )
                    or 0
                )
                + 1
            )
            if not observations_equal(observation, refreshed):
                route.runtime_context["__utg_page_mismatch_back_no_change_count__"] = 0
            else:
                route.runtime_context["__utg_page_mismatch_back_no_change_count__"] = (
                    int(
                        route.runtime_context.get(
                            "__utg_page_mismatch_back_no_change_count__", 0
                        )
                        or 0
                    )
                    + 1
                )
        if phase == "execute_action":
            route.effective_action = last_action
            route.response = last_response
            route.effect_result = None if skip_post_observation else refreshed
            if skip_post_observation:
                route.action_effect_debug = {}
                self._last_action_effect_debug = {}
            else:
                xml_changed = not observations_equal(
                    route.before_observation, refreshed
                )
                route.action_effect_debug = {
                    "action_type": str(getattr(last_action, "type", "") or ""),
                    "reason": "effect_verified" if xml_changed else "no_effect",
                    "xml_changed": xml_changed,
                    "before": {
                        "package_name": str(
                            getattr(route.before_observation, "package_name", "") or ""
                        ),
                        "activity_name": str(
                            getattr(route.before_observation, "activity_name", "") or ""
                        ),
                    },
                    "after": {
                        "package_name": str(
                            getattr(refreshed, "package_name", "") or ""
                        ),
                        "activity_name": str(
                            getattr(refreshed, "activity_name", "") or ""
                        ),
                    },
                }
                self._last_action_effect_debug = dict(route.action_effect_debug or {})
                route.runtime_context["__utg_last_action_effect_debug__"] = dict(
                    route.action_effect_debug or {}
                )
                self.tracer.log_action_effect_debug(last_action)
        return {"kind": "continue", "observation": refreshed}

    def _build_result_metadata(
        self,
        *,
        route: RouteContext | None,
        observation: Observation | None,
        action_used: Any | None = None,
    ) -> dict[str, Any]:
        """Build one normalized action-result metadata payload from executor state."""
        # 提取 observation 数据
        before_obs = getattr(route, "before_observation", None)
        before_observation = (
            observation_to_dict(before_obs)
            if isinstance(before_obs, Observation)
            else None
        )
        final_observation = observation_to_dict(observation)

        # 提取 runtime context
        runtime_context = route.runtime_context if route is not None else {}
        control_trace = to_jsonable(runtime_context.get("__utg_control_trace__", {}))
        action_used_json = to_jsonable(action_used)

        # 构建 prompt_context
        source = str(
            runtime_context.get(
                "__utg_control_source__",
                runtime_context.get("__utg_control_scope__", "utg_path"),
            )
            or "utg_path"
        )
        action_effect = safe_dict(getattr(route, "action_effect_debug", None))
        prompt_context = {
            "source": source,
            "action_effect": action_effect,
            "control_trace": control_trace,
            "final_observation": final_observation,
        }

        return {
            "before_observation": before_observation,
            "action_used": action_used_json,
            "final_observation": final_observation,
            "control_trace": control_trace,
            "prompt_context": prompt_context,
            "provider_detail": {
                "before_observation": before_observation,
                "action_used": action_used_json,
                "control_trace": control_trace,
                "prompt_context": prompt_context,
                "final_observation": final_observation,
            },
        }

    def _function_failure(
        self,
        *,
        message: str,
        error_code: str,
        last_action: Optional[AnyAction] = None,
        route: RouteContext | None = None,
        observation: Observation | None = None,
        action_used: Any | None = None,
    ) -> RunFunctionResult:
        """Build one standardized function failure result and record execution stats."""

        self.stats.execution.record_error(message)
        metadata = self._build_result_metadata(
            route=route,
            observation=observation,
            action_used=action_used or last_action,
        )
        return RunFunctionResult(
            success=False,
            error_message=message,
            error_code=error_code,
            last_action=last_action,
            before_observation=metadata["before_observation"],
            final_observation=metadata["final_observation"],
            action_used=metadata["action_used"],
            control_trace=metadata["control_trace"],
            prompt_context=metadata["prompt_context"],
            provider_detail=metadata["provider_detail"],
        )

    # Phase -> (include_xml, include_app_info) 配置表
    _PHASE_OBSERVE_CONFIG: dict[str, tuple[bool, bool]] = {
        "before_step": (True, True),
        "before_action": (True, False),
        "execute_action": (True, True),
        "after_action": (True, True),
    }

    async def _observe(
        self,
        *,
        phase: str,
        observe: ObserveFn,
        stable: bool,
        route: RouteContext,
    ) -> Observation:
        """Unified observation method for all phases.

        Args:
            phase: The phase name (before_step, before_action, execute_action, after_action)
            observe: Shared live observe callable for the current host bridge
            stable: Whether to wait for stable state
            route: Current route context

        Returns:
            Observation with appropriate XML and app_info based on phase
        """
        # 从配置表获取默认值
        include_xml, include_app_info = self._PHASE_OBSERVE_CONFIG.get(
            phase, (True, False)
        )
        # open_app 特殊处理：只需 app_info
        if (
            canonical_action_type(getattr(route.effective_action, "type", None))
            == "open_app"
        ):
            include_xml, include_app_info = False, True
        return await self.control_engine.observe(
            observe,
            stable=stable,
            include_xml=include_xml,
            include_app_info=include_app_info,
        )

    async def _observe_open_app_result(
        self,
        observe: ObserveFn,
        *,
        action: AnyAction | None = None,
    ) -> Observation:
        """Wait for one `open_app` action to reach its target foreground package.

        Args:
            observe: Shared live observe callable for the current host bridge.
            action: Executed `open_app` action. Its `package_name` is treated as
                the expected landing package for the bounded foreground polling.

        Returns:
            One observation representing the settled landing state. The executor
            first waits for consecutive foreground hits on the target package
            within the configured timeout budget, then captures one stabilized
            XML+app snapshot so the next step or `before_step` recovery replay
            does not restart from a transient launcher/app-switch animation
            frame.
        """

        params = getattr(action, "params", None)
        expected_package = (
            str(params.get("package_name") or "").strip()
            if isinstance(params, dict)
            else ""
        )
        timeout_s = max(0.0, float(self.path_control.open_app_foreground_timeout_s))
        poll_interval_s = max(
            0.0,
            float(self.path_control.open_app_foreground_poll_interval_s),
        )
        required_hits = max(1, int(self.path_control.open_app_foreground_required_hits))
        deadline = perf_counter() + timeout_s
        matched_hits = 0
        observation = Observation()

        while True:
            observation = await self.control_engine.observe(
                observe,
                stable=False,
                include_xml=False,
                include_app_info=True,
            )
            current_package = str(
                getattr(observation, "package_name", "") or ""
            ).strip()
            if not expected_package or current_package == expected_package:
                matched_hits += 1
            else:
                matched_hits = 0
            if matched_hits >= required_hits:
                return await self.control_engine.observe(
                    observe,
                    stable=True,
                    include_xml=True,
                    include_app_info=True,
                )
            if perf_counter() >= deadline:
                return observation
            if poll_interval_s > 0:
                await asyncio.sleep(poll_interval_s)

    @staticmethod
    def _remember_observation(
        runtime_context: dict[str, Any],
        observation: Observation,
    ) -> None:
        """Persist the latest observation so runtime/logging can reuse it later."""
        runtime_context["__utg_last_observation__"] = observation_to_dict(observation)
        runtime_context["__utg_observation_obj__"] = observation
        runtime_context["__utg_has_final_observation__"] = True
