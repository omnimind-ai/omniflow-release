"""
Unified Semantic Compile: Goal → Function 编译器。

核心设计：
1. 收集所有候选 Functions (全局 + App + 页面)
2. 外部 Embedding API 计算向量，本地存储和检索
3. 轻量级匹配作为 fallback (N-gram + 编辑距离 + 动词词表)
4. 编译决策: HIT / AMBIGUOUS / MISS
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import json
import logging
import os
from pathlib import Path
import pickle
import re
from time import perf_counter
from typing import Dict, List, Optional, Protocol, Sequence, Set, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# ============================================================================
# External Embedding Provider Protocol
# ============================================================================


class EmbeddingProvider(Protocol):
    """外部 Embedding 服务接口.

    OmniFlow 不执行模型推理，通过此接口调用外部 API 计算 embedding。
    """

    def encode(self, texts: List[str]) -> np.ndarray:
        """将文本编码为向量.

        Args:
            texts: 待编码的文本列表

        Returns:
            numpy 数组，shape = (len(texts), embedding_dim)
        """
        ...


# Global embedding provider (can be set by external code)
_embedding_provider: Optional[EmbeddingProvider] = None


def set_embedding_provider(provider: Optional[EmbeddingProvider]) -> None:
    """设置外部 Embedding Provider.

    Example:
        class OOBEmbeddingProvider:
            def encode(self, texts):
                # 调用 OOB RAG API
                response = requests.post(OOB_EMBEDDING_URL, json={"texts": texts})
                return np.array(response.json()["embeddings"])

        set_embedding_provider(OOBEmbeddingProvider())
    """
    global _embedding_provider
    _embedding_provider = provider
    if provider:
        logger.info("External embedding provider configured")


def get_embedding_provider() -> Optional[EmbeddingProvider]:
    """获取当前的 Embedding Provider.

    如果未显式设置，自动使用 DashScope（需要 DASHSCOPE_API_KEY）。
    """
    global _embedding_provider
    if _embedding_provider is None:
        # 尝试自动初始化 DashScope provider
        _embedding_provider = _try_init_dashscope_provider()
    return _embedding_provider


def _validate_api_key_format(api_key: str) -> bool:
    """验证 API 密钥格式（不泄露密钥内容）.

    Args:
        api_key: 待验证的 API 密钥

    Returns:
        True 如果格式有效，False 否则

    Note:
        此函数只做基本格式检查，不会在日志中记录密钥内容
    """
    if not api_key or not isinstance(api_key, str):
        return False

    # 基本长度检查（DashScope API密钥通常较长）
    if len(api_key) < 20:
        return False

    # 检查是否包含明显的占位符或测试值
    invalid_patterns = [
        "your_api_key",
        "your-api-key",
        "placeholder",
        "test",
        "example",
        "dummy",
        "fake",
    ]
    api_key_lower = api_key.lower()
    for pattern in invalid_patterns:
        if pattern in api_key_lower:
            return False

    # 检查是否只包含空白字符
    if not api_key.strip():
        return False

    return True


def _try_init_dashscope_provider() -> Optional["DashScopeEmbeddingProvider"]:
    """尝试初始化 DashScope Embedding Provider."""
    try:
        from src.foundation.config import config
        from src.foundation.settings import settings

        api_key = config.DASHSCOPE_API_KEY.get_secret_value()
        if not api_key:
            logger.debug("DASHSCOPE_API_KEY not set, embedding provider not available")
            return None

        # 验证 API 密钥格式（基本检查，避免泄露具体值）
        if not _validate_api_key_format(api_key):
            logger.warning("DASHSCOPE_API_KEY format validation failed")
            return None

        model = settings.compile.embedding_model
        provider = DashScopeEmbeddingProvider(api_key=api_key, model=model)
        logger.info(f"DashScope embedding provider initialized (model: {model})")
        return provider
    except Exception as e:
        # 避免在日志中泄露异常详情（可能包含API密钥片段）
        logger.debug("Failed to init DashScope provider (check API key configuration)")
        return None


class DashScopeEmbeddingProvider:
    """DashScope (Qwen) Embedding Provider.

    使用阿里云 DashScope API 计算 text embedding。
    默认模型: text-embedding-v3 (1024 维)

    环境变量:
        DASHSCOPE_API_KEY: API 密钥
        DASHSCOPE_BASE_URL: API 地址（可选）

    Security:
        - API密钥以私有属性存储，不会出现在日志中
        - 错误响应不会包含完整的API响应内容
    """

    DEFAULT_MODEL = "text-embedding-v3"
    DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/api/v1"

    def __init__(
        self,
        api_key: str,
        model: str = DEFAULT_MODEL,
        base_url: Optional[str] = None,
    ):
        # 使用私有属性存储密钥，避免意外暴露
        self._api_key = api_key
        self.model = model
        self.base_url = base_url or self.DEFAULT_BASE_URL

    def __repr__(self) -> str:
        """安全的字符串表示（隐藏API密钥）."""
        return (
            f"DashScopeEmbeddingProvider("
            f"model={self.model!r}, "
            f"base_url={self.base_url!r}, "
            f"api_key=***)"
        )

    def encode(self, texts: List[str]) -> np.ndarray:
        """调用 DashScope API 计算 embedding.

        Args:
            texts: 待编码的文本列表

        Returns:
            numpy 数组，shape = (len(texts), embedding_dim)

        Raises:
            RuntimeError: API调用失败时（不会泄露API密钥或完整响应）
        """
        import requests

        url = f"{self.base_url}/services/embeddings/text-embedding/text-embedding"

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

        # DashScope 支持批量，但有限制，分批处理
        batch_size = 25
        all_embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]

            payload = {
                "model": self.model,
                "input": {"texts": batch},
                "parameters": {"text_type": "query"},
            }

            try:
                response = requests.post(url, headers=headers, json=payload, timeout=30)
                response.raise_for_status()

                result = response.json()
                if "output" not in result or "embeddings" not in result["output"]:
                    # 不记录完整响应内容，避免泄露敏感信息
                    raise RuntimeError(
                        f"Invalid API response structure (missing output or embeddings). "
                        f"Status code: {response.status_code}"
                    )

                # 按 text_index 排序
                embeddings = result["output"]["embeddings"]
                embeddings.sort(key=lambda x: x["text_index"])

                for emb in embeddings:
                    all_embeddings.append(emb["embedding"])

            except requests.exceptions.RequestException as e:
                # 安全的错误处理：不暴露API密钥或完整请求/响应
                error_type = type(e).__name__
                status_code = getattr(e.response, "status_code", None) if hasattr(e, "response") else None

                error_msg = f"DashScope API request failed: {error_type}"
                if status_code:
                    error_msg += f" (status: {status_code})"

                # 提供有用的调试信息，但不泄露敏感数据
                if status_code == 401:
                    error_msg += " - Check your API key configuration"
                elif status_code == 429:
                    error_msg += " - Rate limit exceeded"
                elif status_code == 500:
                    error_msg += " - Server error, please retry later"

                raise RuntimeError(error_msg) from e

        return np.array(all_embeddings, dtype=np.float32)


# ============================================================================
# 动词词表（跟随 execution 模块一起版本化）
# ============================================================================

_VERB_VOCAB_PATH = Path(__file__).with_name("verb_vocab.json")


def _load_verb_vocab() -> Tuple[Dict[str, Set[str]], Dict[str, str]]:
    """加载动词词表，返回 (synonyms, index)."""
    synonyms: Dict[str, Set[str]] = {}
    index: Dict[str, str] = {}
    try:
        with open(_VERB_VOCAB_PATH, encoding="utf-8") as f:
            data = json.load(f)
        for canonical, words in data.items():
            synonyms[canonical] = set(words)
            for word in words:
                if word not in index:
                    index[word] = canonical
    except Exception as e:
        logger.debug(f"Failed to load verb vocab: {e}, using empty")
    return synonyms, index


VERB_SYNONYMS, VERB_INDEX = _load_verb_vocab()


def extract_verbs(text: str) -> Set[str]:
    """从文本中提取动词 (返回规范化动词集合)."""
    found = set()
    text_lower = text.lower()
    for word, canonical in VERB_INDEX.items():
        if word in text_lower:
            found.add(canonical)
    return found


def get_verb_group(verb: str) -> Set[str]:
    """获取动词的同义词组."""
    canonical = VERB_INDEX.get(verb, verb)
    return VERB_SYNONYMS.get(canonical, {verb})


# ============================================================================
# 数据结构
# ============================================================================


class CompileDecision(Enum):
    """编译决策类型."""

    HIT = "hit"  # 高置信度，直接执行
    AMBIGUOUS = "ambiguous"  # 需要确认或 LLM
    MISS = "miss"  # 无匹配，Fallback LLM


class FunctionScope(Enum):
    """Function 作用域."""

    GLOBAL = "global"  # 全局可执行
    APP = "app"  # App 内可执行
    PAGE = "page"  # 特定页面可执行


@dataclass
class FunctionCandidate:
    """候选 Function."""

    function_id: str
    description: str  # 包含上下文的描述
    scope: FunctionScope
    parameter_names: Tuple[str, ...] = ()
    recall_phrases: Tuple[str, ...] = ()  # 额外召回短语

    # 来源信息
    source_app: Optional[str] = None  # App package name
    source_node_id: Optional[str] = None  # UTG node ID (PAGE scope 用)

    # Graph 结构：Function 是图的边
    from_node_id: Optional[str] = None  # 起始节点（None = 任意节点）
    to_node_id: Optional[str] = None  # 目标节点（执行后到达的页面）

    def get_searchable_text(self) -> str:
        """获取用于语义搜索的文本."""
        texts = [self.description]
        texts.extend(self.recall_phrases)
        return " | ".join(filter(None, texts))


@dataclass
class CompileConfig:
    """编译配置."""

    # 阈值
    hit_threshold: float = 0.95  # HIT 最低分数
    ambiguous_threshold: float = 0.60  # AMBIGUOUS 最低分数
    margin_threshold: float = 0.10  # 第一名与第二名的最小差距

    # 页面匹配阈值
    page_match_threshold: float = 0.80  # 页面匹配分数阈值

    # 模型名称（保留用于配置兼容，OmniFlow 不执行模型推理）
    model_name: str = ""

    # Bonus
    locality_bonus: float = 0.10
    recency_bonus: float = 0.05

    @classmethod
    def from_env(cls) -> "CompileConfig":
        """Create config from unified settings."""
        from src.foundation.settings import settings

        return cls(
            hit_threshold=settings.compile.hit_threshold,
            ambiguous_threshold=settings.compile.ambiguous_threshold,
            margin_threshold=settings.compile.margin_threshold,
            page_match_threshold=settings.compile.page_match_threshold,
            locality_bonus=settings.compile.locality_bonus,
            recency_bonus=settings.compile.recency_bonus,
        )


@dataclass
class CompileResult:
    """编译结果."""

    decision: CompileDecision
    function_id: str = ""
    score: float = 0.0
    margin: float = 0.0
    arguments: Dict[str, str] = field(default_factory=dict)
    reason: str = ""

    # Debug info
    candidate_scores: List[Tuple[str, float]] = field(default_factory=list)
    latency_ms: float = 0.0

    @property
    def success(self) -> bool:
        return self.decision == CompileDecision.HIT


@dataclass
class CompileContext:
    """编译上下文."""

    current_xml: Optional[str] = None
    current_package: Optional[str] = None
    current_node_id: Optional[str] = None  # 当前页面的 UTG node ID
    page_match_score: float = 0.0  # 页面匹配分数
    recent_function_ids: List[str] = field(default_factory=list)


# ============================================================================
# Compile Cache (分层缓存，参考 GPTCache 设计)
# ============================================================================


@dataclass
class CacheEntry:
    """缓存条目."""

    result: "CompileResult"
    created_at: float
    goal_embedding: Optional[np.ndarray] = None  # 用于 L2 语义匹配


class CompileCache:
    """分层 Compile 缓存.

    L1: 精确匹配（归一化 goal）- 无需 API 调用
    L2: 语义相似匹配（embedding 相似度 > threshold）- 需要 API 调用

    参考: https://github.com/zilliztech/GPTCache
    """

    def __init__(
        self,
        max_size: int = 1000,
        ttl_seconds: float = 3600,
        semantic_threshold: float = 0.95,
    ):
        self._l1_cache: Dict[str, CacheEntry] = {}  # 精确匹配
        self._l2_embeddings: List[np.ndarray] = []  # L2 语义索引
        self._l2_keys: List[str] = []  # L2 key 列表
        self._max_size = max_size
        self._ttl_seconds = ttl_seconds
        self._semantic_threshold = semantic_threshold
        self._function_version: str = ""  # 用于 invalidate

    def _normalize_goal(self, goal: str) -> str:
        """归一化 goal 作为 L1 cache key."""
        # 去除空格、标点，转小写
        import re

        normalized = goal.lower().strip()
        normalized = re.sub(r"\s+", "", normalized)  # 去除所有空格
        return normalized

    def _context_hash(self, context: Optional[CompileContext]) -> str:
        """计算 context hash（用于区分不同上下文）."""
        if not context:
            return ""
        package_name = context.current_package or ""
        page_scope = context.current_node_id or ""
        return f"{package_name}:{page_scope}"

    def _make_key(self, goal: str, context: Optional[CompileContext]) -> str:
        """生成缓存 key."""
        normalized = self._normalize_goal(goal)
        ctx_hash = self._context_hash(context)
        return f"{normalized}:{ctx_hash}"

    def _is_expired(self, entry: CacheEntry) -> bool:
        """检查是否过期."""
        import time

        return (time.time() - entry.created_at) > self._ttl_seconds

    def get_l1(
        self, goal: str, context: Optional[CompileContext] = None
    ) -> Optional["CompileResult"]:
        """L1 精确匹配查找（无需 API 调用）."""
        key = self._make_key(goal, context)
        entry = self._l1_cache.get(key)
        if entry and not self._is_expired(entry):
            logger.debug(f"Compile cache L1 hit: {goal[:20]}...")
            return entry.result
        return None

    def get_l2(
        self, goal_embedding: np.ndarray, context: Optional[CompileContext] = None
    ) -> Optional["CompileResult"]:
        """L2 语义相似匹配（需要 goal embedding）."""
        if not self._l2_embeddings:
            return None

        # 计算与所有缓存 embedding 的相似度
        embeddings = np.array(self._l2_embeddings)
        scores = np.dot(embeddings, goal_embedding)
        max_idx = np.argmax(scores)
        max_score = scores[max_idx]

        if max_score >= self._semantic_threshold:
            key = self._l2_keys[max_idx]
            entry = self._l1_cache.get(key)
            if entry and not self._is_expired(entry):
                logger.debug(
                    f"Compile cache L2 hit: score={max_score:.3f}, goal={goal_embedding.shape}"
                )
                return entry.result
        return None

    def set(
        self,
        goal: str,
        context: Optional[CompileContext],
        result: "CompileResult",
        goal_embedding: Optional[np.ndarray] = None,
    ) -> None:
        """缓存 compile 结果."""
        import time

        key = self._make_key(goal, context)

        # 检查是否已存在
        if key in self._l1_cache:
            # 更新
            self._l1_cache[key] = CacheEntry(
                result=result,
                created_at=time.time(),
                goal_embedding=goal_embedding,
            )
            return

        # 驱逐旧条目（LRU 简化版：直接删除最旧的）
        if len(self._l1_cache) >= self._max_size:
            oldest_key = next(iter(self._l1_cache))
            self._evict(oldest_key)

        # 添加新条目
        entry = CacheEntry(
            result=result,
            created_at=time.time(),
            goal_embedding=goal_embedding,
        )
        self._l1_cache[key] = entry

        # 添加到 L2 索引
        if goal_embedding is not None:
            self._l2_embeddings.append(goal_embedding)
            self._l2_keys.append(key)

    def _evict(self, key: str) -> None:
        """驱逐指定 key."""
        if key in self._l1_cache:
            del self._l1_cache[key]
        if key in self._l2_keys:
            idx = self._l2_keys.index(key)
            self._l2_keys.pop(idx)
            self._l2_embeddings.pop(idx)

    def invalidate_all(self) -> None:
        """清空所有缓存（当 function 库更新时调用）."""
        self._l1_cache.clear()
        self._l2_embeddings.clear()
        self._l2_keys.clear()
        logger.info("Compile cache invalidated")

    def stats(self) -> Dict[str, int]:
        """返回缓存统计."""
        return {
            "l1_size": len(self._l1_cache),
            "l2_size": len(self._l2_embeddings),
            "max_size": self._max_size,
        }


# Global compile cache
_compile_cache: Optional[CompileCache] = None


def get_compile_cache() -> CompileCache:
    """获取全局 compile cache."""
    global _compile_cache
    if _compile_cache is None:
        _compile_cache = CompileCache()
    return _compile_cache


def invalidate_compile_cache() -> None:
    """清空 compile cache（当 function 库更新时调用）."""
    global _compile_cache
    if _compile_cache:
        _compile_cache.invalidate_all()


# ============================================================================
# 轻量级匹配器 (Fallback)
# ============================================================================


class LightweightMatcher:
    """轻量级匹配器: 编辑距离 + N-gram Hash + 动词词表.

    当 sentence-transformers 不可用时的降级方案。
    """

    NGRAM_N = 2

    def _normalize(self, text: str) -> str:
        return text.lower().strip()

    def _extract_ngrams(self, text: str, n: int = 2) -> set:
        text = self._normalize(text)
        if len(text) < n:
            return {text} if text else set()
        return {text[i : i + n] for i in range(len(text) - n + 1)}

    def _ngram_similarity(self, text1: str, text2: str) -> float:
        ngrams1 = self._extract_ngrams(text1, self.NGRAM_N)
        ngrams2 = self._extract_ngrams(text2, self.NGRAM_N)
        if not ngrams1 or not ngrams2:
            return 0.0
        intersection = len(ngrams1 & ngrams2)
        union = len(ngrams1 | ngrams2)
        return intersection / union if union > 0 else 0.0

    def _edit_distance(self, s1: str, s2: str) -> int:
        s1, s2 = self._normalize(s1), self._normalize(s2)
        if len(s1) < len(s2):
            s1, s2 = s2, s1
        if not s2:
            return len(s1)

        prev_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            curr_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = prev_row[j + 1] + 1
                deletions = curr_row[j] + 1
                substitutions = prev_row[j] + (c1 != c2)
                curr_row.append(min(insertions, deletions, substitutions))
            prev_row = curr_row
        return prev_row[-1]

    def _edit_similarity(self, text1: str, text2: str) -> float:
        dist = self._edit_distance(text1, text2)
        max_len = max(len(text1), len(text2))
        if max_len == 0:
            return 1.0
        return 1.0 - (dist / max_len)

    def _verb_match_score(self, query: str, candidate_text: str) -> float:
        query_verbs = extract_verbs(query)
        cand_verbs = extract_verbs(candidate_text)
        if query_verbs and cand_verbs and (query_verbs & cand_verbs):
            return 0.15
        return 0.0

    def score(self, query: str, candidate_text: str) -> float:
        ngram_score = self._ngram_similarity(query, candidate_text)
        edit_score = self._edit_similarity(query, candidate_text)
        verb_bonus = self._verb_match_score(query, candidate_text)
        base_score = 0.5 * ngram_score + 0.5 * edit_score
        return min(1.0, base_score + verb_bonus)

    def rank(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        if not candidates:
            return []

        scored: List[Tuple[FunctionCandidate, float]] = []
        for candidate in candidates:
            best_score = 0.0
            if candidate.description:
                best_score = max(best_score, self.score(query, candidate.description))
            for phrase in candidate.recall_phrases:
                if phrase:
                    best_score = max(best_score, self.score(query, phrase))
            scored.append((candidate, best_score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored


# ============================================================================
# 语义匹配器
# ============================================================================


class SemanticMatcher:
    """语义匹配器: 外部 API 计算 embedding，本地存储和检索.

    OmniFlow 不执行模型推理。通过外部 Embedding Provider 计算向量，
    本地使用 numpy 存储和检索。无 Provider 时降级到 LightweightMatcher。
    """

    def __init__(self, model_name: str = "", index_dir: Optional[str] = None):
        self.model_name = model_name  # 保留用于配置兼容
        self.index_dir = index_dir
        self._lightweight = LightweightMatcher()

        # 向量索引（numpy 存储）
        self._embeddings: Optional[np.ndarray] = None  # shape: (n_phrases, dim)
        self._phrases: List[str] = []
        self._phrase_to_func_id: List[str] = []
        self._func_id_to_candidate: Dict[str, FunctionCandidate] = {}
        self._index_loaded = False

    def encode(self, texts: List[str]) -> np.ndarray:
        """通过外部 Provider 编码文本为向量."""
        provider = get_embedding_provider()
        if not provider:
            raise RuntimeError(
                "No embedding provider configured. "
                "Use set_embedding_provider() or install omniflow[ml]"
            )
        embeddings = provider.encode(texts)
        if not isinstance(embeddings, np.ndarray):
            embeddings = np.array(embeddings)
        # 归一化（用于余弦相似度）
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)  # 避免除零
        return embeddings / norms

    def build_index(self, all_candidates: List[FunctionCandidate]) -> None:
        """构建向量索引.

        通过外部 Embedding Provider 计算所有候选的向量，存储到本地。
        """
        provider = get_embedding_provider()
        if not provider:
            logger.info("No embedding provider, using lightweight matcher only")
            return

        # 收集所有短语
        all_phrases: List[str] = []
        phrase_to_func_id: List[str] = []
        func_id_to_candidate: Dict[str, FunctionCandidate] = {}

        for candidate in all_candidates:
            func_id_to_candidate[candidate.function_id] = candidate

            if candidate.description:
                all_phrases.append(candidate.description)
                phrase_to_func_id.append(candidate.function_id)

            for phrase in candidate.recall_phrases:
                if phrase:
                    all_phrases.append(phrase)
                    phrase_to_func_id.append(candidate.function_id)

        if not all_phrases:
            logger.warning("No phrases to index")
            return

        logger.info(
            f"Building embedding index for {len(all_phrases)} phrases "
            f"from {len(all_candidates)} functions"
        )

        try:
            # 调用外部 API 计算 embeddings
            embeddings = self.encode(all_phrases)

            self._embeddings = embeddings
            self._phrases = all_phrases
            self._phrase_to_func_id = phrase_to_func_id
            self._func_id_to_candidate = func_id_to_candidate
            self._index_loaded = True

            logger.info(
                f"Embedding index built: {len(all_phrases)} vectors, "
                f"dim={embeddings.shape[1]}"
            )

            # 持久化到磁盘
            if self.index_dir:
                self._save_index()

        except Exception as e:
            logger.warning(f"Failed to build embedding index: {e}")

    def _save_index(self) -> None:
        """保存向量索引到磁盘."""
        if self._embeddings is None or not self.index_dir:
            return

        os.makedirs(self.index_dir, exist_ok=True)

        embeddings_path = os.path.join(self.index_dir, "embeddings.npy")
        meta_path = os.path.join(self.index_dir, "embeddings.meta")

        # 保存 embeddings
        np.save(embeddings_path, self._embeddings)

        # 保存元数据
        metadata = {
            "phrases": self._phrases,
            "phrase_to_func_id": self._phrase_to_func_id,
            "func_id_to_candidate": self._func_id_to_candidate,
            "model_name": self.model_name,
        }
        with open(meta_path, "wb") as f:
            pickle.dump(metadata, f)

        logger.info(f"Embedding index saved to {self.index_dir}")

    def _load_index(self) -> bool:
        """从磁盘加载向量索引."""
        if not self.index_dir:
            return False

        embeddings_path = os.path.join(self.index_dir, "embeddings.npy")
        meta_path = os.path.join(self.index_dir, "embeddings.meta")

        if not os.path.exists(embeddings_path) or not os.path.exists(meta_path):
            return False

        try:
            self._embeddings = np.load(embeddings_path)

            with open(meta_path, "rb") as f:
                metadata = pickle.load(f)

            self._phrases = metadata["phrases"]
            self._phrase_to_func_id = metadata["phrase_to_func_id"]
            self._func_id_to_candidate = metadata["func_id_to_candidate"]
            self._index_loaded = True

            logger.info(
                f"Embedding index loaded from {self.index_dir}: "
                f"{len(self._phrases)} vectors"
            )
            return True

        except Exception as e:
            logger.warning(f"Failed to load embedding index: {e}")
            return False

    def rank(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        """对候选 Functions 进行排序."""
        if not candidates:
            return []

        # 如果有预构建的索引，使用向量检索
        if self._index_loaded and self._embeddings is not None:
            return self._rank_with_index(query, candidates)

        # 尝试实时计算（如果有 provider）
        provider = get_embedding_provider()
        if provider:
            return self._rank_realtime(query, candidates, provider)

        # 降级到轻量级匹配
        return self._lightweight.rank(query, candidates)

    def _rank_with_index(
        self, query: str, candidates: Sequence[FunctionCandidate]
    ) -> List[Tuple[FunctionCandidate, float]]:
        """使用预构建索引进行排序."""
        try:
            # 编码 query
            query_emb = self.encode([query])[0]  # shape: (dim,)

            # 计算相似度（点积，因为已归一化）
            scores = np.dot(self._embeddings, query_emb)  # shape: (n_phrases,)

            # 过滤并聚合到候选
            candidate_func_ids = {c.function_id for c in candidates}
            candidate_scores: Dict[str, float] = {}

            for idx, score in enumerate(scores):
                func_id = self._phrase_to_func_id[idx]
                if func_id not in candidate_func_ids:
                    continue
                if func_id not in candidate_scores:
                    candidate_scores[func_id] = float(score)
                else:
                    candidate_scores[func_id] = max(
                        candidate_scores[func_id], float(score)
                    )

            # 构建排序结果
            ranked = [(c, candidate_scores.get(c.function_id, 0.0)) for c in candidates]
            ranked.sort(key=lambda x: x[1], reverse=True)
            return ranked

        except Exception as e:
            logger.warning(f"Index-based ranking failed: {e}, using fallback")
            return self._lightweight.rank(query, candidates)

    def _rank_realtime(
        self,
        query: str,
        candidates: Sequence[FunctionCandidate],
        provider: EmbeddingProvider,
    ) -> List[Tuple[FunctionCandidate, float]]:
        """实时计算 embedding 进行排序（无预构建索引时）."""
        try:
            # 收集候选文本
            all_texts = [query]
            text_to_candidate_idx: List[int] = []

            for i, c in enumerate(candidates):
                if c.description:
                    all_texts.append(c.description)
                    text_to_candidate_idx.append(i)
                for phrase in c.recall_phrases:
                    if phrase:
                        all_texts.append(phrase)
                        text_to_candidate_idx.append(i)

            if len(all_texts) == 1:
                return [(c, 0.0) for c in candidates]

            # 批量编码
            embeddings = self.encode(all_texts)
            query_emb = embeddings[0]
            phrase_embs = embeddings[1:]

            # 计算相似度
            scores = np.dot(phrase_embs, query_emb)

            # 聚合到候选
            candidate_scores = [0.0] * len(candidates)
            for idx, score in enumerate(scores):
                cand_idx = text_to_candidate_idx[idx]
                candidate_scores[cand_idx] = max(
                    candidate_scores[cand_idx], float(score)
                )

            ranked = [
                (candidates[i], candidate_scores[i]) for i in range(len(candidates))
            ]
            ranked.sort(key=lambda x: x[1], reverse=True)
            return ranked

        except Exception as e:
            logger.warning(f"Realtime ranking failed: {e}, using fallback")
            return self._lightweight.rank(query, candidates)


# ============================================================================
# Goal 归一化
# ============================================================================


class GoalNormalizer:
    """Goal 归一化器（用于缓存）."""

    PATTERNS = [
        (r"给[\u4e00-\u9fa5]{2,4}", "给{}"),
        (r"\d+", "{}"),
        (r"@\w+", "@{}"),
        (r"[「」『』" "''\"'].*?[「」『』" "''\"']", "{}"),
    ]

    @classmethod
    def normalize(cls, goal: str) -> str:
        result = goal
        for pattern, replacement in cls.PATTERNS:
            result = re.sub(pattern, replacement, result)
        return result

    @classmethod
    def extract_params(cls, goal: str, template: str) -> Dict[str, str]:
        pattern = re.escape(template)
        param_names = re.findall(r"\{(\w+)\}", template)

        if not param_names:
            return {}

        for i, name in enumerate(param_names):
            escaped_placeholder = re.escape(f"{{{name}}}")
            if i == len(param_names) - 1:
                pattern = pattern.replace(escaped_placeholder, f"(?P<{name}>.+)")
            else:
                pattern = pattern.replace(escaped_placeholder, f"(?P<{name}>.+?)")

        pattern = pattern + "$"
        match = re.match(pattern, goal)
        if match:
            return match.groupdict()
        return {}


# ============================================================================
# 统一编译器
# ============================================================================


class Compiler:
    """统一语义匹配编译器."""

    def __init__(
        self, config: Optional[CompileConfig] = None, index_dir: Optional[str] = None
    ):
        self.config = config or CompileConfig()
        self.index_dir = index_dir or "runtime/embedding_index"
        self._matcher = SemanticMatcher(
            self.config.model_name, index_dir=self.index_dir
        )

        # Function 注册表
        self._global_functions: List[FunctionCandidate] = []
        self._app_functions: Dict[str, List[FunctionCandidate]] = {}
        self._page_functions: Dict[str, List[FunctionCandidate]] = {}
        self._function_ids: List[str] = []

    def register_function(self, candidate: FunctionCandidate) -> None:
        """注册 Function."""
        if candidate.scope == FunctionScope.GLOBAL:
            self._global_functions.append(candidate)
        elif candidate.scope == FunctionScope.APP:
            if candidate.source_app:
                self._app_functions.setdefault(candidate.source_app, []).append(
                    candidate
                )
        elif candidate.scope == FunctionScope.PAGE:
            if candidate.source_node_id:
                self._page_functions.setdefault(candidate.source_node_id, []).append(
                    candidate
                )

    def register_functions(self, candidates: Sequence[FunctionCandidate]) -> None:
        """批量注册 Functions."""
        for candidate in candidates:
            self.register_function(candidate)

    def build_index(self) -> None:
        """构建向量索引.

        通过外部 Embedding Provider 计算向量，存储到本地。
        无 Provider 时仅使用轻量级匹配。
        """
        all_funcs = list(self._global_functions)
        for funcs in self._app_functions.values():
            all_funcs.extend(funcs)
        for funcs in self._page_functions.values():
            all_funcs.extend(funcs)

        if not all_funcs:
            return

        self._function_ids = [f.function_id for f in all_funcs]

        # 尝试从磁盘加载已有索引
        if self._matcher._load_index():
            logger.info("Embedding index loaded from disk")
            return

        # 构建新索引（需要外部 Embedding Provider）
        self._matcher.build_index(all_funcs)
        logger.info(f"Compile index ready with {len(self._function_ids)} functions")

    def compile(
        self, goal: str, context: Optional[CompileContext] = None
    ) -> CompileResult:
        """编译 goal 到 function（内联版本 ~100 行）

        使用分层缓存加速：
        - L1: 精确匹配（归一化 goal）- 无需 API 调用
        - L2: 语义相似匹配 - 复用 goal embedding
        """
        started_at = perf_counter()
        context = context or CompileContext()
        cache_context = CompileContext(current_package=context.current_package)
        if (
            context.current_node_id
            and context.page_match_score >= self.config.page_match_threshold
        ):
            cache_context.current_node_id = context.current_node_id

        # 0. 验证输入
        if not goal or not goal.strip():
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="empty_goal",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        # 1. L1 缓存查找（精确匹配，无需 API）
        cache = get_compile_cache()
        cached = cache.get_l1(goal, cache_context)
        if cached is not None:
            cached.latency_ms = (perf_counter() - started_at) * 1000
            cached.reason = f"cache_l1_hit:{cached.reason}"
            return cached

        # 2. 收集候选（内联 collect_candidates）
        all_funcs = list(self._global_functions)

        if context.current_package:
            all_funcs.extend(self._app_functions.get(context.current_package, []))

        if (
            context.current_node_id
            and context.page_match_score >= self.config.page_match_threshold
        ):
            all_funcs.extend(self._page_functions.get(context.current_node_id, []))

        # Graph 约束过滤
        if context.current_node_id:
            candidates = [
                f
                for f in all_funcs
                if f.from_node_id is None or f.from_node_id == context.current_node_id
            ]
        else:
            candidates = [f for f in all_funcs if f.from_node_id is None]

        if not candidates:
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="no_candidates",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        # 3. 语义匹配 + 应用 bonuses（内联 _apply_bonuses）
        ranked = self._matcher.rank(goal, candidates)
        recent_ids = set(context.recent_function_ids or [])

        adjusted = []
        for candidate, score in ranked:
            bonus = 0.0

            # Locality bonus
            if context.current_node_id:
                if candidate.from_node_id == context.current_node_id:
                    bonus += self.config.locality_bonus
                elif candidate.from_node_id is not None:
                    bonus -= 0.02

            # Recency bonus
            if candidate.function_id in recent_ids:
                bonus += self.config.recency_bonus

            adjusted.append((candidate, score + bonus))

        adjusted.sort(key=lambda x: x[1], reverse=True)

        # 4. 做出决策（内联 _make_decision）
        if not adjusted:
            return CompileResult(
                decision=CompileDecision.MISS,
                reason="no_match",
                latency_ms=(perf_counter() - started_at) * 1000,
            )

        top_candidate, top_score = adjusted[0]
        margin = top_score - adjusted[1][1] if len(adjusted) > 1 else 1.0
        candidate_scores = [(c.function_id, s) for c, s in adjusted[:5]]

        # 5. 构建结果
        latency_ms = (perf_counter() - started_at) * 1000

        if top_score < self.config.ambiguous_threshold:
            result = CompileResult(
                decision=CompileDecision.MISS,
                score=top_score,
                margin=margin,
                reason=f"below_threshold_{top_score:.2f}",
                candidate_scores=candidate_scores,
                latency_ms=latency_ms,
            )
        elif (
            top_score >= self.config.hit_threshold
            and margin >= self.config.margin_threshold
        ):
            result = CompileResult(
                decision=CompileDecision.HIT,
                function_id=top_candidate.function_id,
                score=top_score,
                margin=margin,
                arguments={},
                reason="hit",
                candidate_scores=candidate_scores,
                latency_ms=latency_ms,
            )
        else:
            result = CompileResult(
                decision=CompileDecision.AMBIGUOUS,
                function_id=top_candidate.function_id,
                score=top_score,
                margin=margin,
                reason=f"ambiguous_margin_{margin:.2f}"
                if margin < self.config.margin_threshold
                else f"below_hit_{top_score:.2f}",
                candidate_scores=candidate_scores,
                latency_ms=latency_ms,
            )

        # 6. 缓存结果（只缓存 HIT 和 AMBIGUOUS，不缓存 MISS）
        if result.decision != CompileDecision.MISS:
            cache.set(goal, cache_context, result)

        return result


__all__ = [
    # Core
    "Compiler",
    "CompileConfig",
    "CompileResult",
    "CompileContext",
    "CompileDecision",
    "FunctionCandidate",
    "FunctionScope",
    # Cache
    "CompileCache",
    "get_compile_cache",
    "invalidate_compile_cache",
    # Embedding
    "EmbeddingProvider",
    "set_embedding_provider",
    "get_embedding_provider",
    "DashScopeEmbeddingProvider",
    # Utilities
    "GoalNormalizer",
    "SemanticMatcher",
    "LightweightMatcher",
    # Verb vocab
    "extract_verbs",
    "get_verb_group",
    "VERB_SYNONYMS",
    "VERB_INDEX",
]
