from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from src.foundation.source_tools import (
    parse_bounds,
    parse_bounds_center,
    read_xml_attr,
)
from src.utg.core.actions import (
    ClickAction,
    canonical_action_type,
    is_system_level_action,
    make_press_back_action,
)
from src.utg.core.triggers import (
    AlwaysCondition,
    DeviceActionEffect,
    NeverCondition,
    NodeExistsCondition,
    RunActionsEffect,
    TriggerActionTemplate,
    TriggerScope,
    TriggerSpec,
    XmlMatchCondition,
    evaluate_node_exists,
    normalize_trigger,
)
from src.utg.execution.execution_policy import (
    ExecutionPolicyProvider,
    get_utg_bundle_file_for_execution,
)
from src.utg.execution.protocol import WhenContext, observations_equal
from src.utg.execution.utils import (
    bounds_area,
    extract_int_list,
    extract_string_list,
    point_in_bounds,
)

logger = logging.getLogger(__name__)

_MAX_XML_SIZE = 10 * 1024 * 1024  # 10MB


def _parse_xml_safe(xml_text: str) -> Optional[ET.Element]:
    """Parse XML with size validation.

    Args:
        xml_text: Raw XML string to parse.

    Returns:
        Parsed Element root, or None if too large or invalid.
    """
    if len(xml_text) > _MAX_XML_SIZE:
        logger.warning("XML too large: %d bytes (max %d)", len(xml_text), _MAX_XML_SIZE)
        return None
    try:
        return ET.fromstring(xml_text)
    except Exception:
        return None


VALID_TRIGGER_PHASES = {
    "before_step",
    "before_action",
    "execute_action",
    "after_action",
    "terminal",
}

__all__ = [
    "TriggerPool",
    "TriggerRuntime",
    "WhenContext",
    "evaluate_trigger_when",
    "load_trigger_pool",
    "resolve_trigger_then",
    "when_handoff_human",
    "when_human_gate",
    "when_package_mismatch_open_app",
    "when_auto_back_after_type",
    "when_keyboard_dismiss",
    "when_no_effect_guard",
    "when_observation_trigger",
    "when_open_app_verify",
    "when_page_mismatch_press_back",
    "when_scroll_retry",
]


class TriggerPool:
    """Runtime trigger-pool config loaded from policy payload or bundle file."""

    def __init__(
        self,
        *,
        enabled: bool,
        rules: Optional[List[TriggerSpec]] = None,
        max_rounds_per_phase: int = 2,
        source_path: Optional[str] = None,
        reason: str = "",
    ) -> None:
        self.enabled = bool(enabled)
        self.rules = list(rules or [])
        self.max_rounds_per_phase = max(1, int(max_rounds_per_phase))
        self.source_path = source_path
        self.reason = reason

    @classmethod
    def disabled(cls, reason: str = "") -> "TriggerPool":
        """Return one disabled trigger pool with an explicit reason."""

        return cls(enabled=False, rules=[], reason=reason)


def load_trigger_pool(
    *,
    explicit_path: Optional[str] = None,
    utg_path: Optional[str] = None,
    enabled: bool = True,
    payload: Optional[Dict[str, Any]] = None,
) -> TriggerPool:
    """Load the runtime trigger pool from inline payload or bundle file."""

    if not enabled:
        return TriggerPool.disabled(reason="disabled_by_config")
    if isinstance(payload, dict):
        return _pool_from_payload(payload, source_path=explicit_path)
    path = _resolve_trigger_pool_config_path(
        explicit_path=explicit_path, utg_path=utg_path
    )
    if path is None:
        return TriggerPool.disabled(reason="config_not_found")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Failed to load trigger control config from %s: %s", path, exc)
        return TriggerPool.disabled(reason="invalid_config")
    if not isinstance(raw, dict):
        return TriggerPool.disabled(reason="invalid_config")
    return _pool_from_payload(raw, source_path=str(path))


def evaluate_trigger_when(
    condition: Any,
    node: Any,
    current_xml: str,
    *,
    package_name: Optional[str] = None,
) -> bool:
    """Evaluate one trigger `when` condition against the current observation."""

    if isinstance(condition, AlwaysCondition):
        return True
    if isinstance(condition, NeverCondition):
        return False
    if isinstance(condition, NodeExistsCondition):
        return evaluate_node_exists(condition, utg_node=node) is True
    if isinstance(condition, XmlMatchCondition):
        return _match_xml_condition(
            condition,
            xml_text=current_xml,
            package_name=package_name,
        )
    return False


def resolve_trigger_then(
    effect: Any,
    *,
    current_xml: str,
) -> Optional[RunActionsEffect]:
    """Resolve one trigger `then` effect into concrete actions."""

    if isinstance(effect, RunActionsEffect):
        return effect
    if isinstance(effect, DeviceActionEffect):
        action = _resolve_action(effect.action, xml_text=current_xml)
        if action is None:
            return None
        return RunActionsEffect(actions=[action])
    return None


class TriggerRuntime:
    """Own trigger-pool loading and matching for the unified `when` runtime."""

    def __init__(self, policy_provider: ExecutionPolicyProvider) -> None:
        self.policy_provider = policy_provider
        self.pool = load_trigger_pool(
            explicit_path=policy_provider.trigger_pool_source_path(),
            enabled=policy_provider.trigger_pool_enabled(),
            payload=policy_provider.trigger_pool_payload(),
        )
        self.node_triggers_enabled = bool(policy_provider.node_triggers_enabled())

    def max_rounds_per_phase(self, phase: str) -> int:
        """Return the per-phase rerun budget used by executor after run_actions."""

        if phase == "before_step":
            return max(4, int(self.pool.max_rounds_per_phase))
        return 2

    def match_trigger(
        self,
        *,
        runtime: Any,
        phase: str,
        observation: Any,
        route: Any,
    ) -> Optional[TriggerSpec]:
        """Return the highest-priority trigger matching the current route observation."""

        package_name = str(getattr(observation, "package_name", "") or "")
        node = getattr(route, "node", None)
        path = getattr(route, "path", None)
        step = getattr(route, "step", None)
        action = getattr(route, "action", None)
        action_type = canonical_action_type(getattr(action, "type", None))
        for spec in self._collect_phase_triggers(
            runtime,
            phase=phase,
            node=node,
            path=path,
            package_name=package_name,
            step=step,
            action_type=action_type,
            include_trigger_pool=True,
        ):
            if evaluate_trigger_when(
                spec.condition,
                node,
                str(getattr(observation, "xml", "") or ""),
                package_name=package_name,
            ):
                return spec
        return None

    def _collect_phase_triggers(
        self,
        runtime: Any,
        *,
        phase: str,
        node: Any,
        path: Any,
        package_name: str,
        step: Any,
        action_type: Optional[str] = None,
        include_trigger_pool: bool = False,
    ) -> List[TriggerSpec]:
        candidates: List[TriggerSpec] = []
        if include_trigger_pool and self.pool.enabled:
            candidates.extend(list(self.pool.rules))
        graph_triggers = list(
            getattr(getattr(runtime, "_utg", None), "triggers", []) or []
        )
        path_triggers = list(getattr(path, "triggers", []) or [])
        node_triggers = (
            list(getattr(node, "triggers", []) or [])
            if self.node_triggers_enabled
            else []
        )
        for raw_trigger in [*graph_triggers, *path_triggers, *node_triggers]:
            spec = normalize_trigger(raw_trigger)
            if spec is None or not bool(spec.enabled):
                continue
            if str(spec.phase or "") != phase:
                continue
            if not _trigger_scope_matches(
                getattr(spec, "scope", None),
                package_name=package_name,
                node=node,
                path=path,
                step=step,
                action_type=action_type,
            ):
                continue
            candidates.append(spec)
        candidates.sort(key=lambda item: int(item.priority or 0), reverse=True)
        return candidates


def when_observation_trigger(
    trigger_runtime: TriggerRuntime,
    *,
    runtime: Any,
    observation: Any,
    route: Any,
) -> Optional[TriggerSpec]:
    """Return the highest-priority `before_step` trigger matching the observation."""

    return trigger_runtime.match_trigger(
        runtime=runtime,
        phase="before_step",
        observation=observation,
        route=route,
    )


def when_keyboard_dismiss(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when the software keyboard is visible and current target looks mismatched."""

    if ctx.policy is None:
        return None
    if not bool(ctx.policy.path_config().enable_keyboard_dismiss_re_adapt):
        return None

    # Use PageVectorSet for fast keyboard detection (50x faster)
    vector_set = getattr(ctx.observation, "vector_set", None)
    if not _is_keyboard_visible_from_vector_set(vector_set):
        return None

    adaptation_debug = dict(getattr(ctx.route, "adaptation_debug", {}) or {})
    if not _editable_target_mismatch(adaptation_debug):
        return None
    return {
        "reason": "editable_target_mismatch",
        "keyboard_visible": True,
    }


def when_scroll_retry(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when adapted target is predicted outside the visible viewport."""

    if ctx.policy is None:
        return None
    if not bool(ctx.policy.path_config().enable_scroll_retry_re_adapt):
        return None

    # Use PageVectorSet for fast scrollable viewport finding (10x faster)
    vector_set = getattr(ctx.observation, "vector_set", None)
    probe = _inspect_scroll_retry_from_vector_set(
        vector_set=vector_set,
        adaptation_debug=dict(getattr(ctx.route, "adaptation_debug", {}) or {}),
    )

    if not bool(probe.get("proposed")):
        return None
    return dict(probe)


def when_open_app_verify(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when the executed action is `open_app` and needs foreground verification."""

    action = getattr(ctx.route, "effective_action", None) or getattr(
        ctx.route, "action", None
    )
    if canonical_action_type(getattr(action, "type", None)) != "open_app":
        return None
    package_name = _extract_open_app_expected_package(action)
    if not package_name:
        return None
    return {"expected_package": package_name}


def when_package_mismatch_open_app(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when the current foreground app differs from the step's expected app.

    Args:
        ctx: Unified when context containing observation, route, phase, runtime, policy.

    Returns:
        A compact recovery payload when the step expects one concrete package and
        the host is currently on another package. Returns `None` when the step
        already starts with a system-level action or when app identity is unknown.
    """

    expected_node = getattr(ctx.route, "node", None)
    expected_package = str(
        getattr(getattr(expected_node, "repr", None), "packageName", "") or ""
    ).strip()
    current_package = str(getattr(ctx.observation, "package_name", "") or "").strip()
    if (
        not expected_package
        or expected_package == "unknown.package"
        or not current_package
        or current_package == expected_package
    ):
        return None
    step = getattr(ctx.route, "step", None)
    node_functions = (
        getattr(expected_node, "functions", {}) if expected_node is not None else {}
    )
    for function_name in list(getattr(step, "functions", []) or []):
        function_obj = node_functions.get(function_name)
        if function_obj is None:
            continue
        actions = list(getattr(function_obj, "actions", []) or [])
        if not actions:
            continue
        first_action = actions[0]
        if canonical_action_type(first_action) == "open_app":
            return None
        if is_system_level_action(first_action):
            return None
        break
    return {
        "expected_package": expected_package,
        "current_package": current_package,
        "reason": "package_mismatch_before_step",
    }


def when_page_mismatch_press_back(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match one same-package page mismatch that should recover via back.

    Args:
        ctx: Unified when context containing observation, route, phase, runtime, policy.

    Returns:
        One compact recovery payload when the foreground package already matches
        the expected package but the current page still does not match the
        expected node. Returns `None` when the step starts with a system-level
        action, when page identity is unknown, or when the page already matches.
    """

    expected_node = getattr(ctx.route, "node", None)
    expected_package = str(
        getattr(getattr(expected_node, "repr", None), "packageName", "") or ""
    ).strip()
    current_package = str(getattr(ctx.observation, "package_name", "") or "").strip()
    vector_set = getattr(ctx.observation, "vector_set", None)

    if (
        not expected_package
        or expected_package == "unknown.package"
        or not current_package
        or current_package != expected_package
        or vector_set is None
        or expected_node is None
    ):
        return None
    runtime_context = (
        getattr(ctx.route, "runtime_context", {})
        if isinstance(getattr(ctx.route, "runtime_context", {}), dict)
        else {}
    )
    if (
        int(runtime_context.get("__utg_page_mismatch_back_attempt_count__", 0) or 0)
        >= 1
    ):
        return None
    last_effect_debug = (
        dict(runtime_context.get("__utg_last_action_effect_debug__") or {})
        if isinstance(runtime_context.get("__utg_last_action_effect_debug__"), dict)
        else {}
    )
    if str(last_effect_debug.get("reason") or "").strip() == "no_effect":
        return None
    step = getattr(ctx.route, "step", None)
    node_functions = (
        getattr(expected_node, "functions", {}) if expected_node is not None else {}
    )
    for function_name in list(getattr(step, "functions", []) or []):
        function_obj = node_functions.get(function_name)
        if function_obj is None:
            continue
        actions = list(getattr(function_obj, "actions", []) or [])
        if not actions:
            continue
        first_action = actions[0]
        if canonical_action_type(first_action) == "open_app":
            return None
        if is_system_level_action(first_action):
            return None
        break
    # 优先使用 VectorSet 版本，fallback 到 XML 版本
    is_page_match_node = getattr(
        ctx.runtime, "_is_current_page_match_node_from_vector_set", None
    )
    if callable(is_page_match_node):
        # 使用 VectorSet 版本
        if bool(is_page_match_node(vector_set, expected_node)):
            return None
    else:
        # Fallback: 使用 XML 版本（向后兼容）
        is_page_match_node = getattr(ctx.runtime, "_is_current_page_match_node", None)
        if not callable(is_page_match_node):
            return None
        # 需要 XML，但我们已经移除了，所以跳过检查
        return None
    return {
        "expected_package": expected_package,
        "current_package": current_package,
        "reason": "page_mismatch_before_step",
    }


def when_no_effect_guard(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when the action should have changed the page but observation stayed unchanged."""

    if ctx.policy is None:
        return None
    if not bool(ctx.policy.action_config().enabled):
        return None
    action = getattr(ctx.route, "effective_action", None) or getattr(
        ctx.route, "action", None
    )
    action_type = canonical_action_type(getattr(action, "type", None))
    if action_type not in {"click", "click_node", "long_press"}:
        return None
    if _is_focus_input_action(action):
        return None
    before = getattr(ctx.route, "before_observation", None)
    if before is None:
        return None
    if not observations_equal(before, ctx.observation):
        return None
    return {
        "reason": "no_effect",
        "action_type": action_type,
    }


def when_auto_back_after_type(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match when keyboard is still visible after one input-text action."""

    action = getattr(ctx.route, "effective_action", None) or getattr(
        ctx.route, "action", None
    )
    if canonical_action_type(getattr(action, "type", None)) != "input_text":
        return None

    # Use PageVectorSet for fast keyboard detection
    vector_set = getattr(ctx.observation, "vector_set", None)
    if not _is_keyboard_visible_from_vector_set(vector_set):
        return None

    return {"reason": "keyboard_still_visible_after_type"}


def when_human_gate(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match one env-driven human-confirmation gate once per phase/step/action."""

    phase = ctx.phase
    if not str(phase or "").strip():
        return None
    env_key = f"UTG_HUMAN_GATE_{str(phase or '').strip().upper()}"
    if not _env_flag_enabled(env_key):
        return None
    gate_key = _human_gate_key(phase=phase, route=ctx.route)
    seen = _runtime_flag_bucket(ctx.route, "__utg_human_gate_seen__")
    if gate_key in seen:
        return None
    return {"env_key": env_key, "gate_key": gate_key, "phase": str(phase or "")}


def when_handoff_human(ctx: WhenContext) -> Optional[dict[str, Any]]:
    """Match one env-driven human handoff once per phase/step/action."""

    phase = ctx.phase
    if not str(phase or "").strip():
        return None
    env_key = f"UTG_HANDOFF_HUMAN_{str(phase or '').strip().upper()}"
    if not _env_flag_enabled(env_key):
        return None
    gate_key = _human_gate_key(phase=phase, route=ctx.route)
    seen = _runtime_flag_bucket(ctx.route, "__utg_handoff_human_seen__")
    if gate_key in seen:
        return None
    return {"env_key": env_key, "gate_key": gate_key, "phase": str(phase or "")}


def _pool_from_payload(
    payload: Dict[str, Any], *, source_path: Optional[str]
) -> TriggerPool:
    """从配置 payload 构建 TriggerPool。"""
    rules: List[TriggerSpec] = []
    for item in list(payload.get("rules") or []):
        if not isinstance(item, dict):
            continue
        match_raw = item.get("match") if isinstance(item.get("match"), dict) else {}
        action_raw = item.get("action") if isinstance(item.get("action"), dict) else {}
        scope_raw = item.get("scope") if isinstance(item.get("scope"), dict) else {}
        rule_id = str(item.get("id") or "").strip()
        if not rule_id:
            continue
        phase = str(item.get("phase") or "before_step").strip() or "before_step"
        if phase not in VALID_TRIGGER_PHASES:
            phase = "before_step"
        rules.append(
            TriggerSpec(
                id=rule_id,
                description=str(item.get("description") or "").strip() or None,
                phase=phase,
                enabled=bool(item.get("enabled", True)),
                priority=int(item.get("priority", 0) or 0),
                scope=TriggerScope(
                    package_names=extract_string_list(scope_raw, "package_names"),
                    node_ids=extract_string_list(scope_raw, "node_ids"),
                    function_ids=extract_string_list(scope_raw, "function_ids"),
                    step_indexes=extract_int_list(scope_raw, "step_indexes"),
                    action_types=extract_string_list(scope_raw, "action_types"),
                ),
                condition=XmlMatchCondition(
                    package_allowlist=extract_string_list(
                        match_raw, "package_allowlist"
                    ),
                    package_denylist=extract_string_list(match_raw, "package_denylist"),
                    xml_contains_any=extract_string_list(match_raw, "xml_contains_any"),
                    text_contains_any=extract_string_list(
                        match_raw, "text_contains_any"
                    ),
                    content_desc_contains_any=extract_string_list(
                        match_raw, "content_desc_contains_any"
                    ),
                    resource_id_contains_any=extract_string_list(
                        match_raw, "resource_id_contains_any"
                    ),
                ),
                effect=DeviceActionEffect(
                    action=TriggerActionTemplate(
                        kind=str(action_raw.get("kind") or "press_back"),
                        values=extract_string_list(action_raw, "values"),
                        bounds=str(action_raw.get("bounds") or "").strip() or None,
                        fallback_kind=(
                            str(action_raw.get("fallback_kind") or "").strip() or None
                        ),
                    )
                ),
                source=str(source_path or ""),
            )
        )
    return TriggerPool(
        enabled=bool(payload.get("enabled", True)),
        rules=rules,
        max_rounds_per_phase=max(
            1,
            int(
                payload.get(
                    "max_rounds_per_phase", payload.get("max_rounds_per_step", 2)
                )
                or 2
            ),
        ),
        source_path=source_path,
    )


def _resolve_trigger_pool_config_path(
    *, explicit_path: Optional[str], utg_path: Optional[str]
) -> Path | None:
    if explicit_path:
        path = Path(explicit_path)
        return path if path.is_file() else None
    candidate = Path(get_utg_bundle_file_for_execution("trigger_pool.json", utg_path))
    return candidate if candidate.is_file() else None


def _trigger_scope_matches(
    scope: Optional[TriggerScope],
    *,
    package_name: str,
    node: Any,
    path: Any,
    step: Any,
    action_type: Optional[str],
) -> bool:
    if scope is None:
        return True
    package_names = {
        str(v or "").strip()
        for v in list(scope.package_names or [])
        if str(v or "").strip()
    }
    if package_names and package_name not in package_names:
        return False
    node_ids = {
        str(v or "").strip() for v in list(scope.node_ids or []) if str(v or "").strip()
    }
    if node_ids and str(getattr(node, "id", "") or "").strip() not in node_ids:
        return False
    function_ids = {
        str(v or "").strip()
        for v in list(scope.function_ids or [])
        if str(v or "").strip()
    }
    if function_ids and str(getattr(path, "id", "") or "").strip() not in function_ids:
        return False
    if list(scope.step_indexes or []):
        try:
            current_step = int(getattr(step, "index", None))
        except Exception:
            current_step = None
        if current_step not in {int(v) for v in list(scope.step_indexes or [])}:
            return False
    action_types = {
        canonical_action_type(v)
        for v in list(scope.action_types or [])
        if canonical_action_type(v)
    }
    if action_types and canonical_action_type(action_type) not in action_types:
        return False
    return True


def _env_flag_enabled(env_key: str) -> bool:
    raw = str(os.getenv(str(env_key or ""), "") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _runtime_flag_bucket(route: Any, bucket_key: str) -> set[str]:
    runtime_context = (
        getattr(route, "runtime_context", None)
        if isinstance(getattr(route, "runtime_context", None), dict)
        else {}
    )
    bucket = runtime_context.setdefault(bucket_key, set())
    if isinstance(bucket, set):
        return bucket
    normalized = {str(item) for item in list(bucket or []) if str(item).strip()}
    runtime_context[bucket_key] = normalized
    return normalized


def _human_gate_key(*, phase: str, route: Any) -> str:
    step_index = getattr(getattr(route, "step", None), "index", None)
    action = getattr(route, "action", None)
    action_type = canonical_action_type(getattr(action, "type", None)) or "-"
    return (
        f"{str(phase or '').strip()}::"
        f"{str(getattr(getattr(route, 'path', None), 'id', '') or '-')}::"
        f"{str(step_index if step_index is not None else '-')}::"
        f"{str(action_type or '-')}"
    )


def _match_xml_condition(
    condition: XmlMatchCondition,
    *,
    xml_text: str,
    package_name: Optional[str] = None,
) -> bool:
    xml_lower = str(xml_text or "").lower()
    package_lower = str(package_name or "").strip().lower()
    if list(condition.package_allowlist or []):
        allow = {
            str(v or "").strip().lower()
            for v in list(condition.package_allowlist or [])
            if str(v or "").strip()
        }
        if package_lower not in allow:
            return False
    if list(condition.package_denylist or []):
        deny = {
            str(v or "").strip().lower()
            for v in list(condition.package_denylist or [])
            if str(v or "").strip()
        }
        if package_lower in deny:
            return False

    if any(
        str(item).lower() in xml_lower
        for item in list(condition.xml_contains_any or [])
    ):
        pass
    elif list(condition.xml_contains_any or []):
        return False

    if any(
        _xml_attr_contains(xml_text, "text", value)
        for value in list(condition.text_contains_any or [])
    ):
        pass
    elif list(condition.text_contains_any or []):
        return False

    if any(
        _xml_attr_contains(xml_text, attr, value)
        for value in list(condition.content_desc_contains_any or [])
        for attr in ("content-desc", "content_desc")
    ):
        pass
    elif list(condition.content_desc_contains_any or []):
        return False

    if any(
        _xml_attr_contains(xml_text, attr, value)
        for value in list(condition.resource_id_contains_any or [])
        for attr in ("resource-id", "resource_id", "resource-id-raw", "resource_id_raw")
    ):
        pass
    elif list(condition.resource_id_contains_any or []):
        return False
    return True


def _xml_attr_contains(xml_text: str, attr_name: str, needle: str) -> bool:
    target = str(needle or "").strip().lower()
    if not target:
        return False
    root = _parse_xml_safe(xml_text)
    if root is None:
        return False
    for elem in root.iter():
        value = read_xml_attr(elem.attrib, attr_name).strip().lower()
        if target in value:
            return True
    return False


def _resolve_action(template: TriggerActionTemplate, *, xml_text: str) -> Any | None:
    kind = str(template.kind or "").strip()
    if kind == "press_back":
        return make_press_back_action(description="trigger_press_back")
    if kind == "click_bounds":
        center = parse_bounds_center(str(template.bounds or "").strip())
        if center is not None:
            return ClickAction(
                type="click", params={"x": int(center[0]), "y": int(center[1])}
            )
        if template.fallback_kind == "press_back":
            return make_press_back_action(description="trigger_press_back_fallback")
        return None
    click_action = _resolve_click_template_action(
        kind, template.values, xml_text=xml_text
    )
    if click_action is not None:
        return click_action
    if template.fallback_kind == "press_back":
        return make_press_back_action(description="trigger_press_back_fallback")
    return None


def _resolve_click_template_action(
    kind: str,
    values: List[str],
    *,
    xml_text: str,
) -> ClickAction | None:
    candidates = [
        str(v or "").strip() for v in list(values or []) if str(v or "").strip()
    ]
    if not candidates:
        return None
    root = _parse_xml_safe(xml_text)
    if root is None:
        return None
    search_attrs = {
        "click_content_desc": ("content-desc", "content_desc"),
        "click_text": ("text",),
        "click_resource_id": (
            "resource-id",
            "resource_id",
            "resource-id-raw",
            "resource_id_raw",
        ),
    }.get(kind)
    if search_attrs is None:
        return None
    for candidate in candidates:
        lowered = candidate.lower()
        for elem in root.iter():
            attrs = elem.attrib
            matched = False
            for attr_name in search_attrs:
                value = read_xml_attr(attrs, attr_name).strip().lower()
                if lowered and lowered in value:
                    matched = True
                    break
            if not matched:
                continue
            center = parse_bounds_center(read_xml_attr(attrs, "bounds"))
            if center is None:
                continue
            return ClickAction(
                type="click",
                params={"x": int(center[0]), "y": int(center[1])},
            )
    return None


def _is_keyboard_visible_from_vector_set(vector_set) -> bool:
    """Check if keyboard is visible using PageVectorSet (optimized)."""
    if vector_set is None:
        return False

    for element in vector_set.elements:
        package_name = str(element.package or "").lower()
        resource_id = str(element.resource_id or "").lower()

        if "inputmethod" in package_name or resource_id.startswith(
            "android:id/input_method_"
        ):
            return True
    return False


def _is_keyboard_visible(xml_text: str) -> bool:
    """Deprecated: Use _is_keyboard_visible_from_vector_set instead."""
    if not xml_text:
        return False
    root = _parse_xml_safe(xml_text)
    if root is None:
        return False
    for elem in root.iter():
        attrs = elem.attrib
        package_name = str(attrs.get("package") or "").lower()
        resource_id = str(
            attrs.get("resource-id")
            or attrs.get("resource_id")
            or attrs.get("resource-id-raw")
            or ""
        ).lower()
        if "inputmethod" in package_name or resource_id.startswith(
            "android:id/input_method_"
        ):
            return True
    return False


def _debug_element_label(element: dict[str, Any]) -> str:
    for key in (
        "text",
        "hint-text",
        "hint_text",
        "content_desc",
        "content-desc",
        "resource_id",
        "resource-id",
        "resource-id-raw",
    ):
        label = str(element.get(key) or "").strip()
        if label:
            return label
    return ""


def _editable_target_mismatch(adaptation_debug: dict[str, Any]) -> bool:
    matcher_debug = adaptation_debug.get("matcher_debug")
    if not isinstance(matcher_debug, dict):
        return False
    src_element = matcher_debug.get("src_element")
    target_element = (matcher_debug.get("selected_match") or {}).get("element")
    if not isinstance(src_element, dict) or not isinstance(target_element, dict):
        return False
    if str(src_element.get("editable") or "").lower() != "true":
        return False
    src_class = str(src_element.get("class") or "").strip()
    target_class = str(target_element.get("class") or "").strip()
    if src_class and target_class and src_class != target_class:
        return False
    src_label = _debug_element_label(src_element)
    target_label = _debug_element_label(target_element)
    return bool(src_label and target_label and src_label != target_label)


def _is_focus_input_action(action: Any) -> bool:
    desc = str(getattr(action, "description", "") or "").strip().lower()
    return desc == "focus_input" or desc.startswith("focus_input:")


def _extract_open_app_expected_package(action: Any) -> str:
    params = getattr(action, "params", None)
    if isinstance(params, dict):
        return str(params.get("package_name") or "").strip()
    return str(getattr(params, "package_name", "") or "").strip()


def _inspect_scroll_retry_from_vector_set(
    *,
    vector_set,
    adaptation_debug: dict[str, Any],
) -> dict[str, Any]:
    """使用 PageVectorSet 检查是否需要滚动重试（优化版，~70 行）."""
    probe: dict[str, Any] = {"proposed": False, "decision": "insufficient_debug"}
    matcher_debug = adaptation_debug.get("matcher_debug")
    top3_candidates = adaptation_debug.get("top3_candidates")

    if (
        not isinstance(matcher_debug, dict)
        or not isinstance(top3_candidates, list)
        or not top3_candidates
    ):
        return probe

    if vector_set is None:
        probe["decision"] = "missing_vector_set"
        return probe

    # 提取候选位置
    candidate_rows = []
    for idx, item in enumerate(top3_candidates[:3]):
        element = item.get("element") if isinstance(item, dict) else None
        if not isinstance(element, dict):
            continue
        center = _extract_bounds_center(str(element.get("bounds") or ""))
        if center is None:
            continue
        candidate_rows.append((idx, center))

    if not candidate_rows:
        probe["decision"] = "top3_missing_bounds"
        return probe

    # 计算预测点
    vote_records = matcher_debug.get("vote_records") or []
    predicted_points = []
    for record in vote_records:
        point = (
            (record or {}).get("predicted_point") if isinstance(record, dict) else None
        )
        if not isinstance(point, dict):
            continue
        try:
            predicted_points.append((float(point.get("x")), float(point.get("y"))))
        except Exception:
            continue

    if not predicted_points:
        probe["decision"] = "missing_predicted_points"
        return probe

    predicted_y = sum(y for _, y in predicted_points) / len(predicted_points)
    selected_center = candidate_rows[0][1]

    # 使用 VectorSet 快速查找可滚动 viewport（10x 提升）
    viewport = _find_smallest_scrollable_viewport_from_vector_set(
        vector_set, selected_center[0], selected_center[1]
    )

    if viewport is None:
        # Fallback: 使用第一个有 bounds 的节点
        viewport = (
            vector_set.root_bounds
            if hasattr(vector_set, "root_bounds")
            else (0, 0, 1080, 1920)
        )

    _, viewport_top, _, viewport_bottom = viewport
    viewport_height = max(1.0, float(viewport_bottom - viewport_top))

    # 计算加权平均
    weighted_mean_y = 0.0
    total_weight = 0.0
    top1_y = float(candidate_rows[0][1][1])
    for idx, center in candidate_rows:
        weight = float(max(1, 3 - idx))
        weighted_mean_y += float(center[1]) * weight
        total_weight += weight

    if total_weight <= 0:
        probe["decision"] = "no_candidate_weight"
        return probe

    weighted_mean_y = weighted_mean_y / total_weight
    margin = max(48.0, viewport_height * 0.12)
    outer_margin = margin * 0.5

    probe.update(
        {
            "decision": "in_range",
            "predicted_y": float(predicted_y),
            "viewport_top": float(viewport_top),
            "viewport_bottom": float(viewport_bottom),
            "weighted_mean_y": float(weighted_mean_y),
            "top1_y": float(top1_y),
            "margin": float(margin),
            "selected_center_x": float(selected_center[0]),
            "selected_center_y": float(selected_center[1]),
        }
    )

    # 判断滚动方向
    if (
        predicted_y > (viewport_bottom + outer_margin)
        and (predicted_y - weighted_mean_y) > margin
        and (predicted_y - top1_y) > (margin * 0.5)
    ):
        probe.update(
            {
                "decision": "top3_out_of_projected_range",
                "proposed": True,
                "direction": "down",
                "distance": int(
                    min(
                        max(
                            predicted_y - ((viewport_top + viewport_bottom) / 2.0),
                            120.0,
                        ),
                        viewport_height * 0.85,
                    )
                ),
            }
        )
        return probe

    if (
        predicted_y < (viewport_top - outer_margin)
        and (weighted_mean_y - predicted_y) > margin
        and (top1_y - predicted_y) > (margin * 0.5)
    ):
        probe.update(
            {
                "decision": "top3_out_of_projected_range",
                "proposed": True,
                "direction": "up",
                "distance": int(
                    min(
                        max(
                            ((viewport_top + viewport_bottom) / 2.0) - predicted_y,
                            120.0,
                        ),
                        viewport_height * 0.85,
                    )
                ),
            }
        )
        return probe

    return probe


def _inspect_scroll_retry(
    *,
    current_xml: str,
    adaptation_debug: dict[str, Any],
) -> dict[str, Any]:
    probe: dict[str, Any] = {"proposed": False, "decision": "insufficient_debug"}
    matcher_debug = adaptation_debug.get("matcher_debug")
    top3_candidates = adaptation_debug.get("top3_candidates")
    if (
        not isinstance(matcher_debug, dict)
        or not isinstance(top3_candidates, list)
        or not top3_candidates
    ):
        return probe
    root = _parse_xml_safe(current_xml)
    if root is None:
        probe["decision"] = "invalid_xml"
        return probe
    candidate_rows = []
    for idx, item in enumerate(top3_candidates[:3]):
        element = item.get("element") if isinstance(item, dict) else None
        if not isinstance(element, dict):
            continue
        center = _extract_bounds_center(str(element.get("bounds") or ""))
        if center is None:
            continue
        candidate_rows.append((idx, center))
    if not candidate_rows:
        probe["decision"] = "top3_missing_bounds"
        return probe
    vote_records = matcher_debug.get("vote_records") or []
    predicted_points = []
    for record in vote_records:
        point = (
            (record or {}).get("predicted_point") if isinstance(record, dict) else None
        )
        if not isinstance(point, dict):
            continue
        try:
            predicted_points.append((float(point.get("x")), float(point.get("y"))))
        except Exception:
            continue
    if not predicted_points:
        probe["decision"] = "missing_predicted_points"
        return probe
    predicted_y = sum(y for _, y in predicted_points) / len(predicted_points)
    selected_center = candidate_rows[0][1]
    viewport = _find_smallest_scrollable_bounds_containing_point(
        current_xml, selected_center[0], selected_center[1]
    )
    if viewport is None:
        viewport = (0, 0, 0, 0)
        for elem in root.iter():
            bounds = parse_bounds(str(elem.attrib.get("bounds") or ""))
            if bounds is not None:
                viewport = bounds
                break
    _, viewport_top, _, viewport_bottom = viewport
    viewport_height = max(1.0, float(viewport_bottom - viewport_top))
    weighted_mean_y = 0.0
    total_weight = 0.0
    top1_y = float(candidate_rows[0][1][1])
    for idx, center in candidate_rows:
        weight = float(max(1, 3 - idx))
        weighted_mean_y += float(center[1]) * weight
        total_weight += weight
    if total_weight <= 0:
        probe["decision"] = "no_candidate_weight"
        return probe
    weighted_mean_y = weighted_mean_y / total_weight
    margin = max(48.0, viewport_height * 0.12)
    outer_margin = margin * 0.5
    probe.update(
        {
            "decision": "in_range",
            "predicted_y": float(predicted_y),
            "viewport_top": float(viewport_top),
            "viewport_bottom": float(viewport_bottom),
            "weighted_mean_y": float(weighted_mean_y),
            "top1_y": float(top1_y),
            "margin": float(margin),
            "selected_center_x": float(selected_center[0]),
            "selected_center_y": float(selected_center[1]),
        }
    )
    if (
        predicted_y > (viewport_bottom + outer_margin)
        and (predicted_y - weighted_mean_y) > margin
        and (predicted_y - top1_y) > (margin * 0.5)
    ):
        probe.update(
            {
                "decision": "top3_out_of_projected_range",
                "proposed": True,
                "direction": "down",
                "distance": int(
                    min(
                        max(
                            predicted_y - ((viewport_top + viewport_bottom) / 2.0),
                            120.0,
                        ),
                        viewport_height * 0.85,
                    )
                ),
            }
        )
        return probe
    if (
        predicted_y < (viewport_top - outer_margin)
        and (weighted_mean_y - predicted_y) > margin
        and (top1_y - predicted_y) > (margin * 0.5)
    ):
        probe.update(
            {
                "decision": "top3_out_of_projected_range",
                "proposed": True,
                "direction": "up",
                "distance": int(
                    min(
                        max(
                            ((viewport_top + viewport_bottom) / 2.0) - predicted_y,
                            120.0,
                        ),
                        viewport_height * 0.85,
                    )
                ),
            }
        )
        return probe
    return probe


def _extract_bounds_center(bounds_text: str) -> tuple[float, float] | None:
    """从 bounds 字符串提取中心点。"""
    bounds = parse_bounds(bounds_text)
    if bounds is None:
        return None
    x1, y1, x2, y2 = bounds
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def _find_smallest_scrollable_viewport_from_vector_set(
    vector_set,
    x: float,
    y: float,
) -> tuple[int, int, int, int] | None:
    """使用 PageVectorSet 快速查找包含指定点的最小可滚动区域 (优化版)."""
    if vector_set is None:
        return None

    SCROLLABLE_FLAG = 8  # scrollable = 1 << 3
    best_bounds = None
    best_area = None

    for element in vector_set.elements:
        # 快速位掩码检查（跳过不可滚动 element）
        if not (element.flags & SCROLLABLE_FLAG):
            continue

        bounds = element.bounds
        # 检查点是否在区域内
        if not (bounds[0] <= x <= bounds[2] and bounds[1] <= y <= bounds[3]):
            continue

        area = element.area
        if best_area is None or area < best_area:
            best_area = area
            best_bounds = bounds

    return best_bounds


def _find_smallest_scrollable_bounds_containing_point(
    xml_text: str,
    x: float,
    y: float,
) -> tuple[int, int, int, int] | None:
    """找到包含指定点的最小可滚动区域（已废弃，使用 vector_set 版本）."""
    root = _parse_xml_safe(xml_text)
    if root is None:
        return None
    best_bounds = None
    best_area = None
    for elem in root.iter():
        attrs = elem.attrib
        if str(attrs.get("scrollable") or "").lower() != "true":
            continue
        bounds = parse_bounds(str(attrs.get("bounds") or ""))
        if bounds is None:
            continue
        if not point_in_bounds(int(x), int(y), bounds):
            continue
        area = bounds_area(bounds)
        if best_area is None or area < best_area:
            best_area = area
            best_bounds = bounds
    return best_bounds
