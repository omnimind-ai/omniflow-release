"""Stable provider-catalog helpers, LLM clients, and chat adapters.

This module supports graceful degradation when LLM dependencies are not installed.
Core provider APIs work without openai/litellm; LLM-specific features raise ImportError.
"""

from abc import ABC, abstractmethod
import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# --- LLM availability flag ---
_LLM_AVAILABLE = False
try:
    import litellm  # noqa: F401
    import openai  # noqa: F401

    _LLM_AVAILABLE = True
except ImportError:
    logger.info(
        "LLM dependencies (openai/litellm) not installed, LLM features disabled"
    )


def is_llm_available() -> bool:
    """Check if LLM dependencies are available."""
    return _LLM_AVAILABLE


def require_llm() -> None:
    """Raise ImportError if LLM dependencies are not available."""
    if not _LLM_AVAILABLE:
        raise ImportError(
            "LLM features require 'openai' and 'litellm'. "
            "Install with: pip install omniflow[llm]"
        )


# --- Provider catalog (always available, no external deps) ---
from .provider_catalog import (
    MODEL_KIND_LLM,
    MODEL_KIND_VLM,
    default_base_url_for_provider,
    default_llm_model,
    default_model_for_provider,
    resolve_llm_provider,
    resolve_provider_alias,
)


# --- LLM client functions (lazy import) ---
def complete(*args, **kwargs):
    """Synchronous LLM completion."""
    require_llm()
    from .litellm_client import complete as _complete

    return _complete(*args, **kwargs)


def acomplete(*args, **kwargs):
    """Async LLM completion."""
    require_llm()
    from .litellm_client import acomplete as _acomplete

    return _acomplete(*args, **kwargs)


def acomplete_vision(*args, **kwargs):
    """Async vision LLM completion."""
    require_llm()
    from .litellm_client import acomplete_vision as _acomplete_vision

    return _acomplete_vision(*args, **kwargs)


def complete_json(*args, **kwargs):
    """Synchronous LLM completion with JSON output."""
    require_llm()
    from .litellm_client import complete_json as _complete_json

    return _complete_json(*args, **kwargs)


def acomplete_json(*args, **kwargs):
    """Async LLM completion with JSON output."""
    require_llm()
    from .litellm_client import acomplete_json as _acomplete_json

    return _acomplete_json(*args, **kwargs)


def extract_json(*args, **kwargs):
    """Extract JSON from LLM response."""
    require_llm()
    from .litellm_client import extract_json as _extract_json

    return _extract_json(*args, **kwargs)


def resolve_provider(*args, **kwargs):
    """Resolve LLM provider configuration."""
    require_llm()
    from .litellm_client import resolve_provider as _resolve_provider

    return _resolve_provider(*args, **kwargs)


def get_model_name(*args, **kwargs):
    """Get model name for provider."""
    require_llm()
    from .litellm_client import get_model_name as _get_model_name

    return _get_model_name(*args, **kwargs)


def get_api_config(*args, **kwargs):
    """Get API configuration."""
    require_llm()
    from .litellm_client import get_api_config as _get_api_config

    return _get_api_config(*args, **kwargs)


def llm_complete_with_timeout(*args, **kwargs):
    """LLM completion with timeout."""
    require_llm()
    from .completion import llm_complete_with_timeout as _llm_complete_with_timeout

    return _llm_complete_with_timeout(*args, **kwargs)


async def llm_complete_with_timeout_async(*args, **kwargs):
    """Async LLM completion with timeout."""
    require_llm()
    from .completion import (
        llm_complete_with_timeout_async as _llm_complete_with_timeout_async,
    )

    return await _llm_complete_with_timeout_async(*args, **kwargs)


# --- Chat adapters ---
class BaseLLMChat(ABC):
    """Minimal sync/async chat abstraction used by mutation helpers."""

    @abstractmethod
    def complete(self, prompt: str) -> str:
        """Synchronously return one plain-text completion for the given prompt."""

    async def acomplete(self, prompt: str) -> str:
        """Asynchronously return one plain-text completion for the given prompt."""
        return await asyncio.to_thread(self.complete, prompt)


class OpenAILLMChat(BaseLLMChat):
    """Minimal OpenAI-compatible chat adapter used by mutation/update helpers."""

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        trust_env: bool = True,
    ) -> None:
        require_llm()
        import httpx
        from openai import AsyncOpenAI, OpenAI

        from src.foundation.config import config

        self.model = model
        resolved_api_key = api_key or config.OPENAI_API_KEY.get_secret_value()
        resolved_base_url = base_url or config.OPENAI_BASE_URL
        if not resolved_api_key:
            raise ValueError(
                "OpenAI API Key must be provided or set in .env file as OPENAI_API_KEY"
            )
        if not resolved_base_url:
            raise ValueError(
                "OpenAI Base URL must be provided or set in .env file as OPENAI_BASE_URL"
            )
        self.client = AsyncOpenAI(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
            http_client=httpx.AsyncClient(trust_env=trust_env),
        )
        self.sync_client = OpenAI(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
            http_client=httpx.Client(trust_env=trust_env),
        )
        logger.debug(
            "OpenAILLMChat initialized with model=%s base_url=%s trust_env=%s",
            model,
            resolved_base_url,
            trust_env,
        )

    async def acomplete(self, prompt: str) -> str:
        """Run one OpenAI-compatible chat completion and return the text body."""
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],  # type: ignore[arg-type]
        )
        result = response.choices[0].message.content
        if result is None:
            raise RuntimeError("OpenAI LLM Chat error: response content is None")
        return result

    def complete(self, prompt: str) -> str:
        """Run one synchronous OpenAI-compatible chat completion."""
        response = self.sync_client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],  # type: ignore[arg-type]
        )
        result = response.choices[0].message.content
        if result is None:
            raise RuntimeError("OpenAI LLM Chat error: response content is None")
        return result


__all__ = [
    # Availability check
    "is_llm_available",
    "require_llm",
    # Chat adapters
    "BaseLLMChat",
    "OpenAILLMChat",
    # Provider catalog
    "MODEL_KIND_LLM",
    "MODEL_KIND_VLM",
    "default_base_url_for_provider",
    "default_llm_model",
    "default_model_for_provider",
    "resolve_llm_provider",
    "resolve_provider_alias",
    # LiteLLM client
    "complete",
    "acomplete",
    "acomplete_vision",
    "complete_json",
    "acomplete_json",
    "extract_json",
    "resolve_provider",
    "get_model_name",
    "get_api_config",
    # Completion utilities
    "llm_complete_with_timeout",
    "llm_complete_with_timeout_async",
]
