"""统一配置加载模块.

从 settings.yaml 加载配置，支持环境变量覆盖。

Usage:
    from src.foundation.settings import settings

    # 访问配置
    threshold = settings.compile.hit_threshold
    enabled = settings.execution.action_effect_enabled

环境变量覆盖格式: OMNIFLOW_<SECTION>_<KEY> (全大写，下划线分隔)
例如: OMNIFLOW_COMPILE_HIT_THRESHOLD=0.80
"""

from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Any, Optional

import yaml


def _env_override(section: str, key: str, default: Any) -> Any:
    """从环境变量获取覆盖值."""
    env_key = f"OMNIFLOW_{section.upper()}_{key.upper()}"
    env_val = os.environ.get(env_key)
    if env_val is None:
        return default

    # 类型转换
    if isinstance(default, bool):
        return env_val.lower() in ("true", "1", "yes", "on")
    if isinstance(default, int):
        try:
            return int(env_val)
        except ValueError:
            return default
    if isinstance(default, float):
        try:
            return float(env_val)
        except ValueError:
            return default
    if isinstance(default, list):
        return [s.strip() for s in env_val.split(",") if s.strip()]
    return env_val


def _get(data: dict, section: str, key: str, default: Any) -> Any:
    """从配置字典获取值，支持环境变量覆盖."""
    section_data = data.get(section, {}) or {}
    value = section_data.get(key, default)
    return _env_override(section, key, value)


@dataclass(frozen=True)
class CompileSettings:
    """编译配置."""

    hit_threshold: float = 0.95
    ambiguous_threshold: float = 0.60
    margin_threshold: float = 0.10
    page_match_threshold: float = 0.80
    locality_bonus: float = 0.10
    recency_bonus: float = 0.05
    candidate_limit: int = 5

    # Embedding 配置（通过外部 API 计算，本地存储）
    embedding_index_dir: str = "runtime/embedding_index"
    embedding_model: str = "text-embedding-v3"  # DashScope Qwen embedding 模型


@dataclass(frozen=True)
class ExecutionSettings:
    """执行配置."""

    # 动作效果检测
    action_effect_enabled: bool = True
    action_effect_types: tuple = ("click", "click_node", "long_press", "open_app")
    poll_timeout_s: float = 0.6
    max_polls: int = 12
    poll_yield_s: float = 0.0
    retry_attempts: int = 5
    retry_jitter_px: int = 0
    hard_fail_on_no_effect: bool = False
    settle_consecutive_observations: int = 2

    # 路径控制
    enable_click_prompt: bool = True
    enable_coordinate_adaptation: bool = True
    enable_keyboard_dismiss_re_adapt: bool = True
    enable_scroll_retry_re_adapt: bool = True
    enable_auto_press_back_after_type: bool = True
    post_action_wait_seconds: float = 1.0

    # open_app 前台验证
    open_app_foreground_timeout_s: float = 2.5
    open_app_foreground_poll_interval_s: float = 0.0
    open_app_foreground_required_hits: int = 2

    # 其他
    terminal_node_verify: bool = True
    print_actions: bool = False


@dataclass(frozen=True)
class TriggerSettings:
    """触发器配置."""

    enabled: bool = True
    pool_file: Optional[str] = None
    node_triggers_enabled: bool = True


@dataclass(frozen=True)
class LogSettings:
    """日志配置."""

    run_log_enabled: bool = True
    run_log_path: Optional[str] = None
    execution_trace_enabled: bool = False
    execution_trace_path: Optional[str] = None
    execution_trace_echo: bool = False


@dataclass(frozen=True)
class StorageSettings:
    """存储配置."""

    utg_store_path: Optional[str] = None
    vector_db_cache_enabled: bool = True


@dataclass(frozen=True)
class ApiSettings:
    """API 服务配置."""

    host: str = "127.0.0.1"
    port: int = 9417
    bridge_port: Optional[int] = None


@dataclass(frozen=True)
class AndroidWorldSettings:
    """AndroidWorld 配置."""

    run_dir: Optional[str] = None
    tasks: Optional[str] = None
    sqlite_backend: str = "auto"


@dataclass
class Settings:
    """统一配置入口."""

    compile: CompileSettings = field(default_factory=CompileSettings)
    execution: ExecutionSettings = field(default_factory=ExecutionSettings)
    trigger: TriggerSettings = field(default_factory=TriggerSettings)
    log: LogSettings = field(default_factory=LogSettings)
    storage: StorageSettings = field(default_factory=StorageSettings)
    api: ApiSettings = field(default_factory=ApiSettings)
    android_world: AndroidWorldSettings = field(default_factory=AndroidWorldSettings)

    _config_path: Optional[str] = None

    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "Settings":
        """加载配置文件.

        Args:
            config_path: 配置文件路径，默认使用 src/foundation/settings.yaml

        Returns:
            Settings 实例
        """
        if config_path is None:
            config_path = str(Path(__file__).parent / "settings.yaml")

        data: dict = {}
        if Path(config_path).exists():
            with open(config_path, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}

        return cls(
            compile=cls._load_compile(data),
            execution=cls._load_execution(data),
            trigger=cls._load_trigger(data),
            log=cls._load_log(data),
            storage=cls._load_storage(data),
            api=cls._load_api(data),
            android_world=cls._load_android_world(data),
            _config_path=config_path,
        )

    @staticmethod
    def _load_compile(data: dict) -> CompileSettings:
        return CompileSettings(
            hit_threshold=float(_get(data, "compile", "hit_threshold", 0.95)),
            ambiguous_threshold=float(
                _get(data, "compile", "ambiguous_threshold", 0.60)
            ),
            margin_threshold=float(_get(data, "compile", "margin_threshold", 0.10)),
            page_match_threshold=float(
                _get(data, "compile", "page_match_threshold", 0.80)
            ),
            locality_bonus=float(_get(data, "compile", "locality_bonus", 0.10)),
            recency_bonus=float(_get(data, "compile", "recency_bonus", 0.05)),
            candidate_limit=int(_get(data, "compile", "candidate_limit", 5)),
            embedding_index_dir=str(
                _get(data, "compile", "embedding_index_dir", "runtime/embedding_index")
            ),
            embedding_model=str(
                _get(data, "compile", "embedding_model", "text-embedding-v3")
            ),
        )

    @staticmethod
    def _load_execution(data: dict) -> ExecutionSettings:
        action_types = _get(
            data,
            "execution",
            "action_effect_types",
            ["click", "click_node", "long_press", "open_app"],
        )
        return ExecutionSettings(
            action_effect_enabled=bool(
                _get(data, "execution", "action_effect_enabled", True)
            ),
            action_effect_types=tuple(action_types)
            if isinstance(action_types, list)
            else action_types,
            poll_timeout_s=float(_get(data, "execution", "poll_timeout_s", 0.6)),
            max_polls=int(_get(data, "execution", "max_polls", 12)),
            poll_yield_s=float(_get(data, "execution", "poll_yield_s", 0.0)),
            retry_attempts=int(_get(data, "execution", "retry_attempts", 5)),
            retry_jitter_px=int(_get(data, "execution", "retry_jitter_px", 0)),
            hard_fail_on_no_effect=bool(
                _get(data, "execution", "hard_fail_on_no_effect", False)
            ),
            settle_consecutive_observations=int(
                _get(data, "execution", "settle_consecutive_observations", 2)
            ),
            enable_click_prompt=bool(
                _get(data, "execution", "enable_click_prompt", True)
            ),
            enable_coordinate_adaptation=bool(
                _get(data, "execution", "enable_coordinate_adaptation", True)
            ),
            enable_keyboard_dismiss_re_adapt=bool(
                _get(data, "execution", "enable_keyboard_dismiss_re_adapt", True)
            ),
            enable_scroll_retry_re_adapt=bool(
                _get(data, "execution", "enable_scroll_retry_re_adapt", True)
            ),
            enable_auto_press_back_after_type=bool(
                _get(data, "execution", "enable_auto_press_back_after_type", True)
            ),
            post_action_wait_seconds=float(
                _get(data, "execution", "post_action_wait_seconds", 1.0)
            ),
            open_app_foreground_timeout_s=float(
                _get(data, "execution", "open_app_foreground_timeout_s", 2.5)
            ),
            open_app_foreground_poll_interval_s=float(
                _get(data, "execution", "open_app_foreground_poll_interval_s", 0.0)
            ),
            open_app_foreground_required_hits=int(
                _get(data, "execution", "open_app_foreground_required_hits", 2)
            ),
            terminal_node_verify=bool(
                _get(data, "execution", "terminal_node_verify", True)
            ),
            print_actions=bool(_get(data, "execution", "print_actions", False)),
        )

    @staticmethod
    def _load_trigger(data: dict) -> TriggerSettings:
        return TriggerSettings(
            enabled=bool(_get(data, "trigger", "enabled", True)),
            pool_file=_get(data, "trigger", "pool_file", None),
            node_triggers_enabled=bool(
                _get(data, "trigger", "node_triggers_enabled", True)
            ),
        )

    @staticmethod
    def _load_log(data: dict) -> LogSettings:
        return LogSettings(
            run_log_enabled=bool(_get(data, "log", "run_log_enabled", True)),
            run_log_path=_get(data, "log", "run_log_path", None),
            execution_trace_enabled=bool(
                _get(data, "log", "execution_trace_enabled", False)
            ),
            execution_trace_path=_get(data, "log", "execution_trace_path", None),
            execution_trace_echo=bool(_get(data, "log", "execution_trace_echo", False)),
        )

    @staticmethod
    def _load_storage(data: dict) -> StorageSettings:
        return StorageSettings(
            utg_store_path=_get(data, "storage", "utg_store_path", None),
            vector_db_cache_enabled=bool(
                _get(data, "storage", "vector_db_cache_enabled", True)
            ),
        )

    @staticmethod
    def _load_api(data: dict) -> ApiSettings:
        return ApiSettings(
            host=str(_get(data, "api", "host", "127.0.0.1")),
            port=int(_get(data, "api", "port", 9417)),
            bridge_port=_get(data, "api", "bridge_port", None),
        )

    @staticmethod
    def _load_android_world(data: dict) -> AndroidWorldSettings:
        return AndroidWorldSettings(
            run_dir=_get(data, "android_world", "run_dir", None),
            tasks=_get(data, "android_world", "tasks", None),
            sqlite_backend=str(_get(data, "android_world", "sqlite_backend", "auto")),
        )


# 全局单例
settings = Settings.load()


def reload_settings(config_path: Optional[str] = None) -> Settings:
    """重新加载配置."""
    global settings
    settings = Settings.load(config_path)
    return settings


__all__ = [
    "Settings",
    "CompileSettings",
    "ExecutionSettings",
    "TriggerSettings",
    "LogSettings",
    "StorageSettings",
    "ApiSettings",
    "AndroidWorldSettings",
    "settings",
    "reload_settings",
]
