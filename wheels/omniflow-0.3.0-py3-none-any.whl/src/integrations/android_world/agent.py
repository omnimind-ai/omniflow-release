"""
AndroidWorld 集成 - 简化版

使用 OmniFlow 作为核心，AndroidWorldHost 只负责设备交互。
"""

from __future__ import annotations

import asyncio
import base64
import logging
import threading
from types import SimpleNamespace
from typing import Any, Dict, Optional
import uuid

from src.foundation.paths import get_raw_run_assets_dir
from src.integrations.android_world.host import (
    android_world_action_to_utg_action,
    capture_current_page,
    capture_xml,
    coerce_android_world_action_for_execution,
    import_json_action_module,
    page_pixels_to_image_data_url,
    ui_elements_to_jsonable,
    utg_action_to_android_world_action,
)
from src.integrations.utg_api import _canonical_run_log_path
from src.omniflow import Action, ActionResult, Observation, OmniFlow
from src.utg.core.actions import parse_action_payload

logger = logging.getLogger(__name__)

# 模式常量
MODE_UTG_ONLY = "utg_only"

# 默认值
DEFAULT_RUN_MAX_STEPS = 8


def _run_coro_sync(coro_factory: Any) -> Any:
    """Run coroutine from sync context with event-loop safety.

    Args:
        coro_factory: Zero-arg callable that returns a coroutine object.
            Factory form avoids creating the coroutine on the wrong thread.

    Returns:
        Result returned by the coroutine.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro_factory())

    result_box: dict[str, Any] = {}
    error_box: dict[str, BaseException] = {}

    def _runner() -> None:
        try:
            result_box["value"] = asyncio.run(coro_factory())
        except BaseException as exc:  # noqa: BLE001
            error_box["error"] = exc

    worker = threading.Thread(
        target=_runner,
        name="androidworld-sync-bridge",
        daemon=True,
    )
    worker.start()
    worker.join()
    if "error" in error_box:
        raise error_box["error"]
    return result_box.get("value")


def _save_raw_asset(
    run_id: str,
    step_index: int,
    asset_type: str,
    content: str | bytes | None,
    suffix: str = ".xml",
) -> str | None:
    """Save raw asset to local storage and return the relative path.

    Args:
        run_id: The run identifier
        step_index: Step index within the run
        asset_type: Asset type identifier (e.g., 'before', 'after')
        content: Raw content to save (XML string or image bytes/base64)
        suffix: File extension

    Returns:
        Relative path from runtime root, or None if content is empty
    """
    if not content:
        return None

    try:
        assets_dir = get_raw_run_assets_dir(run_id)
        filename = f"step_{step_index}_{asset_type}{suffix}"
        filepath = assets_dir / filename

        if isinstance(content, bytes):
            filepath.write_bytes(content)
        elif suffix in (".png", ".jpg", ".jpeg") and isinstance(content, str):
            # Handle base64-encoded image data
            if content.startswith("data:image/"):
                # Extract base64 portion after comma
                parts = content.split(",", 1)
                if len(parts) == 2:
                    content = parts[1]
            try:
                image_bytes = base64.b64decode(content)
                filepath.write_bytes(image_bytes)
            except Exception:
                return None
        else:
            filepath.write_text(content, encoding="utf-8")

        # Return path relative to runtime root
        from src.foundation.paths import get_runtime_root

        return str(filepath.relative_to(get_runtime_root()))
    except Exception as e:
        logger.warning(f"Failed to save raw asset: {e}")
        return None


class AndroidWorldHost:
    """
    AndroidWorld Host 实现

    只负责设备交互:
    - observe(): 获取设备状态
    - act(): 执行动作
    """

    def __init__(
        self,
        env: Any,
        *,
        adb_serial: str = "",
        wait_after_action_seconds: float = 0.0,
    ):
        """
        Args:
            env: AndroidWorld 环境
            adb_serial: ADB 设备序列号
            wait_after_action_seconds: 动作后等待时间
        """
        self.env = env
        self._adb_serial = adb_serial
        self._wait_after_action_seconds = max(0.0, float(wait_after_action_seconds))
        self._last_android_world_action: Any = None

    async def observe(
        self,
        *,
        xml: bool = True,
        screenshot: bool = False,
        app_info: bool = True,
        **_: Any,
    ) -> Observation:
        """获取设备当前状态"""
        page = capture_current_page(env=self.env, adb_serial=self._adb_serial)

        xml_text = capture_xml(env=self.env, page=page) if xml else None
        image_base64 = page_pixels_to_image_data_url(page) if screenshot else None

        package_name = None
        activity_name = None
        if app_info:
            package_name = str(getattr(page, "package_name", "") or "").strip() or None
            activity_name = (
                str(getattr(page, "activity_name", "") or "").strip() or None
            )

        return Observation(
            xml=xml_text,  # 保留 xml 字段（兼容）
            package_name=package_name,
            activity_name=activity_name,
            image_base64=image_base64,
            ui_elements=list(getattr(page, "ui_elements", []) or []),
            raw_state=page,
        )

    async def act(self, action: Action | Dict[str, Any], **_: Any) -> ActionResult:
        """执行动作到设备"""
        # 转换 Action 为 dict，再解析为 UTG action model
        if isinstance(action, Action):
            action_dict = action.to_dict()
        else:
            action_dict = dict(action)
        parsed_action = parse_action_payload(action_dict)

        # 转换为 AndroidWorld 格式
        json_action_module = import_json_action_module()
        try:
            aw_action = utg_action_to_android_world_action(
                parsed_action,
                json_action_module=json_action_module,
            )
            aw_action = coerce_android_world_action_for_execution(
                aw_action,
                json_action_module=json_action_module,
            )
        except Exception as e:
            logger.warning(f"Action conversion failed: {e}")
            return ActionResult(success=False, error=str(e))

        if aw_action is None:
            return ActionResult(success=True)

        # 执行动作
        try:
            self._last_android_world_action = aw_action
            result = self.env.execute_action(aw_action)
            if asyncio.iscoroutine(result):
                await result

            if self._wait_after_action_seconds > 0:
                await asyncio.sleep(self._wait_after_action_seconds)

            return ActionResult(success=True)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    def reset(self, go_home: bool = False) -> None:
        """重置环境"""
        if hasattr(self.env, "reset"):
            self.env.reset(go_home=go_home)


def build_agent(
    *,
    env: Any,
    utg_store_path: Optional[str] = None,
    runtime: Optional[Any] = None,
    max_steps: int = DEFAULT_RUN_MAX_STEPS,
    adb_serial: str = "",
    wait_after_action_seconds: float = 0.0,
) -> OmniFlow:
    """
    构建 AndroidWorld Agent

    Args:
        env: AndroidWorld 环境 (必须)
        utg_store_path: UTG 存储路径
        runtime: 可选运行时注入；若提供，会覆盖 OmniFlow 默认创建的 runtime。
        max_steps: 最大步数
        adb_serial: ADB 设备序列号
        wait_after_action_seconds: 动作后等待时间

    Returns:
        AndroidWorld suite 可直接调用的 OmniFlow 实例。
    """
    if env is None:
        raise TypeError("build_agent requires env parameter")

    # 创建 Host
    host = AndroidWorldHost(
        env=env,
        adb_serial=adb_serial,
        wait_after_action_seconds=wait_after_action_seconds,
    )

    # 创建 OmniFlow（启用 runlog）
    omniflow = OmniFlow(
        utg_path=utg_store_path,
        host=host,
        runtime=runtime,
        max_steps=max_steps,
        enable_runlog=True,
        runlog_path=_canonical_run_log_path(),
    )

    # 设置模式属性 (兼容性)
    omniflow.mode = MODE_UTG_ONLY
    omniflow.name = MODE_UTG_ONLY
    omniflow.env = env
    omniflow.transition_pause = None
    omniflow._collected_steps = []
    omniflow._run_started_at = None
    omniflow._last_goal = None
    omniflow._current_run_id = None

    original_step = omniflow.step

    def _wrap_compile_step(
        step_result: Any,
        *,
        before_observation: Any = None,
        after_observation: Any = None,
        recorded_actions: list[Any] | None = None,
    ) -> Any:
        recorded_actions = list(recorded_actions or [])
        raw_actions: list[Any] = []
        for raw_action in recorded_actions:
            normalized_action = raw_action
            as_dict = getattr(normalized_action, "as_dict", None)
            if callable(as_dict):
                try:
                    normalized_action = as_dict()
                except Exception:  # noqa: BLE001
                    pass
            raw_actions.append(normalized_action)

        compile_miss = bool(getattr(step_result, "fallback", False))
        compile_hit = bool(getattr(step_result, "source", "") == "cache") and bool(
            getattr(step_result, "done", False)
        )
        route_kind = "miss" if compile_miss else "hit"
        execution_route = "vlm" if compile_miss else "utg"
        hook_required = compile_miss
        step_summary = getattr(step_result, "error", None)
        if not step_summary:
            if compile_miss:
                step_summary = (
                    "OmniFlow compile miss; external fallback handoff required."
                )
            elif compile_hit:
                step_summary = "OmniFlow compile hit; cached function executed."
            else:
                step_summary = "OmniFlow step finished without a cache handoff."

        step_data = {
            "summary": step_summary,
            "kind": route_kind,
            "compile_hit": compile_hit,
            "execution_route": execution_route,
            "hook_required": hook_required,
            "fallback_allowed": hook_required,
            "action_output_json": raw_actions,
            "before_ui_elements": list(
                getattr(before_observation, "ui_elements", []) or []
            ),
            "after_ui_elements": list(
                getattr(after_observation, "ui_elements", []) or []
            ),
            "raw_screenshot": getattr(
                getattr(before_observation, "raw_state", None), "pixels", None
            ),
            "ui_elements": list(getattr(before_observation, "ui_elements", []) or []),
        }

        before_xml = (
            capture_xml(env=env, page=before_observation)
            if before_observation is not None
            else None
        )
        after_xml = (
            capture_xml(env=env, page=after_observation)
            if after_observation is not None
            else None
        )
        executed_actions = [
            android_world_action_to_utg_action(
                action,
                ui_elements=list(getattr(before_observation, "ui_elements", []) or []),
            )
            for action in raw_actions
        ]
        step_index = len(omniflow._collected_steps)
        run_id = (
            getattr(omniflow, "_current_run_id", None) or f"run_{uuid.uuid4().hex[:12]}"
        )
        before_image = (
            page_pixels_to_image_data_url(
                getattr(before_observation, "raw_state", None)
            )
            if before_observation is not None
            else None
        )
        before_xml_path = _save_raw_asset(
            run_id, step_index, "before", before_xml, suffix=".xml"
        )
        before_screenshot_path = _save_raw_asset(
            run_id, step_index, "before", before_image, suffix=".png"
        )
        after_xml_path = _save_raw_asset(
            run_id, step_index, "after", after_xml, suffix=".xml"
        )
        omniflow._collected_steps.append(
            {
                "step_index": step_index,
                "source": MODE_UTG_ONLY,
                "observation_before_act": {
                    "xml_path": before_xml_path,
                    "screenshot_path": before_screenshot_path,
                    "xml": before_xml,
                    "image_base64": before_image,
                    "package_name": (
                        str(
                            getattr(before_observation, "package_name", "") or ""
                        ).strip()
                        or None
                    ),
                    "activity_name": (
                        str(
                            getattr(before_observation, "activity_name", "") or ""
                        ).strip()
                        or None
                    ),
                },
                "plan": {
                    "tool_name": "run_action",
                    "tool_args": {"actions": executed_actions},
                    "decision": "hit" if compile_hit else "miss",
                    "function_id": None,
                    "action_description": str(step_data.get("summary") or "").strip(),
                    "kind": route_kind,
                    "execution_route": execution_route,
                },
                "executed_actions": executed_actions,
                "act_result": {
                    "success": bool(getattr(step_result, "done", False))
                    or bool(raw_actions),
                    "error_message": getattr(step_result, "error", None),
                },
                "selection_source": "cache"
                if str(getattr(step_result, "source", "") or "cache") == "cache"
                else str(getattr(step_result, "source", "") or "fallback"),
                "execution_source": MODE_UTG_ONLY,
                "provider_detail": {
                    "executed_actions": executed_actions,
                    "before_ui_elements": ui_elements_to_jsonable(
                        list(getattr(before_observation, "ui_elements", []) or [])
                    ),
                    "after_ui_elements": ui_elements_to_jsonable(
                        list(getattr(after_observation, "ui_elements", []) or [])
                    ),
                    "final_observation": {
                        "xml_path": after_xml_path,
                        "xml": after_xml,
                        "package_name": (
                            str(
                                getattr(after_observation, "package_name", "") or ""
                            ).strip()
                            or None
                        ),
                        "activity_name": (
                            str(
                                getattr(after_observation, "activity_name", "") or ""
                            ).strip()
                            or None
                        ),
                    },
                    "kind": route_kind,
                    "compile_hit": compile_hit,
                    "execution_route": execution_route,
                    "hook_required": hook_required,
                    "compile_summary": str(step_data.get("summary") or "").strip(),
                },
                "_asset_paths": {
                    "run_id": run_id,
                    "before_xml_path": before_xml_path,
                    "before_screenshot_path": before_screenshot_path,
                    "after_xml_path": after_xml_path,
                },
            }
        )
        return SimpleNamespace(
            **vars(step_result),
            data=step_data,
            kind=route_kind,
            compile_hit=compile_hit,
            execution_route=execution_route,
            hook_required=hook_required,
            fallback_allowed=hook_required,
        )

    def _androidworld_reset(go_home: bool = False) -> None:
        # 清空收集的 steps，准备新任务
        omniflow._collected_steps = []
        omniflow._run_started_at = None
        omniflow._last_goal = None
        # Generate a new run_id for asset storage
        omniflow._current_run_id = f"run_{uuid.uuid4().hex[:12]}"
        host.reset(go_home=bool(go_home))

    def _androidworld_set_max_steps(step_budget: int) -> None:
        omniflow.max_steps = max(1, int(step_budget))

    def _androidworld_step(goal: str):
        # 记录 goal (用于 run_log)
        if not omniflow._last_goal:
            omniflow._last_goal = goal
            from datetime import datetime, timezone

            omniflow._run_started_at = datetime.now(timezone.utc).isoformat()
            # Initialize run_id if not already set (e.g., if reset wasn't called)
            if not getattr(omniflow, "_current_run_id", None):
                omniflow._current_run_id = f"run_{uuid.uuid4().hex[:12]}"

        host._last_android_world_action = None
        before_observation = None
        after_observation = None
        try:
            before_observation = _run_coro_sync(
                lambda: host.observe(xml=False, app_info=True)
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("AndroidWorld pre-step observe failed: %s", exc)
        recorded_actions: list[Any] = []
        original_execute_action = getattr(env, "execute_action", None)

        def _recording_execute_action(raw_action: Any) -> Any:
            host._last_android_world_action = raw_action
            recorded_actions.append(raw_action)
            if callable(original_execute_action):
                return original_execute_action(raw_action)
            return None

        if callable(original_execute_action):
            env.execute_action = _recording_execute_action
        try:
            step_result = original_step(goal)
        finally:
            if (
                callable(original_execute_action)
                and getattr(env, "execute_action", None) is _recording_execute_action
            ):
                env.execute_action = original_execute_action
        if recorded_actions:
            try:
                after_observation = _run_coro_sync(
                    lambda: host.observe(xml=False, app_info=True)
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("AndroidWorld post-step observe failed: %s", exc)
        return _wrap_compile_step(
            step_result,
            before_observation=before_observation,
            after_observation=after_observation,
            recorded_actions=recorded_actions,
        )

    def _save_run_log(
        success: bool = False,
        done_reason: str = "",
        auto_import: bool = True,
    ) -> dict | None:
        """保存收集的 run_log 到统一日志流，并可选自动导入为 UTG Function

        Args:
            success: 任务是否成功
            done_reason: 完成原因
            auto_import: 是否自动导入为 UTG Function（默认 True）

        Returns:
            保存的 run_log 或 None
        """
        if not omniflow._collected_steps:
            return None

        from datetime import datetime, timezone

        from src.integrations.utg_api import import_run_log, ingest_run_log

        # Use the pre-generated run_id for consistency with saved assets
        run_id = (
            getattr(omniflow, "_current_run_id", None)
            or f"oob_{id(omniflow)}_{len(omniflow._collected_steps)}"
        )
        run_log = {
            "run_id": run_id,
            "goal": omniflow._last_goal or "",
            "success": success,
            "done_reason": done_reason or ("completed" if success else "unknown"),
            "source": "omniflow",
            "started_at": omniflow._run_started_at,
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "step_count": len(omniflow._collected_steps),
            "steps": list(omniflow._collected_steps),
        }

        async def _do_write():
            return await ingest_run_log(
                omniflow.runtime,
                run_log=run_log,
                auto_import=False,
            )

        try:
            try:
                asyncio.get_running_loop()
                asyncio.ensure_future(_do_write())
                logger.info(f"Scheduled run_log writeback: {run_log['run_id']}")
            except RuntimeError:
                result = _run_coro_sync(_do_write)
                if result.get("success"):
                    logger.info(
                        f"Saved run_log: {result['run_id']} with {run_log['step_count']} steps"
                    )
                    run_log["run_id"] = result["run_id"]
                else:
                    logger.warning(f"Failed to save run_log: {result}")
                    return run_log
        except Exception as exc:
            logger.warning(f"Failed to save run_log: {exc}")
            return run_log

        # 自动导入为 UTG Function
        if auto_import and success and omniflow.runtime is not None:
            try:

                async def _do_import():
                    return await import_run_log(
                        omniflow.runtime, run_id=run_log["run_id"]
                    )

                try:
                    asyncio.get_running_loop()
                    asyncio.ensure_future(_do_import())
                    logger.info(
                        f"Scheduled auto-import for run_log: {run_log['run_id']}"
                    )
                except RuntimeError:
                    import_result = _run_coro_sync(_do_import)
                    if import_result.get("success"):
                        imported_function_id = str(
                            import_result.get("function_id") or ""
                        ).strip()
                        logger.info(
                            f"Auto-imported run_log as UTG Function: "
                            f"{imported_function_id}"
                        )
                    else:
                        logger.warning(
                            f"Failed to auto-import run_log: "
                            f"{import_result.get('error_message')}"
                        )
            except Exception as exc:
                logger.warning(f"Failed to auto-import run_log: {exc}")

        return run_log

    omniflow.reset = _androidworld_reset
    omniflow.set_max_steps = _androidworld_set_max_steps
    omniflow.step = _androidworld_step
    omniflow.save_run_log = _save_run_log

    return omniflow


__all__ = [
    "MODE_UTG_ONLY",
    "AndroidWorldHost",
    "build_agent",
]
