from __future__ import annotations

import os
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from src.utg.execution.compile import CompileContext

_DEFAULT_BRIDGE_PORT = int(os.getenv("OOB_UTG_BRIDGE_PORT", "8899"))
_DEFAULT_BRIDGE_BASE_URL = os.getenv(
    "OOB_UTG_BRIDGE_URL", f"http://127.0.0.1:{_DEFAULT_BRIDGE_PORT}/utg"
)
_DEFAULT_BRIDGE_TOKEN = os.getenv("OOB_UTG_BRIDGE_TOKEN", "")


def _normalize_api_language_value(value: str | None) -> str | None:
    """Normalize one API language token into the provider's supported set.

    Args:
        value: Raw `lang` query value or one item extracted from
            `Accept-Language`.

    Returns:
        `"zh"` or `"en"` when the token maps to one supported provider
        language, otherwise `None`.
    """

    normalized = str(value or "").strip().lower().replace("_", "-")
    if not normalized:
        return None
    if normalized.startswith("zh"):
        return "zh"
    if normalized.startswith("en"):
        return "en"
    return None


def resolve_api_language(
    *, lang: str | None = None, accept_language: str | None = None
) -> str:
    """Resolve the provider response language for user-visible copy.

    Args:
        lang: Optional explicit query parameter supplied by the caller.
        accept_language: Optional raw `Accept-Language` header value.

    Returns:
        Stable provider language code. The provider currently supports only
        `"zh"` and `"en"`, and defaults to `"zh"` to preserve existing API
        behavior.
    """

    normalized_lang = _normalize_api_language_value(lang)
    if normalized_lang is not None:
        return normalized_lang
    for item in str(accept_language or "").split(","):
        candidate = item.split(";", 1)[0]
        normalized_candidate = _normalize_api_language_value(candidate)
        if normalized_candidate is not None:
            return normalized_candidate
    return "zh"


class CompileRequest(BaseModel):
    """Public compile request accepted by the local OmniFlow provider service.

    Args:
        goal: Natural-language goal that should compile to one UTG function.
        context: Optional minimal compile context used by recall/judging.
        match_scope: Optional function id or function id list that restricts compile.
    """

    goal: str
    context: "CompileContextPayload | None" = None
    match_scope: str | list[str] | None = None


class DecomposeGoalRequest(BaseModel):
    """Public goal-decompose request accepted by the provider service.

    Args:
        goal: Natural-language goal that should be split into ordered key
            functions for manual inspection on the compile page.
        llm_provider: Optional provider override for the decompose LLM.
        llm_model: Optional model override for the decompose LLM.
        max_key_functions: Maximum number of ordered key functions that the
            LLM may return for one goal.
    """

    goal: str
    llm_provider: str | None = None
    llm_model: str | None = None
    max_key_functions: int = Field(default=5, ge=2, le=8)


class CompileContextPayload(BaseModel):
    """Explicit public compile context accepted by the provider service.

    Args:
        current_node_id: Current UTG node id from host/provider.
        current_package: Current foreground package name used by compile locality.
        recent_function_ids: Recent function ids kept only as compile hints.
    """

    current_node_id: str | None = None
    current_package: str | None = None
    recent_function_ids: list[str] = Field(default_factory=list)

    def to_compile_context(self) -> CompileContext:
        """Convert the public payload into the internal compile context object."""

        return CompileContext(
            current_node_id=str(self.current_node_id or "").strip() or None,
            current_package=str(self.current_package or "").strip() or None,
            recent_function_ids=[
                str(item or "").strip()
                for item in list(self.recent_function_ids or [])
                if str(item or "").strip()
            ],
        )


class XmlSearchRequest(BaseModel):
    """Request model for UTG XML similarity search.

    Args:
        xml: Source page XML pasted from the device or host capture.
        top_k: Maximum number of similar UTG nodes returned to the desktop page.
        threshold: Optional minimum similarity score; when omitted the API uses
            the route's built-in default cutoff.
    """

    xml: str
    top_k: int = 10
    threshold: float | None = None


class XmlCompareRequest(BaseModel):
    """Request model for source-vs-target XML comparison.

    Args:
        source_xml: Source page XML that the user wants to align against UTG.
        target_node_id: Stable UTG candidate node id chosen from the similarity results.
        target_xml: Optional manual target XML pasted directly in the desktop page.
            Exactly one of `target_node_id` or `target_xml` should be provided.
    """

    source_xml: str
    target_node_id: str = ""
    target_xml: str = ""


class XmlMapCoordinatesRequest(BaseModel):
    """Request model for coordinate transfer across similar XML pages.

    Args:
        source_xml: Source page XML that produced the original click point.
        target_node_id: Stable UTG candidate node id used as the mapping destination.
        target_xml: Optional manual target XML pasted directly in the desktop page.
            Exactly one of `target_node_id` or `target_xml` should be provided.
        x: Source coordinate x in raw screen pixels from the pasted page.
        y: Source coordinate y in raw screen pixels from the pasted page.
    """

    source_xml: str
    target_node_id: str = ""
    target_xml: str = ""
    x: int
    y: int


class RetryContext(BaseModel):
    """Context for resuming a failed execution.

    Args:
        run_id: The original run_id to continue.
        resume_from_step: Step index to resume from.
        function_id: Function that was being executed.
    """

    run_id: str
    resume_from_step: int = 0
    function_id: str = ""


class ExecuteFunctionRequest(BaseModel):
    """Public function execution request accepted by the provider service.

    Args:
        goal: Original natural-language goal for trace/debug context.
        function_id: Function id to execute.
        arguments: Optional parameter values rendered into the function.
        bridge_base_url: OOB bridge URL. Defaults to env OOB_UTG_BRIDGE_URL
            or http://127.0.0.1:8899/utg.
        bridge_token: OOB bridge token. Defaults to env OOB_UTG_BRIDGE_TOKEN.
        context: Optional extra runtime context merged into the UTG run context.
        skip_terminal_verify: Whether to skip terminal state verification.
        stream: If true, return SSE stream of execution events instead of final result.
        retry_context: If provided, resume execution from a previous failed run.
    """

    goal: str
    function_id: str = ""
    arguments: dict[str, str] = Field(default_factory=dict)
    bridge_base_url: str = _DEFAULT_BRIDGE_BASE_URL
    bridge_token: str = _DEFAULT_BRIDGE_TOKEN
    context: dict[str, Any] = Field(default_factory=dict)
    skip_terminal_verify: bool = False
    stream: bool = False
    retry_context: RetryContext | None = None


class VlmPreHookRequest(BaseModel):
    """Public VLM pre-hook request accepted by the provider service.

    Args:
        goal: Natural-language goal for the upcoming VLM task.
        current_package_name: Optional current foreground package passed in by host.
        fallback_allowed: Whether compile/pre-hook failures may fall back to VLM.
    """

    goal: str
    current_package_name: str | None = None
    fallback_allowed: bool = True


class DownloadCloudFunctionRequest(BaseModel):
    """Pull one function bundle from another provider and merge it locally.

    Args:
        cloud_base_url: Remote provider root exposing `/functions` and
            `/functions/{function_id}/bundle`.
        function_id: Optional function id that should be downloaded into the local
            provider. Leave empty to download all remote functions.
    """

    cloud_base_url: str
    function_id: str = ""


class ImportFunctionBundleRequest(BaseModel):
    """Import one serialized function bundle into the current local provider store.

    Args:
        graph: Minimal UTG graph payload produced by
            `export_function_bundle(...)`.
    """

    graph: dict[str, Any]


class UploadCloudFunctionRequest(BaseModel):
    """Push one local function bundle to another provider.

    Args:
        cloud_base_url: Remote provider root exposing
            `/functions/import_bundle`.
        function_id: Local function id that should be uploaded to the remote provider.
    """

    cloud_base_url: str
    function_id: str = ""


class ImportRunLogRequest(BaseModel):
    """Persist one canonical agent run log as local UTG assets.

    支持语义去重：相同语义的 goal 会映射到同一个 function。

    Args:
        run_id: Canonical run identifier from `runtime/logs/run_logs.jsonl`.
        auto_enrich: 是否自动 enrich goal（LLM 规范化），默认 True。
        dedup_threshold: 语义去重阈值，默认 0.95。
            高于此值的相似 goal 会被认为是同一个 function。
    """

    run_id: str
    auto_enrich: bool = True
    dedup_threshold: float = Field(default=0.95, ge=0.5, le=1.0)


class ReplayRunLogRequest(BaseModel):
    """Replay one canonical run log through the provider-owned execution path.

    Args:
        run_id: Canonical run identifier from `runtime/logs/run_logs.jsonl`.
        bridge_base_url: Host bridge root exposing `/utg/observe|act|confirm`.
        bridge_token: Bearer token required by the host bridge.
        context: Optional runtime context merged into replay execution.
        skip_terminal_verify: Whether replay uses "function finished" semantics.
    """

    run_id: str
    bridge_base_url: str
    bridge_token: str
    context: dict[str, Any] = Field(default_factory=dict)
    skip_terminal_verify: bool = False


class MergeFunctionsPreviewRequest(BaseModel):
    """Preview one new UTG function built from selected key functions.

    Args:
        function_ids: Existing function ids explicitly selected as key functions
            in the desktop editor.
        merge_mode: `compose` keeps selected key functions as the primary
            sequence and auto-fills node-to-node gaps with shortest-path bridge
            functions; `aggregate` does deterministic same-skeleton parameter
            promotion only.
        output_function_id: Optional explicit id for the previewed merged function.
        description: Optional human-readable description override.
        function_order: Optional explicit order used only by `compose`.
    """

    function_ids: list[str]
    merge_mode: str = "compose"
    output_function_id: str | None = None
    description: str | None = None
    function_order: list[str] = Field(default_factory=list)
    model_config = ConfigDict(extra="forbid")


class MergeFunctionsSaveRequest(BaseModel):
    """Persist one new UTG function assembled from selected key functions.

    Args:
        function_ids: Existing function ids explicitly selected as key functions
            in the desktop editor.
        merge_mode: `compose` or `aggregate`. `compose` keeps the selected key
            functions as the primary sequence and automatically inserts
            shortest-path bridge functions between adjacent gaps.
        output_function_id: Optional explicit id for the saved merged function.
        description: Optional human-readable description override.
        function_order: Optional explicit order used only by `compose`.
    """

    function_ids: list[str]
    merge_mode: str = "compose"
    output_function_id: str | None = None
    description: str | None = None
    function_order: list[str] = Field(default_factory=list)
    model_config = ConfigDict(extra="forbid")


class SharedPageImportRequest(BaseModel):
    """Import one privacy-safe shared page into the provider-side vector store.

    Args:
        page_id: Optional stable shared page identifier. When omitted, the
            provider derives it from the vector payload metadata or fingerprint.
        vector_set: Optional pre-vectorized `PageVectorSet` payload.
        xml: Optional raw XML that will be converted into `PageVectorSet`
            before persistence. The provider stores only the vectorized form.
        package_name: Optional app package override used when importing from XML.
        source_device: Optional source device label for audit/debug only.
        created_at: Optional caller-supplied timestamp string.
        overwrite: Whether an existing page with the same id may be replaced.
    """

    page_id: str | None = None
    vector_set: dict[str, Any] | None = None
    xml: str = ""
    package_name: str = ""
    source_device: str = ""
    created_at: str = ""
    overwrite: bool = False
    model_config = ConfigDict(extra="forbid")


class SharedPageSearchRequest(BaseModel):
    """Search similar pages inside the provider-side shared vector store.

    Args:
        page_id: Optional existing shared page id used as the query page.
        vector_set: Optional ad-hoc `PageVectorSet` query payload.
        xml: Optional raw XML query page. The provider converts it into a
            vectorized query page without persisting the raw XML.
        package_name: Optional package filter applied to stored shared pages.
        top_k: Maximum number of matches returned.
        threshold: Optional minimum cosine similarity threshold.
    """

    page_id: str = ""
    vector_set: dict[str, Any] | None = None
    xml: str = ""
    package_name: str = ""
    top_k: int = 5
    threshold: float | None = None
    model_config = ConfigDict(extra="forbid")


class SharedPageMapCoordinatesRequest(BaseModel):
    """Map one coordinate from a source page into a target shared page.

    Args:
        source_page_id: Optional stored shared page id used as source.
        source_vector_set: Optional ad-hoc source `PageVectorSet` payload.
        source_xml: Optional source XML used only to derive the source vector set.
        target_page_id: Optional stored shared page id used as target.
        target_vector_set: Optional ad-hoc target `PageVectorSet` payload.
        target_xml: Optional target XML used only to derive the target vector set.
        x: Source x coordinate in raw screen pixels.
        y: Source y coordinate in raw screen pixels.
    """

    source_page_id: str = ""
    source_vector_set: dict[str, Any] | None = None
    source_xml: str = ""
    target_page_id: str = ""
    target_vector_set: dict[str, Any] | None = None
    target_xml: str = ""
    x: float
    y: float
    model_config = ConfigDict(extra="forbid")


class ManualCaptureRequest(BaseModel):
    """One-shot manual screenshot request used by the desktop editor.

    Args:
        bridge_base_url: OOB host bridge root exposing `/observe`.
        bridge_token: Bearer token accepted by the OOB host bridge.
        adb_serial: Optional ADB device serial for fallback capture.
        skip_screenshot: Skip screenshot capture for faster XML-only mode.
    """

    bridge_base_url: str = f"http://127.0.0.1:{_DEFAULT_BRIDGE_PORT}"
    bridge_token: str = ""
    adb_serial: str = ""
    skip_screenshot: bool = False
    model_config = ConfigDict(extra="forbid")


class WorkbenchOobRequest(BaseModel):
    """One desktop-workbench OOB command request.

    Args:
        adb_serial: Target adb serial for the current OOB/provider bridge flow.
        timeout_seconds: Upper bound for one desktop-side script or adb command.
    """

    adb_serial: str = "emulator-5554"
    timeout_seconds: float = 180.0
    model_config = ConfigDict(extra="forbid")


class RunLogIngestRequest(BaseModel):
    """OOB / host 侧 canonical run 写回请求。

    Args:
        run_log: 调用方直接上传 canonical/materialized run payload。
            `goal`、`steps[*]`、`compile_result` 等正式语义都必须放在这里，
            provider 不再接受顶层旧 `goal/steps` 兼容字段。
        auto_import: 是否在写统一事件流后自动导入为本地 function asset。
        client_user_id: 可选的调用方用户标识；provider 只会持久化哈希标签。
        client_session_id: 可选的调用方会话标识；provider 只会持久化哈希标签。
    """

    run_log: dict[str, Any]
    auto_import: bool = False
    client_user_id: str | None = None
    client_session_id: str | None = None
    model_config = ConfigDict(extra="forbid")


class EnrichNodeRequest(BaseModel):
    """LLM 增强 Node 请求。"""

    node_id: str
    screenshot_base64: str | None = None
    llm_provider: str | None = None
    llm_model: str | None = None


class ExportNodeMemoryRequest(BaseModel):
    """导出单个 Node Memory 请求。"""

    node_id: str


class ExportMemoryBundleRequest(BaseModel):
    """导出 Memory Bundle 请求。"""

    include_xml: bool = True
    enrich: bool = False
    llm_provider: str | None = None
    llm_model: str | None = None


class ExportMemoryToDirRequest(BaseModel):
    """导出 Memory 到目录请求。"""

    output_dir: str | None = None
    include_xml: bool = True
    enrich: bool = False
    llm_provider: str | None = None
    llm_model: str | None = None


class ExportRAGMemoryRequest(BaseModel):
    """一键导出 RAG Memory 请求。"""

    output_dir: str | None = None
    output_format: str = "all"
    enrich: bool = True
    llm_provider: str | None = None
    llm_model: str | None = None
    create_embeddings: bool = False
    embedding_provider: str | None = None
    include_nodes: bool = True
    include_functions: bool = True
    include_apps: bool = True
    include_graph: bool = True


class UpdateFunctionRequest(BaseModel):
    """更新 Function 请求。

    支持更新函数的所有可编辑字段。未提供的字段保持不变。

    Args:
        description: 函数描述（最常用）。
        goal: 任务目标。
        preconditions: 前置条件列表。
        postconditions: 后置条件列表。
        enriched_goal: LLM 规范化后的目标。
    """

    description: str | None = None
    goal: str | None = None
    preconditions: list[str] | None = None
    postconditions: list[str] | None = None
    enriched_goal: str | None = None
    model_config = ConfigDict(extra="forbid")


# ============================================================================
# Response Models (供 SDK 和服务端共用)
# ============================================================================


class CompileResult(BaseModel):
    """Compile API 返回结果。

    Args:
        matched: 是否命中缓存。
        function_id: 命中的 function id。
        confidence: 匹配置信度 (0-1)。
        candidate_function_ids: 候选 function id 列表。
        decision: 决策结果 (hit/miss)。
        reason: 决策原因。
    """

    matched: bool = False
    function_id: str | None = None
    confidence: float = 0.0
    candidate_function_ids: list[str] = Field(default_factory=list)
    decision: str = "miss"
    reason: str | None = None

    @classmethod
    def from_api_response(cls, response: dict[str, Any]) -> "CompileResult":
        """从 API 响应 dict 创建 CompileResult。"""
        decision = str(response.get("decision") or "miss").strip()
        matched = decision == "hit" or bool(response.get("success"))
        return cls(
            matched=matched,
            function_id=str(response.get("function_id") or "").strip() or None,
            confidence=float(
                response.get("confidence") or response.get("score") or 0.0
            ),
            candidate_function_ids=[
                str(item or "").strip()
                for item in list(response.get("candidate_function_ids") or [])
                if str(item or "").strip()
            ],
            decision=decision,
            reason=str(response.get("reason") or "").strip() or None,
        )


class ExecuteResult(BaseModel):
    """Execute API 返回结果。

    Args:
        success: 执行是否成功。
        steps_executed: 执行的步数。
        actions_executed: 执行的动作数。
        error_code: 错误码。
        error_message: 错误信息。
        run_id: 运行 ID。
    """

    success: bool = False
    steps_executed: int = 0
    actions_executed: int = 0
    error_code: str | None = None
    error_message: str | None = None
    run_id: str | None = None

    @classmethod
    def from_api_response(cls, response: dict[str, Any]) -> "ExecuteResult":
        """从 API 响应 dict 创建 ExecuteResult。"""
        return cls(
            success=bool(response.get("success")),
            steps_executed=int(
                response.get("steps_executed") or response.get("step_count") or 0
            ),
            actions_executed=int(response.get("actions_executed") or 0),
            error_code=str(response.get("error_code") or "").strip() or None,
            error_message=str(response.get("error_message") or "").strip() or None,
            run_id=str(response.get("run_id") or "").strip() or None,
        )


class IngestResult(BaseModel):
    """Ingest API 返回结果。

    Args:
        success: 是否成功。
        run_id: 分配的 run id。
        step_count: 导入的步数。
        function_id: 自动导入结果里的最终 function id 便捷别名。
        auto_import: 原始 auto_import 结果，保留 provider 返回的 metadata。
        error_code: 错误码。
        error_message: 错误信息。
    """

    success: bool = False
    run_id: str | None = None
    step_count: int = 0
    function_id: str | None = None
    auto_import: dict[str, Any] | None = None
    error_code: str | None = None
    error_message: str | None = None

    @classmethod
    def from_api_response(cls, response: dict[str, Any]) -> "IngestResult":
        """从 API 响应 dict 创建 IngestResult。"""
        auto_import = (
            dict(response.get("auto_import") or {})
            if isinstance(response.get("auto_import"), dict)
            else None
        )
        return cls(
            success=bool(response.get("success", True)),
            run_id=str(response.get("run_id") or "").strip() or None,
            step_count=int(response.get("step_count") or 0),
            function_id=str(
                response.get("function_id")
                or (auto_import or {}).get("function_id")
                or ""
            ).strip()
            or None,
            auto_import=auto_import,
            error_code=str(response.get("error_code") or "").strip() or None,
            error_message=str(response.get("error_message") or "").strip() or None,
        )
