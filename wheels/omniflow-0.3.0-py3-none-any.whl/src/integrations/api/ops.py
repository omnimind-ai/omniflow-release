from __future__ import annotations

import asyncio
import base64
import os
from datetime import datetime, timezone
from pathlib import Path
import subprocess
from time import perf_counter
from typing import Any
from urllib.parse import urlparse

from fastapi import FastAPI
from src.foundation.paths import get_runtime_file

from .contracts import ManualCaptureRequest, WorkbenchOobRequest

_REPO_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_PROVIDER_PORT = int(os.getenv("OMNIFLOW_UTG_API_PORT", "9417"))
_DEFAULT_BRIDGE_PORT = int(os.getenv("OOB_UTG_BRIDGE_PORT", "8899"))
_DEFAULT_OOB_PACKAGE = "cn.com.omnimind.bot.debug"
_DEFAULT_OOB_ACCESSIBILITY_SERVICE = (
    f"{_DEFAULT_OOB_PACKAGE}/"
    "com.google.android.accessibility.selecttospeak.SelectToSpeakService"
)


def trim_command_output(text: str | None, *, max_chars: int = 12000) -> str:
    """Trim one command output for JSON/UI transport without losing the tail."""

    value = str(text or "")
    if len(value) <= max_chars:
        return value
    return f"...(truncated {len(value) - max_chars} chars)...\n{value[-max_chars:]}"


async def run_workbench_command(
    command: list[str],
    *,
    cwd: str | Path | None = None,
    timeout_seconds: float = 60.0,
) -> dict[str, Any]:
    """Run one whitelisted desktop workbench command and capture stable output."""

    normalized_command = [str(item) for item in list(command or []) if str(item)]
    if not normalized_command:
        return {
            "success": False,
            "error_code": "EMPTY_COMMAND",
            "error_message": "Workbench command is required.",
            "command": [],
        }

    try:
        completed = await asyncio.to_thread(
            subprocess.run,
            normalized_command,
            cwd=str(cwd or _REPO_ROOT),
            capture_output=True,
            text=True,
            timeout=max(1.0, float(timeout_seconds)),
            env=os.environ.copy(),
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "success": False,
            "error_code": "COMMAND_TIMEOUT",
            "error_message": (
                f"Workbench command timed out after {float(timeout_seconds):.1f}s."
            ),
            "command": normalized_command,
            "returncode": None,
            "stdout": trim_command_output(getattr(exc, "stdout", "")),
            "stderr": trim_command_output(getattr(exc, "stderr", "")),
        }
    except Exception as exc:
        return {
            "success": False,
            "error_code": "COMMAND_EXEC_FAILED",
            "error_message": str(exc),
            "command": normalized_command,
            "returncode": None,
            "stdout": "",
            "stderr": "",
        }

    return {
        "success": completed.returncode == 0,
        "command": normalized_command,
        "returncode": int(completed.returncode),
        "stdout": trim_command_output(completed.stdout),
        "stderr": trim_command_output(completed.stderr),
    }


def _get_version() -> str:
    """Get OmniFlow version from package metadata."""
    try:
        from importlib.metadata import version

        return version("omniflow")
    except Exception:
        return "0.3.0"  # fallback


def health(
    runtime,
    *,
    provider_id: str,
    provider_api_methods: list[str],
    host_callbacks: list[str],
    supported_bridge_actions: list[str],
    canonical_run_log_path: str,
) -> dict[str, Any]:
    """Return the minimal provider health payload."""

    payload: dict[str, Any] = {
        "success": True,
        "status": "ok",
        "provider": provider_id,
        "version": _get_version(),
        "provider_aliases": [provider_id],
        "provider_api_methods": list(provider_api_methods),
        "host_callbacks": list(host_callbacks),
        "supported_bridge_actions": list(supported_bridge_actions),
        "canonical_run_log_path": canonical_run_log_path,
    }
    if runtime is not None:
        payload["utg_store_path"] = getattr(runtime, "_filepath", None)
        # Add function/run_log counts for frontend display
        payload["function_count"] = len(getattr(runtime, "functions", []))
        payload["run_log_count"] = (
            len(list(runtime.iter_run_logs()))
            if hasattr(runtime, "iter_run_logs")
            else 0
        )
    return payload


async def port_probe(
    target: str,
    *,
    timeout_ms: int = 1200,
    provider_id: str,
) -> dict[str, Any]:
    """Probe whether one TCP port is reachable for the desktop editor."""

    normalized_target = str(target or "").strip()
    if not normalized_target:
        return {
            "success": False,
            "error_code": "INVALID_PORT_TARGET",
            "error_message": "Port target is required.",
        }
    parsed = urlparse(
        normalized_target
        if "://" in normalized_target
        else f"tcp://{normalized_target}"
    )
    host = str(parsed.hostname or "").strip()
    port = int(parsed.port or 0)
    if not host or port <= 0:
        return {
            "success": False,
            "error_code": "INVALID_PORT_TARGET",
            "error_message": f"Invalid port target: {normalized_target}",
            "target": normalized_target,
        }
    start = perf_counter()
    writer = None
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=max(0.2, float(timeout_ms) / 1000.0),
        )
        latency_ms = round((perf_counter() - start) * 1000.0, 1)
        return {
            "success": True,
            "target": normalized_target,
            "host": host,
            "port": port,
            "open": True,
            "latency_ms": latency_ms,
            "provider": provider_id,
        }
    except Exception as exc:
        latency_ms = round((perf_counter() - start) * 1000.0, 1)
        return {
            "success": True,
            "target": normalized_target,
            "host": host,
            "port": port,
            "open": False,
            "latency_ms": latency_ms,
            "error_message": str(exc),
            "provider": provider_id,
        }
    finally:
        if writer is not None:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass


async def check_oob_workbench_environment(
    runtime,
    *,
    adb_serial: str,
    timeout_seconds: float = 30.0,
    provider_id: str,
    provider_api_methods: list[str],
    host_callbacks: list[str],
    supported_bridge_actions: list[str],
    canonical_run_log_path: str,
) -> dict[str, Any]:
    """Collect one desktop workbench snapshot for the current OOB bridge chain."""

    normalized_serial = str(adb_serial or "").strip()
    if not normalized_serial:
        return {
            "success": False,
            "error_code": "INVALID_ADB_SERIAL",
            "error_message": "adb_serial is required.",
        }

    provider_health = health(
        runtime,
        provider_id=provider_id,
        provider_api_methods=provider_api_methods,
        host_callbacks=host_callbacks,
        supported_bridge_actions=supported_bridge_actions,
        canonical_run_log_path=canonical_run_log_path,
    )
    bridge_probe = await port_probe(
        f"127.0.0.1:{_DEFAULT_BRIDGE_PORT}",
        timeout_ms=1200,
        provider_id=provider_id,
    )
    adb_state = await run_workbench_command(
        ["adb", "-s", normalized_serial, "get-state"],
        cwd=_REPO_ROOT,
        timeout_seconds=min(float(timeout_seconds), 15.0),
    )
    adb_reverse = await run_workbench_command(
        ["adb", "-s", normalized_serial, "reverse", "--list"],
        cwd=_REPO_ROOT,
        timeout_seconds=min(float(timeout_seconds), 15.0),
    )
    adb_forward = await run_workbench_command(
        ["adb", "-s", normalized_serial, "forward", "--list"],
        cwd=_REPO_ROOT,
        timeout_seconds=min(float(timeout_seconds), 15.0),
    )
    app_pid = await run_workbench_command(
        ["adb", "-s", normalized_serial, "shell", "pidof", _DEFAULT_OOB_PACKAGE],
        cwd=_REPO_ROOT,
        timeout_seconds=min(float(timeout_seconds), 15.0),
    )
    accessibility_services = await run_workbench_command(
        [
            "adb",
            "-s",
            normalized_serial,
            "shell",
            "settings",
            "get",
            "secure",
            "enabled_accessibility_services",
        ],
        cwd=_REPO_ROOT,
        timeout_seconds=min(float(timeout_seconds), 15.0),
    )
    reverse_rule = f"tcp:{_DEFAULT_PROVIDER_PORT} tcp:{_DEFAULT_PROVIDER_PORT}"
    forward_rule = f"tcp:{_DEFAULT_BRIDGE_PORT} tcp:{_DEFAULT_BRIDGE_PORT}"
    reverse_bound = reverse_rule in str(adb_reverse.get("stdout") or "")
    forward_bound = forward_rule in str(adb_forward.get("stdout") or "")
    app_running = bool(str(app_pid.get("stdout") or "").strip()) and bool(
        app_pid.get("success")
    )
    accessibility_enabled = _DEFAULT_OOB_ACCESSIBILITY_SERVICE in str(
        accessibility_services.get("stdout") or ""
    )
    ready = (
        bool(provider_health.get("success"))
        and bool(bridge_probe.get("success") and bridge_probe.get("open"))
        and bool(adb_state.get("success"))
        and reverse_bound
        and forward_bound
        and app_running
        and accessibility_enabled
    )
    return {
        "success": True,
        "ready": ready,
        "adb_serial": normalized_serial,
        "expected_provider_port": _DEFAULT_PROVIDER_PORT,
        "expected_bridge_port": _DEFAULT_BRIDGE_PORT,
        "provider_health": provider_health,
        "bridge_probe": bridge_probe,
        "adb_state": adb_state,
        "adb_reverse": {
            **adb_reverse,
            "expected_rule": reverse_rule,
            "bound": reverse_bound,
        },
        "adb_forward": {
            **adb_forward,
            "expected_rule": forward_rule,
            "bound": forward_bound,
        },
        "oob_app": {
            **app_pid,
            "package_name": _DEFAULT_OOB_PACKAGE,
            "running": app_running,
        },
        "oob_accessibility": {
            **accessibility_services,
            "service_component": _DEFAULT_OOB_ACCESSIBILITY_SERVICE,
            "enabled": accessibility_enabled,
        },
    }


async def capture_manual_page(
    runtime,
    *,
    bridge_base_url: str,
    bridge_token: str,
    adb_serial: str = "",
    skip_screenshot: bool = False,
    provider_id: str,
) -> dict[str, Any]:
    """Capture one current page screenshot/XML snapshot from the OOB bridge."""

    xml_text = ""
    package_name = ""
    activity_name = ""
    raw_image = ""
    capture_method = "adb"
    bridge_available = False

    try:
        probe_result = await port_probe(
            bridge_base_url,
            timeout_ms=500,
            provider_id=provider_id,
        )
        bridge_available = bool(probe_result.get("open"))
    except Exception:
        bridge_available = False

    if bridge_available:
        try:
            import httpx

            normalized_base_url = str(bridge_base_url or "").rstrip("/")
            headers = (
                {"Authorization": f"Bearer {bridge_token}"}
                if str(bridge_token or "").strip()
                else {}
            )
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.post(
                    f"{normalized_base_url}/observe",
                    json={
                        "xml": True,
                        "screenshot": True,
                        "app_info": True,
                    },
                    headers=headers,
                )
            payload = response.json() if response.status_code < 400 else {}
            if not isinstance(payload, dict):
                payload = {}
            xml_text = str(payload.get("xml") or "").strip()
            package_name = str(payload.get("package_name") or "").strip()
            activity_name = str(payload.get("activity_name") or "").strip()
            raw_image = str(payload.get("image_base64") or "").strip()
            if xml_text:
                capture_method = "bridge"
        except Exception:
            pass

    if not xml_text:
        try:
            if not adb_serial:
                result = await asyncio.wait_for(
                    asyncio.to_thread(
                        subprocess.run,
                        ["adb", "devices"],
                        capture_output=True,
                        text=True,
                    ),
                    timeout=5.0,
                )
                lines = result.stdout.strip().split("\n")[1:]
                devices = [
                    line.split()[0]
                    for line in lines
                    if "device" in line and not line.startswith("*")
                ]
                if devices:
                    adb_serial = devices[0]

            if adb_serial:
                dump_result = await asyncio.wait_for(
                    asyncio.to_thread(
                        subprocess.run,
                        [
                            "adb",
                            "-s",
                            adb_serial,
                            "shell",
                            "uiautomator",
                            "dump",
                            "/sdcard/window_dump.xml",
                        ],
                        capture_output=True,
                        text=True,
                    ),
                    timeout=10.0,
                )
                if dump_result.returncode == 0:

                    async def read_xml() -> str:
                        result = await asyncio.wait_for(
                            asyncio.to_thread(
                                subprocess.run,
                                [
                                    "adb",
                                    "-s",
                                    adb_serial,
                                    "exec-out",
                                    "cat",
                                    "/sdcard/window_dump.xml",
                                ],
                                capture_output=True,
                                text=True,
                            ),
                            timeout=5.0,
                        )
                        return result.stdout.strip() if result.returncode == 0 else ""

                    async def capture_screenshot() -> str:
                        if skip_screenshot:
                            return ""
                        result = await asyncio.wait_for(
                            asyncio.to_thread(
                                subprocess.run,
                                [
                                    "adb",
                                    "-s",
                                    adb_serial,
                                    "exec-out",
                                    "screencap",
                                    "-p",
                                ],
                                capture_output=True,
                            ),
                            timeout=10.0,
                        )
                        if result.returncode == 0 and result.stdout:
                            import base64

                            return base64.b64encode(result.stdout).decode("utf-8")
                        return ""

                    if skip_screenshot:
                        xml_text = await read_xml()
                        raw_image = ""
                    else:
                        xml_text, raw_image = await asyncio.gather(
                            read_xml(), capture_screenshot()
                        )

                    import re

                    pkg_match = re.search(r'package="([^"]+)"', xml_text)
                    if pkg_match:
                        package_name = pkg_match.group(1)
        except Exception as adb_error:
            return {
                "success": False,
                "error": f"ADB capture failed: {adb_error}",
                "capture_method": "failed",
            }

    if not xml_text:
        return {
            "success": False,
            "error": "No XML captured from bridge or ADB",
            "capture_method": capture_method,
        }

    capture_id = (
        f"manual_capture_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}"
    )
    screenshot_path = ""
    screenshot_payload = str(raw_image or "").strip()
    if screenshot_payload:
        if screenshot_payload.startswith("data:image/") and "," in screenshot_payload:
            screenshot_payload = screenshot_payload.split(",", 1)[1]
        try:
            screenshot_bytes = base64.b64decode(screenshot_payload, validate=False)
        except Exception:
            screenshot_bytes = b""
        if screenshot_bytes:
            screenshot_file = get_runtime_file("captures", f"{capture_id}.png")
            screenshot_file.parent.mkdir(parents=True, exist_ok=True)
            screenshot_file.write_bytes(screenshot_bytes)
            screenshot_path = str(screenshot_file.resolve())
    image_data_url = ""
    if raw_image.startswith("data:image/"):
        image_data_url = raw_image
    elif raw_image:
        image_data_url = f"data:image/png;base64,{raw_image}"
    matched_node = (
        runtime.match_node(xml_text, package_name=package_name) if xml_text else None
    )
    return {
        "success": True,
        "capture_id": capture_id,
        "capture_method": capture_method,
        "utg_store_path": str(getattr(runtime, "_filepath", "") or ""),
        "package_name": package_name,
        "activity_name": activity_name,
        "matched_node_id": str(getattr(matched_node, "id", "") or ""),
        "matched_node_description": str(
            getattr(getattr(matched_node, "repr", None), "description", "") or ""
        )
        if matched_node is not None
        else "",
        "screenshot_path": screenshot_path,
        "image_data_url": image_data_url,
        "xml": xml_text,
    }


def register_ops_routes(
    app: FastAPI,
    *,
    runtime,
    provider_id: str,
    provider_api_methods: list[str],
    host_callbacks: list[str],
    supported_bridge_actions: list[str],
    canonical_run_log_path: str,
    health_fn,
    capture_manual_page_fn,
    run_workbench_command_fn,
    check_oob_workbench_environment_fn,
    reset_all_data_fn,
) -> None:
    """Register system and OOB workbench routes for the provider entrypoint."""

    @app.get("/health")
    async def health_route() -> dict[str, Any]:
        return health_fn(runtime)

    @app.post("/provider/reset")
    async def reset_provider_route() -> dict[str, Any]:
        """清空所有数据：run_logs + functions + shared_pages"""
        return await reset_all_data_fn(runtime)

    @app.post("/capture_manual")
    async def capture_manual_route(request: ManualCaptureRequest) -> dict[str, Any]:
        return await capture_manual_page_fn(
            runtime,
            bridge_base_url=request.bridge_base_url,
            bridge_token=request.bridge_token,
            adb_serial=request.adb_serial,
            skip_screenshot=request.skip_screenshot,
        )

    @app.post("/workbench/oob/check")
    async def workbench_oob_check_route(
        request: WorkbenchOobRequest,
    ) -> dict[str, Any]:
        return await check_oob_workbench_environment_fn(
            runtime,
            adb_serial=request.adb_serial,
            timeout_seconds=request.timeout_seconds,
        )

    @app.post("/workbench/oob/one_click")
    async def workbench_oob_one_click_route(
        request: WorkbenchOobRequest,
    ) -> dict[str, Any]:
        command_result = await run_workbench_command_fn(
            [
                "bash",
                str(_REPO_ROOT / "scripts" / "start_oob_one_click.sh"),
                str(request.adb_serial or "").strip(),
            ],
            cwd=_REPO_ROOT,
            timeout_seconds=max(float(request.timeout_seconds), 180.0),
        )
        environment = await check_oob_workbench_environment_fn(
            runtime,
            adb_serial=request.adb_serial,
            timeout_seconds=min(float(request.timeout_seconds), 30.0),
        )
        command_ok = bool(command_result.get("success"))
        return {
            "success": command_ok,
            "command_ok": command_ok,
            "ready": bool(environment.get("ready")),
            "action": "oob_one_click",
            "adb_serial": str(request.adb_serial or "").strip(),
            "command_result": command_result,
            "environment": environment,
        }
