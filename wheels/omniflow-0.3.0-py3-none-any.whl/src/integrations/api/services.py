from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse
from src.foundation.paths import get_runtime_root

from .contracts import (
    CompileRequest,
    DecomposeGoalRequest,
    DownloadCloudFunctionRequest,
    EnrichNodeRequest,
    ExecuteFunctionRequest,
    ExportMemoryBundleRequest,
    ExportMemoryToDirRequest,
    ExportNodeMemoryRequest,
    ExportRAGMemoryRequest,
    ImportFunctionBundleRequest,
    ImportRunLogRequest,
    MergeFunctionsPreviewRequest,
    MergeFunctionsSaveRequest,
    ReplayRunLogRequest,
    RunLogIngestRequest,
    SharedPageImportRequest,
    SharedPageMapCoordinatesRequest,
    SharedPageSearchRequest,
    UpdateFunctionRequest,
    UploadCloudFunctionRequest,
    VlmPreHookRequest,
    XmlCompareRequest,
    XmlMapCoordinatesRequest,
    XmlSearchRequest,
    resolve_api_language,
)

logger = logging.getLogger(__name__)


def register_service_routes(
    app: FastAPI,
    *,
    runtime,
    provider_id: str,
    bridge_client_cls,
    list_graph_apps_fn,
    get_app_graph_fn,
    list_nodes_fn,
    list_functions_fn,
    delete_function_fn,
    update_function_fn,
    merge_functions_preview_fn,
    merge_functions_save_fn,
    enrich_function_fn,
    split_function_fn,
    export_function_bundle_fn,
    import_function_bundle_fn,
    list_run_logs_fn,
    ingest_run_log_fn,
    import_run_log_fn,
    delete_run_log_fn,
    get_run_log_fn,
    get_run_log_timeline_payload_fn,
    get_multi_user_global_registry_fn,
    download_cloud_function_fn,
    upload_cloud_function_fn,
    list_shared_pages_fn,
    get_shared_page_fn,
    import_shared_page_fn,
    search_shared_pages_fn,
    map_shared_coordinates_fn,
    enrich_node_fn,
    export_node_memory_fn,
    export_memory_bundle_fn,
    export_memory_to_dir_fn,
    export_rag_memory_fn,
    compile_goal_fn,
    decompose_goal_fn,
    prepare_vlm_task_execution_fn,
    execute_function_fn,
    get_background_task_fn,
    list_background_tasks_fn,
    get_control_plane_rules_fn,
    get_control_plane_trace_fn,
) -> None:
    """Register provider data/function routes while keeping `utg_api` thin."""

    @app.get("/api/graph/shortest_path")
    async def graph_shortest_path_route(
        from_node: str = "",
        to_node: str = "",
        package_name: str = "",
    ) -> dict[str, Any]:
        del package_name
        from src.utg.core.graph_runtime import UTGGraphRuntime

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded"}
        if not from_node.strip() or not to_node.strip():
            return {"error": "Both from_node and to_node are required"}
        graph_runtime = UTGGraphRuntime.from_utg_graph(utg_graph)
        path = graph_runtime.shortest_path(from_node.strip(), to_node.strip())
        if path is None:
            return {"error": f"No path found from '{from_node}' to '{to_node}'"}
        return {
            "node_sequence": path.node_sequence,
            "functions": path.function_sequence,
            "total_cost": path.total_cost,
        }

    @app.get("/api/graph/export/dot", response_class=PlainTextResponse)
    async def graph_export_dot_route(package_name: str = "") -> str:
        del package_name
        from src.utg.core.graph_runtime import UTGGraphRuntime

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return "# No UTG graph loaded"
        graph_runtime = UTGGraphRuntime.from_utg_graph(utg_graph)
        return graph_runtime.export_dot()

    @app.get("/api/graph/export/mermaid", response_class=PlainTextResponse)
    async def graph_export_mermaid_route(package_name: str = "") -> str:
        del package_name
        from src.utg.core.graph_runtime import UTGGraphRuntime

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return "# No UTG graph loaded"
        graph_runtime = UTGGraphRuntime.from_utg_graph(utg_graph)
        return graph_runtime.export_mermaid()

    @app.get("/graphs/apps")
    async def graph_apps_route() -> dict[str, Any]:
        return list_graph_apps_fn(runtime)

    @app.get("/graphs/apps/{package_name}")
    async def app_graph_route(package_name: str) -> dict[str, Any]:
        return get_app_graph_fn(runtime, package_name=package_name)

    @app.get("/graphs/apps/{package_name}/nodes/{node_id}")
    async def app_graph_node_route(package_name: str, node_id: str) -> dict[str, Any]:
        normalized_package_name = str(package_name or "").strip()
        normalized_node_id = str(node_id or "").strip()
        if not normalized_package_name or not normalized_node_id:
            return {
                "success": False,
                "error_code": "INVALID_NODE_REFERENCE",
                "error_message": "package_name and node_id are required.",
                "package_name": normalized_package_name,
                "node_id": normalized_node_id,
                "provider": provider_id,
            }
        graph_payload = get_app_graph_fn(runtime, package_name=normalized_package_name)
        if graph_payload.get("success") is False:
            return graph_payload
        nodes = list(graph_payload.get("nodes") or [])
        edges = list(graph_payload.get("edges") or [])
        selected_node = next(
            (
                item
                for item in nodes
                if str(item.get("id") or "").strip() == normalized_node_id
            ),
            None,
        )
        if not isinstance(selected_node, dict):
            return {
                "success": False,
                "error_code": "NODE_NOT_FOUND",
                "error_message": (
                    f"node '{normalized_node_id}' not found in '{normalized_package_name}'."
                ),
                "package_name": normalized_package_name,
                "node_id": normalized_node_id,
                "provider": provider_id,
            }
        incoming_edges = [
            edge
            for edge in edges
            if str(edge.get("target") or "").strip() == normalized_node_id
        ]
        outgoing_edges = [
            edge
            for edge in edges
            if str(edge.get("source") or "").strip() == normalized_node_id
        ]
        return {
            "success": True,
            "package_name": normalized_package_name,
            "app_name": graph_payload.get("app_name"),
            "node_id": normalized_node_id,
            "node": selected_node,
            "incoming_edges": incoming_edges,
            "outgoing_edges": outgoing_edges,
            "provider": provider_id,
        }

    @app.get("/nodes")
    async def nodes_route() -> dict[str, Any]:
        return list_nodes_fn(runtime)

    @app.get("/functions")
    async def functions_route() -> dict[str, Any]:
        payload = list_functions_fn(runtime)
        return {
            **payload,
            "functions": list(payload.get("functions") or []),
        }

    @app.get("/functions/{function_id}")
    async def get_function_route(function_id: str) -> dict[str, Any]:
        normalized_function_id = str(function_id or "").strip()
        if not normalized_function_id:
            return {
                "success": False,
                "error_code": "INVALID_FUNCTION_ID",
                "error_message": "function_id is required.",
                "function_id": normalized_function_id,
                "provider": provider_id,
            }
        payload = list_functions_fn(runtime)
        functions = list(payload.get("functions") or [])
        selected_function = next(
            (
                item
                for item in functions
                if str(item.get("function_id") or "").strip() == normalized_function_id
            ),
            None,
        )
        if not isinstance(selected_function, dict):
            return {
                "success": False,
                "error_code": "FUNCTION_NOT_FOUND",
                "error_message": f"function '{normalized_function_id}' not found.",
                "function_id": normalized_function_id,
                "provider": provider_id,
            }
        return {
            "success": True,
            "function_id": normalized_function_id,
            "function": selected_function,
            "provider": provider_id,
        }

    @app.delete("/functions/{function_id}")
    async def delete_function_route(function_id: str) -> dict[str, Any]:
        return await delete_function_fn(runtime, function_id)

    @app.post("/functions/{function_id}/update")
    async def update_function_route(
        function_id: str,
        request: UpdateFunctionRequest,
    ) -> dict[str, Any]:
        return await update_function_fn(
            runtime,
            function_id=function_id,
            description=request.description,
            goal=request.goal,
            preconditions=request.preconditions,
            postconditions=request.postconditions,
            enriched_goal=request.enriched_goal,
        )

    @app.post("/functions/{function_id}/enrich")
    async def enrich_function_route(
        function_id: str,
        request: dict[str, Any] = {},
    ) -> dict[str, Any]:
        return await enrich_function_fn(
            runtime,
            function_id=function_id,
            llm_provider=request.get("llm_provider"),
            llm_model=request.get("llm_model"),
        )

    @app.post("/functions/{function_id}/split")
    async def split_function_route(
        function_id: str,
        request: dict[str, Any] = {},
    ) -> dict[str, Any]:
        return await split_function_fn(
            runtime,
            function_id=function_id,
            hint=request.get("hint"),
            llm_provider=request.get("llm_provider"),
            llm_model=request.get("llm_model"),
        )

    @app.post("/functions/merge_preview")
    async def merge_functions_preview_route(
        request: MergeFunctionsPreviewRequest,
    ) -> dict[str, Any]:
        return merge_functions_preview_fn(
            runtime,
            function_ids=request.function_ids,
            merge_mode=request.merge_mode,
            output_function_id=request.output_function_id,
            description=request.description,
            function_order=request.function_order,
        )

    @app.post("/functions/merge_save")
    async def merge_functions_save_route(
        request: MergeFunctionsSaveRequest,
    ) -> dict[str, Any]:
        return await merge_functions_save_fn(
            runtime,
            function_ids=request.function_ids,
            merge_mode=request.merge_mode,
            output_function_id=request.output_function_id,
            description=request.description,
            function_order=request.function_order,
        )

    @app.get("/functions/{function_id}/bundle")
    async def function_bundle_route(function_id: str) -> dict[str, Any]:
        return export_function_bundle_fn(runtime, function_id)

    @app.post("/functions/import_bundle")
    async def import_function_bundle_route(
        request: ImportFunctionBundleRequest,
    ) -> dict[str, Any]:
        payload = await import_function_bundle_fn(runtime, graph=request.graph)
        if isinstance(payload.get("function"), dict):
            return payload
        if isinstance(payload.get("path"), dict):
            return {
                **payload,
                "function": dict(payload.get("path") or {}),
            }
        return payload

    @app.get("/run_logs")
    async def run_logs_route(
        limit: int = 20,
        user_tag: str = "",
        session_tag: str = "",
    ) -> dict[str, Any]:
        return list_run_logs_fn(
            limit=limit,
            user_tag=user_tag,
            session_tag=session_tag,
        )

    @app.get("/run_logs/global_index")
    async def run_logs_global_index_route() -> dict[str, Any]:
        return get_multi_user_global_registry_fn()

    @app.post("/run_logs/ingest")
    async def ingest_run_log_route(
        request: RunLogIngestRequest,
    ) -> dict[str, Any]:
        return await ingest_run_log_fn(
            runtime,
            run_log=request.run_log,
            auto_import=request.auto_import,
            client_user_id=request.client_user_id,
            client_session_id=request.client_session_id,
        )

    @app.post("/run_logs/import")
    async def import_run_log_route(
        request: ImportRunLogRequest,
    ) -> dict[str, Any]:
        return await import_run_log_fn(
            runtime,
            run_id=request.run_id,
            auto_enrich=request.auto_enrich,
            dedup_threshold=request.dedup_threshold,
        )

    @app.post("/run_logs/replay")
    async def replay_run_log_route(
        http_request: Request,
        request: ReplayRunLogRequest,
        lang: str | None = None,
    ) -> dict[str, Any]:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        # persist=False: 只在内存中创建临时 function，不保存到文件
        import_result = await import_run_log_fn(
            runtime, run_id=request.run_id, persist=False
        )
        if not bool(import_result.get("success")):
            return import_result
        function_id = str(import_result.get("function_id") or "").strip()
        if not function_id:
            return {
                "success": False,
                "error_code": "IMPORT_RUN_LOG_MISSING_FUNCTION_ID",
                "error_message": (
                    "Imported run log did not produce one replayable function_id."
                ),
                "run_id": str(request.run_id or "").strip(),
                "import_result": import_result,
            }
        bridge = bridge_client_cls(
            bridge_base_url=request.bridge_base_url,
            bridge_token=request.bridge_token,
        )
        replay_result = await execute_function_fn(
            runtime,
            bridge.observe,
            bridge.act,
            function_id=function_id,
            arguments={},
            goal=str(import_result.get("goal") or "").strip()
            or f"replay_run_log:{str(request.run_id or '').strip()}",
            context={
                **dict(request.context or {}),
                "source": str(
                    dict(request.context or {}).get("source") or "oob_run_log_replay"
                ).strip()
                or "oob_run_log_replay",
                "replay_run_id": str(request.run_id or "").strip(),
            },
            skip_terminal_verify=bool(request.skip_terminal_verify),
            lang=resolved_lang,
        )
        replay_result.setdefault("run_id", str(request.run_id or "").strip())
        replay_result.setdefault("function_id", function_id)
        replay_result["replayed_function_id"] = function_id
        replay_result["import_result"] = import_result
        return replay_result

    @app.get("/run_logs/{run_id}")
    async def run_log_detail_route(
        http_request: Request,
        run_id: str,
        lang: str | None = None,
    ) -> dict[str, Any]:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return get_run_log_fn(run_id=run_id, lang=resolved_lang)

    @app.delete("/run_logs/{run_id}")
    async def delete_run_log_route(run_id: str) -> dict[str, Any]:
        return delete_run_log_fn(run_id=run_id)

    # =========================================================================
    # Background Tasks
    # =========================================================================
    @app.get("/tasks")
    async def list_tasks_route(
        task_type: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        tasks = list_background_tasks_fn(
            task_type=task_type, status=status, limit=limit
        )
        return {"success": True, "tasks": tasks, "count": len(tasks)}

    @app.get("/tasks/{task_id}")
    async def get_task_route(task_id: str) -> dict[str, Any]:
        task = get_background_task_fn(task_id)
        if task is None:
            return {
                "success": False,
                "error_code": "TASK_NOT_FOUND",
                "error_message": f"Task {task_id} not found",
            }
        return {"success": True, **task}

    @app.get("/run_logs/{run_id}/timeline_payload")
    async def run_log_timeline_payload_route(
        http_request: Request,
        run_id: str,
        lang: str | None = None,
    ) -> dict[str, Any]:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return get_run_log_timeline_payload_fn(run_id=run_id, lang=resolved_lang)

    # =========================================================================
    # Control Plane Management
    # =========================================================================

    @app.get("/control_plane/rules")
    async def control_plane_rules_route() -> dict[str, Any]:
        return get_control_plane_rules_fn(runtime)

    @app.get("/control_plane/trace/{run_id}")
    async def control_plane_trace_route(run_id: str) -> dict[str, Any]:
        return get_control_plane_trace_fn(run_id=run_id)

    @app.post("/functions/pull")
    async def pull_function_route(
        request: DownloadCloudFunctionRequest,
    ) -> dict[str, Any]:
        return await download_cloud_function_fn(
            runtime,
            cloud_base_url=request.cloud_base_url,
            function_id=request.function_id,
        )

    @app.post("/functions/push")
    async def push_function_route(
        request: UploadCloudFunctionRequest,
    ) -> dict[str, Any]:
        return await upload_cloud_function_fn(
            runtime,
            cloud_base_url=request.cloud_base_url,
            function_id=request.function_id,
        )

    @app.get("/shared_pages")
    async def shared_pages_route(package_name: str = "") -> dict[str, Any]:
        return list_shared_pages_fn(runtime, package_name=package_name)

    @app.get("/shared_pages/{page_id}")
    async def shared_page_detail_route(page_id: str) -> dict[str, Any]:
        return get_shared_page_fn(runtime, page_id=page_id)

    @app.post("/shared_pages/import")
    async def import_shared_page_route(
        request: SharedPageImportRequest,
    ) -> dict[str, Any]:
        return import_shared_page_fn(
            runtime,
            page_id=request.page_id,
            vector_set=request.vector_set,
            xml=request.xml,
            package_name=request.package_name,
            source_device=request.source_device,
            created_at=request.created_at,
            overwrite=request.overwrite,
        )

    @app.post("/shared_pages/search")
    async def search_shared_pages_route(
        request: SharedPageSearchRequest,
    ) -> dict[str, Any]:
        return search_shared_pages_fn(
            runtime,
            page_id=request.page_id,
            vector_set=request.vector_set,
            xml=request.xml,
            package_name=request.package_name,
            top_k=request.top_k,
            threshold=request.threshold,
        )

    @app.post("/shared_pages/map_coordinates")
    async def map_shared_coordinates_route(
        request: SharedPageMapCoordinatesRequest,
    ) -> dict[str, Any]:
        return map_shared_coordinates_fn(
            runtime,
            source_page_id=request.source_page_id,
            source_vector_set=request.source_vector_set,
            source_xml=request.source_xml,
            target_page_id=request.target_page_id,
            target_vector_set=request.target_vector_set,
            target_xml=request.target_xml,
            x=request.x,
            y=request.y,
        )

    @app.post("/enrich_node")
    async def enrich_node_route(request: EnrichNodeRequest) -> dict[str, Any]:
        return await enrich_node_fn(
            runtime,
            node_id=request.node_id,
            screenshot_base64=request.screenshot_base64,
            llm_provider=request.llm_provider,
            llm_model=request.llm_model,
        )

    @app.post("/export_node_memory")
    async def export_node_memory_route(
        request: ExportNodeMemoryRequest,
    ) -> dict[str, Any]:
        return export_node_memory_fn(runtime, node_id=request.node_id)

    @app.post("/export_memory_bundle")
    async def export_memory_bundle_route(
        request: ExportMemoryBundleRequest,
    ) -> dict[str, Any]:
        return await export_memory_bundle_fn(
            runtime,
            include_xml=request.include_xml,
            enrich=request.enrich,
            llm_provider=request.llm_provider,
            llm_model=request.llm_model,
        )

    @app.post("/export_memory_to_dir")
    async def export_memory_to_dir_route(
        request: ExportMemoryToDirRequest,
    ) -> dict[str, Any]:
        return await export_memory_to_dir_fn(
            runtime,
            output_dir=request.output_dir,
            include_xml=request.include_xml,
            enrich=request.enrich,
            llm_provider=request.llm_provider,
            llm_model=request.llm_model,
        )

    @app.post("/export_rag_memory")
    async def export_rag_memory_route(
        request: ExportRAGMemoryRequest,
    ) -> dict[str, Any]:
        return await export_rag_memory_fn(
            runtime,
            output_dir=request.output_dir,
            output_format=request.output_format,
            enrich=request.enrich,
            llm_provider=request.llm_provider,
            llm_model=request.llm_model,
            create_embeddings=request.create_embeddings,
            embedding_provider=request.embedding_provider,
            include_nodes=request.include_nodes,
            include_functions=request.include_functions,
            include_apps=request.include_apps,
            include_graph=request.include_graph,
        )

    @app.post("/compile")
    async def compile_route(request: CompileRequest) -> dict[str, Any]:
        return compile_goal_fn(
            runtime,
            request.goal,
            context=request.context.to_compile_context() if request.context else None,
            match_scope=request.match_scope,
        )

    @app.post("/compile/decompose")
    async def decompose_goal_route(request: DecomposeGoalRequest) -> dict[str, Any]:
        return await decompose_goal_fn(
            runtime,
            goal=request.goal,
            llm_provider=request.llm_provider,
            llm_model=request.llm_model,
            max_key_functions=request.max_key_functions,
        )

    @app.post("/vlm/pre_hook")
    async def vlm_pre_hook_route(
        http_request: Request,
        request: VlmPreHookRequest,
        lang: str | None = None,
    ) -> dict[str, Any]:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        return prepare_vlm_task_execution_fn(
            runtime,
            request.goal,
            current_package_name=request.current_package_name,
            fallback_allowed=request.fallback_allowed,
            lang=resolved_lang,
        )

    @app.post("/functions/execute")
    async def execute_function_route(
        http_request: Request,
        request: ExecuteFunctionRequest,
        lang: str | None = None,
    ) -> dict[str, Any]:
        resolved_lang = resolve_api_language(
            lang=lang,
            accept_language=http_request.headers.get("accept-language"),
        )
        bridge = bridge_client_cls(
            bridge_base_url=request.bridge_base_url,
            bridge_token=request.bridge_token,
        )
        # Convert retry_context Pydantic model to dict if present
        retry_ctx = None
        if request.retry_context is not None:
            retry_ctx = {
                "run_id": request.retry_context.run_id,
                "resume_from_step": request.retry_context.resume_from_step,
                "function_id": request.retry_context.function_id,
            }
        return await execute_function_fn(
            runtime,
            bridge.observe,
            bridge.act,
            function_id=request.function_id,
            arguments=request.arguments,
            goal=request.goal,
            context=request.context,
            skip_terminal_verify=request.skip_terminal_verify,
            lang=resolved_lang,
            retry_context=retry_ctx,
        )

    @app.post("/api/xml/search")
    async def xml_search_route(request: XmlSearchRequest) -> dict[str, Any]:
        from src.utg.assets.embedding.xml_api import xml_similarity

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded", "results": []}

        source_xml = str(request.xml or "").strip()
        if not source_xml:
            return {"error": "No XML provided", "results": []}

        results = []
        nodes = getattr(utg_graph, "nodes", []) or []
        for node in nodes:
            node_id = (
                str(node.get("id") or "").strip()
                if isinstance(node, dict)
                else str(getattr(node, "id", "") or "").strip()
            )
            if not node_id:
                continue
            if hasattr(node, "repr"):
                node_repr = node.repr
                node_xmls = getattr(node_repr, "xmls", []) or []
                node_images = getattr(node_repr, "images", []) or []
                package_name = getattr(node_repr, "packageName", "") or ""
            elif isinstance(node, dict):
                node_repr = node.get("repr", {})
                node_xmls = (
                    node_repr.get("xmls", []) if isinstance(node_repr, dict) else []
                )
                node_images = (
                    node_repr.get("images", []) if isinstance(node_repr, dict) else []
                )
                package_name = (
                    node_repr.get("packageName", "")
                    if isinstance(node_repr, dict)
                    else ""
                )
            else:
                continue
            if not node_xmls:
                continue

            max_sim = 0.0
            best_xml_index = 0
            for idx, stored_xml in enumerate(node_xmls):
                try:
                    sim = xml_similarity(source_xml, str(stored_xml or ""))
                    if sim > max_sim:
                        max_sim = sim
                        best_xml_index = idx
                except Exception:
                    continue
            if max_sim > (request.threshold or 0.3):
                has_screenshot = bool(
                    node_images
                    and best_xml_index < len(node_images)
                    and node_images[best_xml_index]
                )
                results.append(
                    {
                        "node_id": node_id,
                        "package_name": package_name,
                        "similarity": round(max_sim, 4),
                        "xml_count": len(node_xmls),
                        "has_screenshot": has_screenshot,
                    }
                )

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return {"results": results[: request.top_k]}

    @app.post("/api/xml/compare")
    async def xml_compare_route_api(request: XmlCompareRequest) -> dict[str, Any]:
        from src.utg.assets.embedding.element_match import UTGMatcher
        from src.utg.assets.embedding.xml_api import xml_similarity

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded"}

        source_xml = str(request.source_xml or "").strip()
        target_node_id = str(request.target_node_id or "").strip()
        target_xml = str(request.target_xml or "").strip()
        if not source_xml or (not target_node_id and not target_xml):
            return {"error": "Missing source_xml and target selector"}

        if target_node_id:
            nodes = getattr(utg_graph, "nodes", []) or []
            target_node = None
            for node in nodes:
                nid = (
                    str(node.get("id") or "").strip()
                    if isinstance(node, dict)
                    else str(getattr(node, "id", "") or "").strip()
                )
                if nid == target_node_id:
                    target_node = node
                    break
            if target_node is None:
                return {"error": f"Node '{target_node_id}' not found"}

            if hasattr(target_node, "repr"):
                target_xmls = getattr(target_node.repr, "xmls", []) or []
            elif isinstance(target_node, dict):
                target_repr = target_node.get("repr", {})
                target_xmls = (
                    target_repr.get("xmls", []) if isinstance(target_repr, dict) else []
                )
            else:
                target_xmls = []
            if not target_xmls:
                return {"error": "Target node has no XMLs"}
            target_xml = str(target_xmls[0] or "")

        overall_sim = xml_similarity(source_xml, target_xml)

        anchors = []
        debug_info = {}
        try:
            matcher = UTGMatcher(source=source_xml, target=target_xml)
            matcher._get_anchors(max_anchor_count=10)
            anchor_debug = getattr(matcher, "_last_anchor_debug", {})
            for pair_info in anchor_debug.get("selected_pairs", []):
                source_element = pair_info.get("source_element", {})
                target_element = pair_info.get("target_element", {})
                anchors.append(
                    {
                        "source_element_id": source_element.get("id", ""),
                        "source_label": source_element.get("text")
                        or source_element.get("content_desc")
                        or "",
                        "source_class": source_element.get("class", ""),
                        "target_element_id": target_element.get("id", ""),
                        "target_label": target_element.get("text")
                        or target_element.get("content_desc")
                        or "",
                        "target_class": target_element.get("class", ""),
                        "similarity": pair_info.get("similarity", 0),
                    }
                )
            debug_info = {
                "total_source_elements": len(
                    anchor_debug.get("all_source_best_matches", [])
                ),
                "selected_anchor_count": len(anchors),
            }
        except Exception as exc:
            debug_info["error"] = str(exc)

        return {
            "similarity": round(overall_sim, 4),
            "anchors": anchors,
            "target_node_id": target_node_id or None,
            "target_mode": "utg_candidate" if target_node_id else "manual_target",
            "debug": debug_info,
        }

    @app.post("/api/xml/map_coordinates")
    async def xml_map_coordinates_route(
        request: XmlMapCoordinatesRequest,
    ) -> dict[str, Any]:
        from src.utg.assets.embedding.element_match import match_element

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded", "mapped": False}

        source_xml = str(request.source_xml or "").strip()
        target_node_id = str(request.target_node_id or "").strip()
        target_xml = str(request.target_xml or "").strip()
        if not source_xml or (not target_node_id and not target_xml):
            return {
                "error": "Missing source_xml and target selector",
                "mapped": False,
            }

        if target_node_id:
            nodes = getattr(utg_graph, "nodes", []) or []
            target_node = None
            for node in nodes:
                nid = (
                    str(node.get("id") or "").strip()
                    if isinstance(node, dict)
                    else str(getattr(node, "id", "") or "").strip()
                )
                if nid == target_node_id:
                    target_node = node
                    break
            if target_node is None:
                return {"error": f"Node '{target_node_id}' not found", "mapped": False}

            if hasattr(target_node, "repr"):
                target_xmls = getattr(target_node.repr, "xmls", []) or []
            elif isinstance(target_node, dict):
                target_repr = target_node.get("repr", {})
                target_xmls = (
                    target_repr.get("xmls", []) if isinstance(target_repr, dict) else []
                )
            else:
                target_xmls = []
            if not target_xmls:
                return {"error": "Target node has no XMLs", "mapped": False}
            target_xml = str(target_xmls[0] or "")

        result = match_element(
            source_xml,
            target_xml,
            request.x,
            request.y,
            allow_scaled_fallback=True,
        )
        result["source_x"] = request.x
        result["source_y"] = request.y
        result["target_node_id"] = target_node_id or None
        result["target_mode"] = "utg_candidate" if target_node_id else "manual_target"
        return result

    @app.get("/api/xml/node_screenshot/{node_id}")
    async def node_screenshot_route(node_id: str, xml_index: int = 0) -> dict[str, Any]:
        import base64
        from pathlib import Path

        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded", "has_image": False}

        nodes = getattr(utg_graph, "nodes", []) or []
        target_node = None
        for node in nodes:
            nid = (
                str(node.get("id") or "").strip()
                if isinstance(node, dict)
                else str(getattr(node, "id", "") or "").strip()
            )
            if nid == node_id:
                target_node = node
                break
        if target_node is None:
            return {"error": f"Node '{node_id}' not found", "has_image": False}

        if hasattr(target_node, "repr"):
            node_repr = target_node.repr
            images = getattr(node_repr, "images", []) or []
            xml_refs = getattr(node_repr, "xmlRefs", []) or []
        elif isinstance(target_node, dict):
            node_repr = target_node.get("repr", {})
            images = node_repr.get("images", []) if isinstance(node_repr, dict) else []
            xml_refs = (
                node_repr.get("xmlRefs", []) if isinstance(node_repr, dict) else []
            )
        else:
            images = []
            xml_refs = []

        if not images or xml_index >= len(images):
            return {
                "has_image": False,
                "xml_ref": xml_refs[xml_index] if xml_index < len(xml_refs) else "",
                "total_images": len(images),
            }

        image_path_or_data = str(images[xml_index] or "")
        if image_path_or_data.startswith("data:image/"):
            return {
                "has_image": True,
                "image": image_path_or_data,
                "image_path": "",
                "xml_ref": xml_refs[xml_index] if xml_index < len(xml_refs) else "",
                "total_images": len(images),
            }

        runtime_dir = get_runtime_root()
        image_file = runtime_dir / image_path_or_data
        if not image_file.exists():
            image_file = Path(image_path_or_data)

        if image_file.exists() and image_file.is_file():
            try:
                image_bytes = image_file.read_bytes()
                ext = image_file.suffix.lower()
                mime_type = {
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".gif": "image/gif",
                    ".webp": "image/webp",
                }.get(ext, "image/png")
                b64_data = base64.b64encode(image_bytes).decode("utf-8")
                return {
                    "has_image": True,
                    "image": f"data:{mime_type};base64,{b64_data}",
                    "image_path": str(image_path_or_data),
                    "xml_ref": xml_refs[xml_index] if xml_index < len(xml_refs) else "",
                    "total_images": len(images),
                }
            except Exception as exc:
                return {
                    "has_image": False,
                    "error": f"Failed to read image: {exc}",
                    "image_path": str(image_path_or_data),
                    "xml_ref": xml_refs[xml_index] if xml_index < len(xml_refs) else "",
                    "total_images": len(images),
                }

        return {
            "has_image": False,
            "error": f"Image file not found: {image_path_or_data}",
            "image_path": str(image_path_or_data),
            "xml_ref": xml_refs[xml_index] if xml_index < len(xml_refs) else "",
            "total_images": len(images),
        }

    @app.get("/api/merge/stats")
    async def merge_stats_route() -> dict[str, Any]:
        utg_graph = getattr(runtime, "_utg", None)
        if utg_graph is None:
            return {"error": "No UTG graph loaded"}

        nodes = getattr(utg_graph, "nodes", []) or []
        functions = getattr(utg_graph, "functions", {}) or {}
        app_info = getattr(utg_graph, "appInfo", []) or []

        total_nodes = len(nodes)
        total_functions = len(functions)
        total_apps = len(app_info)

        xml_counts = []
        for node in nodes:
            if hasattr(node, "repr"):
                xmls = getattr(node.repr, "xmls", []) or []
            elif isinstance(node, dict):
                node_repr = node.get("repr", {})
                xmls = node_repr.get("xmls", []) if isinstance(node_repr, dict) else []
            else:
                xmls = []
            xml_counts.append(len(xmls))

        multi_xml_nodes = sum(1 for count in xml_counts if count > 1)
        avg_xmls_per_node = sum(xml_counts) / len(xml_counts) if xml_counts else 0

        return {
            "total_nodes": total_nodes,
            "total_functions": total_functions,
            "total_apps": total_apps,
            "multi_xml_nodes": multi_xml_nodes,
            "avg_xmls_per_node": round(avg_xmls_per_node, 2),
            "apps": [
                {
                    "name": item.get("appName")
                    if isinstance(item, dict)
                    else getattr(item, "appName", ""),
                    "package": item.get("packageName")
                    if isinstance(item, dict)
                    else getattr(item, "packageName", ""),
                }
                for item in app_info
            ],
        }
